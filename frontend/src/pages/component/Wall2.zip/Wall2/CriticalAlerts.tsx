// import React, { useEffect, useState } from 'react';
// import { Box, Card, Grid } from '@mui/material';
// import { ResponsiveContainer } from 'recharts';
// import { ChevronLeft, ChevronRight } from 'lucide-react';
// import Charts from './Charts';
// import LineGraph from './LineGraph';
// import Stackbar from './Stackbar';
// import RadientChart from './RadientChart';
// // import AlertsList from './Alerts';
// import PerformanceBarchart from './PerformanceBarchart';
// import Indiamap from './Indiamap';
// import PageChart from './PageChart';
// // import DrilldownChart from '../home/DrilldownChart';
// // import AlertsList from './AlertsList';
// import Alerts from './Alerts';
// import SalesPerformanceChart from './PerformanceBarchart';
// import AmChartsStackedBarChart from '../RetailTerminalHome/AmChartsStackedBarChart';

// interface ChartData {
//   ACTUAL_TMT_SALES: { [key: string]: number };
//   TARGET_TMT_SALES: { [key: string]: number };
//   fy_month: { [key: string]: string };
//   month_name: { [key: string]: string };
// }

// const CriticalAlerts: React.FC = () => { 
//   const [currentSlide, setCurrentSlide] = useState<number>(0);
//   const [selectedSection, setSelectedSection] = useState<string>('Retail');
//   const [chartData, setChartData] = useState<ChartData | null>(null);

//   const [loading, setLoading] = useState<boolean>(true);


//   const retailCharts = [
//     <Charts  />,
//     <LineGraph />,
//     <Stackbar  />,
//     <RadientChart />
//   ];

//   const sodCharts = [
//     // <DrilldownChart key="drilldown" />,
//     <AmChartsStackedBarChart
//       bu="TAS"
//       alert_section="TAS"
//       alert_status="Open"
//       title="TAS Section Alerts"
//     />,
//     <AmChartsStackedBarChart
//       bu="TAS"
//       alert_section="VA"
//       alert_status="Open"
//       title="VA Section Alerts"
//     />,
//     <AmChartsStackedBarChart
//       bu="TAS"
//       alert_section="VTS"
//       alert_status="Open"
//       title="VTS Section Alerts"
//     />,
//   ];

//   const chartSections = [
//     { name: 'Retail', color: '#4ADE80', charts: retailCharts },
//     { name: 'SOD', color: '#60A5FA', charts: sodCharts },
//     { name: 'LPG', color: '#F472B6', charts: sodCharts },
//     {name:'Sales', color:'#', charts: sodCharts },
//     {name:'DryOut', color:'#', charts: sodCharts },
//     {name:'CDCEMS', color:'#', charts: sodCharts }
//   ];

//   const getCurrentCharts = () => {
//     const section = chartSections.find(s => s.name === selectedSection);
//     return section ? section.charts : [];
//   };

//   const nextSlide = () => {
//     setCurrentSlide(prev => (prev + 1) % Math.ceil(getCurrentCharts().length / 2));
//   };

//   const prevSlide = () => {
//     setCurrentSlide(prev => (prev - 1 + Math.ceil(getCurrentCharts().length / 2)) % Math.ceil(getCurrentCharts().length / 2));
//   };

//   const handleSectionChange = (sectionName: string) => {
//     setSelectedSection(sectionName);
//     setCurrentSlide(0);
//   };

//   const handleChartClick = (index: number) => {
//     // Add navigation logic here
//     console.log('Chart clicked:', index);
//   };

//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const response = await fetch('/api/charts/generate_vis_data', {
//           method: 'POST',
//           headers: {
//             'Content-Type': 'application/json',
//           },
//           body: JSON.stringify({
//             filters: [],
//             action: 'sales_performance',
//             drill_state: '',
//           }),
//         });
//         const result = await response.json();
//         if (result.status && result.data) {
//           setChartData(result.data);
//         }
//       } catch (error) {
//         console.error('Error fetching chart data:', error);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchData();
//   }, []);

//   const handleDrillDown = async (params: any) => {
//     try {
//       const response = await fetch('/api/charts/generate_vis_data', {
//         method: 'POST',
//         headers: {
//           'Content-Type': 'application/json',
//         },
//         body: JSON.stringify(params),
//       });
//       return response.json();
//     } catch (error) {
//       console.error('Drill-down error:', error);
//       return [];
//     }
//   };

//   return (
//     <Box sx={{
//       flexGrow: 1,
//       p: { xs: 1, sm: 2 },
//       bgcolor: '#1a1a2e',
//       maxWidth: '100%',
//       overflowX: 'hidden',
//       minHeight: '100vh'
//     }}>
//       <Grid container spacing={{ xs: 1, sm: 2 }} sx={{ mb: { xs: 1, sm: 2 } }}>
//         <Grid item xs={12} md={8}>
//           <Grid container direction="column" spacing={2}>
//             <Grid item>
//             <Card
//                 sx={{
//                   boxShadow: 'none',
//                   border: '1px solid rgba(255,255,255,0.1)',
//                   height: '100%',
//                   minHeight: 300
//                 }}
//               >
//                 {/* Remove ResponsiveContainer since amCharts handles responsiveness internally */}
//                 {chartData && (
//                   <SalesPerformanceChart 
//                     data={chartData} 
//                     onDrillDown={handleDrillDown}
//                   />
//                 )}
//               </Card>
//             </Grid>
//             <Grid item>
//               <PageChart />
//             </Grid>
//           </Grid>
//         </Grid>

//         <Grid item xs={12} md={4}>
//           <Card sx={{
//             bgcolor: '#1a1a2e',
//             boxShadow: 'none',
//             border: '1px solid rgba(255,255,255,0.1)',
//             height: '100%',
//             minHeight: 300
//           }}>
//             <ResponsiveContainer width="100%">
//               <Indiamap />
//             </ResponsiveContainer>
//           </Card>
//         </Grid>
//       </Grid>

//       <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4, mb: 2 }}>
//         <ChevronLeft 
//           color="white" 
//           onClick={prevSlide}
//           style={{ cursor: 'pointer' }}
//         />
//         {chartSections.map((section) => (
//           <a
//             key={section.name}
//             href="#"
//             onClick={(e) => {
//               e.preventDefault();
//               handleSectionChange(section.name);
//             }}
//             style={{
//               textDecoration: 'none',
//               color: selectedSection === section.name ? section.color : 'white',
//               fontSize: "18px",
//               fontWeight: selectedSection === section.name ? 'bold' : 'normal',
//               transition: 'all 0.3s ease',
//             }}
//             onMouseOver={(e) => {
//               e.currentTarget.style.color = section.color;
//               e.currentTarget.style.transform = 'scale(1.1)';
//             }}
//             onMouseOut={(e) => {
//               e.currentTarget.style.color = selectedSection === section.name ? section.color : 'white';
//               e.currentTarget.style.transform = 'scale(1)';
//             }}
//           >
//             {section.name}
//           </a>
//         ))}
//         <ChevronRight 
//           color="white" 
//           onClick={nextSlide}
//           style={{ cursor: 'pointer' }}
//         />
//       </Box>

//       <Grid container spacing={{ xs: 1, sm: 1 }}>
//         <Grid item xs={12} md={4}>
//           <Alerts/>
//         </Grid>

//         {getCurrentCharts()
//           .map((chart, index) => (
//             <Grid item xs={12} md={4} key={`chart-${index}`}>
//               <Box 
//                 component="a" 
//                 href="#"
//                 onClick={(e) => {
//                   e.preventDefault();
//                   handleChartClick(index);
//                 }}
//                 sx={{
//                   display: 'flex',
//                   flexDirection: 'column',
//                   gap: { xs: 1, sm: 2 },
//                   height: "850px",
//                   textDecoration: 'none'
//                 }}
//               >
//                 <Card sx={{
//                   bgcolor: '#1a1a2e',
//                   boxShadow: 'none',
//                   border: '1px solid rgba(255,255,255,0.1)',
//                   flex: 1,
//                   '&:hover': {
//                     border: `1px solid ${chartSections.find(s => s.name === selectedSection)?.color}`
//                   }
//                 }}>
//                   <ResponsiveContainer width="100%" height={500}>
//                     {chart}
//                   </ResponsiveContainer>
//                 </Card>
  
//               </Box>
//             </Grid>
//           ))}
//       </Grid>
//     </Box>
//   );
// };

// export default CriticalAlerts;




import React, { useEffect, useState, ReactElement } from 'react';
import { Box, Card, Grid } from '@mui/material';
import { ResponsiveContainer } from 'recharts';
import Charts from './Charts';
import LineGraph from './LineGraph';
import SalesPerformanceChart from './PerformanceBarchart';
import Indiamap from './Indiamap';
import PageChart from './PageChart';
import Alerts from './Alerts';
import AmChartsStackedBarChart from '../RetailTerminalHome/AmChartsStackedBarChart';
import RejectionChart from '../RetailTerminalHome/LPGRejectionChart';
import CombinedRateChart from '../RetailTerminalHome/LPGCombinedBarChart';

interface ChartData {
  ACTUAL_TMT_SALES: { [key: string]: number };
  TARGET_TMT_SALES: { [key: string]: number };
  fy_month: { [key: string]: string };
  month_name: { [key: string]: string };
}

interface ChartSection {
  name: string;
  color: string;
  charts: ReactElement[];
  gridColumns: number;
  fullWidth?: boolean; // New property to control chart width

}

const CriticalAlerts: React.FC = () => {
  const [selectedSection, setSelectedSection] = useState<string>('Retail');
  const [chartData, setChartData] = useState<ChartData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  // Retail charts configuration - 4 charts in 2x2 grid
  const retailCharts: ReactElement[] = [
    <Charts key="retail-1" />,
    <LineGraph key="retail-2" />,
    <Charts key="retail-3" />,
    <LineGraph key="retail-4" />
  ];

  // SOD charts configuration - 4 charts in 2x2 grid
  const sodCharts: ReactElement[] = [
    <AmChartsStackedBarChart
      key="sod-1"
      bu="TAS"
      alert_section="TAS"
      alert_status="Open"
      title="TAS Alerts"
    />,
    <AmChartsStackedBarChart
      key="sod-2"
      bu="TAS"
      alert_section="VA"
      alert_status="Open"
      title="VA Alerts"
    />,
    <AmChartsStackedBarChart
      key="sod-3"
      bu="TAS"
      alert_section="VTS"
      alert_status="Open"
      title="VTS Alerts"
    />,
    <AmChartsStackedBarChart
      key="sod-4"
      bu="TAS"
      alert_section="General"
      alert_status="Open"
      title="General Alerts"
    />
  ];
  const lpgCharts: ReactElement[] = [
    <CombinedRateChart key="lpg-1" />,
    <RejectionChart key="lpg-2" />
  ];

  const chartSections: ChartSection[] = [
    { name: 'Retail', color: '#4ADE80', charts: retailCharts, gridColumns: 2 },
    { name: 'SOD', color: '#60A5FA', charts: sodCharts, gridColumns: 2 },
    { name: 'LPG', color: '#F472B6', charts: lpgCharts, gridColumns: 2, fullWidth: true }, // Modified for full-width vertical layout
    { name: 'Sales', color: '#FCD34D', charts: sodCharts, gridColumns: 2 },
    { name: 'DryOut', color: '#F87171', charts: sodCharts, gridColumns: 3 },
    { name: 'CDCEMS', color: '#818CF8', charts: sodCharts, gridColumns: 2 }
  ];

  const handleSectionChange = (sectionName: string) => {
    setSelectedSection(sectionName);
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('/api/charts/generate_vis_data', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            filters: [],
            action: 'sales_performance',
            drill_state: '',
          }),
        });
        const result = await response.json();
        if (result.status && result.data) {
          setChartData(result.data);
        }
      } catch (error) {
        console.error('Error fetching chart data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleDrillDown = async (params: any) => {
    try {
      const response = await fetch('/api/charts/generate_vis_data', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(params),
      });
      return response.json();
    } catch (error) {
      console.error('Drill-down error:', error);
      return [];
    }
  };

  return (
    <Box sx={{
      flexGrow: 1,
      p: { xs: 1, sm: 2 },
      bgcolor: '#1a1a2e',
      maxWidth: '100%',
      overflowX: 'hidden',
      minHeight: '100vh'
    }}>
      {/* Top Section */}
      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid item xs={12} md={8}>
          <Card sx={{
            boxShadow: 'none',
            border: '1px solid rgba(255,255,255,0.1)',
            height: '100%',
            minHeight: 300,
            bgcolor: '#1a1a2e'
          }}>
            {chartData && (
              <SalesPerformanceChart/>
            )}
          </Card>
        </Grid>

        <Grid item xs={12} md={4}>
          <Card sx={{
            bgcolor: '#1a1a2e',
            boxShadow: 'none',
            border: '1px solid rgba(255,255,255,0.1)',
            height: '100%',
            minHeight: 300
          }}>
            <ResponsiveContainer width="100%">
              <Indiamap />
            </ResponsiveContainer>
          </Card>
        </Grid>

        <Grid item xs={12}>
          <Card sx={{
            bgcolor: '#1a1a2e',
            boxShadow: 'none',
            border: '1px solid rgba(255,255,255,0.1)'
          }}>
            <PageChart />
          </Card>
        </Grid>
      </Grid>

      {/* Main Content Area */}
      <Grid container spacing={2}>
        {/* Left Side - Static Alerts Section */}
        <Grid item xs={12} md={3}>
          <Card sx={{
            bgcolor: '#1a1a2e',
            boxShadow: 'none',
            border: '1px solid rgba(255,255,255,0.1)',
            height: '100%'
          }}>
            <Alerts />
          </Card>
        </Grid>

        {/* Right Side - Tabbed Content */}
        <Grid item xs={12} md={9}>
          {/* Tabs Navigation */}
          <Box sx={{ 
            borderBottom: 1, 
            borderColor: 'rgba(255,255,255,0.1)', 
            mb: 3
          }}>
            <Box sx={{ 
              display: 'flex', 
              width: '100%',
              overflowX: 'auto',
              scrollbarWidth: 'none',
              '&::-webkit-scrollbar': { display: 'none' }
            }}>
              {chartSections.map((section) => (
                <Box
                  key={section.name}
                  onClick={() => handleSectionChange(section.name)}
                  sx={{
                    px: 4,
                    py: 2,
                    cursor: 'pointer',
                    color: selectedSection === section.name ? section.color : 'white',
                    borderBottom: `2px solid ${selectedSection === section.name ? section.color : 'transparent'}`,
                    fontSize: "16px",
                    fontWeight: selectedSection === section.name ? 'bold' : 'normal',
                    transition: 'all 0.2s ease',
                    '&:hover': {
                      color: section.color,
                      backgroundColor: 'rgba(255,255,255,0.05)'
                    }
                  }}
                >
                  {section.name}
                </Box>
              ))}
            </Box>
          </Box>

        {/* Dynamic Grid based on selected section */}
        {chartSections.map(section => {
            if (section.name === selectedSection) {
              return (
                <Grid 
                  container 
                  spacing={section.name === 'LPG' ? 1 : 2}
                  key={section.name}
                >
                  {section.charts.map((chart, index) => (
                    <Grid 
                      item 
                      xs={12} 
                      md={section.name === 'LPG' ? 12 : 6}
                      key={`${section.name}-chart-${index}`}
                      sx={{
                        mb: section.name === 'LPG' ? 1 : 2
                      }}
                    >
                      <Card sx={{
                        bgcolor: '#1a1a2e',
                        boxShadow: 'none',
                        border: '1px solid rgba(255,255,255,0.1)',
                        height: '100%',
                        // Different heights for first and second LPG charts
                        minHeight: section.name === 'LPG' 
                          ? (index === 0 ? 300 : 350) // Reduced heights for both charts
                          : 400,
                        '&:hover': {
                          border: `1px solid ${section.color}`
                        }
                      }}>
                        <ResponsiveContainer 
                          width="100%" 
                          height={section.name === 'LPG' 
                            ? (index === 0 ? 300 : 350) // Matching ResponsiveContainer heights
                            : 400
                          }
                        >
                          {chart}
                        </ResponsiveContainer>
                      </Card>
                    </Grid>
                  ))}
                </Grid>
              );
            }
            return null;
          })}
        </Grid>
      </Grid>
    </Box>
  );
};

export default CriticalAlerts;