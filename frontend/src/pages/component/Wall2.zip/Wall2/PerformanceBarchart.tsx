// import { useLayoutEffect, useRef } from 'react';
// import * as am5 from '@amcharts/amcharts5';
// import * as am5xy from '@amcharts/amcharts5/xy';
// import * as am5stock from '@amcharts/amcharts5/stock';
// import am5themes_Animated from '@amcharts/amcharts5/themes/Animated';

// interface StockData {
//   date: number;
//   open: number;
//   high: number;
//   low: number;
//   close: number;
//   rsi?: number;
// }

// const StockChartComponent: React.FC = () => {
//   const chartId = useRef(`chart-${Math.random().toString(36).substr(2, 9)}`);
//   const controlsId = useRef(`controls-${Math.random().toString(36).substr(2, 9)}`);
//   const rootRef = useRef<am5.Root | null>(null);

//   useLayoutEffect(() => {
//     if (rootRef.current) {
//       rootRef.current.dispose();
//     }

//     const root = am5.Root.new(chartId.current);
//     root._logo.dispose();
//     rootRef.current = root;

//     // Generate dummy data with RSI
//     const generateDummyData = (): StockData[] => {
//       const data: StockData[] = [];
//       const today = new Date();
//       let basePrice = 100;

//       for (let i = 365; i >= 0; i--) {
//         const date = new Date(today);
//         date.setDate(date.getDate() - i);
        
//         const volatility = 2;
//         const change = (Math.random() - 0.5) * volatility;
//         basePrice *= (1 + change / 100);
        
//         data.push({
//           date: date.getTime(),
//           open: basePrice * (1 + (Math.random() - 0.5) * 0.01),
//           high: basePrice * (1 + Math.random() * 0.02),
//           low: basePrice * (1 - Math.random() * 0.02),
//           close: basePrice
//         });
//       }

//       // Calculate RSI
//       const period = 14;
//       for (let i = 0; i < data.length; i++) {
//         if (i >= period) {
//           let gains = 0;
//           let losses = 0;
          
//           for (let j = i - period + 1; j <= i; j++) {
//             const change = data[j].close - data[j - 1].close;
//             if (change >= 0) {
//               gains += change;
//             } else {
//               losses -= change;
//             }
//           }
          
//           const avgGain = gains / period;
//           const avgLoss = losses / period;
//           const rs = avgGain / avgLoss;
//           data[i].rsi = 100 - (100 / (1 + rs));
//         }
//       }

//       return data;
//     };

//     // Set themes
//     root.setThemes([am5themes_Animated.new(root)]);

//     // Create stock chart
//     const stockChart = root.container.children.push(
//       am5stock.StockChart.new(root, {})
//     );

//     // Create main panel
//     const mainPanel = stockChart.panels.push(
//       am5stock.StockPanel.new(root, {
//         wheelY: "zoomX",
//         panX: true,
//         panY: true,
//         height: am5.percent(70)
//       })
//     );

//     // Create value axis
//     const valueAxis = mainPanel.yAxes.push(
//       am5xy.ValueAxis.new(root, {
//         renderer: am5xy.AxisRendererY.new(root, {
//           pan: "zoom"
//         })
//       })
//     );

//     // Create date axis
//     const dateAxis = mainPanel.xAxes.push(
//       am5xy.GaplessDateAxis.new(root, {
//         baseInterval: { timeUnit: "day", count: 1 },
//         renderer: am5xy.AxisRendererX.new(root, {})
//       })
//     );

//     // Create candlestick series without wicks
//     const valueSeries = mainPanel.series.push(
//       am5xy.CandlestickSeries.new(root, {
//         name: "MSFT",
//         valueYField: "close",
//         openValueYField: "open",
//         // Set high and low values to be the same as close and open to remove wicks
//         lowValueYField: "open",  // Changed from 'low' to 'open'
//         highValueYField: "close", // Changed from 'high' to 'close'
//         valueXField: "date",
//         tooltipText: "{name}\nOpen: {openValueY}\nClose: {valueY}",
//         xAxis: dateAxis,
//         yAxis: valueAxis
//       })
//     );

//     // Style the candlesticks
//     valueSeries.columns.template.states.create("riseFromOpen", {
//       fill: am5.color(0x00ff00),
//       stroke: am5.color(0x00ff00)
//     });

//     valueSeries.columns.template.states.create("dropFromOpen", {
//       fill: am5.color(0xff0000),
//       stroke: am5.color(0xff0000)
//     });

//     // Create RSI panel
//     const rsiPanel = stockChart.panels.push(
//       am5stock.StockPanel.new(root, {
//         wheelY: "zoomX",
//         panX: true,
//         panY: true,
//         height: am5.percent(30)
//       })
//     );

//     // Create RSI axes
//     const rsiValueAxis = rsiPanel.yAxes.push(
//       am5xy.ValueAxis.new(root, {
//         renderer: am5xy.AxisRendererY.new(root, {}),
//         min: 0,
//         max: 100
//       })
//     );

//     const rsiDateAxis = rsiPanel.xAxes.push(
//       am5xy.GaplessDateAxis.new(root, {
//         baseInterval: { timeUnit: "day", count: 1 },
//         renderer: am5xy.AxisRendererX.new(root, {})
//       })
//     );

//     // Add RSI series
//     const rsiSeries = rsiPanel.series.push(
//       am5xy.LineSeries.new(root, {
//         name: "RSI",
//         valueYField: "rsi",
//         valueXField: "date",
//         xAxis: rsiDateAxis,
//         yAxis: rsiValueAxis,
//         tooltipText: "RSI: {valueY}"
//       })
//     );

//     // Add toolbar
//     const toolbar = am5stock.StockToolbar.new(root, {
//       container: document.getElementById(controlsId.current),
//       stockChart: stockChart,
//       controls: [
//         am5stock.PeriodSelector.new(root, {
//           stockChart: stockChart,
//           periods: [
//             { timeUnit: "day", count: 5, name: "5D" },
//             { timeUnit: "month", count: 1, name: "1M" },
//             { timeUnit: "month", count: 3, name: "3M" },
//             { timeUnit: "month", count: 6, name: "6M" },
//             { timeUnit: "ytd", name: "YTD" },
//             { timeUnit: "year", count: 1, name: "1Y" },
//             { timeUnit: "year", count: 2, name: "2Y" },
//             { timeUnit: "year", count: 5, name: "5Y" },
//             { timeUnit: "max", name: "Max" }
//           ]
//         }),
//         am5stock.DrawingControl.new(root, {
//           stockChart: stockChart
//         }),
//         am5stock.ResetControl.new(root, {
//           stockChart: stockChart
//         })
//       ]
//     });

//     // Set data
//     const data = generateDummyData();
//     valueSeries.data.setAll(data);
//     rsiSeries.data.setAll(data);

//     // Clean up
//     return () => {
//       root.dispose();
//     };
//   }, []);

//   return (
//     <div>
//       <div id={controlsId.current} style={{ height: "40px" }} />
//       <div id={chartId.current} style={{ width: "100%", height: "400px" }} />
//     </div>
//   );
// };

// export default StockChartComponent;


// import React, { useState, useCallback, useEffect } from 'react';
// import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Rectangle } from 'recharts';
// import { transformData } from './dataTransformers';
// import { TooltipProps } from 'recharts';
// import { LabelProps } from 'recharts';
// import { fetchChartData } from './api';
// import { Card, CardContent, CardHeader, CardTitle } from '@/@/components/ui/card';


// interface ChartData {
//   name: string;
//   actual: number;
//   target: number;
// }

// interface SalesData {
//   ACTUAL_TMT_SALES: { [key: string]: number };
//   TARGET_TMT_SALES: { [key: string]: number };
//   fy_month: { [key: string]: string };
//   month_name: { [key: string]: string };
// }

// interface ZoneData {
//   ZONE: string;
//   Zone_Name: string;
//   TARGET_QTY_TMT: number;
//   NETWEIGHT_TMT: number;
// }

// interface SalesPerformanceChartProps {
//   data: SalesData;
//   onDrillDown: (filters: any) => Promise<ZoneData[]>;
// }

// export const CustomTooltip: React.FC<TooltipProps<number, string>> = ({ active, payload, label }) => {
//   if (active && payload && payload.length) {
//     return (
//       <div className="bg-[#2a2a3e] p-4 rounded-lg shadow-lg border border-gray-600">
//         <p className="font-bold text-white mb-2 text-sm">{label}</p>
//         {payload.map((entry, index) => (
//           <p
//             key={index}
//             className="text-sm flex justify-between items-center gap-4"
//             style={{ color: entry.color }}
//           >
//             <span>{entry.name}:</span>
//             <span className="font-semibold">{entry.value?.toLocaleString()} TMT</span>
//           </p>
//         ))}
//       </div>
//     );
//   }
//   return null;
// };
// export const CustomLabel: React.FC<LabelProps> = ({ x, y, width, height, value }) => {
//   if (!value || !width || typeof width === 'string' || width < 40) return null;

//   const xPos = (typeof x === 'number' ? x : parseFloat(x || '0')) + width / 2;
//   const yPos = (typeof y === 'number' ? y : parseFloat(y || '0')) + (typeof height === 'number' ? height : parseFloat(height || '0')) / 2;

//   return (
//     <text
//       x={xPos}
//       y={yPos}
//       fill="white"
//       textAnchor="middle"
//       dominantBaseline="middle"
//       fontSize={11}
//       fontWeight="bold"
//     >
//       {value.toLocaleString()}
//     </text>
//   );
// };


// const SalesPerformanceChart: React.FC = () => {
//   const [chartData, setChartData] = useState<ChartData[]>([]);
//   const [drillLevel, setDrillLevel] = useState(0);
//   const [filters, setFilters] = useState<any[]>([]);
//   const [isLoading, setIsLoading] = useState(true);

//   const loadData = useCallback(async () => {
//     setIsLoading(true);
//     try {
//       const response = await fetchChartData({
//         filters,
//         action: "sales_performance",
//         drill_state: ""
//       });
//       if (response.status && response.data) {
//         let transformedData: ChartData[];
//         if (drillLevel === 0) { 
//           transformedData = Object.keys(response.data.fy_month).map((key) => ({
//             name: response.data.month_name[key],
//             actual: response.data.ACTUAL_TMT_SALES[key],
//             target: response.data.TARGET_TMT_SALES[key],
//           }));
//         } else {
//           transformedData = response.data.map((item: any) => ({
//             name: item.ZONE || item.Region_Name || item.SalesArea_Name ||'',
//             actual: item.NETWEIGHT_TMT,
//             target: item.TARGET_QTY_TMT,
//           }));
//         }
//         setChartData(transformedData);
//       }
//     } catch (error) {
//       console.error("Error fetching data:", error);
//     }
//     setIsLoading(false);
//   }, [filters, drillLevel]);

//   useEffect(() => {
//     loadData();
//   }, [loadData]);

//   const handleBarClick = useCallback((entry: any) => {
//     console.log("entry",entry);
//     if (drillLevel >= 3) return;

//     let newFilters = [...filters];
//     if (drillLevel === 0) {
//       newFilters.push({
//         key: '"month_name"',
//         cond: "equals",
//         value: entry.name
//       });
//     } else if (drillLevel === 1) {
//       newFilters.push({
//         key: '"ZONE"',
//         cond: "equals",
//         value: entry.name.split(' ')[0]
//       });
//     }else if (drillLevel === 2) {
//       newFilters.push({
//         key: '"REGION"',
//         cond: "equals",
//         value: entry.name
//       });
//     }
//     setFilters(newFilters);
//     setDrillLevel(drillLevel + 1);
//   }, [drillLevel, filters]);

//   const handleBackClick = useCallback(() => {
//     if (drillLevel > 0) {
//       setFilters(filters.slice(0, -1));
//       setDrillLevel(drillLevel - 1);
//     }
//   }, [drillLevel, filters]);

//   if (isLoading) {
//     return <div className="flex justify-center items-center h-64 text-white">Loading...</div>;
//   }

//   return (
//     <Card className="w-full bg-[#1a1a2e] border-0">
//       <CardHeader>
//         <CardTitle className="text-2xl font-bold text-white">
//           Sales Performance
//           {drillLevel > 0 && (
//             <button
//               className="ml-4 px-2 py-1 bg-blue-500 text-white text-sm rounded hover:bg-blue-600 transition-colors"
//               onClick={handleBackClick}
//             >
//               Back
//             </button>
//           )}
//         </CardTitle>
//       </CardHeader>
//       <CardContent>
//         <div className="h-[400px] w-full">
//           <ResponsiveContainer width="100%" height="100%">
//             <BarChart
//               data={chartData}
//               margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
//             >
//               <CartesianGrid strokeDasharray="3 3" stroke="#eee" />
//               <XAxis
//                 dataKey="name"
//                 tick={{ fill: 'white' }}
//                 axisLine={{ stroke: 'white' }}
//               />
//               <YAxis
//                 tick={{ fill: 'white' }}
//                 axisLine={{ stroke: 'white' }}
//               />
//               <Tooltip content={<CustomTooltip />} />
//               <Legend wrapperStyle={{ color: 'white' }} />
//               <Bar
//                 dataKey="actual"
//                 name="Actual TMT Sales"
//                 fill="#00a495"
//                 activeBar={<Rectangle fill="#00a495" stroke="#00a495" />}
//                 onClick={handleBarClick}
//               >
//                 <CustomLabel />
//               </Bar>
//               <Bar
//                 dataKey="target"
//                 name="Target TMT Sales"
//                 fill="#dea600"
//                 activeBar={<Rectangle fill="#dea600" stroke="#dea600" />}
//                 onClick={handleBarClick}
//               >
//                 <CustomLabel />
//               </Bar>
//             </BarChart>
//           </ResponsiveContainer>
//         </div>
//       </CardContent>
//     </Card>
//   );
// };

// export default SalesPerformanceChart;


import React, { useState, useCallback, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Rectangle } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from "@/@/components/ui/card";
import { TooltipProps, LabelProps } from 'recharts';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/@/components/ui/select";
import { Button } from "@/@/components/ui/button";
import { fetchChartData } from './api';

interface ChartData {
  name: string;
  actual: number;
  target: number;
}

export const CustomTooltip: React.FC<TooltipProps<number, string>> = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-[#2a2a3e] p-4 rounded-lg shadow-lg border border-gray-600">
        <p className="font-bold text-white mb-2 text-sm">{label}</p>
        {payload.map((entry, index) => (
          <p 
            key={index}
            className="text-sm flex justify-between items-center gap-4"
            style={{ color: entry.color }}
          >
            <span>{entry.name}:</span>
            <span className="font-semibold">{entry.value?.toLocaleString()} TMT</span>
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export const CustomLabel: React.FC<LabelProps> = ({ x, y, width, height, value }) => {
  if (!value || !width || typeof width === 'string' || width < 40) return null;

  const xPos = (typeof x === 'number' ? x : parseFloat(x || '0')) + width / 2;
  const yPos = (typeof y === 'number' ? y : parseFloat(y || '0')) + (typeof height === 'number' ? height : parseFloat(height || '0')) / 2;

  return (
    <text
      x={xPos}
      y={yPos}
      fill="white"
      textAnchor="middle"
      dominantBaseline="middle"
      fontSize={11}
      fontWeight="bold"
    >
      {value.toLocaleString()}
    </text>
  );
};

const SalesPerformanceChart: React.FC = () => {
  const [chartData, setChartData] = useState<ChartData[]>([]);
  const [drillLevel, setDrillLevel] = useState(0);
  const [filters, setFilters] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [mode, setMode] = useState<'month' | 'year'>('month');

  // Filter states
  const [selectedYear, setSelectedYear] = useState('2024');
  const [selectedSBU, setSelectedSBU] = useState('');
  const [selectedZone, setSelectedZone] = useState('');
  const [selectedRegion, setSelectedRegion] = useState('');
  const [selectedPerformance, setSelectedPerformance] = useState('');

  // Filter options (replace with actual data when API is ready)
  const years = ['2024', '2023', '2022'];
  const sbuOptions = ['SBU 1', 'SBU 2', 'SBU 3'];
  const zoneOptions = ['North', 'South', 'East', 'West'];
  const regionOptions = ['Region 1', 'Region 2', 'Region 3'];
  const performanceOptions = ['Monthly', 'Quarterly', 'Yearly'];

  const loadData = useCallback(async () => {
    setIsLoading(true);
    try {
      const response = await fetchChartData({
        filters,
        action: mode === 'month' ? "sales_performance" : "sales_yearly_performance",
        drill_state: ""
      });
      if (response.status && response.data) {
        let transformedData: ChartData[];
        if (drillLevel === 0) {
          if (mode === 'month') {
            transformedData = Object.keys(response.data.fy_month).map((key) => ({
              name: response.data.month_name[key],
              actual: response.data.ACTUAL_TMT_SALES[key],
              target: response.data.TARGET_TMT_SALES[key],
            }));
          } else {
            transformedData = Object.keys(response.data.FISCAL_YEAR).map((key) => ({
              name: response.data.FISCAL_YEAR[key],
              actual: response.data.ACTUAL_TMT_SALES[key],
              target: response.data.TARGET_TMT_SALES[key],
            }));
          }
        } else {
          transformedData = response.data.map((item: any) => ({
            name: item.SBU_Name || item.Zone_Name || item.Region_Name || item.SalesArea_Name || item.ProductName || '',
            actual: item.NETWEIGHT_TMT,
            target: item.TARGET_QTY_TMT,
          }));
        }
        setChartData(transformedData);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
    setIsLoading(false);
  }, [filters, drillLevel, mode]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleBarClick = useCallback((entry: any) => {
    if (drillLevel >= 5) return;
    let newFilters = [...filters];
    const filterKeys = mode === 'month' 
      ? ["month_name", "SBU_Name", "Zone_Name", "Region_Name", "SalesArea_Name"]
      : ["FISCAL_YEAR", "SBU_Name", "Zone_Name", "Region_Name", "SalesArea_Name"];
    newFilters.push({
      key: `"${filterKeys[drillLevel]}"`,
      cond: "equals",
      value: entry.name
    });
    
    setFilters(newFilters);
    setDrillLevel(drillLevel + 1);
  }, [drillLevel, filters, mode]);

  const handleBackClick = useCallback(() => {
    if (drillLevel > 0) {
      setFilters(filters.slice(0, -1));
      setDrillLevel(drillLevel - 1);
    }
  }, [drillLevel, filters]);

  const toggleMode = useCallback(() => {
    setDrillLevel(0);
    setFilters([]);
  }, []);

  if (isLoading) {
    return <div className="flex justify-center items-center h-[500px] text-white">Loading...</div>;
  }

  return (
    <Card className="w-full bg-[#1a1a2e] rounded-lg border border-white/10">
      <CardHeader>
        <div className="flex flex-col gap-4">
          <div className="flex justify-between items-center">
            <CardTitle className="text-xl font-bold text-white">
              Sales Performance
            </CardTitle>
            <div className="flex gap-2">
              <Button
                variant={mode === "month" ? "outline" : "default"}
                onClick={() => {
                  setMode("month");
                  toggleMode();
                }}
                className="border"
              >
                M
              </Button>
              <Button
                variant={mode === "year" ? "outline" : "default"}
                onClick={() => {
                  setMode("year");
                  toggleMode();
                }}
                className="border"
              >
                Y
              </Button>
              {drillLevel > 0 && (
                <Button variant="outline" onClick={handleBackClick}>
                  Back
                </Button>
              )}
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Select value={selectedYear} onValueChange={setSelectedYear}>
              <SelectTrigger className="w-[120px] bg-[#2a2a3e] text-white border-gray-600">
                <SelectValue placeholder="Year" />
              </SelectTrigger>
              <SelectContent>
                {years.map((year) => (
                  <SelectItem key={year} value={year}>
                    {year}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedSBU} onValueChange={setSelectedSBU}>
              <SelectTrigger className="w-[120px] bg-[#2a2a3e] text-white border-gray-600">
                <SelectValue placeholder="SBU" />
              </SelectTrigger>
              <SelectContent>
                {sbuOptions.map((sbu) => (
                  <SelectItem key={sbu} value={sbu}>
                    {sbu}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedZone} onValueChange={setSelectedZone}>
              <SelectTrigger className="w-[120px] bg-[#2a2a3e] text-white border-gray-600">
                <SelectValue placeholder="Zone" />
              </SelectTrigger>
              <SelectContent>
                {zoneOptions.map((zone) => (
                  <SelectItem key={zone} value={zone}>
                    {zone}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedRegion} onValueChange={setSelectedRegion}>
              <SelectTrigger className="w-[120px] bg-[#2a2a3e] text-white border-gray-600">
                <SelectValue placeholder="Region" />
              </SelectTrigger>
              <SelectContent>
                {regionOptions.map((region) => (
                  <SelectItem key={region} value={region}>
                    {region}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select
              value={selectedPerformance}
              onValueChange={setSelectedPerformance}
            >
              <SelectTrigger className="w-[120px] bg-[#2a2a3e] text-white border-gray-600">
                <SelectValue placeholder="Performance" />
              </SelectTrigger>
              <SelectContent>
                {performanceOptions.map((perf) => (
                  <SelectItem key={perf} value={perf}>
                    {perf}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[400px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#eee" />
              <XAxis
                dataKey="name"
                tick={{ fill: "white" }}
                axisLine={{ stroke: "white" }}
              />
              <YAxis tick={{ fill: "white" }} axisLine={{ stroke: "white" }} />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ color: "white" }} />
              <Bar
                dataKey="actual"
                name="Actual TMT Sales"
                fill="#00a495"
                activeBar={<Rectangle fill="#00a495" stroke="#00a495" />}
                onClick={handleBarClick}
              >
                <CustomLabel />
              </Bar>
              <Bar
                dataKey="target"
                name="Target TMT Sales"
                fill="#dea600"
                activeBar={<Rectangle fill="#dea600" stroke="#dea600" />}
                onClick={handleBarClick}
              >
                <CustomLabel />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

export default SalesPerformanceChart;







