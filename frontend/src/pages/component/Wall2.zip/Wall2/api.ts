interface ChartDataParams {
    filters: Array<{ key: string; cond: string; value: string }>;
    action: string;
    drill_state: string;
  }
  
  export const fetchChartData = async (params: ChartDataParams) => {
    const response = await fetch('/api/charts/generate_vis_data', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    });
  
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
  
    return response.json();
  };
  
