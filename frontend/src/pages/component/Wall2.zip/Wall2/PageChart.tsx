// //api alerts wall

import React, { useEffect, useState } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { Factory, LocalGasStation, Propane, WaterDrop } from '@mui/icons-material';

const AnimatedIcon = ({ Icon, iconColor }) => ( 
  <div className="relative w-24 h-24 flex items-center justify-center overflow-hidden cursor-pointer group">
      <Icon
        className="w-16 h-16 opacity-80 transition-all duration-300 ease-in-out z-10"
        sx={{ color: iconColor, fontSize:"60px" }} 
      />
    <div 
      className="absolute inset-0 translate-y-full group-hover:translate-y-0 transition-transform duration-800 ease-out"
      style={{
        background: `linear-gradient(180deg, ${iconColor}4D 30%, ${iconColor}26 100%)`
      }}
    />
  </div>
);

const MainpageAlerts = () => {
  const [locationData, setLocationData] = useState({});
  const [alertData, setAlertData] = useState({});

  const fetchData = async (bu, action) => {
    try {
      const response = await fetch('/api/charts/generate_vis_data', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          filters: [{ key: 'bu', cond: 'equals', value: bu }],
          action,
          drill_state: ''
        })
      });
      const data = await response.json();
      return data;
    } catch (error) {
      console.error(`Error fetching ${action} data for ${bu}:`, error);
      return null;
    }
  };

  useEffect(() => {
    const fetchAllData = async () => {
      const buMapping = {
        RO: 'Retail',
        TAS: 'SOD',
        LPG: 'LPG'
      };

      const locationCounts = {};
      const alertsData = {};

      for (const [apiKey, displayName] of Object.entries(buMapping)) {
        const [locData, analyticsData] = await Promise.all([
          fetchData(apiKey, 'no_of_locations'),
          fetchData(apiKey, 'analytics')
        ]);

        if (locData?.data?.[0]?.count) {
          locationCounts[displayName] = locData.data[0].count;
        }

        if (analyticsData?.data?.alertDistribution) {
          alertsData[displayName] = analyticsData.data.alertDistribution.map(item => ({
            name: item.name,
            value: item.value
          }));
        }
      }

      setLocationData(locationCounts);
      setAlertData(alertsData);
    };

    fetchAllData();
  }, []);

  const icons = [
    {
      icon: <AnimatedIcon Icon={LocalGasStation} iconColor="#FF6B6B" />,
      type: 'Retail'
    },
    {
      icon: <AnimatedIcon Icon={WaterDrop} iconColor="#7FB7E7" />,
      type: 'SOD'
    },
    {
      icon: <AnimatedIcon Icon={Propane} iconColor="#FFD93D" />,
      type: 'LPG'
    },
    {
      icon: <AnimatedIcon Icon={Factory} iconColor="#4ECDC4" />,
      type: 'CP'
    }
  ];

  const COLORS = ['#FAC000', '#5ce65c', '#FF0000'];

  return ( 
    <div className="bg-[#1a1a2e] rounded-lg border border-white/10">
      <div className="grid grid-cols-4">
        {icons.map((item, index) => (
          <div key={index} className="flex items-center space-x-4">
            <div className="flex flex-col items-center">
              <br/>
              <span className="text-white text-md">{item.type}</span>
              {item.icon}
              <span className="text-white mt-2 text-sm md:text-base">
                {locationData[item.type] || 0}
              </span>
              <span className="text-white text-xs">
                ({alertData[item.type]?.reduce((sum, item) => sum + item.value, 0) || 0} alerts)
              </span>
              <br/>
            </div>
            
            <div className="h-20 md:h-52 flex-grow">
              <ResponsiveContainer>
                <PieChart>
                  <Pie
                    data={alertData[item.type] || []}
                    innerRadius="60%"
                    outerRadius="80%"
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {(alertData[item.type] || []).map((entry, i) => (
                      <Cell 
                        key={`cell-${i}`}
                        fill={COLORS[i % COLORS.length]}
                      />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MainpageAlerts;

// import React, { useEffect, useState } from 'react';
// import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
// import { Factory, LocalGasStation, Propane, WaterDrop } from '@mui/icons-material';

// const AnimatedIcon = ({ Icon, iconColor }) => (
//   <div className="relative w-24 h-24 flex items-center justify-center overflow-hidden cursor-pointer group">
//     <Icon
//       className="w-16 h-16 opacity-80 transition-all duration-300 ease-in-out z-10"
//       size={60}
//       color={iconColor}
//     />
//     <div 
//       className="absolute inset-0 translate-y-full group-hover:translate-y-0 transition-transform duration-800 ease-out"
//       style={{
//         background: `linear-gradient(180deg, ${iconColor}4D 30%, ${iconColor}26 100%)`
//       }}
//     />
//   </div>
// );

// // Enhanced tooltip component with percentage calculation
// const CustomTooltip = ({ active, payload, totalAlerts }) => {
//   if (active && payload && payload.length) {
//     const data = payload[0];
//     const percentage = ((data.value / totalAlerts) * 100).toFixed(1);
    
//     return (
//       <div className="bg-gray-800/90 p-3 rounded-lg shadow-lg border border-gray-700">
//         <p className="text-white font-medium mb-1">{data.name}</p>
//         <div className="space-y-1">
//           <p className="text-gray-200 text-sm">Count: {data.value.toLocaleString()}</p>
//           <p className="text-gray-200 text-sm">Percentage: {percentage}%</p>
//         </div>
//       </div>
//     );
//   }
//   return null;
// };

// const MainpageAlerts = () => {
//   const [locationData, setLocationData] = useState({});
//   const [alertData, setAlertData] = useState({});
//   const [summaryData, setSummaryData] = useState({});

//   const fetchData = async (bu, action) => {
//     try {
//       const response = await fetch('/api/charts/generate_vis_data', {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify({
//           filters: [{ key: 'bu', cond: 'equals', value: bu }],
//           action,
//           drill_state: ''
//         })
//       });
//       const data = await response.json();
//       return data;
//     } catch (error) {
//       console.error(`Error fetching ${action} data for ${bu}:`, error);
//       return null;
//     }
//   };

//   useEffect(() => {
//     const fetchAllData = async () => {
//       const buMapping = {
//         RO: 'Retail',
//         TAS: 'SOD',
//         LPG: 'LPG'
//       };

//       const locationCounts = {};
//       const alertsData = {};
//       const summaryInfo = {};

//       for (const [apiKey, displayName] of Object.entries(buMapping)) {
//         const analyticsData = await fetchData(apiKey, 'analytics');

//         if (analyticsData?.data) {
//           locationCounts[displayName] = analyticsData.data.activeLocations || 0;
//           alertsData[displayName] = analyticsData.data.alertDistribution || [];
//           summaryInfo[displayName] = {
//             activeLocations: analyticsData.data.activeLocations,
//             inactiveLocations: analyticsData.data.inactiveLocations,
//             totalAlerts: analyticsData.data.totalAlerts
//           };
//         }
//       }

//       setLocationData(locationCounts);
//       setAlertData(alertsData);
//       setSummaryData(summaryInfo);
//     };

//     fetchAllData();
//   }, []);

//   const icons = [
//     {
//       icon: <AnimatedIcon Icon={LocalGasStation} iconColor="#FF6B6B" />,
//       type: 'Retail'
//     },
//     {
//       icon: <AnimatedIcon Icon={WaterDrop} iconColor="#7FB7E7" />,
//       type: 'SOD'
//     },
//     {
//       icon: <AnimatedIcon Icon={Propane} iconColor="#FFD93D" />,
//       type: 'LPG'
//     },
//     {
//       icon: <AnimatedIcon Icon={Factory} iconColor="#4ECDC4" />,
//       type: 'CP'
//     }
//   ];

//   // Define gradient colors based on severity
//   const COLORS = {
//     Critical: {
//       gradient: {
//         startColor: '#FF1A1A',
//         endColor: '#CC0000'
//       }
//     },
//     High: {
//       gradient: {
//         startColor: '#FF8C00',
//         endColor: '#CC7000'
//       }
//     },
//     Medium: {
//       gradient: {
//         startColor: '#FFD700',
//         endColor: '#B8860B'
//       }
//     }
//   };

//   return (
//     <div className="bg-[#1a1a2e] rounded-lg border border-white/10">
//       <div className="grid grid-cols-4">
//         {icons.map((item, index) => {
//           const totalAlerts = alertData[item.type]?.reduce((sum, alert) => sum + alert.value, 0) || 0;
          
//           return (
//             <div key={index} className="flex items-center space-x-4">
//               <div className="flex flex-col items-center">
//                 <br/>
//                 <span className="text-white text-md font-medium">{item.type}</span>
//                 {item.icon}
//                 <span className="text-white mt-2 text-sm md:text-base">
//                   {locationData[item.type]?.toLocaleString() || 0} locations
//                 </span>
//                 <span className="text-white text-xs">
//                   {totalAlerts.toLocaleString()} alerts
//                 </span>
//                 <br/>
//               </div>
              
//               <div className="h-20 md:h-52 flex-grow">
//                 <ResponsiveContainer>
//                   <PieChart>
//                     <defs>
//                       {Object.entries(COLORS).map(([level, colors]) => (
//                         <radialGradient key={level} id={`color${level}`}>
//                           <stop offset="0%" stopColor={colors.gradient.startColor} />
//                           <stop offset="100%" stopColor={colors.gradient.endColor} />
//                         </radialGradient>
//                       ))}
//                     </defs>
//                     <Pie
//                       data={alertData[item.type] || []}
//                       innerRadius="60%"
//                       outerRadius="80%"
//                       paddingAngle={2}
//                       dataKey="value"
//                       startAngle={90}
//                       endAngle={-270}
//                     >
//                       {(alertData[item.type] || []).map((entry, i) => (
//                         <Cell 
//                           key={`cell-${i}`}
//                           fill={`url(#color${entry.name})`}
//                           strokeWidth={1}
//                           stroke="#1a1a2e"
//                         />
//                       ))}
//                     </Pie>
//                     <Tooltip 
//                       content={props => (
//                         <CustomTooltip {...props} totalAlerts={totalAlerts} />
//                       )}
//                     />
//                   </PieChart>
//                 </ResponsiveContainer>
//               </div>
//             </div>
//           );
//         })}
//       </div>
//     </div>
//   );
// };

// export default MainpageAlerts;
