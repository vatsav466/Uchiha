import React, { useState, useRef, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
} from "../../../../@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../../../../@/components/ui/select";
import { Input } from "../../../../@/components/ui/input";
import { Button } from "../../../../@/components/ui/button";
import {
  Search,
  Plus,
  LayoutDashboard,
  CheckCircle2,
  Send,
  Trash2,
  GripVertical,
  User,
  Users,
} from "lucide-react";
import { AppDispatch, RootState } from "../../../../redux/store";
import {
  Dashboard,
  fetchDashboards,
  updateDashboardGroup,
  updateDashboardOrderLocally,
  updateDashboardStatus,
  deleteDashboard,
  updateGroupsOrder,
} from "../../../../redux/features/dashboardSlice";
import axios from "axios";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "../../../../@/components/ui/dropdown-menu";
import { DashboardWidget } from "./DashboardWidget";
import AI_Animation_5 from "../../../../assets/gif/ai_animation_5.gif";
import { useNavigate } from "react-router";
interface GroupWidget {
  i: string;
  name: string;
  content: Dashboard;
}

interface GroupWidgets {
  [key: string]: GroupWidget[];
}
interface DashboardGroupUpdateRequest {
  record_id: number;
  name: string;
  description: string;
  created_by: string;
  created_user: string;
  dashboard_order: Array<{
    dashboard_id: number;
    display_name: string;
  }>;
  group_order: number;
  organization_id: number;
}

const DashboardLayout = () => {
  const dispatch = useDispatch<AppDispatch>();
  const {
    dashboards,
    loading,
    counts: { group: groupCounts },
  } = useSelector((state: RootState) => state.dashboard);

  const [widgets, setWidgets] = useState<GroupWidgets>({});
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedGroup, setSelectedGroup] = useState<string | null>(null);
  const [draggedItem, setDraggedItem] = useState<{
    widget: GroupWidget;
    sourceGroup: string;
  } | null>(null);
  const [updating, setUpdating] = useState(false);
  const [groupOrder, setGroupOrder] = useState<string[]>([]);
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null);
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);
  const [activeGroupId, setActiveGroupId] = useState<string | null>(null);
  const [dragOverGroupId, setDragOverGroupId] = useState<string | null>(null);
  const [isDraggingOverGroup, setIsDraggingOverGroup] = useState(false);
  const navigate = useNavigate();
  useEffect(() => {
    dispatch(fetchDashboards());
  }, [dispatch]);
  const ungroupedDashboards = dashboards.filter(
    (dashboard) => !dashboard.group_name || dashboard.group_name === ''
  );
  const validatePayload = (payload: DashboardGroupUpdateRequest): boolean => {
    if (!payload.record_id || !payload.name || !payload.organization_id) {
      console.error("Missing required fields in payload");
      return false;
    }
    if (!Array.isArray(payload.dashboard_order)) {
      console.error("dashboard_order must be an array");
      return false;
    }
    return payload.dashboard_order.every(
      (item) =>
        typeof item.dashboard_id === "number" &&
        typeof item.display_name === "string"
    );
  };
  const handleGroupOrderUpdate = async (newOrder: string[]) => {
    try {
      // First update local state
      setGroupOrder(newOrder);

      // Prepare payload for API
      const groupOrders = newOrder
        .map((groupName, index) => {
          const groupWidgets = widgets[groupName];
          const groupId = groupWidgets[0]?.content.group_id;
          return {
            group_id: groupId,
            group_order: index + 1, // API expects 1-based index
          };
        })
        .filter((order) => order.group_id); // Filter out any undefined group_ids

      // Dispatch the new action to update group order
      await dispatch(
        updateGroupsOrder({
          group_orders: groupOrders,
        })
      ).unwrap();
    } catch (error) {
      console.error("Error updating group order:", error);
      // Revert to previous order
      setGroupOrder((prev) => [...prev]);
    }
  };
  const handleDeleteDashboard = async (dashboard: Dashboard) => {
    try {
      await dispatch(deleteDashboard(dashboard.id)).unwrap();

      // Update local state
      setWidgets((prev) => {
        const newWidgets = { ...prev };
        if (dashboard.group_name) {
          newWidgets[dashboard.group_name] = newWidgets[
            dashboard.group_name
          ].filter((w) => w.content.id !== dashboard.id);

          if (newWidgets[dashboard.group_name].length === 0) {
            delete newWidgets[dashboard.group_name];
          }
        }
        return newWidgets;
      });
    } catch (error) {
      console.error("Error deleting dashboard:", error);
    }
  };
  useEffect(() => {
    const groupedDashboards = dashboards.reduce((acc: GroupWidgets, dashboard) => {
      // Skip dashboards with empty array group names
      if (Array.isArray(dashboard.group_name) && dashboard.group_name.length === 1 && dashboard.group_name[0] === '') {
        return acc;
      }
      
      // Handle both string and array group names
      const groupName = Array.isArray(dashboard.group_name) 
        ? dashboard.group_name[0] 
        : (dashboard.group_name || "Uncategorized");
      
      if (!acc[groupName]) {
        acc[groupName] = [];
      }
      
      acc[groupName].push({
        i: `widget-${dashboard.id}`,
        name: dashboard.dashboard_title,
        content: dashboard,
      });
      return acc;
    }, {});
  
    // Sort dashboards within each group
    Object.keys(groupedDashboards).forEach((groupName) => {
      groupedDashboards[groupName].sort((a, b) => {
        const posA = a.content.position ?? Number.MAX_VALUE;
        const posB = b.content.position ?? Number.MAX_VALUE;
        return posA - posB;
      });
    });
  
    setWidgets(groupedDashboards);
    // Update group order to include Uncategorized at the end if it exists
    setGroupOrder((prev) => {
      const groups = Object.keys(groupedDashboards).filter(name => name !== "Uncategorized");
      if (groupedDashboards["Uncategorized"]) {
        groups.push("Uncategorized");
      }
      return prev.length ? prev : groups;
    });
  }, [dashboards]);
  const handleGroupDragStart = (e: React.DragEvent, groupName: string) => {
    e.dataTransfer.setData("text/group", groupName);
  };
  const handleGroupDrop = async (e: React.DragEvent, targetGroup: string) => {
    e.preventDefault();
    const draggedGroup = e.dataTransfer.getData("text/group");

    if (draggedGroup === targetGroup) return;

    // Create new order
    const newOrder = [...groupOrder];
    const draggedIndex = newOrder.indexOf(draggedGroup);
    const targetIndex = newOrder.indexOf(targetGroup);

    newOrder.splice(draggedIndex, 1);
    newOrder.splice(targetIndex, 0, draggedGroup);

    // Call the API update function with the new order
    await handleGroupOrderUpdate(newOrder);
  };
  const handleDragOverItem = (
    e: React.DragEvent,
    index: number,
    groupId: string
  ) => {
    e.preventDefault();
    if (activeGroupId === groupId) {
      setDragOverIndex(index);
    }
  };

  const handleGroupDragEnter = (e: React.DragEvent, groupId: string) => {
    e.preventDefault();
    if (draggedItem && draggedItem.sourceGroup !== groupId) {
      setDragOverGroupId(groupId);
      setIsDraggingOverGroup(true);
    }
  };

  const handleGroupDragLeave = (e: React.DragEvent) => {
    const relatedTarget = e.relatedTarget as HTMLElement;
    if (!relatedTarget?.closest(".group-drop-zone")) {
      setIsDraggingOverGroup(false);
    }
  };
  const handleDragEnd = () => {
    setDraggedItem(null);
    setDragOverIndex(null);
    setDraggedIndex(null);
    setActiveGroupId(null);
    setDragOverGroupId(null);
    setIsDraggingOverGroup(false);
  };

  
    const orderedGroups = Object.entries(widgets)
    .filter(([groupName]) => {
      const matchesSearch = groupName
        .toLowerCase()
        .includes(searchTerm.toLowerCase());
      const matchesFilter = selectedGroup ? groupName === selectedGroup : true;
      return matchesSearch && matchesFilter;
    })
    .sort((a, b) => {
      const indexA = groupOrder.indexOf(a[0]);
      const indexB = groupOrder.indexOf(b[0]);
      return indexA - indexB;
    });
    const handleStatusUpdate = async (dashboard: Dashboard, newStatus: string) => {
      try {
        dispatch(updateDashboardStatus({
          dashboardId: dashboard.id,
          newStatus,
        }));
    
        await axios.post("/api/dashboards/save_dashboards", {
          ...dashboard,
          record_id: dashboard.id,
          dashboard_status: newStatus,
          updated_at: new Date().toISOString(),
          group_id: [dashboard.group_id], // Send as array
          group_name: [dashboard.group_name], // Send as array
          organization_id: dashboard.organization_id
        });
      } catch (error) {
        console.error("Error updating status:", error);
        dispatch(fetchDashboards());
      }
    };

    // const handleDashboardGroupOrder = async (groupId: string, groupWidgets: GroupWidget[]) => {
    //   try {
    //     setUpdating(true);
    //     const groupDashboard = groupWidgets[0]?.content;
    //     if (!groupDashboard?.group_id) return;
    
    //     const payload = {
    //       record_id: groupDashboard?.group_id.map
    //       name: groupId,
    //       created_user: groupDashboard?.created_user || "",
    //       dashboard_order: groupWidgets.map((widget, index) => ({
    //         dashboard_id: widget.content.id,
    //         display_name: widget.content.dashboard_title,
    //         position: index,
    //       })),
    //       organization_id: groupDashboard.organization_id,

    //     };
    
    //     dispatch(updateDashboardOrderLocally({
    //       groupName: groupId,
    //       dashboards: groupWidgets.map((widget, index) => ({
    //         ...widget.content,
    //         position: index
    //       })),
    //     }));
    
    //     await axios.post("/api/dashboardgroups/update_dashboard_groups", payload);
    //   } catch (error) {
    //     console.error("Error updating dashboard order:", error);
    //     dispatch(fetchDashboards());
    //   } finally {
    //     setUpdating(false);
    //   }
    // };


    const handleDashboardGroupOrder = async (groupId: string, groupWidgets: GroupWidget[]) => {
      try {
        setUpdating(true);
        const groupDashboard = groupWidgets[0]?.content;
        if (!groupDashboard?.group_id) return;
    
        const payload = {
          record_id: Number(groupDashboard.group_id),
          name: groupId,
          description: "",
          created_by: "",
          created_user: groupDashboard?.created_user || "",
          dashboard_order: groupWidgets.map((widget) => ({
            dashboard_id: widget.content.id,
            display_name: widget.content.dashboard_title
          })),
          group_order: groupWidgets[0]?.content.position || 0,
          organization_id:  Number(groupDashboard.organization_id)
        };
    
        dispatch(updateDashboardOrderLocally({
          groupName: groupId,
          dashboards: groupWidgets.map((widget, index) => ({
            ...widget.content,
            position: index
          })),
        }));
    
        await axios.post("/api/dashboardgroups/update_dashboard_groups", payload);
      } catch (error) {
        console.error("Error updating dashboard order:", error);
        dispatch(fetchDashboards());
      } finally {
        setUpdating(false);
      }
    };
  const handleDragStart = (
    e: React.DragEvent,
    dashboard: Dashboard,
    sourceGroup?: string,
    index?: number
  ) => {
    setDraggedIndex(index !== undefined ? index : null);
    setActiveGroupId(sourceGroup || null);
    setDraggedItem({
      widget: {
        i: `widget-${dashboard.id}`,
        name: dashboard.dashboard_title,
        content: dashboard,
      },
      sourceGroup: sourceGroup || "sidebar",
    });
    e.dataTransfer.setData("text/plain", JSON.stringify(dashboard));
  };

  const handleDrop = async (e: React.DragEvent, groupId: string) => {
    e.preventDefault();
    if (updating || !draggedItem) return;

    const data = e.dataTransfer.getData("text/plain");
    const droppedDashboard: Dashboard = JSON.parse(data);
    const sourceGroup = draggedItem.sourceGroup;
    const dropIndex =
      dragOverIndex !== null ? dragOverIndex : widgets[groupId]?.length || 0;

    const newWidgets = { ...widgets };

    // Handle same group reordering
    if (sourceGroup === groupId) {
      const groupWidgets = [...newWidgets[groupId]];
      const draggedWidget = groupWidgets[draggedIndex!];

      // Remove from old position
      groupWidgets.splice(draggedIndex!, 1);
      // Insert at new position
      groupWidgets.splice(dropIndex, 0, draggedWidget);

      newWidgets[groupId] = groupWidgets.map((widget, index) => ({
        ...widget,
        content: { ...widget.content, position: index },
      }));

      setWidgets(newWidgets);
      await handleDashboardGroupOrder(groupId, groupWidgets);
    }
    // Handle cross-group movement
    else {
      if (sourceGroup !== "sidebar") {
        newWidgets[sourceGroup] = newWidgets[sourceGroup].filter(
          (w) => w.content.id !== droppedDashboard.id
        );
      }

      const newWidget: GroupWidget = {
        i: `widget-${droppedDashboard.id}`,
        name: droppedDashboard.dashboard_title,
        content: {
          ...droppedDashboard,
          group_name: groupId,
        },
      };

      if (!newWidgets[groupId]) {
        newWidgets[groupId] = [];
      }

      newWidgets[groupId].splice(dropIndex, 0, newWidget);

      setWidgets(newWidgets);

      try {
        // await axios.post("/api/dashboards/save_dashboards", {
        //   ...droppedDashboard,
        //   record_id: droppedDashboard.id,
        //   group_name: groupId,
        //   updated_at: new Date().toISOString(),
        // });
        await axios.post("/api/dashboards/save_dashboards", {
          ...droppedDashboard,
          record_id: droppedDashboard.id,
          group_id: droppedDashboard.group_id, // Send as array
          group_name: [groupId], // Send as array
          organization_id: droppedDashboard.organization_id,
          updated_at: new Date().toISOString(),
        });

        if (sourceGroup !== "sidebar") {
          const updatedSourceWidgets = newWidgets[sourceGroup]?.map((w, i) => ({
            ...w,
            content: { ...w.content, position: i },
          }));
          await handleDashboardGroupOrder(sourceGroup, updatedSourceWidgets);
        }

        const updatedDestWidgets = newWidgets[groupId].map((w, i) => ({
          ...w,
          content: { ...w.content, position: i },
        }));
        await handleDashboardGroupOrder(groupId, updatedDestWidgets);
      } catch (error) {
        console.error("Error updating dashboard group:", error);
        dispatch(fetchDashboards());
      }
    }

    // Reset drag states
    setDraggedItem(null);
    setDragOverIndex(null);
    setDraggedIndex(null);
    setActiveGroupId(null);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };
  

  const filteredGroups = Object.entries(widgets).filter(([groupName]) => {
    const matchesSearch = groupName
      .toLowerCase()
      .includes(searchTerm.toLowerCase());
    const matchesFilter = selectedGroup ? groupName === selectedGroup : true;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-gray-50 to-blue-50/30">
      {/* Header Section */}
      <div className="flex-none p-4 border-b border-gray-200">
        <div className="max-w-[1600px] mx-auto">
          <div className="flex items-center gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                type="text"
                placeholder="Search Groups"
                className="w-[50%] pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button
              size="sm"
              variant="outline"
              className="text-[#0047AB] bg-blue-100 h-8 hover:bg-blue-100 hover:text-[#0047AB]"
              onClick={() => navigate("/action-center/ai-chart")}
            >
              <img
                src={AI_Animation_5}
                alt="AI Animation"
                className="w-6 h-6 mr-1"
              />
              Ask AI
            </Button>
            <Select
              value={selectedGroup || "all"}
              onValueChange={(value) =>
                setSelectedGroup(value === "all" ? null : value)
              }
            >
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Select a group" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Groups</SelectItem>
                {Object.keys(widgets).filter(name => name !== '').map((groupName) => (
                  <SelectItem key={groupName} value={groupName}>
                    {groupName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-hidden">
        <div className="h-full max-w-[1600px] mx-auto p-4">
          <div className="flex h-full gap-4">
            {/* Groups Column */}
            <div className="flex-1 overflow-auto">
              <div className="flex flex-col gap-4">
                {orderedGroups.length > 0 ? (
                  orderedGroups.map(([groupName, groupWidgets]) => (
                    <div
                      key={groupName}
                      draggable
                      onDragStart={(e) => handleGroupDragStart(e, groupName)}
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={(e) => handleGroupDrop(e, groupName)}
                      className="flex flex-col bg-blue-50 rounded-lg p-4 hover:shadow-md transition-shadow"
                    >
                      {/* Group Header */}
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2 bg-white/60 backdrop-blur-sm px-3 py-2 rounded-lg">
                          <div className="cursor-move p-1 rounded-md hover:bg-blue-100 transition-colors">
                            <GripVertical className="w-4 h-4 text-blue-600" />
                          </div>
                          <h2 className="text-sm font-semibold text-gray-700">
                            {groupName}
                            <span className="ml-2 px-2 py-0.5 rounded-full bg-white text-gray-600 text-xs">
                              {groupWidgets.length}
                            </span>
                          </h2>
                        </div>
                      </div>
                      {/* Draggable Area */}
                      <div
                        className="flex-1 min-h-[100px] p-4 bg-white/50 rounded-lg"
                        onDrop={(e) => handleDrop(e, groupName)}
                        onDragOver={handleDragOver}
                      >
                        <div className="flex flex-wrap gap-3">
                          {/* ... rest of the group content remains the same ... */}
                          {groupWidgets.map((widget, index) => (
                            <React.Fragment key={widget.i}>
                              <div
                                className={`transition-transform duration-200 ${
                                  draggedIndex === index &&
                                  activeGroupId === groupName
                                    ? "opacity-50"
                                    : ""
                                }`}
                                draggable
                                onDragStart={(e) =>
                                  handleDragStart(
                                    e,
                                    widget.content,
                                    groupName,
                                    index
                                  )
                                }
                                onDragOver={(e) => {
                                  e.preventDefault();
                                  handleDragOverItem(e, index, groupName);
                                }}
                              >
                                <DashboardWidget
                                  widget={widget}
                                  onStatusUpdate={handleStatusUpdate}
                                  onDeleteClick={handleDeleteDashboard}
                                  onDragStart={handleDragStart}
                                  groupId={groupName}
                                />
                              </div>
                            </React.Fragment>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="flex items-center justify-center h-full text-gray-500">
                    Drag dashboards from the sidebar to create groups
                  </div>
                )}
              </div>
            </div>

            {/* Sidebar */}
            <div className="w-60 flex-none flex flex-col bg-white/80 backdrop-blur-sm rounded-lg shadow-md">
              <div className="flex-none p-4 border-b border-gray-100">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-semibold text-gray-700">
                    Available Dashboards
                  </h3>
                  <span className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-600 text-xs font-medium">
                    {dashboards.length}
                  </span>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-4">
                <div className="flex flex-col gap-2">
                  {dashboards.map((dashboard) => (
                    <DashboardWidget
                      key={dashboard.id}
                      widget={{
                        i: `widget-${dashboard.id}`,
                        name: dashboard.dashboard_title,
                        content: dashboard,
                      }}
                      onStatusUpdate={handleStatusUpdate}
                      onDeleteClick={handleDeleteDashboard}
                      onDragStart={handleDragStart}
                    />
                  ))}
                  {dashboards.length === 0 && (
                    <div className="flex items-center justify-center h-24 text-gray-500">
                      No dashboards available
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Loading Overlay */}
      {loading && (
        <div className="fixed inset-0 bg-black/20 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-white p-4 rounded-lg shadow-lg">
            <div className="animate-spin w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full" />
          </div>
        </div>
      )}
    </div>
  );
};

export default DashboardLayout;
