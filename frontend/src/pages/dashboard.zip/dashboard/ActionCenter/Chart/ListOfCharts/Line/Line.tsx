
// import React, { useEffect, useState, useRef } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import LineDataTable from './LineDataTable';
// import { LineSeriesOption } from 'echarts/charts';
// import { EChartsOption } from 'echarts-for-react';

// interface LineProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//     hideDataTable?: boolean;
//   };
//   theme: string;
// }

// const Line: React.FC<LineProps> = ({ data, theme }) => {
//   const chartRef = useRef<EChartsReact>(null);
//   const containerRef = useRef<HTMLDivElement>(null);
//   const [containerSize, setContainerSize] = useState({ width: 0, height: 0 });

//   // Add container size observer
//   useEffect(() => {
//     const resizeObserver = new ResizeObserver(entries => {
//       for (let entry of entries) {
//         const { width, height } = entry.contentRect;
//         setContainerSize({ width, height });
//       }
//     });

//     if (containerRef.current) {
//       resizeObserver.observe(containerRef.current);
//     }

//     return () => {
//       resizeObserver.disconnect();
//     };
//   }, []);

//   // Resize chart on container size change
//   useEffect(() => {
//     if (chartRef.current) {
//       chartRef.current.getEchartsInstance().resize();
//     }
//   }, [containerSize]);

//   const formatValue = (value: any): string => {
//     if (value === null || value === undefined) return '-';
//     return typeof value === 'number'
//       ? new Intl.NumberFormat('en-US', {
//           maximumFractionDigits: 2,
//           notation: Math.abs(value) > 1000000 ? 'compact' : 'standard',
//         }).format(value)
//       : String(value);
//   };

//   const processData = () => {
//     const keys = Object.keys(data.chartData[0] || {});
//     const categoryKey = keys[0];
//     const valueKeys = keys.slice(1);
//     const groupByFields = data.chartRequest?.params?.form_data?.groupby?.map(g => g.name) || [];
//     const hasGroupBy = groupByFields.length > 0;

//     const categories = data.chartData.map(item => String(item[categoryKey]));

//     let series: LineSeriesOption[] = [];

//     if (hasGroupBy) {
//       const dimensionCombinations = Array.from(new Set(
//         data.chartData.map(item => 
//           groupByFields.map(field => item[field]).join(' - ')
//         )
//       ));

//       series = dimensionCombinations.flatMap(dimension =>
//         valueKeys.map(key => ({
//           name: `${dimension} - ${key}`,
//           type: 'line',
//           smooth: true,
//           data: categories.map(category => {
//             const matchingItem = data.chartData.find(item => 
//               String(item[categoryKey]) === category && 
//               groupByFields.map(field => item[field]).join(' - ') === dimension
//             );
//             return matchingItem?.[key] || 0;
//           })
//         }))
//       );
//     } else {
//       series = valueKeys.map(key => ({
//         name: key,
//         type: 'line',
//         smooth: true,
//         data: data.chartData.map(item => Number(item[key]))
//       }));
//     }

//     return { categories, series, hasGroupBy };
//   };

//   const { categories, series, hasGroupBy } = processData();
//   const selectedTheme = getSelectedTheme(theme);

//   const option: EChartsOption = {
//     tooltip: {
//       trigger: 'axis',
//       // formatter: function(params: any) {
//       //   return `${params.seriesName}: ${formatValue(params.value)}`;
//       // }
//     },
//     grid: {
//       left: '3%',
//       right: '4%',
//       bottom: data.showDataZoom ? '15%' : '3%',
//       containLabel: true
//     },
//     legend: {
//       show: data.showLegend,
//       type: data.legendType,
//       top: data.legendOrientation === 'top' ? '0' : 'auto',
//       bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//       left: data.legendOrientation === 'left' ? '0' : 'auto',
//       right: data.legendOrientation === 'right' ? '0' : 'auto',
//     },
//     xAxis: {
//       type: 'category',
//       data: categories,
//       axisLabel: {
//         rotate: 45,
//         interval: 0,
//       }
//     },
//     yAxis: {
//       type: 'value',
//       axisLabel: {
//         formatter: formatValue,
//       },
//     },
//     series: series.map(s => ({
//       ...s,
//       emphasis: {
//         focus: 'series',
//         itemStyle: {
//           shadowBlur: 10,
//           shadowOffsetX: 0,
//           shadowColor: 'rgba(0, 0, 0, 0.5)'
//         }
//       },
//       symbolSize: 6,
//       symbol: 'circle',
//     })),
//     dataZoom: data.showDataZoom ? [
//       {
//         type: 'slider',
//         show: true,
//         start: 0,
//         end: 100,
//         height: 30
//       },
//       {
//         type: 'inside',
//         start: 0,
//         end: 100
//       }
//     ] : [],
//     color: selectedTheme.color,
//   };

//   return (
//     <div ref={containerRef} className="flex flex-col h-full">
//       <div className="relative" style={{ height: '400px', width: '100%' }}>
//         <div className="absolute top-2 right-2 flex items-center space-x-2 z-10">
//           <div className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
//             {data.chartData.length} rows
//           </div>
//         </div>
//         <EChartsReact
//           ref={chartRef}
//           option={option}
//           theme={selectedTheme}
//           style={{ height: '100%', width: '100%' }}
//           notMerge={true}
//           lazyUpdate={false}
//           opts={{ renderer: 'canvas' }}
//         />
//       </div>

//       {!data.hideDataTable && (
//         <div className="mt-4">
//           <Tabs defaultValue="results">
//             <TabsList>
//               <TabsTrigger value="results">RESULTS</TabsTrigger>
//             </TabsList>
//             <TabsContent value="results" className="h-64 overflow-auto">
//               <LineDataTable data={data.chartData} />
//             </TabsContent>
//           </Tabs>
//         </div>
//       )}
//     </div>
//   );
// };

// export default Line;

// function getSelectedTheme(themeName: string) {
//   switch (themeName) {
//     case 'Essos': return Essos;
//     case 'Wonderland': return Wonderland;
//     case 'Walden': return Walden;
//     case 'Infographic': return Infographic;
//     case 'Macarons': return Macarons;
//     case 'Roma': return Roma;
//     case 'CoolTheme': return CoolTheme;
//     case 'Shine': return Shine;
//     default: return Westeros;
//   }
// }






// import React, { useEffect, useState, useRef } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// // import LineDataTable from './LineDataTable';
// import { EChartsOption, SeriesOption } from 'echarts';
// import LineDataTable from '../Line/LineDataTable';

// interface ChartRequest {
//   params: {
//     form_data: {
//       x_axis: {
//         name: string;
//       };
//       groupby: Array<{
//         name: string;
//       }>;
//     };
//     queries: Array<{
//       metrics: Array<{
//         column: {
//           column_name: string;
//         };
//         label: string;
//       }>;
//     }>;
//   };
// }

// interface LineProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: ChartRequest;
//     showDataZoom: boolean;
//     hideDataTable?: boolean;
//   };
//   theme: string;
// }

// const Line: React.FC<LineProps> = ({ data, theme }) => {
//   const chartRef = useRef<EChartsReact>(null);
//   const containerRef = useRef<HTMLDivElement>(null);
//   const [containerSize, setContainerSize] = useState({ width: 0, height: 0 });

//   useEffect(() => {
//     const resizeObserver = new ResizeObserver(entries => {
//       for (let entry of entries) {
//         const { width, height } = entry.contentRect;
//         setContainerSize({ width, height });
//       }
//     });

//     if (containerRef.current) {
//       resizeObserver.observe(containerRef.current);
//     }

//     return () => {
//       resizeObserver.disconnect();
//     };
//   }, []);

//   useEffect(() => {
//     if (chartRef.current) {
//       chartRef.current.getEchartsInstance().resize();
//     }
//   }, [containerSize]);

//   const processData = () => {
//     if (!data.chartData || data.chartData.length === 0) return { dimensions: [], categories: [], series: [] };

//     const chartRequest = data.chartRequest;
    
//     // Get x-axis column name from chart request
//     const xAxisColumn = chartRequest.params.form_data.x_axis.name;
    
//     // Get dimension columns from groupby in chart request
//     const dimensionColumns = chartRequest.params.form_data.groupby.map(group => group.name);
    
//     // Get metric columns from metrics in chart request
//     const metricColumns = chartRequest.params.queries[0].metrics.map(metric => metric.column.column_name);

//     // Get unique dimensions
//     const dimensions = dimensionColumns.length > 0
//       ? Array.from(new Set(data.chartData.map(item => item[dimensionColumns[0]])))
//       : [''];

//     // Get unique categories (time values) and sort them
//     const categories = Array.from(new Set(data.chartData.map(item => item[xAxisColumn])))
//       .sort((a, b) => new Date(a).getTime() - new Date(b).getTime());

//     // Create series for each dimension and metric combination
//     const series: SeriesOption[] = dimensions.flatMap(dimension => 
//       metricColumns.map(metric => {
//         const dimensionData = data.chartData
//           .filter(item => dimensionColumns.length === 0 || item[dimensionColumns[0]] === dimension)
//           .sort((a, b) => new Date(a[xAxisColumn]).getTime() - new Date(b[xAxisColumn]).getTime())
//           .map(item => ({
//             name: new Date(item[xAxisColumn]).toLocaleDateString(),
//             value: Number(item[metric]),
//             itemData: item
//           }));

//         const seriesName = dimensionColumns.length > 0 
//           ? `${dimension} - ${metric}` 
//           : metric;

//         return {
//           name: seriesName,
//           type: 'line',
//           smooth: true,
//           symbol: 'circle',
//           symbolSize: 8,
//           lineStyle: {
//             width: 3
//           },
//           data: dimensionData,
//           emphasis: {
//             focus: 'series',
//             blurScope: 'coordinateSystem',
//             lineStyle: {
//               width: 4
//             },
//             symbolSize: 10
//           }
//         };
//       })
//     );

//     return { dimensions, categories, series };
//   };

//   const { dimensions, categories, series } = processData();

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const selectedTheme = getSelectedTheme(theme);

//   const option: EChartsOption = {
//     animation: false,
//     tooltip: {
//       trigger: 'axis',
//       formatter: function(params: any[]) {
//         if (!params || params.length === 0) return '';

//         const firstParam = params[0];
//         const itemData = firstParam.data.itemData;
//         console.log("itemData",itemData);
//         // Format date for display
//         const xAxisColumn = data.chartRequest.params.form_data.x_axis.name;
//         const date = new Date(itemData[xAxisColumn]);
//         const formattedDate = date.toLocaleDateString() + ' ' + date.toLocaleTimeString();

//         // Create tooltip content
//         let tooltip = `<div style="font-weight: bold; margin-bottom: 4px;">${formattedDate}</div>`;

//         // Add all data columns
//         Object.entries(itemData).forEach(([key, value]) => {
//           // Format date values
//           const displayValue = key.toLowerCase().includes('time') || key.toLowerCase().includes('date')
//             ? new Date(value as string).toLocaleString()
//             : value;

//           tooltip += `
//             <div style="display: flex; justify-content: space-between; margin: 2px 0;">
//               <span style="color: #666;">${key}:</span>
//               <span style="margin-left: 12px; font-weight: ${
//                 data.chartRequest.params.queries[0].metrics.some(m => m.column.column_name === key) 
//                 ? 'bold' : 'normal'
//               }">${displayValue}</span>
//             </div>`;
//         });

//         return tooltip;
//       }
//     },
//     legend: {
//       show: data.showLegend,
//       type: data.legendType,
//       orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' ? 'vertical' : 'horizontal',
//       top: data.legendOrientation === 'top' ? '0' : 'auto',
//       bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//       left: data.legendOrientation === 'left' ? '0' : 'auto',
//       right: data.legendOrientation === 'right' ? '0' : 'auto',
//       textStyle: {
//         fontSize: 12
//       },
//       itemWidth: 15,
//       itemHeight: 10,
//       pageButtonPosition: 'end',
//       selector: false,
//       selectedMode: true,
//       emphasis: {
//         selectorLabel: {
//           show: true
//         }
//       }
//     },
//     grid: {
//       left: '3%',
//       right: '4%',
//       bottom: '15%',
//       top: data.legendOrientation === 'top' ? '15%' : '8%',
//       containLabel: true
//     },
//     xAxis: {
//       type: 'time',
//       boundaryGap: ['5%', '5%'],
//       // data: categories.map(date => new Date(date).toLocaleDateString()),
//     },
//     yAxis: {
//       type: 'value',
//       axisLabel: {
//         formatter: (value: number) => value.toFixed(2)
//       },
//       splitLine: {
//         show: true,
//         lineStyle: {
//           type: 'dashed'
//         }
//       }
//     },
//     series: series,
//     dataZoom: [
//       {
//         type: 'slider',
//         show: data.showDataZoom,
//         start: 0,
//         end: 100,
//         height: 30,
//         bottom: 5,
//         brushSelect: true,
//         zoomLock: false,
//         moveOnMouseMove: true
//       },
//       {
//         type: 'inside',
//         start: 0,
//         end: 100,
//         zoomOnMouseWheel: true,
//         moveOnMouseMove: true
//       }
//     ],
//     color: selectedTheme.color,
//   };

//   return (
//     <div ref={containerRef} className="flex flex-col h-full">
//       <div className="relative" style={{ height: '400px', width: '100%' }}>
//         <div className="absolute top-2 right-2 flex items-center space-x-2 z-10">
//           <div className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
//             {data.chartData.length} rows
//           </div>
//         </div>
//         <EChartsReact
//           ref={chartRef}
//           option={option}
//           style={{ height: '100%', width: '100%' }}
//           theme={selectedTheme}
//           notMerge={true}
//           lazyUpdate={false}
//           opts={{ renderer: 'canvas' }}
//         />
//       </div>

//       {!data.hideDataTable && (
//         <div className="mt-4">
//           <Tabs defaultValue="results">
//             <TabsList>
//               <TabsTrigger value="results">RESULTS</TabsTrigger>
//             </TabsList>
//             <TabsContent value="results" className="h-64 overflow-auto">
//               <LineDataTable data={data.chartData} />
//             </TabsContent>
//           </Tabs>
//         </div>
//       )}
//     </div>
//   );
// };

// export default Line;


// import React, { useEffect, useState, useRef } from 'react';
// import EChartsReact from 'echarts-for-react';
// import LineDataTable from './LineDataTable';
// import { EChartsOption, SeriesOption } from 'echarts';
// import { Tabs, TabsList, TabsTrigger, TabsContent } from '../../../../../../@/components/ui/tabs';
// import { Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine, Westeros } from '../../../_Chart/ChartTheme/ChartTheme';

// interface ChartRequest {
//   params: {
//     form_data: {
//       x_axis: {
//         name: string;
//       };
//       groupby: Array<{
//         name: string;
//       }>;
//     };
//     queries: Array<{
//       metrics: Array<{
//         column: {
//           column_name: string;
//         };
//         label: string;
//       }>;
//     }>;
//   };
// }

// interface LineProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: ChartRequest;
//     showDataZoom: boolean;
//     hideDataTable?: boolean;
//   };
//   theme: string;
// }

// const Line: React.FC<LineProps> = ({ data, theme }) => {
//   const chartRef = useRef<EChartsReact>(null);
//   const containerRef = useRef<HTMLDivElement>(null);
//   const [containerSize, setContainerSize] = useState({ width: 0, height: 0 });

//   useEffect(() => {
//     const resizeObserver = new ResizeObserver(entries => {
//       for (let entry of entries) {
//         const { width, height } = entry.contentRect;
//         setContainerSize({ width, height });
//       }
//     });

//     if (containerRef.current) {
//       resizeObserver.observe(containerRef.current);
//     }

//     return () => {
//       resizeObserver.disconnect();
//     };
//   }, []);

//   useEffect(() => {
//     if (chartRef.current) {
//       chartRef.current.getEchartsInstance().resize();
//     }
//   }, [containerSize]);

//   const processData = () => {
//     if (!data.chartData || data.chartData.length === 0) return { dimensions: [], categories: [], series: [] };

//     const chartRequest = data.chartRequest;
    
//     // Get x-axis column name from chart request
//     const xAxisColumn = chartRequest.params.form_data.x_axis.name;
    
//     // Get dimension columns from groupby in chart request
//     const dimensionColumns = chartRequest.params.form_data.groupby.map(group => group.name);
    
//     // Get metric columns from metrics in chart request
//     const metricColumns = chartRequest.params.queries[0].metrics.map(metric => metric.column.column_name);

//     // Get unique dimensions
//     const dimensions = dimensionColumns.length > 0
//       ? Array.from(new Set(data.chartData.map(item => item[dimensionColumns[0]])))
//       : [''];

//     // Get unique categories (time values) and sort them
//     const categories = Array.from(new Set(data.chartData.map(item => item[xAxisColumn])))
//       .sort((a, b) => new Date(a).getTime() - new Date(b).getTime());

//     // Create series for each dimension and metric combination
//     const series: SeriesOption[] = dimensions.flatMap(dimension => 
//       metricColumns.map(metric => {
//         const dimensionData = data.chartData
//           .filter(item => dimensionColumns.length === 0 || item[dimensionColumns[0]] === dimension)
//           .sort((a, b) => new Date(a[xAxisColumn]).getTime() - new Date(b[xAxisColumn]).getTime())
//           .map(item => ({
//             name: new Date(item[xAxisColumn]).toLocaleDateString(),
//             value: Number(item[metric]),
//             itemData: item
//           }));

//         const seriesName = dimensionColumns.length > 0 
//           ? `${dimension} - ${metric}` 
//           : metric;

//         return {
//           name: seriesName,
//           type: 'line',
//           smooth: true,
//           symbol: 'circle',
//           symbolSize: 8,
//           lineStyle: {
//             width: 3
//           },
//           data: dimensionData,
//           emphasis: {
//             focus: 'series',
//             blurScope: 'coordinateSystem',
//             lineStyle: {
//               width: 4
//             },
//             symbolSize: 10
//           }
//         };
//       })
//     );

//     return { dimensions, categories, series };
//   };

//   const { dimensions, categories, series } = processData();

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const selectedTheme = getSelectedTheme(theme);

//   const option: EChartsOption = {
//     animation: false,
//     tooltip: {
//       trigger: 'axis',
//       formatter: function(params: any[]) {
//         if (!params || params.length === 0) return '';

//         const firstParam = params[0];
//         const itemData = firstParam.data.itemData;
        
//         // Format date for display
//         const xAxisColumn = data.chartRequest.params.form_data.x_axis.name;
//         const date = new Date(itemData[xAxisColumn]);
//         const formattedDate = date.toLocaleDateString() + ' ' + date.toLocaleTimeString();

//         // Create tooltip content
//         let tooltip = `<div style="font-weight: bold; margin-bottom: 4px;">${formattedDate}</div>`;

//         // Add all data columns
//         Object.entries(itemData).forEach(([key, value]) => {
//           // Format date values
//           const displayValue = key.toLowerCase().includes('time') || key.toLowerCase().includes('date')
//             ? new Date(value as string).toLocaleString()
//             : value;

//           tooltip += `
//             <div style="display: flex; justify-content: space-between; margin: 2px 0;">
//               <span style="color: #666;">${key}:</span>
//               <span style="margin-left: 12px; font-weight: ${
//                 data.chartRequest.params.queries[0].metrics.some(m => m.column.column_name === key) 
//                 ? 'bold' : 'normal'
//               }">${displayValue}</span>
//             </div>`;
//         });

//         return tooltip;
//       }
//     },
//     legend: {
//       show: data.showLegend,
//       type: data.legendType,
//       orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' ? 'vertical' : 'horizontal',
//       top: data.legendOrientation === 'top' ? '0' : 'auto',
//       bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//       left: data.legendOrientation === 'left' ? '0' : 'auto',
//       right: data.legendOrientation === 'right' ? '0' : 'auto',
//       textStyle: {
//         fontSize: 12
//       },
//       itemWidth: 15,
//       itemHeight: 10,
//       pageButtonPosition: 'end',
//       selector: false,
//       selectedMode: true,
//       emphasis: {
//         selectorLabel: {
//           show: true
//         }
//       }
//     },
//     grid: {
//       left: '3%',
//       right: '4%',
//       bottom: '15%',
//       top: data.legendOrientation === 'top' ? '15%' : '8%',
//       containLabel: true
//     },
//     xAxis: {
//       type: 'time',
//       boundaryGap: ['5%', '5%']
//     },
//     yAxis: {
//       type: 'value',
//       axisLabel: {
//         formatter: (value: number) => value.toFixed(2)
//       },
//       splitLine: {
//         show: true,
//         lineStyle: {
//           type: 'dashed'
//         }
//       }
//     },
//     series: series,
//     dataZoom: [
//       {
//         type: 'slider',
//         show: data.showDataZoom,
//         start: 0,
//         end: 100,
//         height: 30,
//         bottom: 5,
//         brushSelect: true,
//         zoomLock: false,
//         moveOnMouseMove: true
//       },
//       {
//         type: 'inside',
//         start: 0,
//         end: 100,
//         zoomOnMouseWheel: true,
//         moveOnMouseMove: true
//       }
//     ],
//     color: selectedTheme.color,
//   };

//   return (
//     <div ref={containerRef} className="flex flex-col h-full">
//       <div className="relative" style={{ height: '400px', width: '100%' }}>
//         <div className="absolute top-2 right-2 flex items-center space-x-2 z-10">
//           <div className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
//             {data.chartData.length} rows
//           </div>
//         </div>
//         <EChartsReact
//           ref={chartRef}
//           option={option}
//           style={{ height: '100%', width: '100%' }}
//           theme={selectedTheme}
//           notMerge={true}
//           lazyUpdate={false}
//           opts={{ renderer: 'canvas' }}
//         />
//       </div>

//       {!data.hideDataTable && (
//         <div className="mt-4">
//           <Tabs defaultValue="results">
//             <TabsList>
//               <TabsTrigger value="results">RESULTS</TabsTrigger>
//             </TabsList>
//             <TabsContent value="results" className="h-64 overflow-auto">
//               <LineDataTable data={data.chartData} />
//             </TabsContent>
//           </Tabs>
//         </div>
//       )}
//     </div>
//   );
// };

// export default Line;

// import React, { useEffect, useState, useRef } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import LineDataTable from './LineDataTable';
// import { LineSeriesOption } from 'echarts/charts';
// import { EChartsOption } from 'echarts-for-react';

// interface LineProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//     hideDataTable?: boolean;
//   };
//   theme: string;
// }

// const Line: React.FC<LineProps> = ({ data, theme }) => {
//   const chartRef = useRef<EChartsReact>(null);
//   const containerRef = useRef<HTMLDivElement>(null);
//   const [containerSize, setContainerSize] = useState({ width: 0, height: 0 });

//   // Add container size observer
//   useEffect(() => {
//     const resizeObserver = new ResizeObserver(entries => {
//       for (let entry of entries) {
//         const { width, height } = entry.contentRect;
//         setContainerSize({ width, height });
//       }
//     });

//     if (containerRef.current) {
//       resizeObserver.observe(containerRef.current);
//     }

//     return () => {
//       resizeObserver.disconnect();
//     };
//   }, []);

//   // Resize chart on container size change
//   useEffect(() => {
//     if (chartRef.current) {
//       chartRef.current.getEchartsInstance().resize();
//     }
//   }, [containerSize]);

//   const formatValue = (value: any): string => {
//     if (value === null || value === undefined) return '-';
//     return typeof value === 'number'
//       ? new Intl.NumberFormat('en-US', {
//           maximumFractionDigits: 2,
//           notation: Math.abs(value) > 1000000 ? 'compact' : 'standard',
//         }).format(value)
//       : String(value);
//   };

//   const processData = () => {
//     const keys = Object.keys(data.chartData[0] || {});
//     const categoryKey = keys[0];
//     const valueKeys = keys.slice(1);
//     const groupByFields = data.chartRequest?.params?.form_data?.groupby?.map(g => g.name) || [];
//     const hasGroupBy = groupByFields.length > 0;

//     const categories = data.chartData.map(item => String(item[categoryKey]));

//     let series: LineSeriesOption[] = [];

//     if (hasGroupBy) {
//       const dimensionCombinations = Array.from(new Set(
//         data.chartData.map(item => 
//           groupByFields.map(field => item[field]).join(' - ')
//         )
//       ));

//       series = dimensionCombinations.flatMap(dimension =>
//         valueKeys.map(key => ({
//           name: `${dimension} - ${key}`,
//           type: 'line',
//           smooth: true,
//           data: categories.map(category => {
//             const matchingItem = data.chartData.find(item => 
//               String(item[categoryKey]) === category && 
//               groupByFields.map(field => item[field]).join(' - ') === dimension
//             );
//             return matchingItem?.[key] || 0;
//           })
//         }))
//       );
//     } else {
//       series = valueKeys.map(key => ({
//         name: key,
//         type: 'line',
//         smooth: true,
//         data: data.chartData.map(item => Number(item[key]))
//       }));
//     }

//     return { categories, series, hasGroupBy };
//   };

//   const { categories, series, hasGroupBy } = processData();
//   const selectedTheme = getSelectedTheme(theme);

//   const option: EChartsOption = {
//     tooltip: {
//       axisPointer: {
//         type: 'line',
//       },
//       trigger: 'axis',
      // position: function (point, params, dom, rect, size) {
      //   let x = point[0];
      //   let y = point[1];
      //   const container = containerRef.current?.getBoundingClientRect();
      //   const availableWidth = container?.width || 0;
      //   const availableHeight = container?.height || 0;
        
      //   if (x + size.contentSize[0] + 20 > availableWidth) x -= size.contentSize[0] + 20;
      //   else x += 20;
      //   if (y + size.contentSize[1] + 20 > availableHeight) y -= size.contentSize[1] + 20;
      //   else y += 20;
  
      //   return [x, y];
      // },
//       formatter: function (params) {
//         const rowData = data.chartData.find(
//           item => String(item[Object.keys(item)[0]]) === params[0].axisValue
//         );
//         const date = rowData ? rowData[Object.keys(rowData)[0]] : ''; 
        
//         const tooltipContent = [`${date}`];
    
//         params.forEach(param => {
//           const seriesName = param.seriesName;
//           const value = param.value;

//           if (seriesName.includes('region') || value === 'no region') return;
    
//           tooltipContent.push(`${param.marker} ${seriesName}: ${formatValue(value)}`);
//         });
    
//         return tooltipContent.filter(Boolean).join('<br/>'); 
//       }
//     },
//     grid: {
//       left: '3%',
//       right: '4%',
//       bottom: data.showDataZoom ? '15%' : '3%',
//       containLabel: true
//     },
//     legend: {
//       show: data.showLegend,
//       type: data.legendType,
//       top: data.legendOrientation === 'top' ? '0' : 'auto',
//       bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//       left: data.legendOrientation === 'left' ? '0' : 'auto',
//       right: data.legendOrientation === 'right' ? '0' : 'auto',
//     },
//     xAxis: {
//       type: 'category',
//       data: categories,
//       axisLabel: {
//         rotate: 45,
//         interval: 0,
//       }
//     },
//     yAxis: {
//       type: 'value',
//       axisLabel: {
//         formatter: formatValue,
//       },
//     },
//     series: series.map(s => ({
//       ...s,
//       emphasis: {
//         focus: 'series',
//         itemStyle: {
//           shadowBlur: 10,
//           shadowOffsetX: 0,
//           shadowColor: 'rgba(0, 0, 0, 0.5)'
//         }
//       },
//       symbolSize: 6,
//       symbol: 'circle',
//     })),
//     dataZoom: data.showDataZoom ? [
//       {
//         type: 'slider',
//         show: true,
//         start: 0,
//         end: 100,
//         height: 30
//       },
//       {
//         type: 'inside',
//         start: 0,
//         end: 100
//       }
//     ] : [],
//     color: selectedTheme.color,
//   };

//   return (
//     <div ref={containerRef} className="flex flex-col h-full">
//       <div className="relative" style={{ height: '400px', width: '100%' }}>
//         <div className="absolute top-2 right-2 flex items-center space-x-2 z-10">
//           <div className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
//             {data.chartData.length} rows
//           </div>
//         </div>
//         <EChartsReact
//           ref={chartRef}
//           option={option}
//            theme={selectedTheme}
//           style={{ height: '100%', width: '100%' }}
//           notMerge={true}
//           lazyUpdate={false}
//           opts={{ renderer: 'canvas' }}
//         />
//       </div>

//       {!data.hideDataTable && (
//         <div className="mt-4">
//           <Tabs defaultValue="results">
//             <TabsList>
//               <TabsTrigger value="results">RESULTS</TabsTrigger>
//             </TabsList>
//             <TabsContent value="results" className="h-64 overflow-auto">
//               <LineDataTable data={data.chartData} />
//             </TabsContent>
//           </Tabs>
//         </div>
//       )}
//     </div>
//   );
// };

// export default Line;

// function getSelectedTheme(themeName: string) {
//   switch (themeName) {
//     case 'Essos': return Essos;
//     case 'Wonderland': return Wonderland;
//     case 'Walden': return Walden;
//     case 'Infographic': return Infographic;
//     case 'Macarons': return Macarons;
//     case 'Roma': return Roma;
//     case 'CoolTheme': return CoolTheme;
//     case 'Shine': return Shine;
//     default: return Westeros;
//   }
// }


// import React, { useEffect, useRef } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import LineDataTable from './LineDataTable';
// import { LineSeriesOption } from 'echarts/charts';
// import { EChartsOption } from 'echarts-for-react';

// interface LineChartProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//     hideDataTable?: boolean;
//     showSymbol?: boolean;
//     smooth?: boolean;
//     areaStyle?: boolean;
//     showMarkLine?: boolean;
//     showMarkPoint?: boolean;
//   };
//   theme: string;
// }

// const LineChart: React.FC<LineChartProps> = ({ data, theme }) => {
//   const chartRef = useRef<EChartsReact>(null);
//   const containerRef = useRef<HTMLDivElement>(null);

//   const formatValue = (value: any): string => {
//     if (value === null || value === undefined) return '-';
    
//     if (typeof value === 'number') {
//       if (Math.abs(value) > 1000000) {
//         return new Intl.NumberFormat('en-US', {
//           notation: 'compact'
//         }).format(value);
//       }
      
//       if (Math.abs(value) < 1) {
//         if (value < 0.5) return '0';
//         if (value >= 0.5) return '1';
//       }
      
//       return new Intl.NumberFormat('en-US', {
//         maximumFractionDigits: 2
//       }).format(value);
//     }
    
//     return String(value);
//   };

//   const processData = () => {
//     const keys = Object.keys(data.chartData[0] || {});
//     const categoryKey = keys[0];
//     const valueKeys = keys.slice(1);
//     const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => g.name) || [];
//     const hasGroupBy = groupByFields.length > 0;
//     const dimensions = groupByFields.length;

//     const uniqueCategories = Array.from(new Set(
//       data.chartData.map(item => String(item[categoryKey]))
//     ));

//     if (hasGroupBy) {
//       const getDimensionKey = (item: any) => 
//         groupByFields.map(field => item[field]).join('|');

//       const uniqueDimensions = Array.from(new Set(
//         data.chartData.map(getDimensionKey)
//       )).map(key => ({
//         key,
//         values: key.split('|')
//       }));

//       const series = uniqueDimensions.flatMap(dimension =>
//         valueKeys.map(metricKey => {
//           const seriesName = dimension.values.join(' - ');
//           const seriesData = uniqueCategories.map(category => {
//             const matchingItem = data.chartData.find(item => 
//               String(item[categoryKey]) === category && 
//               getDimensionKey(item) === dimension.key
//             );

//             return {
//               value: matchingItem?.[metricKey] ?? 0,
//               itemData: matchingItem,
//               dimensions: groupByFields.map((field, index) => ({
//                 field,
//                 value: dimension.values[index]
//               })),
//               metric: metricKey,
//               dimensionDisplay: seriesName
//             };
//           });

//           return {
//             name: `${metricKey},${dimension.values.join(' - ')} :`,
//             type: 'line' as const,
//             data: seriesData,
//             smooth: data.smooth ?? false,
//             showSymbol: data.showSymbol ?? true,
//             symbolSize: 6,
//             ...(data.areaStyle && {
//               areaStyle: {
//                 opacity: 0.1
//               }
//             }),
//             ...(data.showMarkPoint && {
//               markPoint: {
//                 data: [
//                   { type: 'max', name: 'Maximum' },
//                   { type: 'min', name: 'Minimum' }
//                 ]
//               }
//             }),
//             ...(data.showMarkLine && {
//               markLine: {
//                 data: [{ type: 'average', name: 'Average' }]
//               }
//             })
//           };
//         })
//       );

//       return { categories: uniqueCategories, series, hasGroupBy, dimensions };
//     } else {
//       const series: LineSeriesOption[] = valueKeys.map(key => ({
//         name: key,
//         type: 'line',
//         data: uniqueCategories.map(category => {
//           const matchingItem = data.chartData.find(item => 
//             String(item[categoryKey]) === category
//           );
//           return {
//             value: matchingItem ? Number(matchingItem[key]) : 0,
//             itemData: matchingItem,
//             metric: key
//           };
//         }),
//         smooth: data.smooth ?? false,
//         showSymbol: data.showSymbol ?? true,
//         symbolSize: 6,
//         ...(data.areaStyle && {
//           areaStyle: {
//             opacity: 0.1
//           }
//         }),
//         ...(data.showMarkPoint && {
//           markPoint: {
//             data: [
//               { type: 'max', name: 'Maximum' },
//               { type: 'min', name: 'Minimum' }
//             ]
//           }
//         }),
//         ...(data.showMarkLine && {
//           markLine: {
//             data: [{ type: 'average', name: 'Average' }]
//           }
//         })
//       }));

//       return { categories: uniqueCategories, series, hasGroupBy, dimensions: 0 };
//     }
//   };

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };
//   const getGroupByColumns = () => {
//     // Get only the groupby columns from form_data
//     return data.chartRequest.params.form_data.groupby?.map(g => g.name.toLowerCase()) || data.chartRequest.params.form_data.groupby?.map(g => g.label.toLowerCase());
//   };
//   const { categories, series, hasGroupBy, dimensions } = processData();
//   const selectedTheme = getSelectedTheme(theme);
//   const option: EChartsOption = {
//     tooltip: {
//       trigger: 'axis',
//       axisPointer: {
//         type: 'shadow',
//         snap: true,
//         animation: true,
//         shadowStyle: {
//           color: 'rgba(150,150,150,0.1)'
//         }
//       },
//       enterable: true,
//       position: function (point, params, dom, rect, size) {
//         const gap = 20;
//         const chartWidth = containerRef.current?.clientWidth || 0;
//         const chartHeight = containerRef.current?.clientHeight || 0;
//         const tooltipWidth = size.contentSize[0];
//         const tooltipHeight = size.contentSize[1];
        
//         let [x, y] = point;
        
//         if (x + tooltipWidth + gap > chartWidth) {
//           x = x - tooltipWidth - gap;
//         } else {
//           x = x + gap;
//         }
        
//         if (y + tooltipHeight + gap > chartHeight) {
//           y = y - tooltipHeight - gap;
//         } else {
//           y = y + gap;
//         }
        
//         x = Math.max(gap, Math.min(x, chartWidth - tooltipWidth - gap));
//         y = Math.max(gap, Math.min(y, chartHeight - tooltipHeight - gap));
        
//         return [x, y];
//       },
//       backgroundColor: 'rgba(255, 255, 255, 0.95)',
//       borderColor: '#ccc',
//       borderWidth: 1,
//       padding: [8, 12],
//       textStyle: {
//         color: '#333',
//         fontSize: 12
//       },
//       extraCssText: 'box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); border-radius: 4px;',
//       formatter: function(params: any) {
//         if (!Array.isArray(params)) return '';
        
//         const groupByColumns = getGroupByColumns();
        
//         // Filter out params where series name contains any groupby column
//         const filteredParams = params.filter((param: any) => {
//           const seriesName = param.seriesName.toLowerCase();
//           return !groupByColumns.some(column => seriesName.startsWith(column));
//         });

//         // Filter out zero values
//         const nonZeroParams = filteredParams.filter((param: any) => 
//           param.data
//         );
  
//         let tooltipContent = `
//           <div style="margin-bottom: 10px; padding-bottom: 6px; border-bottom: 1px solid #eee;">
//             <span style="font-size: 13px; font-weight: 600; color: #666;">
//               ${params[0].name}
//             </span>
//           </div>
//         `;
  
//         // Group by metric type
//         const metricGroups = new Map();
        
//         nonZeroParams.forEach((param: any) => {
//           const data = param.data;
//           if (!data || !data.metric) return;
          
//           if (!metricGroups.has(data.metric)) {
//             metricGroups.set(data.metric, []);
//           }
          
//           metricGroups.get(data.metric).push({
//             name: param.seriesName,
//             value: data.value,
//             color: param.color,
//             itemData: data.itemData
//           });
//         });
  
//         // Add each metric group to tooltip
//         metricGroups.forEach((items, metric) => {
//           tooltipContent += `
//             <div style="margin-top: 8px;">
//               ${items.map((item: any) => `
//                 <div style="display: flex; justify-content: space-between; align-items: center; margin: 4px 0;">
//                   <div style="display: flex; align-items: center; gap: 6px;">
//                     <span style="color: ${item.color}; font-size: 16px;">●</span>
//                     <span style="color: #666; font-size: 12px;">
//                       ${item.name} ${formatValue(item.value)}
//                     </span>
//                   </div>
//                   <span style="font-size: 12px; color: #666;">
//                   </span>
//                 </div>
//               `).join('')}
//             </div>
//           `;
//         });
  
//         return `
//           <div style="max-height: 200px; overflow-y: auto;">
//             ${tooltipContent}
//           </div>
//         `;
//       }
//     },
//         legend: {
//       show: data.showLegend,
//       type: data.legendType,
//       ...(hasGroupBy ? {
//         orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' 
//           ? 'vertical' 
//           : 'horizontal',
//         top: data.legendOrientation === 'top' ? '0' : 'auto',
//         bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//         left: data.legendOrientation === 'left' ? '0' : 'auto',
//         right: data.legendOrientation === 'right' ? '0' : 'auto',
//         textStyle: {
//           fontSize: 12
//         }
//       } : {
//         top: data.legendOrientation === 'top' ? '0' : 'auto',
//         bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//         left: data.legendOrientation === 'left' ? '0' : 'auto',
//         right: data.legendOrientation === 'right' ? '0' : 'auto',
//       })
//     },
//     grid: {
//       left: '3%',
//       right: '4%',
//       bottom: data.showDataZoom ? '15%' : '3%',
//       top: data.legendOrientation === 'top' ? '15%' : '8%',
//       containLabel: true
//     },
//     xAxis: {
//       type: 'category',
//       boundaryGap: false,
//       data: categories,
//       axisLine: {
//         show: true,
//         lineStyle: {
//           color: '#333',
//           width: 1
//         }
//       },
//       axisTick: {
//         show: true,
//         alignWithLabel: true
//       },
//       axisLabel: {
//         rotate: categories.length > 12 ? 45 : 0,
//         show: true,
//         hideOverlap: true,
//         interval: 'auto'
//       },
//       splitLine: {
//         show: false
//       }
//     },
//     yAxis: {
//       type: 'value',
//       axisLine: {
//         show: true,
//         lineStyle: {
//           color: '#333',
//           width: 1
//         }
//       },
//       axisTick: {
//         show: true
//       },
//       axisLabel: {
//         show: true,
//         formatter: formatValue
//       },
//       splitLine: {
//         show: true,
//         lineStyle: {
//           type: 'dashed',
//           color: '#ddd'
//         }
//       }
//     },
//     series: series,
//     dataZoom: data.showDataZoom ? [
//       {
//         type: 'slider',
//         show: true,
//         start: 0,
//         end: 100,
//         bottom: 10
//       },
//       {
//         type: 'inside',
//         start: 0,
//         end: 100
//       }
//     ] : []
//   };

//   useEffect(() => {
//     if (chartRef.current) {
//       const chart = chartRef.current.getEchartsInstance();
//       chart.resize();
//     }
//   }, [data]);

//   return (
//     <div ref={containerRef} className="w-full h-full flex flex-col">
//       {data.hideDataTable ? (
//         <div className="flex-grow">
//           <EChartsReact
//             ref={chartRef}
//             option={option}
//             theme={selectedTheme}
//             style={{ height: '100%', width: '100%' }}
//             notMerge={true}
//             opts={{ renderer: 'canvas' }}
//           />
//         </div>
//       ) : (
//         <div className="flex-grow">
//           <EChartsReact
//             ref={chartRef}
//             option={option}
//             theme={selectedTheme}
//             style={{ height: '400px', width: '100%' }}
//             notMerge={true}
//             opts={{ renderer: 'canvas' }}
//           />
//         </div>
//       )}

//       {!data.hideDataTable && (
//         <div className="flex-shrink-0 overflow-auto">
//           <Tabs defaultValue="results">
//             <TabsList className="mb-2">
//               <TabsTrigger value="results">RESULTS</TabsTrigger>
//             </TabsList>
//             <TabsContent value="results" className="h-full overflow-auto">
//               <LineDataTable data={data.chartData} />
//             </TabsContent>
//           </Tabs>
//         </div>
//       )}
//     </div>
//   );
// };

// export default LineChart;



import React, { useEffect, useRef } from 'react';
import EChartsReact from 'echarts-for-react';
import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
import LineDataTable from './LineDataTable';
import { EChartsOption } from 'echarts-for-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
import { LineSeriesOption } from 'echarts';

interface LineProps {
  data: {
    chartType: string;
    chartData: Array<Record<string, any>>;
    showLegend: boolean;
    legendOrientation: 'top' | 'bottom' | 'left' | 'right';
    legendType: 'plain' | 'scroll';
    chartRequest: any;
    showDataZoom: boolean;
    hideDataTable?: boolean;
  };
  theme: string;
}

const Line: React.FC<LineProps> = ({ data, theme }) => {
  const chartRef = useRef<EChartsReact>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  
  const formatValue = (value: any): string => {
    if (value === null || value === undefined) return '-';
    
    if (typeof value === 'number') {
      if (Math.abs(value) >= 1000000) {
        return Intl.NumberFormat('en-US', {
          notation: 'compact',
          maximumFractionDigits: 1
        }).format(value);
      }
      
      if (Math.abs(value) < 1) {
        return value.toFixed(2);
      }
      
      return Intl.NumberFormat('en-US', {
        maximumFractionDigits: 2,
        minimumFractionDigits: 0
      }).format(value);
    }
    
    return String(value);
  };

  const processData = () => {
    const keys = Object.keys(data.chartData[0] || {});
    const categoryKey = keys[0];
    const valueKeys = keys.slice(1);
    const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => g.name) || [];
    const hasGroupBy = groupByFields.length > 0;
    const dimensions = groupByFields.length;

    const uniqueCategories = Array.from(new Set(
      data.chartData.map(item => String(item[categoryKey]))
    ));

    if (hasGroupBy) {
      const getDimensionKey = (item: any) => 
        groupByFields.map(field => item[field]).join('|');

      const uniqueDimensions = Array.from(new Set(
        data.chartData.map(getDimensionKey)
      )).map(key => ({
        key,
        values: key.split('|')
      }));

      const series = uniqueDimensions.flatMap(dimension =>
        valueKeys.map(metricKey => ({
          // name: `${dimension.values.join(' - ')} - ${metricKey}`,
          name: `${metricKey},${dimension.values.join(' - ')} `,

          type: 'line' as const,
          emphasis: {
            focus: 'series',
            blurScope: 'series',
            scale: false,
            itemStyle: {
              opacity: 0.7
            }
          },
          select: {
            disabled: true
          },
          data: uniqueCategories.map(category => {
            const matchingItem = data.chartData.find(item => 
              String(item[categoryKey]) === category && 
              getDimensionKey(item) === dimension.key
            );

            return {
              value: matchingItem?.[metricKey] ?? 0,
              itemData: matchingItem,
              dimensions: groupByFields.map((field, index) => ({
                field,
                value: dimension.values[index]
              })),
              metric: metricKey,
              dimensionDisplay: dimension.values.join(' - ')
            };
          })
        }))
      );

      return { categories: uniqueCategories, series, hasGroupBy, dimensions };
    } else {
      const series: LineSeriesOption[] = valueKeys.map(key => ({
        name: key,
        type: 'line',
        emphasis: {
          focus: 'series',
          blurScope: 'series',
          scale: false,
          itemStyle: {
            opacity: 0.7
          }
        },
        select: {
          disabled: true
        },
        data: uniqueCategories.map(category => {
          const matchingItem = data.chartData.find(item => 
            String(item[categoryKey]) === category
          );
          return {
            value: matchingItem ? Number(matchingItem[key]) : 0,
            itemData: matchingItem,
            metric: key
          };
        })
      }));

      return { categories: uniqueCategories, series, hasGroupBy, dimensions: 0 };
    }
  };

  const getSelectedTheme = (themeName: string) => {
    switch (themeName) {
      case 'Essos': return Essos;
      case 'Wonderland': return Wonderland;
      case 'Walden': return Walden;
      case 'Infographic': return Infographic;
      case 'Macarons': return Macarons;
      case 'Roma': return Roma;
      case 'CoolTheme': return CoolTheme;
      case 'Shine': return Shine;
      default: return Westeros;
    }
  };
  const getGroupByColumns = () => {
    // Get only the groupby columns from form_data
    return data.chartRequest.params.form_data.groupby?.map(g => g.name.toLowerCase()) || [];
  };

  const { categories, series, hasGroupBy, dimensions } = processData();
  const selectedTheme = getSelectedTheme(theme);
  const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => g.name) || [];
  const option: EChartsOption = {
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow',
        snap: true,
        animation: true,
        shadowStyle: {
          color: 'rgba(150,150,150,0.1)'
        }
      },
      enterable: true,
      position: function (point, params, dom, rect, size) {
        const gap = 20;
        const chartWidth = containerRef.current?.clientWidth || 0;
        const chartHeight = containerRef.current?.clientHeight || 0;
        const tooltipWidth = size.contentSize[0];
        const tooltipHeight = size.contentSize[1];
        
        let [x, y] = point;
        
        if (x + tooltipWidth + gap > chartWidth) {
          x = x - tooltipWidth - gap;
        } else {
          x = x + gap;
        }
        
        if (y + tooltipHeight + gap > chartHeight) {
          y = y - tooltipHeight - gap;
        } else {
          y = y + gap;
        }
        
        x = Math.max(gap, Math.min(x, chartWidth - tooltipWidth - gap));
        y = Math.max(gap, Math.min(y, chartHeight - tooltipHeight - gap));
        
        return [x, y];
      },
      backgroundColor: 'rgba(255, 255, 255, 0.95)',
      borderColor: '#ccc',
      borderWidth: 1,
      padding: [8, 12],
      textStyle: {
        color: '#333',
        fontSize: 12
      },
      extraCssText: 'box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); border-radius: 4px;',
      formatter: function(params: any) {
        if (!Array.isArray(params)) return '';
        
        const groupByColumns = getGroupByColumns();
        
        // Filter out params where series name contains any groupby column
        const filteredParams = params.filter((param: any) => {
          const seriesName = param.seriesName.toLowerCase();
          return !groupByColumns.some(column => seriesName.startsWith(column));
        });
        
        // Filter out zero values
        const nonZeroParams = filteredParams.filter((param: any) => 
          param.data 
        );
  
        let tooltipContent = `
          <div style="margin-bottom: 10px; padding-bottom: 6px; border-bottom: 1px solid #eee;">
            <span style="font-size: 13px; font-weight: 600; color: #666;">
              ${params[0].name}
            </span>
          </div>
        `;
  
        // Group by metric type
        const metricGroups = new Map();
        
        nonZeroParams.forEach((param: any) => {
          const data = param.data;
          if (!data || !data.metric) return;
          
          if (!metricGroups.has(data.metric)) {
            metricGroups.set(data.metric, []);
          }
          
          metricGroups.get(data.metric).push({
            name: param.seriesName,
            value: data.value,
            color: param.color,
            itemData: data.itemData
          });
        });
  
        // Add each metric group to tooltip
        metricGroups.forEach((items, metric) => {
          tooltipContent += `
            <div style="margin-top: 8px;">
              ${items.map((item: any) => `
                <div style="display: flex; justify-content: space-between; align-items: center; margin: 4px 0;">
                  <div style="display: flex; align-items: center; gap: 6px;">
                    <span style="color: ${item.color}; font-size: 16px;">●</span>
                    <span style="color: #666; font-size: 12px;">
                      ${item.name} : ${formatValue(item.value)}
                    </span>
                  </div>
                  <span style="font-size: 12px; color: #666;">
                  </span>
                </div>
              `).join('')}
            </div>
          `;
        });
  
        return `
          <div style="max-height: 200px; overflow-y: auto;">
            ${tooltipContent}
          </div>
        `;
      }
    },
    legend: {
      show: data.showLegend,
      type: data.legendType,
      ...(hasGroupBy ? {
        orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' 
          ? 'vertical' 
          : 'horizontal',
        top: data.legendOrientation === 'top' ? '0' : 'auto',
        bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
        left: data.legendOrientation === 'left' ? '0' : 'auto',
        right: data.legendOrientation === 'right' ? '0' : 'auto',
        textStyle: {
          fontSize: 12
        }
      } : {
        top: data.legendOrientation === 'top' ? '0' : 'auto',
        bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
        left: data.legendOrientation === 'left' ? '0' : 'auto',
        right: data.legendOrientation === 'right' ? '0' : 'auto',
      })
    },
    grid: {
      left: '3%',
      right: '3%',
      bottom: data.showDataZoom ? '15%' : '3%',
      top: data.legendOrientation === 'top' ? '15%' : '8%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      data: categories,
      axisLine: {
        show: true,
        lineStyle: {
          color: '#333',
          width: 1
        }
      },
      axisTick: {
        show: true,
        alignWithLabel: true
      },
      axisLabel: {
        rotate: categories.length > 12 ? 45 : 0,
        show: true,
        hideOverlap: true,
        interval: 'auto'
      },
      splitLine: {
        show: false
      }
    },
    yAxis: {
      type: 'value',
      axisLine: {
        show: true,
        lineStyle: {
          color: '#333',
          width: 1
        }
      },
      axisTick: {
        show: true
      },
      axisLabel: {
        show: true,
        formatter: formatValue
      },
      splitLine: {
        show: true,
        lineStyle: {
          type: 'dashed',
          color: '#ddd'
        }
      }
    },
    dataZoom: data.showDataZoom ? [
      {
        type: 'slider',
        show: true,
        start: 0,
        end: 100,
        bottom: 10
      },
      {
        type: 'inside',
        start: 0,
        end: 100
      }
    ] : [],
    series
  };
  console.log("series",series);
  console.log("option",option);

  useEffect(() => {
    if (chartRef.current) {
      const chart = chartRef.current.getEchartsInstance();
      chart.resize();
    }
  }, [data]);

  return (
    <div ref={containerRef} className="w-full h-full flex flex-col">
      {data.hideDataTable ? (
        <div className="flex-grow">
          <EChartsReact
            ref={chartRef}
            option={option}
            theme={selectedTheme}
            style={{ height: '100%', width: '100%' }}
            notMerge={true}
            opts={{ renderer: 'canvas' }}
          />
        </div>
      ) : (
        <div className="flex-grow">
          <EChartsReact
            ref={chartRef}
            option={option}
            theme={selectedTheme}
            style={{ height: '400px', width: '100%' }}
            notMerge={true}
            opts={{ renderer: 'canvas' }}
          />
        </div>
      )}

      {!data.hideDataTable && (
        <div className="flex-shrink-0 overflow-auto">
          <Tabs defaultValue="results">
            <TabsList className="mb-2">
              <TabsTrigger value="results">RESULTS</TabsTrigger>
            </TabsList>
            <TabsContent value="results" className="h-full overflow-auto">
              <LineDataTable data={data.chartData} />
            </TabsContent>
          </Tabs>
        </div>
      )}
    </div>
  );
};

export default Line;