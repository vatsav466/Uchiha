// import React, { useEffect, useState } from 'react';
// import ReactECharts from 'echarts-for-react';
// import { Card, CardContent, CardHeader } from '../../../../../../@/components/ui/card';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';

// interface DonutProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//   };
// }

// const Donut: React.FC<DonutProps> = ({ data }) => {
//   const [elapsedTime, setElapsedTime] = useState(0);

//   useEffect(() => {
//     const timer = setInterval(() => {
//       setElapsedTime((prevTime) => prevTime + 1);
//     }, 1000);

//     return () => clearInterval(timer);
//   }, []);

//   const processedData = data.chartData.map(item => {
//     const keys = Object.keys(item);
//     return {
//       name: String(item[keys[0]]),
//       value: Number(item[keys[1]])
//     };
//   }).filter(item => !isNaN(item.value));

//   const option: echarts.EChartsOption = {
//     tooltip: {
//       trigger: 'item',
//       formatter: '{a} <br/>{b}: {c} ({d}%)'
//     },
//     legend: {
//       show: data.showLegend,
//       orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' ? 'vertical' : 'horizontal',
//       [data.legendOrientation]: 10,
//       type: data.legendType,
//     },
//     series: [
//       {
//         name: 'Data',
//         type: 'pie',
//         radius: ['50%', '70%'],
//         avoidLabelOverlap: false,
//         label: {
//           show: false,
//           position: 'center'
//         },
//         emphasis: {
//           label: {
//             show: true,
//             fontSize: '20',
//             fontWeight: 'bold'
//           }
//         },
//         labelLine: {
//           show: false
//         },
//         data: processedData
//       }
//     ]
//   };

//   return (
//     <Card className="w-full h-full">
//       <CardHeader>
//         <div className="flex justify-between items-center">
//           <h3 className="text-lg font-semibold">Data explorer</h3>
//           <span className="text-sm text-gray-500">Last run at 2023-09-21 09:53:19</span>
//         </div>
//       </CardHeader>
//       <CardContent>
//         <div className="flex flex-col h-full">
//           <div className="flex-grow">
//             <ReactECharts option={option} style={{ height: '400px', width: '100%' }} />
//           </div>
//           <Tabs defaultValue="build" className="mt-4">
//             <TabsList>
//               <TabsTrigger value="build">Build</TabsTrigger>
//               <TabsTrigger value="data">Data</TabsTrigger>
//             </TabsList>
//             <TabsContent value="build">
//               {/* Add build content here */}
//             </TabsContent>
//             <TabsContent value="data">
//               {/* Add data content here */}
//             </TabsContent>
//           </Tabs>
//         </div>
//       </CardContent>
//     </Card>
//   );
// };

// // export default Donut;
// import React, { useEffect, useState } from 'react';
// import ReactECharts from 'echarts-for-react';
// import { Card, CardContent, CardHeader } from '../../../../../../@/components/ui/card';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';

// interface DonutProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//   };
//   theme: string;
// }

// const Donut: React.FC<DonutProps> = ({ data, theme }) => {
//   const [elapsedTime, setElapsedTime] = useState(0);

//   useEffect(() => {
//     const timer = setInterval(() => {
//       setElapsedTime((prevTime) => prevTime + 1);
//     }, 1000);

//     return () => clearInterval(timer);
//   }, []);

//   const processedData = data.chartData.map(item => {
//     const keys = Object.keys(item);
//     return {
//       name: String(item[keys[0]]),
//       value: Number(item[keys[1]])
//     };
//   }).filter(item => !isNaN(item.value));

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const selectedTheme = getSelectedTheme(theme);

//   const option: echarts.EChartsOption = {
//     tooltip: {
//       trigger: 'item',
//       formatter: '{a} <br/>{b}: {c} ({d}%)'
//     },
//     legend: {
//       show: data.showLegend,
//       orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' ? 'vertical' : 'horizontal',
//       [data.legendOrientation]: 10,
//       type: data.legendType,
//     },
//     color: selectedTheme.color,
//     series: [
//       {
//         name: 'Data',
//         type: 'pie',
//         radius: ['50%', '70%'],
//         avoidLabelOverlap: false,
//         label: {
//           show: false,
//           position: 'center'
//         },
//         emphasis: {
//           label: {
//             show: true,
//             fontSize: '20',
//             fontWeight: 'bold'
//           }
//         },
//         labelLine: {
//           show: false
//         },
//         data: processedData
//       }
//     ]
//   };

//   return (
//     <Card className="w-full h-full">
//       <CardHeader>
//         <div className="flex justify-between items-center">
//           <span className="text-sm text-gray-500">Last run at {new Date().toLocaleString()}</span>
//         </div>
//       </CardHeader>
//       <CardContent>
//         <div className="flex flex-col h-full">
//           <div className="flex-grow">
//             <ReactECharts 
//               option={option} 
//               theme={selectedTheme} 
//               style={{ height: '400px', width: '100%' }} 
//             />
//           </div>
//           <Tabs defaultValue="build" className="mt-4">
          
//             <TabsContent value="build">
//               {/* Add build content here */}
//             </TabsContent>
//             <TabsContent value="data">
//               {/* Add data content here */}
//             </TabsContent>
//           </Tabs>
//         </div>
//       </CardContent>
//     </Card>
//   );
// };

// export default Donut;


// import React, { useEffect, useState } from 'react';
// import ReactECharts from 'echarts-for-react';
// import { Card, CardContent, CardHeader } from '../../../../../../@/components/ui/card';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import DonutDataTable from './DonutDataTable';

// interface DonutProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//   };
//   theme: string;
// }

// const Donut: React.FC<DonutProps> = ({ data, theme }) => {
//   const [elapsedTime, setElapsedTime] = useState(0);

//   useEffect(() => {
//     const timer = setInterval(() => {
//       setElapsedTime((prevTime) => prevTime + 1);
//     }, 1000);

//     return () => clearInterval(timer);
//   }, []);

//   const processedData = data.chartData.map(item => {
//     const keys = Object.keys(item);
//     return {
//       name: String(item[keys[0]]),
//       value: Number(item[keys[1]])
//     };
//   }).filter(item => !isNaN(item.value));

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const selectedTheme = getSelectedTheme(theme);

//   const option: echarts.EChartsOption = {
//     tooltip: {
//       trigger: 'item',
//       formatter: '{a} <br/>{b}: {c} ({d}%)'
//     },
//     legend: {
//       show: data.showLegend,
//       orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' ? 'vertical' : 'horizontal',
//       [data.legendOrientation]: 10,
//       type: data.legendType,
//     },
//     color: selectedTheme.color,
//     series: [
//       {
//         name: 'Data',
//         type: 'pie',
//         radius: ['50%', '70%'],
//         avoidLabelOverlap: false,
//         label: {
//           show: false,
//           position: 'center'
//         },
//         emphasis: {
//           label: {
//             show: true,
//             fontSize: '20',
//             fontWeight: 'bold'
//           }
//         },
//         labelLine: {
//           show: false
//         },
//         data: processedData
//       }
//     ]
//   };

//   return (
//     <Card className="w-full h-full flex flex-col">
//       <CardHeader>
//         <div className="flex justify-between items-center">
//           {/* <h3 className="text-lg font-semibold">Data explorer</h3> */}
//           <span className="text-sm text-gray-500">Last run at {new Date().toLocaleString()}</span>
//         </div>
//       </CardHeader>
//       <CardContent className="flex-grow flex flex-col">
//         <div className="mb-4 flex justify-between items-center">
//           <div className="bg-gray-100 text-gray-800 text-sm font-medium rounded-full px-3 py-1">
//             {data.chartData.length} rows
//           </div>
//         </div>
//         <div className="h-[400px] w-full">
//           <ReactECharts 
//             option={option} 
//             theme={selectedTheme} 
//             style={{ height: '100%', width: '100%' }} 
//           />
//         </div>
//         <Tabs defaultValue="results" className="mt-4 flex-grow flex flex-col">
//           <TabsList>
//             <TabsTrigger value="results">RESULTS</TabsTrigger>
//             <TabsTrigger value="samples">SAMPLES</TabsTrigger>
//           </TabsList>
//           <TabsContent value="results" className="flex-grow overflow-auto">
//             <DonutDataTable data={data.chartData} />
//           </TabsContent>
//           <TabsContent value="samples">
//             {/* Add sample content here */}
//           </TabsContent>
//         </Tabs>
//       </CardContent>
//     </Card>
//   );
// };

// // export default Donut;
// import React, { useEffect, useState } from 'react';
// import ReactECharts from 'echarts-for-react';
// import { Card, CardContent, CardHeader } from '../../../../../../@/components/ui/card';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import DonutDataTable from './DonutDataTable';

// interface DonutProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//   };
//   theme: string;
// }

// const Donut: React.FC<DonutProps> = ({ data, theme }) => {
//   const [elapsedTime, setElapsedTime] = useState(0);

//   useEffect(() => {
//     const timer = setInterval(() => {
//       setElapsedTime((prevTime) => prevTime + 1);
//     }, 1000);

//     return () => clearInterval(timer);
//   }, []);

//   const processedData = data.chartData.map(item => {
//     const keys = Object.keys(item);
//     return {
//       name: String(item[keys[0]]),
//       value: Number(item[keys[1]])
//     };
//   }).filter(item => !isNaN(item.value));

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const selectedTheme = getSelectedTheme(theme);

//   const option: echarts.EChartsOption = {
//     tooltip: {
//       trigger: 'item',
//       formatter: '{a} <br/>{b}: {c} ({d}%)'
//     },
//     legend: {
//       show: data.showLegend,
//       orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' ? 'vertical' : 'horizontal',
//       [data.legendOrientation]: 10,
//       type: data.legendType,
//     },
//     color: selectedTheme.color,
//     series: [
//       {
//         name: 'Data',
//         type: 'pie',
//         radius: ['50%', '70%'],
//         avoidLabelOverlap: false,
//         label: {
//           show: false,
//           position: 'center'
//         },
//         emphasis: {
//           label: {
//             show: true,
//             fontSize: '20',
//             fontWeight: 'bold'
//           }
//         },
//         labelLine: {
//           show: false
//         },
//         data: processedData
//       }
//     ]
//   };

//   return (
//     <Card className="w-full h-full flex flex-col">
//       <CardHeader>
//         <div className="flex justify-between items-center">
//           <span className="text-sm text-gray-500">Last run at {new Date().toLocaleString()}</span>
//         </div>
//       </CardHeader>
//       <CardContent className="flex-grow flex flex-col">
//         <div className="mb-4 flex justify-between items-center">
//           <div className="bg-gray-100 text-gray-800 text-sm font-medium rounded-full px-3 py-1">
//             {data.chartData.length} rows
//           </div>
//         </div>
//         <div className="relative" style={{ height: '400px', width: '100%' }}>
//           <ReactECharts 
//             option={option} 
//             theme={selectedTheme} 
//             style={{ height: '100%', width: '100%' }} 
//           />
//         </div>
//         <div className="mt-4">
//           <Tabs defaultValue="results" className="flex-grow flex flex-col">
//             <TabsList>
//               <TabsTrigger value="results">RESULTS</TabsTrigger>
//               <TabsTrigger value="samples">SAMPLES</TabsTrigger>
//             </TabsList>
//             <TabsContent value="results" className="h-64 overflow-auto">
//               <DonutDataTable data={data.chartData} />
//             </TabsContent>
//             <TabsContent value="samples">
//               {/* Add sample content here */}
//             </TabsContent>
//           </Tabs>
//         </div>
//       </CardContent>
//     </Card>
//   );
// };

// export default Donut;

// import React, { useEffect, useRef, useState } from 'react';
// import ReactECharts from 'echarts-for-react';
// import { Card, CardContent, CardHeader } from '../../../../../../@/components/ui/card';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import DonutDataTable from './DonutDataTable';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import EChartsReact from 'echarts-for-react';

// interface DonutProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showLabelLines: boolean;
//     showDataZoom: boolean;
//     hideDataTable?: boolean;

//   };
//   theme: string;
// }

// const Donut: React.FC<DonutProps> = ({ data, theme }) => {
//   const [elapsedTime, setElapsedTime] = useState(0);
//   const chartRef = useRef<EChartsReact>(null);
//   const containerRef = useRef<HTMLDivElement>(null);

//   useEffect(() => {
//     const timer = setInterval(() => {
//       setElapsedTime((prevTime) => prevTime + 1);
//     }, 1000);

//     return () => clearInterval(timer);
//   }, []);

//   const processedData = data.chartData.map(item => {
//     const keys = Object.keys(item);
//     return {
//       name: String(item[keys[0]]),
//       value: Number(item[keys[1]])
//     };
//   }).filter(item => !isNaN(item.value));

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const selectedTheme = getSelectedTheme(theme);

//   const option: echarts.EChartsOption = {
//     tooltip: {
//       trigger: 'item',
//       formatter: '{a} <br/>{b}: {c} ({d}%)',
//       position: function (point, params, dom, rect, size) {
//         return [point[0], point[1]];
//       }
//     },
//     legend: {
//       show: data.showLegend,
//       orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' ? 'vertical' : 'horizontal',
//       [data.legendOrientation]: 10,
//       type: data.legendType,
//     },
//     color: selectedTheme.color,
//     series: [
//       {
//         name: 'Data',
//         type: 'pie',
//         radius: ['50%', '70%'],
//         avoidLabelOverlap: false,
//         label: {
//           show: data.showLabelLines,
//           formatter: data.showLabelLines ? '{b}: {c}' : '{b}',
//           position: data.showLabelLines ? 'outer' : 'inner',
//         },
//         labelLine: {
//           show: data.showLabelLines,
//           length: 15,
//           length2: 10,
//           smooth: true
//         },
//         emphasis: {
//           itemStyle: {
//             shadowBlur: 10,
//             shadowOffsetX: 0,
//             shadowColor: 'rgba(0, 0, 0, 0.5)'
//           }
//         },
//         data: processedData
//       }
//     ],
//     dataZoom: data.showDataZoom ? [
//       {
//         type: 'inside',
//         start: 0,
//         end: 100
//       },
//       {
//         start: 0,
//         end: 100
//       }
//     ] : undefined
//   };

 
//   return (
//     <div ref={containerRef} className="w-full h-full flex flex-col">
//     {data.hideDataTable ? (
//       <div className="flex-grow">
//         <EChartsReact
//           ref={chartRef}
//           option={option}
//           theme={selectedTheme}
//           style={{ height: '100%', width: '100%' }}
//           opts={{ renderer: 'svg' }}
//         />
//       </div>
//     ) : (
//       <div className="flex-grow">
//         <EChartsReact
//           option={option}
//           theme={selectedTheme}
//           style={{ height: '400px', width: '100%' }}
//           opts={{ renderer: 'svg' }}
//         />
//       </div>
//     )}

//     {!data.hideDataTable && (
//       <div className="flex-shrink-0 overflow-auto">
//         <Tabs defaultValue="results">
//           <TabsList className="mb-2">
//             <TabsTrigger value="results">RESULTS</TabsTrigger>
//           </TabsList>
//           <TabsContent value="results" className="h-full overflow-auto">
//             <DonutDataTable data={data.chartData} />
//           </TabsContent>
        
//         </Tabs>
//       </div>
//     )}
//   </div>
// );
// };

// export default Donut;





import React, { useRef, useEffect, useState } from 'react';
import EChartsReact from 'echarts-for-react';
import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
import DonutDataTable from './DonutDataTable';

interface DonutProps {
  data: {
    chartType: string;
    chartData: Array<Record<string, any>>;
    showLegend: boolean;
    legendOrientation: 'top' | 'bottom' | 'left' | 'right';
    legendType: 'plain' | 'scroll';
    chartRequest: any;
    showLabelLines: boolean;
    hideDataTable?: boolean;
  };
  theme: string;
  onChartClick?: (params: any) => void;
}

const Donut: React.FC<DonutProps> = ({ data, theme, onChartClick }) => {
  const chartRef = useRef<EChartsReact>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [containerSize, setContainerSize] = useState({ width: 0, height: 0 });
  const [selectedSegment, setSelectedSegment] = useState<string | null>(null);

  useEffect(() => {
    const resizeObserver = new ResizeObserver(entries => {
      for (let entry of entries) {
        const { width, height } = entry.contentRect;
        setContainerSize({ width, height });
      }
    });

    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }

    return () => {
      resizeObserver.disconnect();
    };
  }, []);

  useEffect(() => {
    if (chartRef.current) {
      chartRef.current.getEchartsInstance().resize();
    }
  }, [containerSize]);

  useEffect(() => {
    if (chartRef.current) {
      const chart = chartRef.current.getEchartsInstance();
      
      chart.on('click', (params) => {
        console.log('Clicked segment:', params);
        setSelectedSegment(params.name);
        
        if (onChartClick) {
          onChartClick(params);
        }
      });

      return () => {
        chart.off('click');
      };
    }
  }, [onChartClick]);

  const processedData = data.chartData.map(item => {
    const keys = Object.keys(item);
    return {
      name: keys.slice(0, -1).map(key => String(item[key])).join(', '),
      value: Number(item[keys[keys.length - 1]])
    };
  }).filter(item => !isNaN(item.value));

  const getSelectedTheme = (themeName: string) => {
    switch (themeName) {
      case 'Essos': return Essos;
      case 'Wonderland': return Wonderland;
      case 'Walden': return Walden;
      case 'Infographic': return Infographic;
      case 'Macarons': return Macarons;
      case 'Roma': return Roma;
      case 'CoolTheme': return CoolTheme;
      case 'Shine': return Shine;
      default: return Westeros;
    }
  };

  const selectedTheme = getSelectedTheme(theme);

  const option: echarts.EChartsOption = {
    tooltip: {
      trigger: 'item',
      formatter: (params: any) => {
        const { name, value, percent } = params;
        return `${name}: ${value.toFixed(2)} (${percent.toFixed(2)}%)`;
      }
    },
    legend: {
      show: data.showLegend,
      orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' ? 'vertical' : 'horizontal',
      [data.legendOrientation]: 10,
      type: data.legendType,
    },
    color: selectedTheme.color,
    series: [
      {
        name: 'Data',
        type: 'pie',
        radius: ['40%', '70%'], // Inner and outer radius to create donut effect
        center: ['50%', '50%'],
        data: processedData,
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
        },
        label: {
          show: data.showLabelLines,
          formatter: '{b}: {c} ({d}%)',
          position: 'outer',
          alignTo: 'none',
          bleedMargin: 5
        },
        labelLine: {
          show: data.showLabelLines,
          length: 15,
          length2: 10,
          smooth: true
        }
      }
    ]
  };

  return (
    <div ref={containerRef} className="w-full h-full flex flex-col">
      {data.hideDataTable ? (
        <div className="flex-grow">
          <EChartsReact
            ref={chartRef}
            option={option}
            theme={selectedTheme}
            style={{ height: '100%', width: '100%' }}
            opts={{ renderer: 'svg' }}
          />
          {selectedSegment && (
            <div className="mt-2 p-2 text-sm text-gray-600">
              Selected segment: {selectedSegment}
            </div>
          )}
        </div>
      ) : (
        <div className="flex-grow">
          <EChartsReact
            ref={chartRef}
            option={option}
            theme={selectedTheme}
            style={{ height: '400px', width: '100%' }}
            opts={{ renderer: 'svg' }}
          />
          {selectedSegment && (
            <div className="mt-2 p-2 text-sm text-gray-600">
              Selected segment: {selectedSegment}
            </div>
          )}
        </div>
      )}

      {!data.hideDataTable && (
        <div className="flex-shrink-0 overflow-auto">
          <Tabs defaultValue="results">
            <TabsList className="mb-2">
              <TabsTrigger value="results">RESULTS</TabsTrigger>
            </TabsList>
            <TabsContent value="results" className="h-full overflow-auto">
              <DonutDataTable data={data.chartData} />
            </TabsContent>
          </Tabs>
        </div>
      )}
    </div>
  );
};

export default Donut;