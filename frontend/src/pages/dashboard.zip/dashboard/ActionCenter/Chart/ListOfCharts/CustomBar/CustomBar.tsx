
// import React from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import CustomBarDataTable from './CustomBarDataTable';
// import { EChartsOption } from 'echarts';

// interface BarProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'horizontal' | 'vertical';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//   };
//   theme: string;
// }

// const CustomBar: React.FC<BarProps> = ({ data, theme }) => {
//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const selectedTheme = getSelectedTheme(theme);

//   // Process data for the chart
//   const categories = data.chartData.map(item => String(Object.values(item)[0]));
//   const values = data.chartData.map(item => Number(Object.values(item)[1]) || 0);

//   const option: EChartsOption = {
//     tooltip: {
//       trigger: 'axis',
//       axisPointer: {
//         type: 'shadow'
//       }
//     },
//     grid: {
//       left: '3%',
//       right: '4%',
//       bottom: '3%',
//       containLabel: true
//     },
//     xAxis: {
//       type: 'value',
//       max: 100
//     },
//     yAxis: {
//       type: 'category',
//       data: values.map(value => `${value}%`), // Display percentages on y-axis
//       axisLabel: {
//         color: '#111'
//       }
//     },
//     series: [{
//       name: 'CPU requests',
//       type: 'bar',
//       data: values.map((value, index) => ({
//         value: value,
//         itemStyle: {
//           color: '#8884d8'
//         },
//         label: {
//           show: true,
//           position: 'insideLeft',
//           formatter: categories[index],
//           color: '#ffffff',
//           fontSize: 12
//         }
//       })),
//     }],
//     backgroundColor: '#ffffff'
//   };

//   return (
//     <div className="flex flex-col h-full bg-white p-4 rounded-lg shadow-md">
//       {/* <h2 className="text-gray-800 text-lg mb-4">CPU requests in % of allocatable</h2> */}
//       <div className="relative" style={{ height: '400px', width: '100%' }}>
//         <div className="absolute top-2 right-2 flex items-center space-x-2 z-10">
//           <div className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
//             {data.chartData.length} rows
//           </div>
//         </div>
//         <EChartsReact
//           option={option}
//           style={{ height: '100%', width: '100%' }}
//           theme={selectedTheme}
//         />
//       </div>
      
//       <div className="mt-4">
//         <Tabs defaultValue="results">
//           <TabsList>
//             <TabsTrigger value="results">RESULTS</TabsTrigger>
//             <TabsTrigger value="samples">SAMPLES</TabsTrigger>
//           </TabsList>
//           <TabsContent value="results" className="h-64 overflow-auto">
//             <CustomBarDataTable data={data.chartData} />
//           </TabsContent>
//           <TabsContent value="samples">
//             {/* Add sample content here */}
//           </TabsContent>
//         </Tabs>
//       </div>
//     </div>
//   );
// };

// export default CustomBar;

// import React from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import CustomBarDataTable from './CustomBarDataTable';
// import { EChartsOption } from 'echarts';

// interface BarProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'horizontal' | 'vertical';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//   };
//   theme: string;
// }

// const CustomBar: React.FC<BarProps> = ({ data, theme }) => {
//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const selectedTheme = getSelectedTheme(theme);

//   // Process data for the chart
//   const categories = data.chartData.map(item => String(Object.values(item)[0]));
//   const values = data.chartData.map(item => Number(Object.values(item)[1]) || 0);
//   const option: EChartsOption = {
//     tooltip: {
//       trigger: 'axis',
//       axisPointer: {
//         type: 'shadow'
//       },
//       formatter: (params: any) => {
//         const category = categories[params[0].dataIndex];  // Extract category name
//         const value = values[params[0].dataIndex];  // Extract value
//         return `${category}: ${value}%`;  // Customize tooltip format
//       }
//     },
//     grid: {
//       left: '3%',
//       right: '4%',
//       bottom: '3%',
//       containLabel: true
//     },
//     xAxis: {
//       type: 'value',
//       max: 100
//     },
//     yAxis: {
//       type: 'category',
//       data: values.map(value => `${value}%`),
//       axisLabel: {
//         color: '#111'
//       }
//     },
//     series: [{
//       name: 'CPU requests',
//       type: 'bar',
//       data: values.map((value, index) => ({
//         value: value,
//         itemStyle: {
//           color: '#8884d8'
//         },
//         label: {
//           show: true,
//           position: 'insideLeft',
//           formatter: categories[index],
//           color: '#ffffff',
//           fontSize: 12
//         }
//       })),
//     }],
//     backgroundColor: '#ffffff'
//   };
  

//   return (
//     <div className="flex flex-col h-full bg-white p-4 rounded-lg shadow-md">
//       {/* <h2 className="text-gray-800 text-lg mb-4">CPU requests in % of allocatable</h2> */}
//       <div className="relative" style={{ height: '400px', width: '100%' }}>
//         <div className="absolute top-2 right-2 flex items-center space-x-2 z-10">
//           <div className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
//             {data.chartData.length} rows
//           </div>
//         </div>
//         <EChartsReact
//           option={option}
//           style={{ height: '100%', width: '100%' }}
//           theme={selectedTheme}
//         />
//       </div>
      
//       <div className="mt-4">
//         <Tabs defaultValue="results">
//           <TabsList>
//             <TabsTrigger value="results">RESULTS</TabsTrigger>
//             <TabsTrigger value="samples">SAMPLES</TabsTrigger>
//           </TabsList>
//           <TabsContent value="results" className="h-64 overflow-auto">
//             <CustomBarDataTable data={data.chartData} />
//           </TabsContent>
//           {/* <TabsContent value="samples"> */}
//             {/* Add sample content here */}
//           {/* </TabsContent> */}
//         </Tabs>
//       </div>
//     </div>
//   );
// };

// export default CustomBar;


// import React, { useEffect, useState } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import CustomBarDataTable from './CustomBarDataTable';
// import { BarSeriesOption } from 'echarts/charts';
// import { EChartsOption } from 'echarts-for-react';

// interface BarProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//     hideDataTable?: boolean;

//   };
//   theme: string;
// }

// const CustomBar: React.FC<BarProps> = ({ data, theme }) => {
//   const [elapsedTime, setElapsedTime] = useState(0);

//   useEffect(() => {
//     const timer = setInterval(() => {
//       setElapsedTime((prevTime) => prevTime + 1);
//     }, 1000);

//     return () => clearInterval(timer);
//   }, []);

//   const processData = () => {
//     const keys = Object.keys(data.chartData[0]);
//     const categoryKey = keys[0];
//     const valueKeys = keys.slice(1);

//     const categories = data.chartData.map(item => String(item[categoryKey]));
//     const series: BarSeriesOption[] = valueKeys.map(key => ({
//       name: key,
//       type: 'bar',
//       data: data.chartData.map(item => Number(item[key]))
//     }));

//     return { categories, series };
//   };

//   const { categories, series } = processData();

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const selectedTheme = getSelectedTheme(theme);

//   const option: EChartsOption = {
//     tooltip: {
//       trigger: 'axis',
//       axisPointer: {
//         type: 'shadow'
//       }
//     },
//     legend: {
//       show: data.showLegend,
//       type: data.legendType,
//       top: data.legendOrientation === 'top' ? '0' : 'auto',
//       bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//       left: data.legendOrientation === 'left' ? '0' : 'auto',
//       right: data.legendOrientation === 'right' ? '0' : 'auto',
//     },
//     grid: {
//       left: '3%',
//       right: '4%',
//       bottom: data.showDataZoom ? '15%' : '3%',
//       top: '8%',
//       containLabel: true
//     },
//     xAxis: {
//       type: 'value'
//     },
//     yAxis: {
//       type: 'category',
//       data: categories,
//       axisTick: {
//         alignWithLabel: true
//       }
//     },
//     series: series,
//     dataZoom: data.showDataZoom ? [
//       {
//         type: 'slider',
//         show: true,
//         start: 0,
//         end: 100,
//         height: 30
//       },
//       {
//         type: 'inside',
//         start: 0,
//         end: 100
//       }
//     ] : [],
//     color: selectedTheme.color
//   };

//   return (
//     <div className="flex flex-col h-full">
//       <div className="relative" style={{ height: '400px', width: '100%' }}>
//         <div className="absolute top-2 right-2 flex items-center space-x-2 z-10">
//           {/* <div className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
//             {data.chartData.length} rows
//           </div> */}
//         </div>
//         <EChartsReact
//           option={option}
//           style={{ height: '100%', width: '100%' }}
//           theme={selectedTheme}
//           notMerge={true}
//           lazyUpdate={false}
//         />
//       </div>
//       {!data.hideDataTable && (

//       <div className="mt-4">
//         <Tabs defaultValue="results">
//           <TabsList>
//             <TabsTrigger value="results">RESULTS</TabsTrigger>
//           </TabsList>
//           <TabsContent value="results" className="h-64 overflow-auto">
//             <CustomBarDataTable data={data.chartData} />
//           </TabsContent>
//         </Tabs>
//       </div>
//       )}
//     </div>
//   );
// };

// // export default CustomBar;
// import React, { useEffect, useState, useRef } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import CustomBarDataTable from './CustomBarDataTable';
// import { EChartsOption, SeriesOption } from 'echarts';

// interface ChartRequest {
//   params: {
//     form_data: {
//       x_axis: {
//         name: string;
//       };
//       groupby: Array<{
//         name: string;
//       }>;
//     };
//     queries: Array<{
//       metrics: Array<{
//         column: {
//           column_name: string;
//         };
//         label: string;
//       }>;
//     }>;
//   };
// }

// interface BarProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: ChartRequest;
//     showDataZoom: boolean;
//     hideDataTable?: boolean;
//   };
//   theme: string;
// }

// const CustomBar: React.FC<BarProps> = ({ data, theme }) => {
//   const chartRef = useRef<EChartsReact>(null);
//   const containerRef = useRef<HTMLDivElement>(null);
//   const [containerSize, setContainerSize] = useState({ width: 0, height: 0 });

//   useEffect(() => {
//     const resizeObserver = new ResizeObserver(entries => {
//       for (let entry of entries) {
//         const { width, height } = entry.contentRect;
//         setContainerSize({ width, height });
//       }
//     });

//     if (containerRef.current) {
//       resizeObserver.observe(containerRef.current);
//     }

//     return () => {
//       resizeObserver.disconnect();
//     };
//   }, []);

//   useEffect(() => {
//     if (chartRef.current) {
//       chartRef.current.getEchartsInstance().resize();
//     }
//   }, [containerSize]);

//   const processData = () => {
//     if (!data.chartData || data.chartData.length === 0) return { dimensions: [], categories: [], series: [] };

//     const chartRequest = data.chartRequest;
    
//     // Get x-axis column name from chart request
//     const xAxisColumn = chartRequest.params.form_data.x_axis.name;
    
//     // Get dimension columns from groupby in chart request
//     const dimensionColumns = chartRequest.params.form_data.groupby.map(group => group.name);
    
//     // Get metric columns from metrics in chart request
//     const metricColumns = chartRequest.params.queries[0].metrics.map(metric => metric.column.column_name);

//     // Get unique dimensions
//     const dimensions = dimensionColumns.length > 0
//       ? Array.from(new Set(data.chartData.map(item => item[dimensionColumns[0]])))
//       : [''];

//     // Get unique categories and sort them
//     const categories = Array.from(new Set(data.chartData.map(item => item[xAxisColumn])));

//     // Create series for each dimension and metric combination
//     const series: SeriesOption[] = dimensions.flatMap(dimension => 
//       metricColumns.map(metric => {
//         const dimensionData = data.chartData
//           .filter(item => dimensionColumns.length === 0 || item[dimensionColumns[0]] === dimension)
//           .map(item => ({
//             name: item[xAxisColumn],
//             value: Number(item[metric]),
//             itemData: item
//           }));

//         const seriesName = dimensionColumns.length > 0 
//           ? `${dimension} - ${metric}` 
//           : metric;

//         return {
//           name: seriesName,
//           type: 'bar',
//           data: dimensionData,
//           emphasis: {
//             focus: 'series',
//             blurScope: 'coordinateSystem'
//           },
//           barMaxWidth: 50,
//           label: {
//             show: false,
//             position: 'top'
//           }
//         };
//       })
//     );

//     return { dimensions, categories, series };
//   };

//   const { dimensions, categories, series } = processData();

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const selectedTheme = getSelectedTheme(theme);

//   const option: EChartsOption = {
//     animation: false,
//     tooltip: {
//       trigger: 'axis',
//       axisPointer: {
//         type: 'shadow'
//       },
//       formatter: function(params: any[]) {
//         if (!params || params.length === 0) return '';

//         const firstParam = params[0];
//         const itemData = firstParam.data.itemData;
        
//         // Create tooltip content
//         let tooltip = `<div style="font-weight: bold; margin-bottom: 4px;">${firstParam.name}</div>`;

//         // Add all data columns
//         Object.entries(itemData).forEach(([key, value]) => {
//           // Format date values
//           const displayValue = key.toLowerCase().includes('time') || key.toLowerCase().includes('date')
//             ? new Date(value as string).toLocaleString()
//             : value;

//           tooltip += `
//             <div style="display: flex; justify-content: space-between; margin: 2px 0;">
//               <span style="color: #666;">${key}:</span>
//               <span style="margin-left: 12px; font-weight: ${
//                 data.chartRequest.params.queries[0].metrics.some(m => m.column.column_name === key) 
//                 ? 'bold' : 'normal'
//               }">${displayValue}</span>
//             </div>`;
//         });

//         return tooltip;
//       }
//     },
//     legend: {
//       show: data.showLegend,
//       type: data.legendType,
//       orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' ? 'vertical' : 'horizontal',
//       top: data.legendOrientation === 'top' ? '0' : 'auto',
//       bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//       left: data.legendOrientation === 'left' ? '0' : 'auto',
//       right: data.legendOrientation === 'right' ? '0' : 'auto',
//       textStyle: {
//         fontSize: 12
//       },
//       itemWidth: 15,
//       itemHeight: 10,
//       pageButtonPosition: 'end',
//       selector: false,
//       selectedMode: true,
//       emphasis: {
//         selectorLabel: {
//           show: true
//         }
//       }
//     },
//     grid: {
//       left: '3%',
//       right: '4%',
//       bottom: '15%',
//       top: data.legendOrientation === 'top' ? '15%' : '8%',
//       containLabel: true
//     },
//     xAxis: {
//       type: 'category',
//       data: categories,
//       axisLabel: {
//         rotate: 45,
//         formatter: (value: string) => value,
//         interval: 'auto',
//         hideOverlap: true
//       }
//     },
//     yAxis: {
//       type: 'value',
//       axisLabel: {
//         formatter: (value: number) => value.toFixed(2)
//       },
//       splitLine: {
//         show: true,
//         lineStyle: {
//           type: 'dashed'
//         }
//       }
//     },
//     series: series,
//     dataZoom: data.showDataZoom ? [
//       {
//         type: 'slider',
//         show: true,
//         start: 0,
//         end: 100,
//         height: 30,
//         bottom: 5,
//         brushSelect: true,
//         zoomLock: false,
//         moveOnMouseMove: true
//       },
//       {
//         type: 'inside',
//         start: 0,
//         end: 100,
//         zoomOnMouseWheel: true,
//         moveOnMouseMove: true
//       }
//     ] : [],
//     color: selectedTheme.color,
//   };

//   return (
//     <div ref={containerRef} className="flex flex-col h-full">
//       <div className="relative" style={{ height: '400px', width: '100%' }}>
//         <div className="absolute top-2 right-2 flex items-center space-x-2 z-10">
//           <div className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
//             {data.chartData.length} rows
//           </div>
//         </div>
//         <EChartsReact
//           ref={chartRef}
//           option={option}
//           style={{ height: '100%', width: '100%' }}
//           theme={selectedTheme}
//           notMerge={true}
//           lazyUpdate={false}
//           opts={{ renderer: 'canvas' }}
//         />
//       </div>

//       {!data.hideDataTable && (
//         <div className="mt-4">
//           <Tabs defaultValue="results">
//             <TabsList>
//               <TabsTrigger value="results">RESULTS</TabsTrigger>
//             </TabsList>
//             <TabsContent value="results" className="h-64 overflow-auto">
//               <CustomBarDataTable data={data.chartData} />
//             </TabsContent>
//           </Tabs>
//         </div>
//       )}
//     </div>
//   );
// };

// export default CustomBar;




// import React, { useEffect, useState, useRef } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import CustomBarDataTable from './CustomBarDataTable';
// import { EChartsOption, SeriesOption } from 'echarts';

// interface ChartRequest {
//   params: {
//     form_data: {
//       x_axis: {
//         name: string;
//       };
//       groupby: Array<{
//         name: string;
//       }>;
//     };
//     queries: Array<{
//       metrics: Array<{
//         column: {
//           column_name: string;
//         };
//         label: string;
//       }>;
//     }>;
//   };
// }

// interface BarProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: ChartRequest;
//     showDataZoom: boolean;
//     hideDataTable?: boolean;
//   };
//   theme: string;
// }

// const CustomBar: React.FC<BarProps> = ({ data, theme }) => {
//   const chartRef = useRef<EChartsReact>(null);
//   const containerRef = useRef<HTMLDivElement>(null);
//   const [containerSize, setContainerSize] = useState({ width: 0, height: 0 });

//   useEffect(() => {
//     const resizeObserver = new ResizeObserver(entries => {
//       for (let entry of entries) {
//         const { width, height } = entry.contentRect;
//         setContainerSize({ width, height });
//       }
//     });

//     if (containerRef.current) {
//       resizeObserver.observe(containerRef.current);
//     }

//     return () => {
//       resizeObserver.disconnect();
//     };
//   }, []);

//   useEffect(() => {
//     if (chartRef.current) {
//       chartRef.current.getEchartsInstance().resize();
//     }
//   }, [containerSize]);

//   const processData = () => {
//     if (!data.chartData || data.chartData.length === 0) return { dimensions: [], categories: [], series: [] };

//     const chartRequest = data.chartRequest;
    
//     // Get x-axis column name from chart request
//     const xAxisColumn = chartRequest.params.form_data.x_axis.name;
    
//     // Get dimension columns from groupby in chart request
//     const dimensionColumns = chartRequest.params.form_data.groupby.map(group => group.name);
    
//     // Get metric columns from metrics in chart request
//     const metricColumns = chartRequest.params.queries[0].metrics.map(metric => metric.column.column_name);

//     // Get unique dimensions
//     const dimensions = dimensionColumns.length > 0
//       ? Array.from(new Set(data.chartData.map(item => item[dimensionColumns[0]])))
//       : [''];

//     // Get unique categories and sort them
//     const categories = Array.from(new Set(data.chartData.map(item => item[xAxisColumn])));

//     // Create series for each dimension and metric combination
//     const series: SeriesOption[] = dimensions.flatMap(dimension => 
//       metricColumns.map(metric => {
//         const dimensionData = data.chartData
//           .filter(item => dimensionColumns.length === 0 || item[dimensionColumns[0]] === dimension)
//           .map(item => ({
//             name: item[xAxisColumn],
//             value: Number(item[metric]),
//             itemData: item
//           }));

//         const seriesName = dimensionColumns.length > 0 
//           ? `${dimension} - ${metric}` 
//           : metric;

//         return {
//           name: seriesName,
//           type: 'bar',
//           data: dimensionData,
//           emphasis: {
//             focus: 'series',
//             blurScope: 'coordinateSystem'
//           },
//           barMaxWidth: 50
//         };
//       })
//     );

//     return { dimensions, categories, series };
//   };

//   const { dimensions, categories, series } = processData();

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const selectedTheme = getSelectedTheme(theme);

//   const option: EChartsOption = {
//     animation: false,
//     tooltip: {
//       trigger: 'axis',
//       axisPointer: {
//         type: 'shadow'
//       },
//       formatter: function(params: any[]) {
//         if (!params || params.length === 0) return '';

//         const firstParam = params[0];
//         const itemData = firstParam.data.itemData;
        
//         // Create tooltip content
//         let tooltip = `<div style="font-weight: bold; margin-bottom: 4px;">${firstParam.name}</div>`;

//         // Add all data columns
//         Object.entries(itemData).forEach(([key, value]) => {
//           // Format date values
//           const displayValue = key.toLowerCase().includes('time') || key.toLowerCase().includes('date')
//             ? new Date(value as string).toLocaleString()
//             : value;

//           tooltip += `
//             <div style="display: flex; justify-content: space-between; margin: 2px 0;">
//               <span style="color: #666;">${key}:</span>
//               <span style="margin-left: 12px; font-weight: ${
//                 data.chartRequest.params.queries[0].metrics.some(m => m.column.column_name === key) 
//                 ? 'bold' : 'normal'
//               }">${displayValue}</span>
//             </div>`;
//         });

//         return tooltip;
//       }
//     },
//     legend: {
//       show: data.showLegend,
//       type: data.legendType,
//       orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' ? 'vertical' : 'horizontal',
//       top: data.legendOrientation === 'top' ? '0' : 'auto',
//       bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//       left: data.legendOrientation === 'left' ? '0' : 'auto',
//       right: data.legendOrientation === 'right' ? '0' : 'auto',
//       textStyle: {
//         fontSize: 12
//       },
//       itemWidth: 15,
//       itemHeight: 10,
//       pageButtonPosition: 'end',
//       selector: false,
//       selectedMode: true,
//       emphasis: {
//         selectorLabel: {
//           show: true
//         }
//       }
//     },
//     grid: {
//       left: '3%',
//       right: '4%',
//       bottom: '15%',
//       top: data.legendOrientation === 'top' ? '15%' : '8%',
//       containLabel: true
//     },
//     xAxis: {
//       type: 'value',
//       axisLabel: {
//         formatter: (value: number) => value.toFixed(2)
//       },
//       splitLine: {
//         show: true,
//         lineStyle: {
//           type: 'dashed'
//         }
//       }
//     },
//     yAxis: {
//       type: 'category',
//       data: categories,
//       axisLabel: {
//         formatter: (value: string) => value,
//         interval: 'auto',
//         hideOverlap: true
//       }
//     },
//     series: series,
//     dataZoom: data.showDataZoom ? [
//       {
//         type: 'slider',
//         show: true,
//         start: 0,
//         end: 100,
//         height: 30,
//         bottom: 5,
//         brushSelect: true,
//         zoomLock: false,
//         moveOnMouseMove: true
//       },
//       {
//         type: 'inside',
//         start: 0,
//         end: 100,
//         zoomOnMouseWheel: true,
//         moveOnMouseMove: true
//       }
//     ] : [],
//     color: selectedTheme.color,
//   };

//   return (
//     <div ref={containerRef} className="flex flex-col h-full">
//       <div className="relative" style={{ height: '400px', width: '100%' }}>
//         <div className="absolute top-2 right-2 flex items-center space-x-2 z-10">
//           <div className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
//             {data.chartData.length} rows
//           </div>
//         </div>
//         <EChartsReact
//           ref={chartRef}
//           option={option}
//           style={{ height: '100%', width: '100%' }}
//           theme={selectedTheme}
//           notMerge={true}
//           lazyUpdate={false}
//           opts={{ renderer: 'canvas' }}
//         />
//       </div>

//       {!data.hideDataTable && (
//         <div className="mt-4">
//           <Tabs defaultValue="results">
//             <TabsList>
//               <TabsTrigger value="results">RESULTS</TabsTrigger>
//             </TabsList>
//             <TabsContent value="results" className="h-64 overflow-auto">
//               <CustomBarDataTable data={data.chartData} />
//             </TabsContent>
//           </Tabs>
//         </div>
//       )}
//     </div>
//   );
// };

// export default CustomBar;


// import React, { useEffect, useRef, useState } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import CustomBarDataTable from './CustomBarDataTable';
// import { BarSeriesOption } from 'echarts/charts';
// import { EChartsOption } from 'echarts-for-react';

// interface CustomBarProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//     hideDataTable?: boolean;
//   };
//   theme: string;
// }

// const CustomBar: React.FC<CustomBarProps> = ({ data, theme }) => {
//   const chartRef = useRef<EChartsReact>(null);
//   const containerRef = useRef<HTMLDivElement>(null);

//   const formatValue = (value: any): string => {
//     if (value === null || value === undefined) return '-';
    
//     if (typeof value === 'number') {
//       return new Intl.NumberFormat('en-US', {
//         maximumFractionDigits: 2,
//         notation: Math.abs(value) > 1000000 ? 'compact' : 'standard'
//       }).format(value);
//     }
    
//     return String(value);
//   };

//   const processData = () => {
//     const keys = Object.keys(data.chartData[0] || {});
//     const categoryKey = keys[0];
//     const valueKeys = keys.slice(1);
//     const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => g.name) || [];
//     const hasGroupBy = groupByFields.length > 0;
//     const dimensions = groupByFields.length;

//     const categories = data.chartData.map(item => String(item[categoryKey]));
    
//     if (hasGroupBy) {
//       const getDimensionValue = (item: any) => 
//         groupByFields.map(field => ({
//           field,
//           value: item[field]
//         }));

//       const dimensionCombinations = Array.from(new Set(
//         data.chartData.map(item => 
//           groupByFields.map(field => item[field]).join(' - ')
//         )
//       ));

//       const series = dimensionCombinations.flatMap(dimension =>
//         valueKeys.map(key => ({
//           name: `${dimension} - ${key}`,
//           type: 'bar' as const,
//           data: categories.map(category => {
//             const matchingItem = data.chartData.find(item => 
//               String(item[categoryKey]) === category && 
//               groupByFields.map(field => item[field]).join(' - ') === dimension
//             );

//             return {
//               value: matchingItem?.[key] || 0,
//               itemData: matchingItem,
//               dimensions: getDimensionValue(matchingItem || {}),
//               metric: key,
//               dimensionDisplay: dimension
//             };
//           })
//         }))
//       );

//       return { categories, series, hasGroupBy, dimensions };
//     } else {
//       const series: BarSeriesOption[] = valueKeys.map(key => ({
//         name: key,
//         type: 'bar',
//         data: data.chartData.map(item => ({
//           value: Number(item[key]),
//           itemData: item,
//           metric: key
//         }))
//       }));

//       return { categories, series, hasGroupBy, dimensions: 0 };
//     }
//   };

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const { categories, series, hasGroupBy, dimensions } = processData();
//   const selectedTheme = getSelectedTheme(theme);
//   const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => g.name) || [];

//   const option: EChartsOption = {
//     tooltip: {
//       trigger: 'item',
//       axisPointer: {
//         type: 'shadow',
//         snap: true,
//         animation: true,
//         shadowStyle: {
//           color: 'rgba(150,150,150,0.1)'
//         }
//       },
//       backgroundColor: 'rgba(255, 255, 255, 0.9)',
//       borderColor: '#ccc',
//       borderWidth: 1,
//       padding: [5, 10],
//       textStyle: {
//         color: '#333'
//       },
//       extraCssText: 'box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);',
//       formatter: function(params: any) {
//         if (!params.data) return '';

//         const xAxisField = data.chartRequest.params.form_data.x_axis.name;
//         const xAxisLabel = data.chartRequest.params.form_data.x_axis.label || xAxisField;
        
//         let tooltipContent = `
//           <div style="font-weight: bold; margin-bottom: 8px;">
//             ${xAxisLabel}: ${params.name}
//           </div>
//         `;

//         if (hasGroupBy) {
//           if (dimensions === 1) {
//             tooltipContent += `
//               <div style="margin: 4px 0;">
//                 <div style="font-weight: bold; color: #666;">
//                   ${groupByFields[0]}: ${params.data.dimensions[0].value}
//                 </div>
//                 <div style="display: flex; justify-content: space-between; margin: 4px 0;">
//                   <span style="color: ${params.color};">● ${params.data.metric}:</span>
//                   <span style="margin-left: 12px;">${formatValue(params.data.value)}</span>
//                 </div>
//               </div>
//             `;
//           } else if (dimensions === 2) {
//             tooltipContent += `
//               <div style="margin: 4px 0;">
//                 <div style="font-weight: bold; color: #666;">
//                   ${groupByFields[0]}: ${params.data.dimensions[0].value}
//                 </div>
//                 <div style="font-weight: bold; color: #666;">
//                   ${groupByFields[1]}: ${params.data.dimensions[1].value}
//                 </div>
//                 <div style="display: flex; justify-content: space-between; margin: 4px 0;">
//                   <span style="color: ${params.color};">● ${params.data.metric}:</span>
//                   <span style="margin-left: 12px;">${formatValue(params.data.value)}</span>
//                 </div>
//               </div>
//             `;
//           } else {
//             tooltipContent += `<div style="margin: 4px 0;">`;
//             params.data.dimensions.forEach((dim: any) => {
//               tooltipContent += `
//                 <div style="font-weight: bold; color: #666;">
//                   ${dim.field}: ${dim.value}
//                 </div>
//               `;
//             });
//             tooltipContent += `
//               <div style="display: flex; justify-content: space-between; margin: 4px 0;">
//                 <span style="color: ${params.color};">● ${params.data.metric}:</span>
//                 <span style="margin-left: 12px;">${formatValue(params.data.value)}</span>
//               </div>
//             </div>
//             `;
//           }
//         } else {
//           tooltipContent += `
//             <div style="display: flex; justify-content: space-between; margin: 4px 0;">
//               <span style="color: ${params.color};">● ${params.seriesName}:</span>
//               <span style="margin-left: 12px;">${formatValue(params.data.value)}</span>
//             </div>
//           `;
//         }

//         return tooltipContent;
//       }
//     },
//     series: series.map(s => ({
//       ...s,
//       emphasis: {
//         focus: 'self',
//         blurScope: 'none'
//       },
//       tooltip: {
//         show: true
//       }
//     })),
//     legend: {
//       show: data.showLegend,
//       type: data.legendType,
//       ...(hasGroupBy ? {
//         orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' 
//           ? 'vertical' 
//           : 'horizontal',
//         top: data.legendOrientation === 'top' ? '0' : 'auto',
//         bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//         left: data.legendOrientation === 'left' ? '0' : 'auto',
//         right: data.legendOrientation === 'right' ? '0' : 'auto',
//         textStyle: {
//           fontSize: 12
//         }
//       } : {
//         top: data.legendOrientation === 'top' ? '0' : 'auto',
//         bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//         left: data.legendOrientation === 'left' ? '0' : 'auto',
//         right: data.legendOrientation === 'right' ? '0' : 'auto',
//       })
//     },
    
//         grid: {
//           left: '8%',      // Increased left margin for y-axis datazoom
//           right: '8%',     // Increased right margin
//           bottom: data.showDataZoom ? '15%' : '3%',
//           top: data.legendOrientation === 'top' ? '15%' : '8%',
//           containLabel: true
//         },
//         yAxis: {
//           type: 'category',
//           data: categories,
//           axisLine: {
//             show: true,
//             lineStyle: {
//               color: '#333',
//               width: 1
//             }
//           },
//           axisTick: {
//             show: true,
//             alignWithLabel: true
//           },
//           axisLabel: {
//             show: true,
//             hideOverlap: true
//           },
//           splitLine: {
//             show: false
//           }
//         },
//         xAxis: {
//           type: 'value',
//           axisLine: {
//             show: true,
//             lineStyle: {
//               color: '#333',
//               width: 1
//             }
//           },
//           axisTick: {
//             show: true
//           },
//           axisLabel: {
//             show: true,
//             formatter: formatValue
//           },
//           splitLine: {
//             show: true,
//             lineStyle: {
//               type: 'dashed',
//               color: '#ddd'
//             }
//           }
//         },
//         dataZoom: data.showDataZoom ? [
//           {
//             show: true,
//             start: 94,
//             end: 100
//           },
//           {
//             type: 'inside',
//             start: 94,
//             end: 100
//           },
//           {
//             show: true,
//             yAxisIndex: 0,
//             filterMode: 'empty',
//             width: 30,
//             height: '80%',
//             showDataShadow: false,
//             left: '93%'
//           }
//         ] : []
//       };
    

//   useEffect(() => {
//     if (chartRef.current) {
//       const chart = chartRef.current.getEchartsInstance();
//       chart.resize();
//     }
//   }, [data]);

//   return (
//     <div ref={containerRef} className="w-full h-full flex flex-col">
//       {data.hideDataTable ? (
//         <div className="flex-grow">
//           <EChartsReact
//             ref={chartRef}
//             option={option}
//             theme={selectedTheme}
//             style={{ height: '100%', width: '100%' }}
//             notMerge={true}
//             opts={{ renderer: 'canvas' }}
//           />
//         </div>
//       ) : (
//         <div className="flex-grow">
//           <EChartsReact
//             ref={chartRef}
//             option={option}
//             theme={selectedTheme}
//             style={{ height: '400px', width: '100%' }}
//             notMerge={true}
//             opts={{ renderer: 'canvas' }}
//           />
//         </div>
//       )}

//       {!data.hideDataTable && (
//         <div className="flex-shrink-0 overflow-auto">
//           <Tabs defaultValue="results">
//             <TabsList className="mb-2">
//               <TabsTrigger value="results">RESULTS</TabsTrigger>
//             </TabsList>
//             <TabsContent value="results" className="h-full overflow-auto">
//               <CustomBarDataTable data={data.chartData} />
//             </TabsContent>
//           </Tabs>
//         </div>
//       )}
//     </div>
//   );
// };

// export default CustomBar;




// import React, { useEffect, useRef } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import CustomBarDataTable from './CustomBarDataTable';
// import { BarSeriesOption } from 'echarts/charts';
// import { EChartsOption } from 'echarts-for-react';

// interface HorizontalBarProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//     hideDataTable?: boolean;
//   };
//   theme: string;
// }

// const CustomBar: React.FC<HorizontalBarProps> = ({ data, theme }) => {
//   const chartRef = useRef<EChartsReact>(null);
//   const containerRef = useRef<HTMLDivElement>(null);

//   const formatValue = (value: any): string => {
//     if (value === null || value === undefined) return '-';
    
//     if (typeof value === 'number') {
//       if (Math.abs(value) > 1000000) {
//         return new Intl.NumberFormat('en-US', {
//           notation: 'compact'
//         }).format(value);
//       }
      
//       if (Math.abs(value) < 1) {
//         if (value < 0.5) return '0';
//         if (value >= 0.5) return '1';
//       }
      
//       return new Intl.NumberFormat('en-US', {
//         maximumFractionDigits: 2
//       }).format(value);
//     }
    
//     return String(value);
//   };

//   const processData = () => {
//     const keys = Object.keys(data.chartData[0] || {});
//     const categoryKey = keys[0];
//     const valueKeys = keys.slice(1);
//     const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => g.name) || [];
//     const hasGroupBy = groupByFields.length > 0;
//     const dimensions = groupByFields.length;

//     const uniqueCategories = Array.from(new Set(
//       data.chartData.map(item => String(item[categoryKey]))
//     ));

//     if (hasGroupBy) {
//       const getDimensionKey = (item: any) => 
//         groupByFields.map(field => item[field]).join('|');

//       const uniqueDimensions = Array.from(new Set(
//         data.chartData.map(getDimensionKey)
//       )).map(key => ({
//         key,
//         values: key.split('|')
//       }));

//       const series = uniqueDimensions.flatMap(dimension =>
//         valueKeys.map(metricKey => {
//           const seriesName = dimension.values.join(' - ');
//           return {
//             name: `${seriesName} - ${metricKey}`,
//             type: 'bar' as const,
//             data: uniqueCategories.map(category => {
//               const matchingItem = data.chartData.find(item => 
//                 String(item[categoryKey]) === category && 
//                 getDimensionKey(item) === dimension.key
//               );

//               return {
//                 value: matchingItem?.[metricKey] ?? 0,
//                 itemData: matchingItem,
//                 dimensions: groupByFields.map((field, index) => ({
//                   field,
//                   value: dimension.values[index]
//                 })),
//                 metric: metricKey,
//                 dimensionDisplay: seriesName
//               };
//             })
//           };
//         })
//       );

//       return { categories: uniqueCategories, series, hasGroupBy, dimensions };
//     } else {
//       const series: BarSeriesOption[] = valueKeys.map(key => ({
//         name: key,
//         type: 'bar',
//         data: uniqueCategories.map(category => {
//           const matchingItem = data.chartData.find(item => 
//             String(item[categoryKey]) === category
//           );
//           return {
//             value: matchingItem ? Number(matchingItem[key]) : 0,
//             itemData: matchingItem,
//             metric: key
//           };
//         })
//       }));

//       return { categories: uniqueCategories, series, hasGroupBy, dimensions: 0 };
//     }
//   };

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const { categories, series, hasGroupBy, dimensions } = processData();
//   const selectedTheme = getSelectedTheme(theme);

//   const option: EChartsOption = {
//     tooltip: {
//       trigger: 'item',
//       axisPointer: {
//         type: 'shadow',
//         snap: true,
//         animation: true,
//         shadowStyle: {
//           color: 'rgba(150,150,150,0.1)'
//         }
//       },
//       backgroundColor: 'rgba(255, 255, 255, 0.9)',
//       borderColor: '#ccc',
//       borderWidth: 1,
//       padding: [5, 10],
//       textStyle: {
//         color: '#333'
//       },
//       extraCssText: 'box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);',
//       formatter: function(params: any) {
//         if (!params.data) return '';

//         const xAxisField = data.chartRequest.params.form_data.x_axis.name;
//         const xAxisLabel = data.chartRequest.params.form_data.x_axis.label || xAxisField;
        
//         let tooltipContent = `
//           <div style="font-weight: bold; margin-bottom: 8px;">
//             ${xAxisLabel}: ${params.name}
//           </div>
//         `;

//         if (hasGroupBy) {
//           tooltipContent += `<div style="margin: 4px 0;">`;
//           params.data.dimensions.forEach((dim: any) => {
//             tooltipContent += `
//               <div style="font-weight: bold; color: #666;">
//                 ${dim.field}: ${dim.value}
//               </div>
//             `;
//           });
//           tooltipContent += `
//             <div style="display: flex; justify-content: space-between; margin: 4px 0;">
//               <span style="color: ${params.color};">● ${params.data.metric}:</span>
//               <span style="margin-left: 12px;">${formatValue(params.data.value)}</span>
//             </div>
//           </div>`;
//         } else {
//           tooltipContent += `
//             <div style="display: flex; justify-content: space-between; margin: 4px 0;">
//               <span style="color: ${params.color};">● ${params.seriesName}:</span>
//               <span style="margin-left: 12px;">${formatValue(params.data.value)}</span>
//             </div>
//           `;
//         }

//         return tooltipContent;
//       }
//     },
//     series: series.map(s => ({
//       ...s,
//       emphasis: {
//         focus: 'series',
//         blurScope: 'coordinateSystem'
//       },
//       tooltip: {
//         show: true
//       }
//     })),
//     legend: {
//       show: data.showLegend,
//       type: data.legendType,
//       ...(hasGroupBy ? {
//         orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' 
//           ? 'vertical' 
//           : 'horizontal',
//         top: data.legendOrientation === 'top' ? '0' : 'auto',
//         bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//         left: data.legendOrientation === 'left' ? '0' : 'auto',
//         right: data.legendOrientation === 'right' ? '0' : 'auto',
//         textStyle: {
//           fontSize: 12
//         }
//       } : {
//         top: data.legendOrientation === 'top' ? '0' : 'auto',
//         bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//         left: data.legendOrientation === 'left' ? '0' : 'auto',
//         right: data.legendOrientation === 'right' ? '0' : 'auto',
//       })
//     },
//     grid: {
//       left: '15%',  // Increased left margin for y-axis labels
//       right: '3%',
//       bottom: data.showDataZoom ? '15%' : '3%',
//       top: data.legendOrientation === 'top' ? '15%' : '8%',
//       containLabel: true
//     },
//     yAxis: {  // Changed from xAxis to yAxis for horizontal orientation
//       type: 'category',
//       data: categories,
//       axisLine: {
//         show: true,
//         lineStyle: {
//           color: '#333',
//           width: 1
//         }
//       },
//       axisTick: {
//         show: true,
//         alignWithLabel: true
//       },
//       axisLabel: {
//         show: true,
//         hideOverlap: true,
//         interval: 'auto',
//         width: 100,  // Maximum width for labels
//         overflow: 'truncate'  // Truncate long labels
//       },
//       splitLine: {
//         show: false
//       }
//     },
//     xAxis: {  // Changed from yAxis to xAxis for horizontal orientation
//       type: 'value',
//       axisLine: {
//         show: true,
//         lineStyle: {
//           color: '#333',
//           width: 1
//         }
//       },
//       axisTick: {
//         show: true
//       },
//       axisLabel: {
//         show: true,
//         formatter: formatValue
//       },
//       splitLine: {
//         show: true,
//         lineStyle: {
//           type: 'dashed',
//           color: '#ddd'
//         }
//       }
//     },
//     dataZoom: data.showDataZoom ? [
//       {
//         type: 'slider',
//         show: true,
//         start: 0,
//         end: 100,
//         right: 10,
//         yAxisIndex: 0,  // Changed to yAxisIndex for vertical slider
//         width: 10  // Slim width for vertical slider
//       },
//       {
//         type: 'inside',
//         start: 0,
//         end: 100,
//         yAxisIndex: 0  // Changed to yAxisIndex for vertical zoom
//       }
//     ] : []
//   };

//   useEffect(() => {
//     if (chartRef.current) {
//       const chart = chartRef.current.getEchartsInstance();
//       chart.resize();
//     }
//   }, [data]);

//   return (
//     <div ref={containerRef} className="w-full h-full flex flex-col">
//       {data.hideDataTable ? (
//         <div className="flex-grow">
//           <EChartsReact
//             ref={chartRef}
//             option={option}
//             theme={selectedTheme}
//             style={{ height: '100%', width: '100%' }}
//             notMerge={true}
//             opts={{ renderer: 'canvas' }}
//           />
//         </div>
//       ) : (
//         <div className="flex-grow">
//           <EChartsReact
//             ref={chartRef}
//             option={option}
//             theme={selectedTheme}
//             style={{ height: '400px', width: '100%' }}
//             notMerge={true}
//             opts={{ renderer: 'canvas' }}
//           />
//         </div>
//       )}

//       {!data.hideDataTable && (
//         <div className="flex-shrink-0 overflow-auto">
//           <Tabs defaultValue="results">
//             <TabsList className="mb-2">
//               <TabsTrigger value="results">RESULTS</TabsTrigger>
//             </TabsList>
//             <TabsContent value="results" className="h-full overflow-auto">
//               <CustomBarDataTable data={data.chartData} />
//             </TabsContent>
//           </Tabs>
//         </div>
//       )}
//     </div>
//   );
// };

// export default CustomBar;


import React, { useEffect, useRef } from 'react';
import EChartsReact from 'echarts-for-react';
import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
import CustomBarDataTable from './CustomBarDataTable';
import { BarSeriesOption } from 'echarts/charts';
import { EChartsOption } from 'echarts-for-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';

interface HorizontalBarProps {
  data: {
    chartType: string;
    chartData: Array<Record<string, any>>;
    showLegend: boolean;
    legendOrientation: 'top' | 'bottom' | 'left' | 'right';
    legendType: 'plain' | 'scroll';
    chartRequest: any;
    showDataZoom: boolean;
    hideDataTable?: boolean;
  };
  theme: string;
}

const CustomBar: React.FC<HorizontalBarProps> = ({ data, theme }) => {
  const chartRef = useRef<EChartsReact>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  
  const formatValue = (value: any): string => {
    if (value === null || value === undefined) return '-';
    
    if (typeof value === 'number') {
      if (Math.abs(value) >= 1000000) {
        return Intl.NumberFormat('en-US', {
          notation: 'compact',
          maximumFractionDigits: 1
        }).format(value);
      }
      
      if (Math.abs(value) < 1) {
        return value.toFixed(2);
      }
      
      return Intl.NumberFormat('en-US', {
        maximumFractionDigits: 2,
        minimumFractionDigits: 0
      }).format(value);
    }
    
    return String(value);
  };

  const processData = () => {
    const keys = Object.keys(data.chartData[0] || {});
    const categoryKey = keys[0];
    const valueKeys = keys.slice(1);
    const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => g.name) || [];
    const hasGroupBy = groupByFields.length > 0;
    const dimensions = groupByFields.length;

    const uniqueCategories = Array.from(new Set(
      data.chartData.map(item => String(item[categoryKey]))
    ));

    if (hasGroupBy) {
      const getDimensionKey = (item: any) => 
        groupByFields.map(field => item[field]).join('|');

      const uniqueDimensions = Array.from(new Set(
        data.chartData.map(getDimensionKey)
      )).map(key => ({
        key,
        values: key.split('|')
      }));

      const series = uniqueDimensions.flatMap(dimension =>
        valueKeys.map(metricKey => ({
          // name: `${dimension.values.join(' - ')} - ${metricKey}`,
          name: `${metricKey},${dimension.values.join(' - ')} :`,

          type: 'bar' as const,
          emphasis: {
            focus: 'series',
            blurScope: 'series',
            scale: false,
            itemStyle: {
              opacity: 0.7
            }
          },
          select: {
            disabled: true
          },
          data: uniqueCategories.map(category => {
            const matchingItem = data.chartData.find(item => 
              String(item[categoryKey]) === category && 
              getDimensionKey(item) === dimension.key
            );

            return {
              value: matchingItem?.[metricKey] ?? 0,
              itemData: matchingItem,
              dimensions: groupByFields.map((field, index) => ({
                field,
                value: dimension.values[index]
              })),
              metric: metricKey,
              dimensionDisplay: dimension.values.join(' - ')
            };
          })
        }))
      );

      return { categories: uniqueCategories, series, hasGroupBy, dimensions };
    } else {
      const series: BarSeriesOption[] = valueKeys.map(key => ({
        name: key,
        type: 'bar',
        emphasis: {
          focus: 'series',
          blurScope: 'series',
          scale: false,
          itemStyle: {
            opacity: 0.7
          }
        },
        select: {
          disabled: true
        },
        data: uniqueCategories.map(category => {
          const matchingItem = data.chartData.find(item => 
            String(item[categoryKey]) === category
          );
          return {
            value: matchingItem ? Number(matchingItem[key]) : 0,
            itemData: matchingItem,
            metric: key
          };
        })
      }));

      return { categories: uniqueCategories, series, hasGroupBy, dimensions: 0 };
    }
  };

  const getSelectedTheme = (themeName: string) => {
    switch (themeName) {
      case 'Essos': return Essos;
      case 'Wonderland': return Wonderland;
      case 'Walden': return Walden;
      case 'Infographic': return Infographic;
      case 'Macarons': return Macarons;
      case 'Roma': return Roma;
      case 'CoolTheme': return CoolTheme;
      case 'Shine': return Shine;
      default: return Westeros;
    }
  };
  const getGroupByColumns = () => {
    // Get only the groupby columns from form_data
    return data.chartRequest.params.form_data.groupby?.map(g => g.name.toLowerCase()) || [];
  };
  const { categories, series, hasGroupBy, dimensions } = processData();
  const selectedTheme = getSelectedTheme(theme);
  const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => g.name) || [];
  const option: EChartsOption = {
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow',
        snap: true,
        animation: true,
        shadowStyle: {
          color: 'rgba(150,150,150,0.1)'
        }
      },
      enterable: true,
      position: function (point, params, dom, rect, size) {
        const gap = 20;
        const chartWidth = containerRef.current?.clientWidth || 0;
        const chartHeight = containerRef.current?.clientHeight || 0;
        const tooltipWidth = size.contentSize[0];
        const tooltipHeight = size.contentSize[1];
        
        let [x, y] = point;
        
        if (x + tooltipWidth + gap > chartWidth) {
          x = x - tooltipWidth - gap;
        } else {
          x = x + gap;
        }
        
        if (y + tooltipHeight + gap > chartHeight) {
          y = y - tooltipHeight - gap;
        } else {
          y = y + gap;
        }
        
        x = Math.max(gap, Math.min(x, chartWidth - tooltipWidth - gap));
        y = Math.max(gap, Math.min(y, chartHeight - tooltipHeight - gap));
        
        return [x, y];
      },
      backgroundColor: 'rgba(255, 255, 255, 0.95)',
      borderColor: '#ccc',
      borderWidth: 1,
      padding: [8, 12],
      textStyle: {
        color: '#333',
        fontSize: 12
      },
      extraCssText: 'box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); border-radius: 4px;',
      formatter: function(params: any) {
        if (!Array.isArray(params)) return '';
        
        const groupByColumns = getGroupByColumns();
        
        // Filter out params where series name contains any groupby column
        const filteredParams = params.filter((param: any) => {
          const seriesName = param.seriesName.toLowerCase();
          return !groupByColumns.some(column => seriesName.startsWith(column));
        });

        // Filter out zero values
        const nonZeroParams = filteredParams.filter((param: any) => 
          param.data 
        );
  
        let tooltipContent = `
          <div style="margin-bottom: 10px; padding-bottom: 6px; border-bottom: 1px solid #eee;">
            <span style="font-size: 13px; font-weight: 600; color: #666;">
              ${params[0].name}
            </span>
          </div>
        `;
  
        // Group by metric type
        const metricGroups = new Map();
        
        nonZeroParams.forEach((param: any) => {
          const data = param.data;
          if (!data || !data.metric) return;
          
          if (!metricGroups.has(data.metric)) {
            metricGroups.set(data.metric, []);
          }
          
          metricGroups.get(data.metric).push({
            name: param.seriesName,
            value: data.value,
            color: param.color,
            itemData: data.itemData
          });
        });
  
        // Add each metric group to tooltip
        metricGroups.forEach((items, metric) => {
          tooltipContent += `
            <div style="margin-top: 8px;">
              ${items.map((item: any) => `
                <div style="display: flex; justify-content: space-between; align-items: center; margin: 4px 0;">
                  <div style="display: flex; align-items: center; gap: 6px;">
                    <span style="color: ${item.color}; font-size: 16px;">●</span>
                    <span style="color: #666; font-size: 12px;">
                      ${item.name} ${formatValue(item.value)}
                    </span>
                  </div>
                  <span style="font-size: 12px; color: #666;">
                  </span>
                </div>
              `).join('')}
            </div>
          `;
        });
  
        return `
          <div style="max-height: 200px; overflow-y: auto;">
            ${tooltipContent}
          </div>
        `;
      }
    },
    legend: {
      show: data.showLegend,
      type: data.legendType,
      ...(hasGroupBy ? {
        orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' 
          ? 'vertical' 
          : 'horizontal',
        top: data.legendOrientation === 'top' ? '0' : 'auto',
        bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
        left: data.legendOrientation === 'left' ? '0' : 'auto',
        right: data.legendOrientation === 'right' ? '0' : 'auto',
        textStyle: {
          fontSize: 12
        }
      } : {
        top: data.legendOrientation === 'top' ? '0' : 'auto',
        bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
        left: data.legendOrientation === 'left' ? '0' : 'auto',
        right: data.legendOrientation === 'right' ? '0' : 'auto',
      })
    },
    grid: {
      left: '3%',
      right: '8%', // Increased right margin for y-axis labels
      bottom: data.showDataZoom ? '15%' : '3%',
      top: data.legendOrientation === 'top' ? '15%' : '8%',
      containLabel: true
    },
    yAxis: { // Switched from xAxis
      type: 'category',
      data: categories,
      axisLine: {
        show: true,
        lineStyle: {
          color: '#333',
          width: 1
        }
      },
      axisTick: {
        show: true,
        alignWithLabel: true
      },
      axisLabel: {
        show: true,
        hideOverlap: true,
        interval: 'auto'
      },
      splitLine: {
        show: false
      }
    },
    xAxis: { // Switched from yAxis
      type: 'value',
      axisLine: {
        show: true,
        lineStyle: {
          color: '#333',
          width: 1
        }
      },
      axisTick: {
        show: true
      },
      axisLabel: {
        show: true,
        formatter: formatValue
      },
      splitLine: {
        show: true,
        lineStyle: {
          type: 'dashed',
          color: '#ddd'
        }
      }
    },
    dataZoom: data.showDataZoom ? [
      {
        type: 'slider',
        show: true,
        start: 0,
        end: 100,
        right: 10,
        yAxisIndex: 0, // Changed to yAxisIndex for vertical slider
        width: 10 // Reduced width for vertical slider
      },
      {
        type: 'inside',
        start: 0,
        end: 100,
        yAxisIndex: 0 // Changed to yAxisIndex for vertical zoom
      }
    ] : [],
    series: series.map(s => ({
      ...s,
      barMaxWidth: 30 // Added to control maximum bar width
    }))
  };

  useEffect(() => {
    if (chartRef.current) {
      const chart = chartRef.current.getEchartsInstance();
      chart.resize();
    }
  }, [data]);

  return (
    <div ref={containerRef} className="w-full h-full flex flex-col">
      {data.hideDataTable ? (
        <div className="flex-grow">
          <EChartsReact
            ref={chartRef}
            option={option}
            theme={selectedTheme}
            style={{ height: '100%', width: '100%' }}
            notMerge={true}
            opts={{ renderer: 'canvas' }}
          />
        </div>
       ) : (
        <div className="flex-grow">
          <EChartsReact
            ref={chartRef}
            option={option}
            theme={selectedTheme}
            style={{ height: '400px', width: '100%' }}
            notMerge={true}
            opts={{ renderer: 'canvas' }}
          />
        </div>
      )}

      {!data.hideDataTable && (
        <div className="flex-shrink-0 overflow-auto">
          <Tabs defaultValue="results">
            <TabsList className="mb-2">
              <TabsTrigger value="results">RESULTS</TabsTrigger>
            </TabsList>
            <TabsContent value="results" className="h-full overflow-auto">
              <CustomBarDataTable data={data.chartData} />
            </TabsContent>
          </Tabs>
        </div>
      )}
    </div>
  );
};

export default CustomBar;