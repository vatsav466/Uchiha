
// import React, { useEffect, useState } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';

// interface BarProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
    // showDataZoom: boolean;
//   };
//   theme: string;
// }

// const Bar: React.FC<BarProps> = ({ data, theme }) => {
//   const [elapsedTime, setElapsedTime] = useState(0);

//   useEffect(() => {
//     const timer = setInterval(() => {
//       setElapsedTime((prevTime) => prevTime + 1);
//     }, 1000);

//     return () => clearInterval(timer);
//   }, []);

//   useEffect(() => {
//     console.log("Number of rows in API response:", data.chartData.length);
//   }, [data.chartData]);

//   const processedData = data.chartData.map(item => {
//     const keys = Object.keys(item);
//     return {
//       name: String(item[keys[0]]),
//       value: Number(item[keys[1]])
//     };
//   }).filter(item => !isNaN(item.value));

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const selectedTheme = getSelectedTheme(theme);

//   const option: echarts.EChartsOption = {
//     tooltip: {
//       trigger: 'axis',
//       axisPointer: {
//         type: 'shadow'
//       }
//     },
//     legend: {
//       show: data.showLegend,
//       orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' ? 'vertical' : 'horizontal',
//       [data.legendOrientation]: 10,
//       type: data.legendType,
//     },
//     dataZoom: data.showDataZoom
//     ? [
//         {
//           id: 'dataZoomX',
//           type: 'slider',
//           xAxisIndex: [0],
//           filterMode: 'filter'
//         },
//         {
//           id: 'dataZoomY',
//           type: 'slider',
//           yAxisIndex: [0],
//           filterMode: 'empty'
//         }
//       ]
//     : [],
//     xAxis: {
//       type: 'category',
//       data: processedData.map(item => item.name),
//       axisLabel: {
//         rotate: 45,
//         interval: 0
//       }
//     },
//     yAxis: {
//       type: 'value'
//     },
//     series: [
//       {
//         name: 'Data',
//         type: 'bar',
//         data: processedData.map(item => item.value),
//         itemStyle: {
//           color: selectedTheme.color[0]
//         }
//       }
//     ],
//     color: selectedTheme.color,
//   };

//   return (
//     <div className="relative" style={{ height: '600px', width: '100%' }}>
//       <div className="absolute top-2 right-2 flex items-center space-x-2 z-10">
//         <div className="bg-red-500 mt-5 text-white px-3 py-1 rounded-full text-sm font-semibold">
//           {data.chartData.length} rows
//         </div>
//       </div>
//       <EChartsReact
//         option={option}
//         style={{ height: '100%', width: '100%' }}
//         theme={selectedTheme}
//       />
//     </div>
//   );
// };

// // export default Bar;
// import React, { useEffect, useState } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';

// interface BarProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//   };
//   theme: string;
// }

// const Bar: React.FC<BarProps> = ({ data, theme }) => {
//   const [elapsedTime, setElapsedTime] = useState(0);

//   useEffect(() => {
//     const timer = setInterval(() => {
//       setElapsedTime((prevTime) => prevTime + 1);
//     }, 1000);

//     return () => clearInterval(timer);
//   }, []);

//   useEffect(() => {
//     console.log("Number of rows in API response:", data.chartData.length);
//   }, [data.chartData]);

//   const processedData = data.chartData.map(item => {
//     const keys = Object.keys(item);
//     return {
//       name: String(item[keys[0]]),
//       value: Number(item[keys[1]])
//     };
//   }).filter(item => !isNaN(item.value));

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const selectedTheme = getSelectedTheme(theme);

//   const option: echarts.EChartsOption = {
//     tooltip: {
//       trigger: 'axis',
//       axisPointer: {
//         type: 'shadow'
//       }
//     },
//     legend: {
//       show: data.showLegend,
//       orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' ? 'vertical' : 'horizontal',
//       [data.legendOrientation]: 10,
//       type: data.legendType,
//     },
//     dataZoom: data.showDataZoom
//     ? [
//         {
//           id: 'dataZoomX',
//           type: 'slider',
//           xAxisIndex: [0],
//           filterMode: 'filter'
//         },
//         {
//           id: 'dataZoomY',
//           type: 'slider',
//           yAxisIndex: [0],
//           filterMode: 'empty'
//         }
//       ]
//     : [],
//     xAxis: {
//       type: 'category',
//       data: processedData.map(item => item.name),
//       axisLabel: {
//         rotate: 45,
//         interval: 0
//       }
//     },
//     yAxis: {
//       type: 'value'
//     },
//     series: [
//       {
//         name: 'Data',
//         type: 'bar',
//         data: processedData.map(item => item.value),
//         itemStyle: {
//           color: selectedTheme.color[0]
//         }
//       }
//     ],
//     color: selectedTheme.color,
//   };

//   return (
//     <div className="relative" style={{ height: '600px', width: '100%' }}>
//       <div className="absolute top-2 right-2 flex items-center space-x-2 z-10">
//         <div className="bg-red-500 mt-5 text-white px-3 py-1 rounded-full text-sm font-semibold">
//           {data.chartData.length} rows
//         </div>
//       </div>
//       <EChartsReact
//         option={option}
//         style={{ height: '100%', width: '100%' }}
//         theme={selectedTheme}
//       />
//     </div>
//   );
// };

// // export default Bar;
// import React, { useEffect, useState } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';

// interface BarProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//   };
//   theme: string;
// }

// const Bar: React.FC<BarProps> = ({ data, theme }) => {
//   const [elapsedTime, setElapsedTime] = useState(0);

//   useEffect(() => {
//     const timer = setInterval(() => {
//       setElapsedTime((prevTime) => prevTime + 1);
//     }, 1000);

//     return () => clearInterval(timer);
//   }, []);

//   useEffect(() => {
//     console.log("Number of rows in API response:", data.chartData.length);
//   }, [data.chartData]);

//   const processedData = data.chartData.map(item => {
//     const keys = Object.keys(item);
//     return {
//       name: String(item[keys[0]]),
//       value: Number(item[keys[1]])
//     };
//   }).filter(item => !isNaN(item.value));

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const selectedTheme = getSelectedTheme(theme);

//   const option: echarts.EChartsOption = {
//     tooltip: {
//       trigger: 'axis',
//       axisPointer: {
//         type: 'shadow'
//       }
//     },
//     legend: {
//       show: data.showLegend,
//       orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' ? 'vertical' : 'horizontal',
//       [data.legendOrientation]: 10,
//       type: data.legendType,
//     },
//     dataZoom: data.showDataZoom
//   ? [
//       {
//         id: 'dataZoomX',
//         type: 'slider',
//         xAxisIndex: [0],
//         filterMode: 'filter'
//       },
//       {
//         id: 'dataZoomY',
//         type: 'slider',
//         yAxisIndex: [0],
//         filterMode: 'empty'
//       }
//     ]
//   : [],
//     xAxis: {
//       type: 'category',
//       data: processedData.map(item => item.name),
//       axisLabel: {
//         rotate: 45,
//         interval: 0
//       }
//     },
//     yAxis: {
//       type: 'value'
//     },
//     series: [
//       {
//         name: 'Data',
//         type: 'bar',
//         data: processedData.map(item => item.value),
//         itemStyle: {
//           color: selectedTheme.color[0]
//         }
//       }
//     ],
//     color: selectedTheme.color,
//   };

//   return (
//     <div className="relative" style={{ height: '600px', width: '100%' }}>
//       <div className="absolute top-2 right-2 flex items-center space-x-2 z-10">
//         <div className="bg-red-500 mt-5 text-white px-3 py-1 rounded-full text-sm font-semibold">
//           {data.chartData.length} rows
//         </div>
//       </div>
//       <EChartsReact
//         option={option}
//         style={{ height: '100%', width: '100%' }}
//         theme={selectedTheme}
//       />
//     </div>
//   );
// };

// export default Bar;







// import React, { useEffect, useState } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { EChartsOption } from 'echarts';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import BarDataTable from './BarDataTable';

// interface BarProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//   };
//   theme: string;
// }

// const Bar: React.FC<BarProps> = ({ data, theme }) => {
//   const [elapsedTime, setElapsedTime] = useState(0);

//   useEffect(() => {
//     const timer = setInterval(() => {
//       setElapsedTime((prevTime) => prevTime + 1);
//     }, 1000);

//     return () => clearInterval(timer);
//   }, []);

//   useEffect(() => {
//     console.log("Number of rows in API response:", data.chartData.length);
//   }, [data.chartData]);

//   // Automatically determine the first column for X-axis (categories) and rest for series
//   const allKeys = Object.keys(data.chartData[0]);
//   const categoryKey = allKeys[0];  // Use the first key for the X-axis categories
//   const seriesKeys = allKeys.slice(1);  // All remaining keys are series

//   // Get the categories dynamically based on the first column in the data
//   const categories = data.chartData.map(item => item[categoryKey] || 'Unknown');  // Fallback if undefined

//   // Process data for each series
//   const series = seriesKeys.map(key => {
//     const seriesData = data.chartData.map(item => item[key]);

//     // Normalize the data to a percentage
//     const total = seriesData.reduce((acc, val) => acc + val, 0);
//     const normalizedData = seriesData.map(val => (val / total) * 100);

//     return {
//       name: key,
//       type: 'bar' as const,
//       stack: 'Total',
//       barWidth: '60%',
//       data: normalizedData
//     };
//   });

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const selectedTheme = getSelectedTheme(theme);

//   // Define ECharts option with proper typing
//   const option: EChartsOption = {
//     tooltip: {
//       trigger: 'axis',
//       axisPointer: {
//         type: 'shadow'
//       },
//       formatter: params => {
//         let result = params[0].name + '<br>';
//         params.forEach(param => {
//           result += param.marker + param.seriesName + ': ' + param.value.toFixed(2) + '%<br>';
//         });
//         return result;
//       }
//     },
//     legend: {
//       show: data.showLegend,
//       top: data.legendOrientation
//     },
    // grid: {
    //   left: '3%',
    //   right: '4%',
    //   bottom: '3%',
    //   containLabel: true
    // },
//     xAxis: {
//       type: 'category',
//       data: categories,  // Categories dynamically taken from the first column
//       axisTick: {
//         alignWithLabel: true
//       }
//     },
//     yAxis: {
//       type: 'value',
//       max: 100,  // Normalized to 100%
//       axisLabel: {
//         formatter: '{value}%'
//       }
//     },
//     series: series,
//     dataZoom: data.showDataZoom ? [
//       {
//         type: 'slider',
//         show: true,
//         xAxisIndex: [0],
//         start: 0,
//         end: 100
//       },
//       {
//         type: 'inside',
//         xAxisIndex: [0],
//         start: 0,
//         end: 100
//       }
//     ] : undefined,
//     color: selectedTheme.color
//   };

//   return (
//     <div className="flex flex-col h-full">
//       <div className="relative" style={{ height: '400px', width: '100%' }}>
//         <div className="absolute top-2 right-2 flex items-center space-x-2 z-10">
//           <div className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
//             {data.chartData.length} rows
//           </div>
//         </div>
//         <EChartsReact
//           option={option}
//           style={{ height: '100%', width: '100%' }}
//           theme={selectedTheme}
//         />
//       </div>

//       <div className="mt-4">
//         <Tabs defaultValue="results">
//           <TabsList>
//             <TabsTrigger value="results">RESULTS</TabsTrigger>
//             <TabsTrigger value="samples">SAMPLES</TabsTrigger>
//           </TabsList>
//           <TabsContent value="results" className="h-64 overflow-auto">
//             <BarDataTable data={data.chartData} />
//           </TabsContent>
//           <TabsContent value="samples">
//             {/* Add sample content here */}
//           </TabsContent>
//         </Tabs>
//       </div>
//     </div>
//   );
// };

// export default Bar;

// import React, { useEffect, useState } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import BarDataTable from './BarDataTable';

// interface BarProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//   };
//   theme: string;
// }

// const Bar: React.FC<BarProps> = ({ data, theme }) => {
//   const [elapsedTime, setElapsedTime] = useState(0);

//   useEffect(() => {
//     const timer = setInterval(() => {
//       setElapsedTime((prevTime) => prevTime + 1);
//     }, 1000);

//     return () => clearInterval(timer);
//   }, []);

//   useEffect(() => {
//     console.log("Number of rows in API response:", data.chartData.length);
//   }, [data.chartData]);

//   const processedData = data.chartData.map(item => {
//     const keys = Object.keys(item);
//     return {
//       name: String(item[keys[0]]),
//       value: Number(item[keys[1]])
//     };
//   }).filter(item => !isNaN(item.value));

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const selectedTheme = getSelectedTheme(theme);

//   const option: echarts.EChartsOption = {
//     tooltip: {
//       trigger: 'axis',
//       axisPointer: {
//         type: 'shadow'
//       }
//     },
//     legend: {
//       show: data.showLegend
//     },
//     grid: {
//       left: '3%',
//       right: '4%',
//       bottom: '3%',
//       containLabel: true
//     },
//     xAxis: {
//       type: 'category',
//       data: processedData.map(item => item.name),
//       axisTick: {
//         alignWithLabel: true
//       }
//     },
//     yAxis: {
//       type: 'value'
//     },
//     series: [
//       {
//         name: 'Value',
//         type: 'bar',
//         barWidth: '60%',
//         data: processedData.map(item => item.value)
//       }
//     ],
//     color: selectedTheme.color
//   };

//   return (
//     <div className="flex flex-col h-full">
//       <div className="relative" style={{ height: '400px', width: '100%' }}>
//         <div className="absolute top-2 right-2 flex items-center space-x-2 z-10">
//           <div className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
//             {data.chartData.length} rows
//           </div>
//         </div>
//         <EChartsReact
//           option={option}
//           style={{ height: '100%', width: '100%' }}
//           theme={selectedTheme}
//         />
//       </div>

//       <div className="mt-4">
//         <Tabs defaultValue="results">
//           <TabsList>
//             <TabsTrigger value="results">RESULTS</TabsTrigger>
//             <TabsTrigger value="samples">SAMPLES</TabsTrigger>
//           </TabsList>
//           <TabsContent value="results" className="h-64 overflow-auto">
//             <BarDataTable data={data.chartData} />
//           </TabsContent>
//           <TabsContent value="samples">
//             {/* Add sample content here */}
//           </TabsContent>
//         </Tabs>
//       </div>
//     </div>
//   );
// };

// //  export default Bar;
// import React, { useEffect, useState } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import BarDataTable from './BarDataTable';

// interface BarProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//   };
//   theme: string;
// }

// const Bar: React.FC<BarProps> = ({ data, theme }) => {
//   const [elapsedTime, setElapsedTime] = useState(0);

//   useEffect(() => {
//     const timer = setInterval(() => {
//       setElapsedTime((prevTime) => prevTime + 1);
//     }, 1000);

//     return () => clearInterval(timer);
//   }, []);

//   useEffect(() => {
//     console.log("Number of rows in API response:", data.chartData.length);
//   }, [data.chartData]);

//   const processedData = data.chartData.map(item => {
//     const keys = Object.keys(item);
//     return {
//       name: String(item[keys[0]]),
//       value: Number(item[keys[1]])
//     };
//   }).filter(item => !isNaN(item.value));

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const selectedTheme = getSelectedTheme(theme);

//   const option: echarts.EChartsOption = {
//     tooltip: {
//       trigger: 'axis',
//       axisPointer: {
//         type: 'shadow'
//       }
//     },
//     legend: {
//       show: data.showLegend,
//       // orient: data.legendOrientation,
//       type: data.legendType,
//       top: data.legendOrientation === 'top' ? '0' : 'auto',
//       bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//       left: data.legendOrientation === 'left' ? '0' : 'auto',
//       right: data.legendOrientation === 'right' ? '0' : 'auto',
//     },
//     grid: {
//       left: '3%',
//       right: '4%',
//       bottom: '3%',
//       containLabel: true
//     },
//     xAxis: {
//       type: 'category',
//       data: processedData.map(item => item.name),
//       axisTick: {
//         alignWithLabel: true
//       }
//     },
//     yAxis: {
//       type: 'value'
//     },
//     series: [
//       {
//         name: 'Value',
//         type: 'bar',
//         barWidth: '60%',
//         data: processedData.map(item => item.value)
//       }
//     ],
//     dataZoom: data.showDataZoom ? [
//       {
//         type: 'inside',
//         start: 0,
//         end: 100
//       },
//       {
//         start: 0,
//         end: 100
//       }
//     ] : undefined,
//     color: selectedTheme.color
//   };

//   return (
//     <div className="flex flex-col h-full">
//       <div className="relative" style={{ height: '400px', width: '100%' }}>
//         <div className="absolute top-2 right-2 flex items-center space-x-2 z-10">
//           <div className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
//             {data.chartData.length} rows
//           </div>
//         </div>
//         <EChartsReact
//           option={option}
//           style={{ height: '100%', width: '100%' }}
//           theme={selectedTheme}
//         />
//       </div>

//       <div className="mt-4">
//         <Tabs defaultValue="results">
//           <TabsList>
//             <TabsTrigger value="results">RESULTS</TabsTrigger>
//             <TabsTrigger value="samples">SAMPLES</TabsTrigger>
//           </TabsList>
//           <TabsContent value="results" className="h-64 overflow-auto">
//             <BarDataTable data={data.chartData} />
//           </TabsContent>
//           <TabsContent value="samples">
//             {/* Add sample content here */}
//           </TabsContent>
//         </Tabs>
//       </div>
//     </div>
//   );
// };

// // export default Bar;
// import React, { useEffect, useState } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import BarDataTable from './BarDataTable';

// interface BarProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//   };
//   theme: string;
// }

// const Bar: React.FC<BarProps> = ({ data, theme }) => {
//   const [elapsedTime, setElapsedTime] = useState(0);

//   useEffect(() => {
//     const timer = setInterval(() => {
//       setElapsedTime((prevTime) => prevTime + 1);
//     }, 1000);

//     return () => clearInterval(timer);
//   }, []);

//   useEffect(() => {
//     console.log("Number of rows in API response:", data.chartData.length);
//   }, [data.chartData]);

//   const processedData = data.chartData.map(item => {
//     const keys = Object.keys(item);
//     return {
//       name: String(item[keys[0]]),
//       value: Number(item[keys[1]])
//     };
//   }).filter(item => !isNaN(item.value));

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const selectedTheme = getSelectedTheme(theme);

//   const option: echarts.EChartsOption = {
//     tooltip: {
//       trigger: 'axis',
//       axisPointer: {
//         type: 'shadow'
//       }
//     },
//     legend: {
//       show: data.showLegend,
//       //orient: data.legendOrientation,
//       type: data.legendType,
//       top: data.legendOrientation === 'top' ? '0' : 'auto',
//       bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//       left: data.legendOrientation === 'left' ? '0' : 'auto',
//       right: data.legendOrientation === 'right' ? '0' : 'auto',
//     },
//     grid: {
//       left: '3%',
//       right: '4%',
//       bottom: data.showDataZoom ? '15%' : '3%',
//       containLabel: true
//     },
//     xAxis: {
//       type: 'category',
//       data: processedData.map(item => item.name),
//       axisTick: {
//         alignWithLabel: true
//       }
//     },
//     yAxis: {
//       type: 'value'
//     },
//     series: [
//       {
//         name: 'Value',
//         type: 'bar',
//         barWidth: '60%',
//         data: processedData.map(item => item.value)
//       }
//     ],
//     dataZoom: data.showDataZoom ? [
//       {
//         type: 'slider',
//         show: true,
//         start: 0,
//         end: 100,
//         height: 30
//       },
//       {
//         type: 'inside',
//         start: 0,
//         end: 100
//       }
//     ] : [],
//     color: selectedTheme.color
//   };

//   return (
//     <div className="flex flex-col h-full">
//       <div className="relative" style={{ height: '400px', width: '100%' }}>
//         <div className="absolute top-2 right-2 flex items-center space-x-2 z-10">
//           <div className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
//             {data.chartData.length} rows
//           </div>
//         </div>
//         <EChartsReact
//           option={option}
//           style={{ height: '100%', width: '100%' }}
//           theme={selectedTheme}
//           notMerge={true}
//           lazyUpdate={false}
//         />
//       </div>

//       <div className="mt-4">
//         <Tabs defaultValue="results">
//           <TabsList>
//             <TabsTrigger value="results">RESULTS</TabsTrigger>
//             {/* <TabsTrigger value="samples">SAMPLES</TabsTrigger> */}
//           </TabsList>
//           <TabsContent value="results" className="h-64 overflow-auto">
//             <BarDataTable data={data.chartData} />
//           </TabsContent>
//           {/* <TabsContent value="samples"> */}
//             {/* Add sample content here */}
//           {/* </TabsContent> */}
//         </Tabs>
//       </div>
//     </div>
//   );
// };

// export default Bar;

// import React, { useEffect, useRef, useState } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import BarDataTable from './BarDataTable';
// import { BarSeriesOption } from 'echarts/charts';
// import { EChartsOption } from 'echarts-for-react';

// interface BarProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//     hideDataTable?: boolean;

//   };
//   theme: string;
// }

// const Bar: React.FC<BarProps> = ({ data, theme }) => {
//   const [elapsedTime, setElapsedTime] = useState(0);
//   const chartRef = useRef<EChartsReact>(null);
//   const containerRef = useRef<HTMLDivElement>(null);

//   useEffect(() => {
//     const timer = setInterval(() => {
//       setElapsedTime((prevTime) => prevTime + 1);
//     }, 1000);

//     return () => clearInterval(timer);
//   }, []);

//   useEffect(() => {
//     console.log("Number of rows in API response:", data.chartData.length);
//   }, [data.chartData]);

//   const processData = () => {
//     const keys = Object.keys(data.chartData[0]);
//     const categoryKey = keys[0];
//     const valueKeys = keys.slice(1);

//     const categories = data.chartData.map(item => String(item[categoryKey]));
//     const series: BarSeriesOption[] = valueKeys.map(key => ({
//       name: key,
//       type: 'bar',
//       data: data.chartData.map(item => Number(item[key]))
//     }));

//     return { categories, series };
//   };

//   const { categories, series } = processData();

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const selectedTheme = getSelectedTheme(theme);

//   const option: EChartsOption = {
//     tooltip: {
//       trigger: 'axis',
//       axisPointer: {
//         type: 'shadow'
//       }
//     },
//     legend: {
//       show: data.showLegend,
//       type: data.legendType,
//       top: data.legendOrientation === 'top' ? '0' : 'auto',
//       bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//       left: data.legendOrientation === 'left' ? '0' : 'auto',
//       right: data.legendOrientation === 'right' ? '0' : 'auto',
//     },
//     grid: {
//       left: '3%',
//       right: '4%',
//       bottom: data.showDataZoom ? '15%' : '3%',
//       containLabel: true
//     },
//     xAxis: {
//       type: 'category',
//       data: categories,
//       axisTick: {
//         alignWithLabel: true
//       }
//     },
//     yAxis: {
//       type: 'value'
//     },
//     series: series,
//     dataZoom: data.showDataZoom ? [
//       {
//         type: 'slider',
//         show: true,
//         start: 0,
//         end: 100,
//         height: 30
//       },
//       {
//         type: 'inside',
//         start: 0,
//         end: 100
//       }
//     ] : [],
//     color: selectedTheme.color
//   };

//   return (
//     <div ref={containerRef} className="w-full h-full flex flex-col">
//     {data.hideDataTable ? (
//       <div className="flex-grow">
//         <EChartsReact
//           ref={chartRef}
//           option={option}
//           theme={selectedTheme}
//           style={{ height: '100%', width: '100%' }}
//           opts={{ renderer: 'svg' }}
//         />
//       </div>
//     ) : (
//       <div className="flex-grow">
//         <EChartsReact
//           option={option}
//           theme={selectedTheme}
//           style={{ height: '400px', width: '100%' }}
//           opts={{ renderer: 'svg' }}
//         />
//       </div>
//     )}

//     {!data.hideDataTable && (
//       <div className="flex-shrink-0 overflow-auto">
//         <Tabs defaultValue="results">
//           <TabsList className="mb-2">
//             <TabsTrigger value="results">RESULTS</TabsTrigger>
//           </TabsList>
//           <TabsContent value="results" className="h-full overflow-auto">
//             <BarDataTable data={data.chartData} />
//           </TabsContent>
        
//         </Tabs>
//       </div>
//             )}

//     </div>
//   );
// };

// export default Bar;










// import React, { useEffect, useRef, useState } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import BarDataTable from './BarDataTable';
// import { BarSeriesOption } from 'echarts/charts';
// import { EChartsOption } from 'echarts-for-react';

// interface BarProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//     hideDataTable?: boolean;
//   };
//   theme: string;
// }

// const Bar: React.FC<BarProps> = ({ data, theme }) => {
//   const [elapsedTime, setElapsedTime] = useState(0);
//   const chartRef = useRef<EChartsReact>(null);
//   const containerRef = useRef<HTMLDivElement>(null);

//   useEffect(() => {
//     const timer = setInterval(() => {
//       setElapsedTime((prevTime) => prevTime + 1);
//     }, 1000);

//     return () => clearInterval(timer);
//   }, []);

//   const formatValue = (value: any): string => {
//     if (value === null || value === undefined) return '-';
    
//     if (typeof value === 'number') {
//       return new Intl.NumberFormat('en-US', {
//         maximumFractionDigits: 2,
//         notation: Math.abs(value) > 1000000 ? 'compact' : 'standard'
//       }).format(value);
//     }
    
//     return String(value);
//   };

//   const processData = () => {
//     const keys = Object.keys(data.chartData[0]);
//     const categoryKey = keys[0];
//     const valueKeys = keys.slice(1);
//     const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => g.name) || [];
//     const hasGroupBy = groupByFields.length > 0;

//     const categories = data.chartData.map(item => String(item[categoryKey]));
    
//     if (hasGroupBy) {
//       // Process data with dimensions (groupBy)
//       const getDimensionValue = (item: any) => 
//         groupByFields.map(field => item[field]).join(' - ');

//       const dimensionCombinations = Array.from(new Set(
//         data.chartData.map(getDimensionValue)
//       ));

//       const series = dimensionCombinations.flatMap(dimension =>
//         valueKeys.map(key => ({
//           name: `${dimension} - ${key}`,
//           type: 'bar' as const,
//           data: categories.map(category => ({
//             value: data.chartData.find(item => 
//               String(item[categoryKey]) === category && 
//               getDimensionValue(item) === dimension
//             )?.[key] || 0,
//             itemData: data.chartData.find(item => 
//               String(item[categoryKey]) === category && 
//               getDimensionValue(item) === dimension
//             ),
//             dimensions: groupByFields.reduce((acc, field) => ({
//               ...acc,
//               [field]: data.chartData.find(item => 
//                 String(item[categoryKey]) === category && 
//                 getDimensionValue(item) === dimension
//               )?.[field] || null
//             }), {}),
//             metric: key,
//             dimensionDisplay: dimension
//           }))
//         }))
//       );

//       return { categories, series, hasGroupBy };
//     } else {
//       // Process data without dimensions (original logic)
//       const series: BarSeriesOption[] = valueKeys.map(key => ({
//         name: key,
//         type: 'bar',
//         data: data.chartData.map(item => Number(item[key]))
//       }));

//       return { categories, series, hasGroupBy };
//     }
//   };

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const { categories, series, hasGroupBy } = processData();
//   const selectedTheme = getSelectedTheme(theme);
//   const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => g.name) || [];

//   const getTooltipFormatter = (params: any) => {
//     if (!params || !params.data) return '';

//     if (hasGroupBy) {
//       const itemData = params.data.itemData || {};
//       const xAxisField = data.chartRequest.params.form_data.x_axis.name;
//       const xAxisLabel = data.chartRequest.params.form_data.x_axis.label || xAxisField;

//       let tooltipContent = `
//         <div style="font-weight: bold; margin-bottom: 8px;">
//           ${xAxisLabel}: ${itemData[xAxisField] || params.name}
//         </div>
//       `;

//       tooltipContent += `<div style="margin: 8px 0; padding-bottom: 8px; border-bottom: 1px solid #eee;">`;
//       groupByFields.forEach(field => {
//         const dimensionValue = params.data.dimensions[field];
//         if (dimensionValue !== null) {
//           tooltipContent += `
//             <div style="margin: 4px 0;">
//               <span style="color: #666;">${field}:</span>
//               <span style="margin-left: 8px;">${dimensionValue}</span>
//             </div>
//           `;
//         }
//       });
//       tooltipContent += `</div>`;

//       tooltipContent += `
//         <div style="display: flex; justify-content: space-between; margin: 4px 0;">
//           <span style="color: ${params.color};">● ${params.data.metric || params.seriesName}:</span>
//           <span style="margin-left: 12px; font-weight: bold;">
//             ${formatValue(params.value)}
//           </span>
//         </div>
//       `;

//       return tooltipContent;
//     } else {
//       // Simple tooltip for non-dimension data
//       return `${params.seriesName}: ${formatValue(params.value)}`;
//     }
//   };

//   const option: EChartsOption = {
//     tooltip: {
//       trigger: 'axis',
//       axisPointer: {
//         type: 'shadow'
//       },
//       formatter: hasGroupBy ? getTooltipFormatter : undefined
//     },
//     legend: {
//       show: data.showLegend,
//       type: data.legendType,
//       ...(hasGroupBy ? {
//         orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' 
//           ? 'vertical' 
//           : 'horizontal',
//         top: data.legendOrientation === 'top' ? '0' : 'auto',
//         bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//         left: data.legendOrientation === 'left' ? '0' : 'auto',
//         right: data.legendOrientation === 'right' ? '0' : 'auto',
//         textStyle: {
//           fontSize: 12
//         }
//       } : {
//         top: data.legendOrientation === 'top' ? '0' : 'auto',
//         bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//         left: data.legendOrientation === 'left' ? '0' : 'auto',
//         right: data.legendOrientation === 'right' ? '0' : 'auto',
//       })
//     },
//     grid: {
//       left: '3%',
//       right: '4%',
//       bottom: data.showDataZoom ? '15%' : '3%',
//       containLabel: true
//     },
//     xAxis: {
//       type: 'category',
//       data: categories,
//       axisTick: {
//         alignWithLabel: true
//       }
//     },
//     yAxis: {
//       type: 'value'
//     },
//     series: series,
//     dataZoom: data.showDataZoom ? [
//       {
//         type: 'slider',
//         show: true,
//         start: 0,
//         end: 100,
//         height: 30
//       },
//       {
//         type: 'inside',
//         start: 0,
//         end: 100
//       }
//     ] : []
//   };

//   return (
//     <div ref={containerRef} className="w-full h-full flex flex-col">
//       {data.hideDataTable ? (
//         <div className="flex-grow">
//           <EChartsReact
//             ref={chartRef}
//             option={option}
//             theme={selectedTheme}
//             style={{ height: '100%', width: '100%' }}
//             opts={{ renderer: 'svg' }}
//           />
//         </div>
//       ) : (
//         <div className="flex-grow">
//           <EChartsReact
//             option={option}
//             theme={selectedTheme}
//             style={{ height: '400px', width: '100%' }}
//             opts={{ renderer: 'svg' }}
//           />
//         </div>
//       )}

//       {!data.hideDataTable && (
//         <div className="flex-shrink-0 overflow-auto">
//           <Tabs defaultValue="results">
//             <TabsList className="mb-2">
//               <TabsTrigger value="results">RESULTS</TabsTrigger>
//             </TabsList>
//             <TabsContent value="results" className="h-full overflow-auto">
//               <BarDataTable data={data.chartData} />
//             </TabsContent>
//           </Tabs>
//         </div>
//       )}
//     </div>
//   );
// };

// // export default Bar;
// import React, { useEffect, useRef, useState } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import BarDataTable from './BarDataTable';
// import { BarSeriesOption } from 'echarts/charts';
// import { EChartsOption } from 'echarts-for-react';

// interface BarProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//     hideDataTable?: boolean;
//   };
//   theme: string;
// }

// const Bar: React.FC<BarProps> = ({ data, theme }) => {
//   const chartRef = useRef<EChartsReact>(null);
//   const containerRef = useRef<HTMLDivElement>(null);

//   const formatValue = (value: any): string => {
//     if (value === null || value === undefined) return '-';
    
//     if (typeof value === 'number') {
//       return new Intl.NumberFormat('en-US', {
//         maximumFractionDigits: 2,
//         notation: Math.abs(value) > 1000000 ? 'compact' : 'standard'
//       }).format(value);
//     }
    
//     return String(value);
//   };

//   const processData = () => {
//     const keys = Object.keys(data.chartData[0] || {});
//     const categoryKey = keys[0];
//     const valueKeys = keys.slice(1);
//     const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => g.name) || [];
//     const hasGroupBy = groupByFields.length > 0;

//     const categories = data.chartData.map(item => String(item[categoryKey]));
    
//     if (hasGroupBy) {
//       const getDimensionValue = (item: any) => 
//         groupByFields.map(field => item[field]).join(' - ');

//       const dimensionCombinations = Array.from(new Set(
//         data.chartData.map(getDimensionValue)
//       ));

//       const series = dimensionCombinations.flatMap(dimension =>
//         valueKeys.map(key => ({
//           name: `${dimension} - ${key}`,
//           type: 'bar' as const,
//           data: categories.map(category => ({
//             value: data.chartData.find(item => 
//               String(item[categoryKey]) === category && 
//               getDimensionValue(item) === dimension
//             )?.[key] || 0,
//             itemData: data.chartData.find(item => 
//               String(item[categoryKey]) === category && 
//               getDimensionValue(item) === dimension
//             ),
//             dimensions: groupByFields.reduce((acc, field) => ({
//               ...acc,
//               [field]: data.chartData.find(item => 
//                 String(item[categoryKey]) === category && 
//                 getDimensionValue(item) === dimension
//               )?.[field] || null
//             }), {}),
//             metric: key,
//             dimensionDisplay: dimension
//           }))
//         }))
//       );

//       return { categories, series, hasGroupBy };
//     } else {
//       const series: BarSeriesOption[] = valueKeys.map(key => ({
//         name: key,
//         type: 'bar',
//         data: data.chartData.map(item => ({
//           value: Number(item[key]),
//           itemData: item,
//           metric: key
//         }))
//       }));

//       return { categories, series, hasGroupBy };
//     }
//   };

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const { categories, series, hasGroupBy } = processData();
//   const selectedTheme = getSelectedTheme(theme);
//   const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => g.name) || [];

//   const option: EChartsOption = {
//     tooltip: {
//       show: true,
//       trigger: 'axis',
//       axisPointer: {
//         type: 'line',
//         snap: true,
//         animation: true,
//         lineStyle: {
//           color: '#666',
//           width: 1,
//           type: 'solid'
//         },
//         label: {
//           show: true,
//           backgroundColor: '#666'
//         }
//       },
//       backgroundColor: 'rgba(255, 255, 255, 0.9)',
//       borderColor: '#ccc',
//       borderWidth: 1,
//       padding: [5, 10],
//       textStyle: {
//         color: '#333'
//       },
//       extraCssText: 'box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);',
//       formatter: function(params: any) {
//         if (!Array.isArray(params)) return '';
        
//         const xAxisField = data.chartRequest.params.form_data.x_axis.name;
//         const xAxisLabel = data.chartRequest.params.form_data.x_axis.label || xAxisField;
//         let tooltipContent = `
//           <div style="font-weight: bold; margin-bottom: 8px;">
//             ${xAxisLabel}: ${params[0].name}
//           </div>
//         `;

//         if (hasGroupBy) {
//           const groupedParams = params.reduce((acc: any, param: any) => {
//             const dimensionKey = param.data?.dimensionDisplay || 'default';
//             if (!acc[dimensionKey]) {
//               acc[dimensionKey] = [];
//             }
//             acc[dimensionKey].push(param);
//             return acc;
//           }, {});

//           Object.entries(groupedParams).forEach(([dimension, groupParams]: [string, any]) => {
//             if (dimension !== 'default') {
//               tooltipContent += `
//                 <div style="margin: 8px 0; padding-bottom: 8px; border-bottom: 1px solid #eee;">
//                   <div style="font-weight: bold; color: #666;">${dimension}</div>
//               `;

//               groupParams.forEach((param: any) => {
//                 tooltipContent += `
//                   <div style="display: flex; justify-content: space-between; margin: 4px 0;">
//                     <span style="color: ${param.color};">● ${param.data.metric}:</span>
//                     <span style="margin-left: 12px;">${formatValue(param.data.value)}</span>
//                   </div>
//                 `;
//               });

//               tooltipContent += '</div>';
//             }
//           });
//         } else {
//           params.forEach((param: any) => {
//             tooltipContent += `
//               <div style="display: flex; justify-content: space-between; margin: 4px 0;">
//                 <span style="color: ${param.color};">● ${param.seriesName}:</span>
//                 <span style="margin-left: 12px;">${formatValue(param.data.value)}</span>
//               </div>
//             `;
//           });
//         }

//         return tooltipContent;
//       }
//     },
//     legend: {
//       show: data.showLegend,
//       type: data.legendType,
//       ...(hasGroupBy ? {
//         orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' 
//           ? 'vertical' 
//           : 'horizontal',
//         top: data.legendOrientation === 'top' ? '0' : 'auto',
//         bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//         left: data.legendOrientation === 'left' ? '0' : 'auto',
//         right: data.legendOrientation === 'right' ? '0' : 'auto',
//         textStyle: {
//           fontSize: 12
//         }
//       } : {
//         top: data.legendOrientation === 'top' ? '0' : 'auto',
//         bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//         left: data.legendOrientation === 'left' ? '0' : 'auto',
//         right: data.legendOrientation === 'right' ? '0' : 'auto',
//       })
//     },
//     grid: {
//       left: '3%',
//       right: '4%',
//       bottom: data.showDataZoom ? '15%' : '3%',
//       top: data.legendOrientation === 'top' ? '15%' : '8%',
//       containLabel: true
//     },
//     xAxis: {
//       type: 'category',
//       data: categories,
//       axisLine: {
//         show: true,
//         lineStyle: {
//           color: '#333',
//           width: 1
//         }
//       },
//       axisTick: {
//         show: true,
//         alignWithLabel: true
//       },
//       axisLabel: {
//         rotate: categories.length > 12 ? 45 : 0,
//         show: true,
//         hideOverlap: true
//       },
//       splitLine: {
//         show: false
//       },
//       axisPointer: {
//         show: true,
//         type: 'line',
//         label: {
//           show: true,
//           backgroundColor: '#666'
//         }
//       }
//     },
//     yAxis: {
//       type: 'value',
//       axisLine: {
//         show: true,
//         lineStyle: {
//           color: '#333',
//           width: 1
//         }
//       },
//       axisTick: {
//         show: true
//       },
//       axisLabel: {
//         show: true,
//         formatter: formatValue
//       },
//       splitLine: {
//         show: true,
//         lineStyle: {
//           type: 'dashed',
//           color: '#ddd'
//         }
//       },
//       axisPointer: {
//         show: true,
//         label: {
//           show: true,
//           backgroundColor: '#666'
//         }
//       }
//     },
//     series: series.map(s => ({
//       ...s,
//       emphasis: {
//         focus: 'series',
//         blurScope: 'coordinateSystem'
//       }
//     })),
//     dataZoom: [
//       {
//         show: true,
//         start: 94,
//         end: 100
//       },
//       {
//         type: 'inside',
//         start: 94,
//         end: 100
//       },
//       {
//         show: true,
//         yAxisIndex: 0,
//         filterMode: 'empty',
//         width: 30,
//         height: '80%',
//         showDataShadow: false,
//         left: '93%'
//       }
//     ],};
//   useEffect(() => {
//     if (chartRef.current) {
//       const chart = chartRef.current.getEchartsInstance();
//       chart.resize();
//     }
//   }, [data]);

//   return (
//     <div ref={containerRef} className="w-full h-full flex flex-col">
//       {data.hideDataTable ? (
//         <div className="flex-grow">
//           <EChartsReact
//             ref={chartRef}
//             option={option}
//             theme={selectedTheme}
//             style={{ height: '100%', width: '100%' }}
//             notMerge={true}
//             opts={{ renderer: 'canvas' }}
//           />
//         </div>
//       ) : (
//         <div className="flex-grow">
//           <EChartsReact
//             ref={chartRef}
//             option={option}
//             theme={selectedTheme}
//             style={{ height: '400px', width: '100%' }}
//             notMerge={true}
//             opts={{ renderer: 'canvas' }}
//           />
//         </div>
//       )}

//       {!data.hideDataTable && (
//         <div className="flex-shrink-0 overflow-auto">
//           <Tabs defaultValue="results">
//             <TabsList className="mb-2">
//               <TabsTrigger value="results">RESULTS</TabsTrigger>
//             </TabsList>
//             <TabsContent value="results" className="h-full overflow-auto">
//               <BarDataTable data={data.chartData} />
//             </TabsContent>
//           </Tabs>
//         </div>
//       )}
//     </div>
//   );
// };

// export default Bar;






// import React, { useEffect, useRef } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import BarDataTable from './BarDataTable';
// import { BarSeriesOption } from 'echarts/charts';
// import { EChartsOption } from 'echarts-for-react';

// interface BarProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//     hideDataTable?: boolean;
//   };
//   theme: string;
// }

// const Bar: React.FC<BarProps> = ({ data, theme }) => {
//   const chartRef = useRef<EChartsReact>(null);
//   const containerRef = useRef<HTMLDivElement>(null);

//   const formatValue = (value: any): string => {
//     if (value === null || value === undefined) return '-';
    
//     if (typeof value === 'number') {
//       return new Intl.NumberFormat('en-US', {
//         maximumFractionDigits: 2,
//         notation: Math.abs(value) > 1000000 ? 'compact' : 'standard'
//       }).format(value);
//     }
    
//     return String(value);
//   };

//   const processData = () => {
//     const keys = Object.keys(data.chartData[0] || {});
//     const categoryKey = keys[0];
//     const valueKeys = keys.slice(1);
//     const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => g.name) || [];
//     const hasGroupBy = groupByFields.length > 0;

//     const categories = data.chartData.map(item => String(item[categoryKey]));
    
//     if (hasGroupBy) {
//       const getDimensionValue = (item: any) => 
//         groupByFields.map(field => item[field]).join(' - ');

//       const dimensionCombinations = Array.from(new Set(
//         data.chartData.map(getDimensionValue)
//       ));

//       const series = dimensionCombinations.flatMap(dimension =>
//         valueKeys.map(key => ({
//           name: `${dimension} - ${key}`,
//           type: 'bar' as const,
//           data: categories.map(category => ({
//             value: data.chartData.find(item => 
//               String(item[categoryKey]) === category && 
//               getDimensionValue(item) === dimension
//             )?.[key] || 0,
//             itemData: data.chartData.find(item => 
//               String(item[categoryKey]) === category && 
//               getDimensionValue(item) === dimension
//             ),
//             dimensions: groupByFields.reduce((acc, field) => ({
//               ...acc,
//               [field]: data.chartData.find(item => 
//                 String(item[categoryKey]) === category && 
//                 getDimensionValue(item) === dimension
//               )?.[field] || null
//             }), {}),
//             metric: key,
//             dimensionDisplay: dimension
//           }))
//         }))
//       );

//       return { categories, series, hasGroupBy };
//     } else {
//       const series: BarSeriesOption[] = valueKeys.map(key => ({
//         name: key,
//         type: 'bar',
//         data: data.chartData.map(item => ({
//           value: Number(item[key]),
//           itemData: item,
//           metric: key
//         }))
//       }));

//       return { categories, series, hasGroupBy };
//     }
//   };

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const { categories, series, hasGroupBy } = processData();
//   const selectedTheme = getSelectedTheme(theme);
//   const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => g.name) || [];

//   const option: EChartsOption = {
//     tooltip: {
//       show: true,
//       trigger: 'axis',
//       axisPointer: {
//         type: 'line',
//         snap: true,
//         animation: true,
//         lineStyle: {
//           color: '#666',
//           width: 1,
//           type: 'solid'
//         },
//         label: {
//           show: true,
//           backgroundColor: '#666'
//         }
//       },
//       backgroundColor: 'rgba(255, 255, 255, 0.9)',
//       borderColor: '#ccc',
//       borderWidth: 1,
//       padding: [5, 10],
//       textStyle: {
//         color: '#333'
//       },
//       extraCssText: 'box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);',
//       formatter: function(params: any) {
//         if (!Array.isArray(params)) return '';
        
//         const xAxisField = data.chartRequest.params.form_data.x_axis.name;
//         const xAxisLabel = data.chartRequest.params.form_data.x_axis.label || xAxisField;
//         let tooltipContent = `
//           <div style="font-weight: bold; margin-bottom: 8px;">
//             ${xAxisLabel}: ${params[0].name}
//           </div>
//         `;

//         if (hasGroupBy) {
//           const groupedParams = params.reduce((acc: any, param: any) => {
//             const dimensionKey = param.data?.dimensionDisplay || 'default';
//             if (!acc[dimensionKey]) {
//               acc[dimensionKey] = [];
//             }
//             acc[dimensionKey].push(param);
//             return acc;
//           }, {});

//           Object.entries(groupedParams).forEach(([dimension, groupParams]: [string, any]) => {
//             if (dimension !== 'default') {
//               tooltipContent += `
//                 <div style="margin: 8px 0; padding-bottom: 8px; border-bottom: 1px solid #eee;">
//                   <div style="font-weight: bold; color: #666;">${dimension}</div>
//               `;

//               groupParams.forEach((param: any) => {
//                 tooltipContent += `
//                   <div style="display: flex; justify-content: space-between; margin: 4px 0;">
//                     <span style="color: ${param.color};">● ${param.data.metric}:</span>
//                     <span style="margin-left: 12px;">${formatValue(param.data.value)}</span>
//                   </div>
//                 `;
//               });

//               tooltipContent += '</div>';
//             }
//           });
//         } else {
//           params.forEach((param: any) => {
//             tooltipContent += `
//               <div style="display: flex; justify-content: space-between; margin: 4px 0;">
//                 <span style="color: ${param.color};">● ${param.seriesName}:</span>
//                 <span style="margin-left: 12px;">${formatValue(param.data.value)}</span>
//               </div>
//             `;
//           });
//         }

//         return tooltipContent;
//       }
//     },
//     legend: {
//       show: data.showLegend,
//       type: data.legendType,
//       ...(hasGroupBy ? {
//         orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' 
//           ? 'vertical' 
//           : 'horizontal',
//         top: data.legendOrientation === 'top' ? '0' : 'auto',
//         bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//         left: data.legendOrientation === 'left' ? '0' : 'auto',
//         right: data.legendOrientation === 'right' ? '0' : 'auto',
//         textStyle: {
//           fontSize: 12
//         }
//       } : {
//         top: data.legendOrientation === 'top' ? '0' : 'auto',
//         bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//         left: data.legendOrientation === 'left' ? '0' : 'auto',
//         right: data.legendOrientation === 'right' ? '0' : 'auto',
//       })
//     },
//     grid: {
//       left: '3%',
//       right: '4%',
//       bottom: data.showDataZoom ? '15%' : '3%',
//       top: data.legendOrientation === 'top' ? '15%' : '8%',
//       containLabel: true
//     },
//     xAxis: {
//       type: 'category',
//       data: categories,
//       axisLine: {
//         show: true,
//         lineStyle: {
//           color: '#333',
//           width: 1
//         }
//       },
//       axisTick: {
//         show: true,
//         alignWithLabel: true
//       },
//       axisLabel: {
//         rotate: categories.length > 12 ? 45 : 0,
//         show: true,
//         hideOverlap: true
//       },
//       splitLine: {
//         show: false
//       },
//       axisPointer: {
//         show: true,
//         type: 'line',
//         label: {
//           show: true,
//           backgroundColor: '#666'
//         }
//       }
//     },
//     yAxis: {
//       type: 'value',
//       axisLine: {
//         show: true,
//         lineStyle: {
//           color: '#333',
//           width: 1
//         }
//       },
//       axisTick: {
//         show: true
//       },
//       axisLabel: {
//         show: true,
//         formatter: formatValue
//       },
//       splitLine: {
//         show: true,
//         lineStyle: {
//           type: 'dashed',
//           color: '#ddd'
//         }
//       },
//       axisPointer: {
//         show: true,
//         label: {
//           show: true,
//           backgroundColor: '#666'
//         }
//       }
//     },
//     series: series.map(s => ({
//       ...s,
//       emphasis: {
//         focus: 'series',
//         blurScope: 'coordinateSystem'
//       }
//     })),
//     ...(data.showDataZoom && {
//       dataZoom: [
//         {
//           show: true,
//           start: 94,
//           end: 100
//         },
//         {
//           type: 'inside',
//           start: 94,
//           end: 100
//         },
//         {
//           show: true,
//           yAxisIndex: 0,
//           filterMode: 'empty',
//           width: 30,
//           height: '80%',
//           showDataShadow: false,
//           left: '93%'
//         }
//       ]
//     })
//   };

//   useEffect(() => {
//     if (chartRef.current) {
//       const chart = chartRef.current.getEchartsInstance();
//       chart.resize();
//     }
//   }, [data]);

//   return (
//     <div ref={containerRef} className="w-full h-full flex flex-col">
//       {data.hideDataTable ? (
//         <div className="flex-grow">
//           <EChartsReact
//             ref={chartRef}
//             option={option}
//             theme={selectedTheme}
//             style={{ height: '100%', width: '100%' }}
//             notMerge={true}
//             opts={{ renderer: 'canvas' }}
//           />
//         </div>
//       ) : (
//         <div className="flex-grow">
//           <EChartsReact
//             ref={chartRef}
//             option={option}
//             theme={selectedTheme}
//             style={{ height: '400px', width: '100%' }}
//             notMerge={true}
//             opts={{ renderer: 'canvas' }}
//           />
//         </div>
//       )}

//       {!data.hideDataTable && (
//         <div className="flex-shrink-0 overflow-auto">
//           <Tabs defaultValue="results">
//             <TabsList className="mb-2">
//               <TabsTrigger value="results">RESULTS</TabsTrigger>
//             </TabsList>
//             <TabsContent value="results" className="h-full overflow-auto">
//               <BarDataTable data={data.chartData} />
//             </TabsContent>
//           </Tabs>
//         </div>
//       )}
//     </div>
//   );
// };

// export default Bar;





// import React, { useEffect, useRef, useState } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import BarDataTable from './BarDataTable';
// import { BarSeriesOption } from 'echarts/charts';
// import { EChartsOption } from 'echarts-for-react';

// interface BarProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//     hideDataTable?: boolean;
//   };
//   theme: string;
// }

// const Bar: React.FC<BarProps> = ({ data, theme }) => {
//   const chartRef = useRef<EChartsReact>(null);
//   const containerRef = useRef<HTMLDivElement>(null);

//   const formatValue = (value: any): string => {
//     if (value === null || value === undefined) return '-';
    
//     if (typeof value === 'number') {
//       return new Intl.NumberFormat('en-US', {
//         maximumFractionDigits: 2,
//         notation: Math.abs(value) > 1000000 ? 'compact' : 'standard'
//       }).format(value);
//     }
    
//     return String(value);
//   };

//   const processData = () => {
//     const keys = Object.keys(data.chartData[0] || {});
//     const categoryKey = keys[0];
//     const valueKeys = keys.slice(1);
//     const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => g.name) || [];
//     const hasGroupBy = groupByFields.length > 0;
//     const dimensions = groupByFields.length;

//     const categories = data.chartData.map(item => String(item[categoryKey]));
    
//     if (hasGroupBy) {
//       const getDimensionValue = (item: any) => 
//         groupByFields.map(field => ({
//           field,
//           value: item[field]
//         }));

//       const dimensionCombinations = Array.from(new Set(
//         data.chartData.map(item => 
//           groupByFields.map(field => item[field]).join(' - ')
//         )
//       ));

//       const series = dimensionCombinations.flatMap(dimension =>
//         valueKeys.map(key => ({
//           name: `${dimension} - ${key}`,
//           type: 'bar' as const,
//           data: categories.map(category => {
//             const matchingItem = data.chartData.find(item => 
//               String(item[categoryKey]) === category && 
//               groupByFields.map(field => item[field]).join(' - ') === dimension
//             );

//             return {
//               value: matchingItem?.[key] || 0,
//               itemData: matchingItem,
//               dimensions: getDimensionValue(matchingItem || {}),
//               metric: key,
//               dimensionDisplay: dimension
//             };
//           })
//         }))
//       );

//       return { categories, series, hasGroupBy, dimensions };
//     } else {
//       const series: BarSeriesOption[] = valueKeys.map(key => ({
//         name: key,
//         type: 'bar',
//         data: data.chartData.map(item => ({
//           value: Number(item[key]),
//           itemData: item,
//           metric: key
//         }))
//       }));

//       return { categories, series, hasGroupBy, dimensions: 0 };
//     }
//   };

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const { categories, series, hasGroupBy, dimensions } = processData();
//   const selectedTheme = getSelectedTheme(theme);
//   const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => g.name) || [];

//   const option: EChartsOption = {
//     tooltip: {
//       trigger: 'item',
//       axisPointer: {
//         type: 'shadow',
//         snap: true,
//         animation: true,
//         shadowStyle: {
//           color: 'rgba(150,150,150,0.1)'
//         }
//       },
//       backgroundColor: 'rgba(255, 255, 255, 0.9)',
//       borderColor: '#ccc',
//       borderWidth: 1,
//       padding: [5, 10],
//       textStyle: {
//         color: '#333'
//       },
//       extraCssText: 'box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);',
//       formatter: function(params: any) {
//         if (!params.data) return '';

//         const xAxisField = data.chartRequest.params.form_data.x_axis.name;
//         const xAxisLabel = data.chartRequest.params.form_data.x_axis.label || xAxisField;
        
//         let tooltipContent = `
//           <div style="font-weight: bold; margin-bottom: 8px;">
//             ${xAxisLabel}: ${params.name}
//           </div>
//         `;

//         if (hasGroupBy) {
//           if (dimensions === 1) {
//             tooltipContent += `
//               <div style="margin: 4px 0;">
//                 <div style="font-weight: bold; color: #666;">
//                   ${groupByFields[0]}: ${params.data.dimensions[0].value}
//                 </div>
//                 <div style="display: flex; justify-content: space-between; margin: 4px 0;">
//                   <span style="color: ${params.color};">● ${params.data.metric}:</span>
//                   <span style="margin-left: 12px;">${formatValue(params.data.value)}</span>
//                 </div>
//               </div>
//             `;
//           } else if (dimensions === 2) {
//             tooltipContent += `
//               <div style="margin: 4px 0;">
//                 <div style="font-weight: bold; color: #666;">
//                   ${groupByFields[0]}: ${params.data.dimensions[0].value}
//                 </div>
//                 <div style="font-weight: bold; color: #666;">
//                   ${groupByFields[1]}: ${params.data.dimensions[1].value}
//                 </div>
//                 <div style="display: flex; justify-content: space-between; margin: 4px 0;">
//                   <span style="color: ${params.color};">● ${params.data.metric}:</span>
//                   <span style="margin-left: 12px;">${formatValue(params.data.value)}</span>
//                 </div>
//               </div>
//             `;
//           } else {
//             tooltipContent += `<div style="margin: 4px 0;">`;
//             params.data.dimensions.forEach((dim: any) => {
//               tooltipContent += `
//                 <div style="font-weight: bold; color: #666;">
//                   ${dim.field}: ${dim.value}
//                 </div>
//               `;
//             });
//             tooltipContent += `
//               <div style="display: flex; justify-content: space-between; margin: 4px 0;">
//                 <span style="color: ${params.color};">● ${params.data.metric}:</span>
//                 <span style="margin-left: 12px;">${formatValue(params.data.value)}</span>
//               </div>
//             </div>
//             `;
//           }
//         } else {
//           tooltipContent += `
//             <div style="display: flex; justify-content: space-between; margin: 4px 0;">
//               <span style="color: ${params.color};">● ${params.seriesName}:</span>
//               <span style="margin-left: 12px;">${formatValue(params.data.value)}</span>
//             </div>
//           `;
//         }

//         return tooltipContent;
//       }
//     },
//     series: series.map(s => ({
//       ...s,
//       emphasis: {
//         focus: 'self',
//         blurScope: 'none'
//       },
//       tooltip: {
//         show: true
//       }
//     })),
//     // Rest of the configuration remains the same
//     legend: {
//       show: data.showLegend,
//       type: data.legendType,
//       ...(hasGroupBy ? {
//         orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' 
//           ? 'vertical' 
//           : 'horizontal',
//         top: data.legendOrientation === 'top' ? '0' : 'auto',
//         bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//         left: data.legendOrientation === 'left' ? '0' : 'auto',
//         right: data.legendOrientation === 'right' ? '0' : 'auto',
//         textStyle: {
//           fontSize: 12
//         }
//       } : {
//         top: data.legendOrientation === 'top' ? '0' : 'auto',
//         bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//         left: data.legendOrientation === 'left' ? '0' : 'auto',
//         right: data.legendOrientation === 'right' ? '0' : 'auto',
//       })
//     },
//     grid: {
//       left: '3%',
//       bottom: data.showDataZoom ? '15%' : '3%',
//       top: data.legendOrientation === 'top' ? '15%' : '8%',
//       containLabel: true
//     },
//     xAxis: {
//       type: 'category',
//       data: categories,
//       axisLine: {
//         show: true,
//         lineStyle: {
//           color: '#333',
//           width: 1
//         }
//       },
//       axisTick: {
//         show: true,
//         alignWithLabel: true
//       },
//       axisLabel: {
//         rotate: categories.length > 12 ? 45 : 0,
//         show: true,
//         hideOverlap: true
//       },
//       splitLine: {
//         show: false
//       }
//     },
//     yAxis: {
//       type: 'value',
//       axisLine: {
//         show: true,
//         lineStyle: {
//           color: '#333',
//           width: 1
//         }
//       },
//       axisTick: {
//         show: true
//       },
//       axisLabel: {
//         show: true,
//         formatter: formatValue
//       },
//       splitLine: {
//         show: true,
//         lineStyle: {
//           type: 'dashed',
//           color: '#ddd'
//         }
//       }
//     },
//     dataZoom: data.showDataZoom ? [
//       {
//         show: true,
//         start: 94,
//         end: 100
//       },
//       {
//         type: 'inside',
//         start: 94,
//         end: 100
//       },
//       {
//         show: true,
//         yAxisIndex: 0,
//         filterMode: 'empty',
//         width: 30,
//         height: '80%',
//         showDataShadow: false,
//         left: '93%'
//       }
//     ] : []
//   };

//   useEffect(() => {
//     if (chartRef.current) {
//       const chart = chartRef.current.getEchartsInstance();
//       chart.resize();
//     }
//   }, [data]);

//   return (
//     <div ref={containerRef} className="w-full h-full flex flex-col">
//       {data.hideDataTable ? (
//         <div className="flex-grow">
//           <EChartsReact
//             ref={chartRef}
//             option={option}
//             theme={selectedTheme}
//             style={{ height: '100%', width: '100%' }}
//             notMerge={true}
//             opts={{ renderer: 'canvas' }}
//           />
//         </div>
//       ) : (
//         <div className="flex-grow">
//           <EChartsReact
//             ref={chartRef}
//             option={option}
//             theme={selectedTheme}
//             style={{ height: '400px', width: '100%' }}
//             notMerge={true}
//             opts={{ renderer: 'canvas' }}
//           />
//         </div>
//       )}

//       {!data.hideDataTable && (
//         <div className="flex-shrink-0 overflow-auto">
//           <Tabs defaultValue="results">
//             <TabsList className="mb-2">
//               <TabsTrigger value="results">RESULTS</TabsTrigger>
//             </TabsList>
//             <TabsContent value="results" className="h-full overflow-auto">
//               <BarDataTable data={data.chartData} />
//             </TabsContent>
//           </Tabs>
//         </div>
//       )}
//     </div>
//   );
// };

// export default Bar;

// import React, { useEffect, useRef } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import BarDataTable from './BarDataTable';
// import { BarSeriesOption } from 'echarts/charts';
// import { EChartsOption } from 'echarts-for-react';

// interface BarProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//     hideDataTable?: boolean;
//   };
//   theme: string;
// }

// const Bar: React.FC<BarProps> = ({ data, theme }) => {
//   const chartRef = useRef<EChartsReact>(null);
//   const containerRef = useRef<HTMLDivElement>(null);

//   const formatValue = (value: any): string => {
//     if (value === null || value === undefined) return '-';
    
//     if (typeof value === 'number') {
//       return new Intl.NumberFormat('en-US', {
//         maximumFractionDigits: 2,
//         notation: Math.abs(value) > 1000000 ? 'compact' : 'standard'
//       }).format(value);
//     }
    
//     return String(value);
//   };

//   const processData = () => {
//     const keys = Object.keys(data.chartData[0] || {});
//     const categoryKey = keys[0];
//     const valueKeys = keys.slice(1);
//     const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => g.name) || [];
//     const hasGroupBy = groupByFields.length > 0;
//     const dimensions = groupByFields.length;

//     // Get unique categories to prevent duplicates
//     const uniqueCategories = Array.from(new Set(
//       data.chartData.map(item => String(item[categoryKey]))
//     ));

//     if (hasGroupBy) {
//       // Create a unique key for each dimension combination
//       const getDimensionKey = (item: any) => 
//         groupByFields.map(field => item[field]).join('|');

//       // Get unique dimension combinations
//       const uniqueDimensions = Array.from(new Set(
//         data.chartData.map(getDimensionKey)
//       )).map(key => ({
//         key,
//         values: key.split('|')
//       }));

//       // Create series data with proper grouping
//       const series = uniqueDimensions.flatMap(dimension =>
//         valueKeys.map(metricKey => {
//           const seriesName = dimension.values.join(' - ');
//           return {
//             name: `${seriesName} - ${metricKey}`,
//             type: 'bar' as const,
//             data: uniqueCategories.map(category => {
//               const matchingItem = data.chartData.find(item => 
//                 String(item[categoryKey]) === category && 
//                 getDimensionKey(item) === dimension.key
//               );

//               return {
//                 value: matchingItem?.[metricKey] ?? 0,
//                 itemData: matchingItem,
//                 dimensions: groupByFields.map((field, index) => ({
//                   field,
//                   value: dimension.values[index]
//                 })),
//                 metric: metricKey,
//                 dimensionDisplay: seriesName
//               };
//             })
//           };
//         })
//       );

//       return { categories: uniqueCategories, series, hasGroupBy, dimensions };
//     } else {
//       // Simple series without grouping
//       const series: BarSeriesOption[] = valueKeys.map(key => ({
//         name: key,
//         type: 'bar',
//         data: uniqueCategories.map(category => {
//           const matchingItem = data.chartData.find(item => 
//             String(item[categoryKey]) === category
//           );
//           return {
//             value: matchingItem ? Number(matchingItem[key]) : 0,
//             itemData: matchingItem,
//             metric: key
//           };
//         })
//       }));

//       return { categories: uniqueCategories, series, hasGroupBy, dimensions: 0 };
//     }
//   };

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const { categories, series, hasGroupBy, dimensions } = processData();
//   const selectedTheme = getSelectedTheme(theme);
//   const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => g.name) || [];

//   const option: EChartsOption = {
//     tooltip: {
//       trigger: 'item',
//       axisPointer: {
//         type: 'shadow',
//         snap: true,
//         animation: true,
//         shadowStyle: {
//           color: 'rgba(150,150,150,0.1)'
//         }
//       },
//       backgroundColor: 'rgba(255, 255, 255, 0.9)',
//       borderColor: '#ccc',
//       borderWidth: 1,
//       padding: [5, 10],
//       textStyle: {
//         color: '#333'
//       },
//       extraCssText: 'box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);',
//       formatter: function(params: any) {
//         if (!params.data) return '';

//         const xAxisField = data.chartRequest.params.form_data.x_axis.name;
//         const xAxisLabel = data.chartRequest.params.form_data.x_axis.label || xAxisField;
        
//         let tooltipContent = `
//           <div style="font-weight: bold; margin-bottom: 8px;">
//             ${xAxisLabel}: ${params.name}
//           </div>
//         `;

//         if (hasGroupBy) {
//           tooltipContent += `<div style="margin: 4px 0;">`;
//           params.data.dimensions.forEach((dim: any) => {
//             tooltipContent += `
//               <div style="font-weight: bold; color: #666;">
//                 ${dim.field}: ${dim.value}
//               </div>
//             `;
//           });
//           tooltipContent += `
//             <div style="display: flex; justify-content: space-between; margin: 4px 0;">
//               <span style="color: ${params.color};">● ${params.data.metric}:</span>
//               <span style="margin-left: 12px;">${formatValue(params.data.value)}</span>
//             </div>
//           </div>`;
//         } else {
//           tooltipContent += `
//             <div style="display: flex; justify-content: space-between; margin: 4px 0;">
//               <span style="color: ${params.color};">● ${params.seriesName}:</span>
//               <span style="margin-left: 12px;">${formatValue(params.data.value)}</span>
//             </div>
//           `;
//         }

//         return tooltipContent;
//       }
//     },
//     series: series.map(s => ({
//       ...s,
//       emphasis: {
//         focus: 'series',
//         blurScope: 'coordinateSystem'
//       },
//       tooltip: {
//         show: true
//       }
//     })),
//     legend: {
//       show: data.showLegend,
//       type: data.legendType,
//       ...(hasGroupBy ? {
//         orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' 
//           ? 'vertical' 
//           : 'horizontal',
//         top: data.legendOrientation === 'top' ? '0' : 'auto',
//         bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//         left: data.legendOrientation === 'left' ? '0' : 'auto',
//         right: data.legendOrientation === 'right' ? '0' : 'auto',
//         textStyle: {
//           fontSize: 12
//         }
//       } : {
//         top: data.legendOrientation === 'top' ? '0' : 'auto',
//         bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//         left: data.legendOrientation === 'left' ? '0' : 'auto',
//         right: data.legendOrientation === 'right' ? '0' : 'auto',
//       })
//     },
//     grid: {
//       left: '3%',
//       right: '3%',
//       bottom: data.showDataZoom ? '15%' : '3%',
//       top: data.legendOrientation === 'top' ? '15%' : '8%',
//       containLabel: true
//     },
//     xAxis: {
//       type: 'category',
//       data: categories,
//       axisLine: {
//         show: true,
//         lineStyle: {
//           color: '#333',
//           width: 1
//         }
//       },
//       axisTick: {
//         show: true,
//         alignWithLabel: true
//       },
//       axisLabel: {
//         rotate: categories.length > 12 ? 45 : 0,
//         show: true,
//         hideOverlap: true,
//         interval: 'auto'
//       },
//       splitLine: {
//         show: false
//       }
//     },
//     yAxis: {
//       type: 'value',
//       axisLine: {
//         show: true,
//         lineStyle: {
//           color: '#333',
//           width: 1
//         }
//       },
//       axisTick: {
//         show: true
//       },
//       axisLabel: {
//         show: true,
//         formatter: formatValue
//       },
//       splitLine: {
//         show: true,
//         lineStyle: {
//           type: 'dashed',
//           color: '#ddd'
//         }
//       }
//     },
//     dataZoom: data.showDataZoom ? [
//       {
//         type: 'slider',
//         show: true,
//         start: 0,
//         end: 100,
//         bottom: 10
//       },
//       {
//         type: 'inside',
//         start: 0,
//         end: 100
//       }
//     ] : []
//   };

//   useEffect(() => {
//     if (chartRef.current) {
//       const chart = chartRef.current.getEchartsInstance();
//       chart.resize();
//     }
//   }, [data]);

//   return (
//     <div ref={containerRef} className="w-full h-full flex flex-col">
//       {data.hideDataTable ? (
//         <div className="flex-grow">
//           <EChartsReact
//             ref={chartRef}
//             option={option}
//             theme={selectedTheme}
//             style={{ height: '100%', width: '100%' }}
//             notMerge={true}
//             opts={{ renderer: 'canvas' }}
//           />
//         </div>
//       ) : (
//         <div className="flex-grow">
//           <EChartsReact
//             ref={chartRef}
//             option={option}
//             theme={selectedTheme}
//             style={{ height: '400px', width: '100%' }}
//             notMerge={true}
//             opts={{ renderer: 'canvas' }}
//           />
//         </div>
//       )}

//       {!data.hideDataTable && (
//         <div className="flex-shrink-0 overflow-auto">
//           <Tabs defaultValue="results">
//             <TabsList className="mb-2">
//               <TabsTrigger value="results">RESULTS</TabsTrigger>
//             </TabsList>
//             <TabsContent value="results" className="h-full overflow-auto">
//               <BarDataTable data={data.chartData} />
//             </TabsContent>
//           </Tabs>
//         </div>
//       )}
//     </div>
//   );
// };

// export default Bar;

// import React, { useEffect, useRef } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import BarDataTable from './BarDataTable';
// import { BarSeriesOption } from 'echarts/charts';
// import { EChartsOption } from 'echarts-for-react';

// interface BarProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//     hideDataTable?: boolean;
//   };
//   theme: string;
// }

// const Bar: React.FC<BarProps> = ({ data, theme }) => {
//   const chartRef = useRef<EChartsReact>(null);
//   const containerRef = useRef<HTMLDivElement>(null);

//   const formatValue = (value: any): string => {
//     if (value === null || value === undefined) return '-';
    
//     if (typeof value === 'number') {
//       // Handle large numbers with compact notation
//       if (Math.abs(value) > 1000000) {
//         return new Intl.NumberFormat('en-US', {
//           notation: 'compact'
//         }).format(value);
//       }
      
//       // Special handling for decimal values
//       if (Math.abs(value) < 1) {
//         if (value < 0.5) {
//           return '0';
//         } else if (value >= 0.5) {
//           return '1';
//         }
//       }
      
//       // For other numbers, use standard formatting with 2 decimal places
//       return new Intl.NumberFormat('en-US', {
//         maximumFractionDigits: 2
//       }).format(value);
//     }
    
//     return String(value);
//   };

//   // Rest of the component remains the same...
//   const processData = () => {
//     const keys = Object.keys(data.chartData[0] || {});
//     const categoryKey = keys[0];
//     const valueKeys = keys.slice(1);
//     const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => g.name) || [];
//     const hasGroupBy = groupByFields.length > 0;
//     const dimensions = groupByFields.length;

//     // Get unique categories to prevent duplicates
//     const uniqueCategories = Array.from(new Set(
//       data.chartData.map(item => String(item[categoryKey]))
//     ));

//     if (hasGroupBy) {
//       // Create a unique key for each dimension combination
//       const getDimensionKey = (item: any) => 
//         groupByFields.map(field => item[field]).join('|');

//       // Get unique dimension combinations
//       const uniqueDimensions = Array.from(new Set(
//         data.chartData.map(getDimensionKey)
//       )).map(key => ({
//         key,
//         values: key.split('|')
//       }));

//       // Create series data with proper grouping
//       const series = uniqueDimensions.flatMap(dimension =>
//         valueKeys.map(metricKey => {
//           const seriesName = dimension.values.join(' - ');
//           return {
//             name: `${seriesName} - ${metricKey}`,
//             type: 'bar' as const,
//             data: uniqueCategories.map(category => {
//               const matchingItem = data.chartData.find(item => 
//                 String(item[categoryKey]) === category && 
//                 getDimensionKey(item) === dimension.key
//               );

//               return {
//                 value: matchingItem?.[metricKey] ?? 0,
//                 itemData: matchingItem,
//                 dimensions: groupByFields.map((field, index) => ({
//                   field,
//                   value: dimension.values[index]
//                 })),
//                 metric: metricKey,
//                 dimensionDisplay: seriesName
//               };
//             })
//           };
//         })
//       );

//       return { categories: uniqueCategories, series, hasGroupBy, dimensions };
//     } else {
//       // Simple series without grouping
//       const series: BarSeriesOption[] = valueKeys.map(key => ({
//         name: key,
//         type: 'bar',
//         data: uniqueCategories.map(category => {
//           const matchingItem = data.chartData.find(item => 
//             String(item[categoryKey]) === category
//           );
//           return {
//             value: matchingItem ? Number(matchingItem[key]) : 0,
//             itemData: matchingItem,
//             metric: key
//           };
//         })
//       }));

//       return { categories: uniqueCategories, series, hasGroupBy, dimensions: 0 };
//     }
//   };

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const { categories, series, hasGroupBy, dimensions } = processData();
//   const selectedTheme = getSelectedTheme(theme);
//   const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => g.name) || [];

//   const option: EChartsOption = {
//     tooltip: {
//       trigger: 'item',
//       axisPointer: {
//         type: 'shadow',
//         snap: true,
//         animation: true,
//         shadowStyle: {
//           color: 'rgba(150,150,150,0.1)'
//         }
//       },
//       backgroundColor: 'rgba(255, 255, 255, 0.9)',
//       borderColor: '#ccc',
//       borderWidth: 1,
//       padding: [5, 10],
//       textStyle: {
//         color: '#333'
//       },
//       extraCssText: 'box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);',
//       formatter: function(params: any) {
//         if (!params.data) return '';

//         const xAxisField = data.chartRequest.params.form_data.x_axis.name;
//         const xAxisLabel = data.chartRequest.params.form_data.x_axis.label || xAxisField;
        
//         let tooltipContent = `
//           <div style="font-weight: bold; margin-bottom: 8px;">
//             ${xAxisLabel}: ${params.name}
//           </div>
//         `;

//         if (hasGroupBy) {
//           tooltipContent += `<div style="margin: 4px 0;">`;
//           params.data.dimensions.forEach((dim: any) => {
//             tooltipContent += `
//               <div style="font-weight: bold; color: #666;">
//                 ${dim.field}: ${dim.value}
//               </div>
//             `;
//           });
//           tooltipContent += `
//             <div style="display: flex; justify-content: space-between; margin: 4px 0;">
//               <span style="color: ${params.color};">● ${params.data.metric}:</span>
//               <span style="margin-left: 12px;">${formatValue(params.data.value)}</span>
//             </div>
//           </div>`;
//         } else {
//           tooltipContent += `
//             <div style="display: flex; justify-content: space-between; margin: 4px 0;">
//               <span style="color: ${params.color};">● ${params.seriesName}:</span>
//               <span style="margin-left: 12px;">${formatValue(params.data.value)}</span>
//             </div>
//           `;
//         }

//         return tooltipContent;
//       }
//     },
//     series: series.map(s => ({
//       ...s,
//       emphasis: {
//         focus: 'series',
//         blurScope: 'coordinateSystem'
//       },
//       tooltip: {
//         show: true
//       }
//     })),
//     legend: {
//       show: data.showLegend,
//       type: data.legendType,
//       ...(hasGroupBy ? {
//         orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' 
//           ? 'vertical' 
//           : 'horizontal',
//         top: data.legendOrientation === 'top' ? '0' : 'auto',
//         bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//         left: data.legendOrientation === 'left' ? '0' : 'auto',
//         right: data.legendOrientation === 'right' ? '0' : 'auto',
//         textStyle: {
//           fontSize: 12
//         }
//       } : {
//         top: data.legendOrientation === 'top' ? '0' : 'auto',
//         bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//         left: data.legendOrientation === 'left' ? '0' : 'auto',
//         right: data.legendOrientation === 'right' ? '0' : 'auto',
//       })
//     },
//     grid: {
//       left: '3%',
//       right: '3%',
//       bottom: data.showDataZoom ? '15%' : '3%',
//       top: data.legendOrientation === 'top' ? '15%' : '8%',
//       containLabel: true
//     },
//     xAxis: {
//       type: 'category',
//       data: categories,
//       axisLine: {
//         show: true,
//         lineStyle: {
//           color: '#333',
//           width: 1
//         }
//       },
//       axisTick: {
//         show: true,
//         alignWithLabel: true
//       },
//       axisLabel: {
//         rotate: categories.length > 12 ? 45 : 0,
//         show: true,
//         hideOverlap: true,
//         interval: 'auto'
//       },
//       splitLine: {
//         show: false
//       }
//     },
//     yAxis: {
//       type: 'value',
//       axisLine: {
//         show: true,
//         lineStyle: {
//           color: '#333',
//           width: 1
//         }
//       },
//       axisTick: {
//         show: true
//       },
//       axisLabel: {
//         show: true,
//         formatter: formatValue
//       },
//       splitLine: {
//         show: true,
//         lineStyle: {
//           type: 'dashed',
//           color: '#ddd'
//         }
//       }
//     },
//     dataZoom: data.showDataZoom ? [
//       {
//         type: 'slider',
//         show: true,
//         start: 0,
//         end: 100,
//         bottom: 10
//       },
//       {
//         type: 'inside',
//         start: 0,
//         end: 100
//       }
//     ] : []
//   };

//   useEffect(() => {
//     if (chartRef.current) {
//       const chart = chartRef.current.getEchartsInstance();
//       chart.resize();
//     }
//   }, [data]);

//   return (
//     <div ref={containerRef} className="w-full h-full flex flex-col">
//       {data.hideDataTable ? (
//         <div className="flex-grow">
//           <EChartsReact
//             ref={chartRef}
//             option={option}
//             theme={selectedTheme}
//             style={{ height: '100%', width: '100%' }}
//             notMerge={true}
//             opts={{ renderer: 'canvas' }}
//           />
//         </div>
//       ) : (
//         <div className="flex-grow">
//           <EChartsReact
//             ref={chartRef}
//             option={option}
//             theme={selectedTheme}
//             style={{ height: '400px', width: '100%' }}
//             notMerge={true}
//             opts={{ renderer: 'canvas' }}
//           />
//         </div>
//       )}

//       {!data.hideDataTable && (
//         <div className="flex-shrink-0 overflow-auto">
//           <Tabs defaultValue="results">
//             <TabsList className="mb-2">
//               <TabsTrigger value="results">RESULTS</TabsTrigger>
//             </TabsList>
//             <TabsContent value="results" className="h-full overflow-auto">
//               <BarDataTable data={data.chartData} />
//             </TabsContent>
//           </Tabs>
//         </div>
//       )}
//     </div>
//   );
// };

// export default Bar;

// import React, { useEffect, useRef } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import BarDataTable from './BarDataTable';
// import { BarSeriesOption } from 'echarts/charts';
// import { EChartsOption } from 'echarts-for-react';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';

// interface BarProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//     hideDataTable?: boolean;
//   };
//   theme: string;
// }

// const Bar: React.FC<BarProps> = ({ data, theme }) => {
//   const chartRef = useRef<EChartsReact>(null);
//   const containerRef = useRef<HTMLDivElement>(null);
  
//   const formatValue = (value: any): string => {
//     if (value === null || value === undefined) return '-';
    
//     if (typeof value === 'number') {
//       if (Math.abs(value) >= 1000000) {
//         return Intl.NumberFormat('en-US', {
//           notation: 'compact',
//           maximumFractionDigits: 1
//         }).format(value);
//       }
      
//       if (Math.abs(value) < 1) {
//         return value.toFixed(2);
//       }
      
//       return Intl.NumberFormat('en-US', {
//         maximumFractionDigits: 2,
//         minimumFractionDigits: 0
//       }).format(value);
//     }
    
//     return String(value);
//   };

//   const processData = () => {
//     const keys = Object.keys(data.chartData[0] || {});
//     const categoryKey = keys[0];
//     const valueKeys = keys.slice(1);
//     const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => g.name) || [];
//     const hasGroupBy = groupByFields.length > 0;
//     const dimensions = groupByFields.length;

//     const uniqueCategories = Array.from(new Set(
//       data.chartData.map(item => String(item[categoryKey]))
//     ));

//     if (hasGroupBy) {
//       const getDimensionKey = (item: any) => 
//         groupByFields.map(field => item[field]).join('|');

//       const uniqueDimensions = Array.from(new Set(
//         data.chartData.map(getDimensionKey)
//       )).map(key => ({
//         key,
//         values: key.split('|')
//       }));

//       const series = uniqueDimensions.flatMap(dimension =>
//         valueKeys.map(metricKey => ({
//           name: `${dimension.values.join(' - ')} - ${metricKey}`,
//           type: 'bar' as const,
//           emphasis: {
//             focus: 'series',
//             blurScope: 'series',
//             scale: false,
//             itemStyle: {
//               opacity: 0.7
//             }
//           },
//           select: {
//             disabled: true
//           },
//           data: uniqueCategories.map(category => {
//             const matchingItem = data.chartData.find(item => 
//               String(item[categoryKey]) === category && 
//               getDimensionKey(item) === dimension.key
//             );

//             return {
//               value: matchingItem?.[metricKey] ?? 0,
//               itemData: matchingItem,
//               dimensions: groupByFields.map((field, index) => ({
//                 field,
//                 value: dimension.values[index]
//               })),
//               metric: metricKey,
//               dimensionDisplay: dimension.values.join(' - ')
//             };
//           })
//         }))
//       );

//       return { categories: uniqueCategories, series, hasGroupBy, dimensions };
//     } else {
//       const series: BarSeriesOption[] = valueKeys.map(key => ({
//         name: key,
//         type: 'bar',
//         emphasis: {
//           focus: 'series',
//           blurScope: 'series',
//           scale: false,
//           itemStyle: {
//             opacity: 0.7
//           }
//         },
//         select: {
//           disabled: true
//         },
//         data: uniqueCategories.map(category => {
//           const matchingItem = data.chartData.find(item => 
//             String(item[categoryKey]) === category
//           );
//           return {
//             value: matchingItem ? Number(matchingItem[key]) : 0,
//             itemData: matchingItem,
//             metric: key
//           };
//         })
//       }));

//       return { categories: uniqueCategories, series, hasGroupBy, dimensions: 0 };
//     }
//   };

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const { categories, series, hasGroupBy, dimensions } = processData();
//   const selectedTheme = getSelectedTheme(theme);
//   const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => g.name) || [];

//   const option: EChartsOption = {
//     tooltip: {
//       trigger: 'axis',
//       axisPointer: {
//         type: 'shadow',
//         snap: true,
//         animation: true,
//         shadowStyle: {
//           color: 'rgba(150,150,150,0.1)'
//         }
//       },
//       enterable: true,

//       position: function (point, params, dom, rect, size) {
//         const gap = 20;
//         const chartWidth = containerRef.current?.clientWidth || 0;
//         const chartHeight = containerRef.current?.clientHeight || 0;
//         const tooltipWidth = size.contentSize[0];
//         const tooltipHeight = size.contentSize[1];
        
//         let [x, y] = point;
        
//         if (x + tooltipWidth + gap > chartWidth) {
//           x = x - tooltipWidth - gap;
//         } else {
//           x = x + gap;
//         }
        
//         if (y + tooltipHeight + gap > chartHeight) {
//           y = y - tooltipHeight - gap;
//         } else {
//           y = y + gap;
//         }
        
//         x = Math.max(gap, Math.min(x, chartWidth - tooltipWidth - gap));
//         y = Math.max(gap, Math.min(y, chartHeight - tooltipHeight - gap));
        
//         return [x, y];
//       },
//       backgroundColor: 'rgba(255, 255, 255, 0.95)',
//       borderColor: '#ccc',
//       borderWidth: 1,
//       padding: [8, 12],
//       textStyle: {
//         color: '#333',
//         fontSize: 12
//       },
//       extraCssText: 'box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); border-radius: 4px;',
//       formatter: function(params: any) {
//         if (!Array.isArray(params)) return '';
  
//         const xAxisField = data.chartRequest.params.form_data.x_axis.name;
//         const xAxisLabel = data.chartRequest.params.form_data.x_axis.label || xAxisField;
//         const hoveredSeriesName = params[0].seriesName;
  
//         let tooltipContent = `
//           <div style="margin-bottom: 10px; padding-bottom: 6px; border-bottom: 1px solid #eee;">
//             <span style="font-size: 13px; font-weight: 600; color: #666;">
//               ${xAxisLabel}: ${params[0].name}
//             </span>
//           </div>
//         `;
  
//         if (hasGroupBy) {
//           // Filter only the metrics (columns that contain 'amount' or other metric identifiers)
//           const metricParams = params.filter((param: any) => 
//             param.data && 
//             param.data.value !== 0 &&
//             param.seriesName.includes('amount')  // Add other metric identifiers if needed
//           );
  
//           metricParams.forEach((param: any) => {
//             const isHovered = param.seriesName === hoveredSeriesName;
//             const dimensionName = param.data.dimensionDisplay;
            
//             tooltipContent += `
//               <div style="display: flex; justify-content: space-between; align-items: center; margin: 4px 0;">
//                 <div style="display: flex; align-items: center; gap: 6px;">
//                   <span style="color: ${param.color}; font-size: 16px;">●</span>
//                   <span style="
//                     color: ${isHovered ? param.color : '#666'}; 
//                     font-size: 12px; 
//                     font-weight: ${isHovered ? '600' : '400'};
//                   ">
//                     ${dimensionName}
//                   </span>
//                 </div>
//                 <span style="
//                   font-size: 12px; 
//                   font-weight: ${isHovered ? '600' : '400'}; 
//                   color: ${isHovered ? param.color : '#666'};
//                 ">
//                   ${formatValue(param.data.value)}
//                 </span>
//               </div>
//             `;
//           });
//         } else {
//           // When no groupBy, show all non-zero values
          // const nonZeroParams = params.filter((param: any) => 
          //   param.data && param.data.value !== 0
          // );
  
//           nonZeroParams.forEach((param: any) => {
//             const isHovered = param.seriesName === hoveredSeriesName;
//             tooltipContent += `
//               <div style="display: flex; justify-content: space-between; align-items: center; margin: 4px 0;">
//                 <div style="display: flex; align-items: center; gap: 6px;">
//                   <span style="color: ${param.color}; font-size: 16px;">●</span>
//                   <span style="
//                     color: ${isHovered ? param.color : '#666'}; 
//                     font-size: 12px; 
//                     font-weight: ${isHovered ? '600' : '400'};
//                   ">
//                     ${param.seriesName}
//                   </span>
//                 </div>
//                 <span style="
//                   font-size: 12px; 
//                   font-weight: ${isHovered ? '600' : '400'}; 
//                   color: ${isHovered ? param.color : '#666'};
//                 ">
//                   ${formatValue(param.data.value)}
//                 </span>
//               </div>
//             `;
//           });
//         }
  
//         return `
//         <div style="max-height: 200px; overflow-y: auto;">
//           ${tooltipContent}
//         </div>
//       `;              }
//     },
//     legend: {
//       show: data.showLegend,
//       type: data.legendType,
//       ...(hasGroupBy ? {
//         orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' 
//           ? 'vertical' 
//           : 'horizontal',
//         top: data.legendOrientation === 'top' ? '0' : 'auto',
//         bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//         left: data.legendOrientation === 'left' ? '0' : 'auto',
//         right: data.legendOrientation === 'right' ? '0' : 'auto',
//         textStyle: {
//           fontSize: 12
//         }
//       } : {
//         top: data.legendOrientation === 'top' ? '0' : 'auto',
//         bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//         left: data.legendOrientation === 'left' ? '0' : 'auto',
//         right: data.legendOrientation === 'right' ? '0' : 'auto',
//       })
//     },
//     grid: {
//       left: '3%',
//       right: '3%',
//       bottom: data.showDataZoom ? '15%' : '3%',
//       top: data.legendOrientation === 'top' ? '15%' : '8%',
//       containLabel: true
//     },
//     xAxis: {
//       type: 'category',
//       data: categories,
//       axisLine: {
//         show: true,
//         lineStyle: {
//           color: '#333',
//           width: 1
//         }
//       },
//       axisTick: {
//         show: true,
//         alignWithLabel: true
//       },
//       axisLabel: {
//         rotate: categories.length > 12 ? 45 : 0,
//         show: true,
//         hideOverlap: true,
//         interval: 'auto'
//       },
//       splitLine: {
//         show: false
//       }
//     },
//     yAxis: {
//       type: 'value',
//       axisLine: {
//         show: true,
//         lineStyle: {
//           color: '#333',
//           width: 1
//         }
//       },
//       axisTick: {
//         show: true
//       },
//       axisLabel: {
//         show: true,
//         formatter: formatValue
//       },
//       splitLine: {
//         show: true,
//         lineStyle: {
//           type: 'dashed',
//           color: '#ddd'
//         }
//       }
//     },
//     dataZoom: data.showDataZoom ? [
//       {
//         type: 'slider',
//         show: true,
//         start: 0,
//         end: 100,
//         bottom: 10
//       },
//       {
//         type: 'inside',
//         start: 0,
//         end: 100
//       }
//     ] : [],
//     series
//   };

//   useEffect(() => {
//     if (chartRef.current) {
//       const chart = chartRef.current.getEchartsInstance();
//       chart.resize();
//     }
//   }, [data]);

//   return (
//     <div ref={containerRef} className="w-full h-full flex flex-col">
//       {data.hideDataTable ? (
//         <div className="flex-grow">
//           <EChartsReact
//             ref={chartRef}
//             option={option}
//             theme={selectedTheme}
//             style={{ height: '100%', width: '100%' }}
//             notMerge={true}
//             opts={{ renderer: 'canvas' }}
//           />
//         </div>
//       ) : (
//         <div className="flex-grow">
//           <EChartsReact
//             ref={chartRef}
//             option={option}
//             theme={selectedTheme}
//             style={{ height: '400px', width: '100%' }}
//             notMerge={true}
//             opts={{ renderer: 'canvas' }}
//           />
//         </div>
//       )}

//       {!data.hideDataTable && (
//         <div className="flex-shrink-0 overflow-auto">
//           <Tabs defaultValue="results">
//             <TabsList className="mb-2">
//               <TabsTrigger value="results">RESULTS</TabsTrigger>
//             </TabsList>
//             <TabsContent value="results" className="h-full overflow-auto">
//               <BarDataTable data={data.chartData} />
//             </TabsContent>
//           </Tabs>
//         </div>
//       )}
//     </div>
//   );
// };

// export default Bar;

import React, { useEffect, useRef } from 'react';
import EChartsReact from 'echarts-for-react';
import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
import { BarSeriesOption } from 'echarts/charts';
import { EChartsOption } from 'echarts-for-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
import BarDataTable from './BarDataTable';

interface BarProps {
  data: {
    chartType: string;
    chartData: Array<Record<string, any>>;
    showLegend: boolean;
    legendOrientation: 'top' | 'bottom' | 'left' | 'right';
    legendType: 'plain' | 'scroll';
    chartRequest: any;
    showDataZoom: boolean;
    hideDataTable?: boolean;
  };
  theme: string;
}

const Bar: React.FC<BarProps> = ({ data, theme }) => {
  const chartRef = useRef<EChartsReact>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  
  const formatValue = (value: any): string => {
    if (value === null || value === undefined) return '-';
    
    if (typeof value === 'number') {
      if (Math.abs(value) >= 1000000) {
        return Intl.NumberFormat('en-US', {
          notation: 'compact',
          maximumFractionDigits: 1
        }).format(value);
      }
      
      if (Math.abs(value) < 1) {
        return value.toFixed(2);
      }
      
      return Intl.NumberFormat('en-US', {
        maximumFractionDigits: 2,
        minimumFractionDigits: 0
      }).format(value);
    }
    
    return String(value);
  };

  const processData = () => {
    const keys = Object.keys(data.chartData[0] || {});
    const categoryKey = keys[0];
    const valueKeys = keys.slice(1);
    console.log("valueKeys",valueKeys)
    console.log("valueKeys",valueKeys)
    const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => 
      (g.label ? g.label.toLowerCase() : g.name.toLowerCase())
    ) || [];
    const hasGroupBy = groupByFields.length > 0;
    const dimensions = groupByFields.length;

    const uniqueCategories = Array.from(new Set(
      data.chartData.map(item => String(item[categoryKey]))
    ));

    if (hasGroupBy) {
      const getDimensionKey = (item: any) => 
        groupByFields.map(field => item[field]).join('|');

      const uniqueDimensions = Array.from(new Set(
        data.chartData.map(getDimensionKey)
      )).map(key => ({
        key,
        values: key.split('|')
      }));

      const series = uniqueDimensions.flatMap(dimension =>
        valueKeys.map(metricKey => ({
          // name: `${dimension.values.join(' - ')} - ${metricKey}`,
          name: `${metricKey},${dimension.values.join(' - ')} `,
          type: 'bar' as const,
          emphasis: {
            focus: 'series',
            blurScope: 'series',
            scale: false,
            itemStyle: {
              opacity: 0.7
            }
          },
          select: {
            disabled: true
          },
          data: uniqueCategories.map(category => {
            const matchingItem = data.chartData.find(item => 
              String(item[categoryKey]) === category && 
              getDimensionKey(item) === dimension.key
            );

            return {
              value: matchingItem?.[metricKey] ?? 0,
              itemData: matchingItem,
              dimensions: groupByFields.map((field, index) => ({
                field,
                value: dimension.values[index]
              })),
              metric: metricKey,
              dimensionDisplay: dimension.values.join(' - ')
            };
          })
        }))
      );

      return { categories: uniqueCategories, series, hasGroupBy, dimensions };
    } else {
      const series: BarSeriesOption[] = valueKeys.map(key => ({
        name: key,
        type: 'bar',
        emphasis: {
          focus: 'series',
          blurScope: 'series',
          scale: false,
          itemStyle: {
            opacity: 0.7
          }
        },
        select: {
          disabled: true
        },
        data: uniqueCategories.map(category => {
          const matchingItem = data.chartData.find(item => 
            String(item[categoryKey]) === category
          );
          return {
            value: matchingItem ? Number(matchingItem[key]) : 0,
            itemData: matchingItem,
            metric: key
          };
        })
      }));

      return { categories: uniqueCategories, series, hasGroupBy, dimensions: 0 };
    }
  };

  const getSelectedTheme = (themeName: string) => {
    switch (themeName) {
      case 'Essos': return Essos;
      case 'Wonderland': return Wonderland;
      case 'Walden': return Walden;
      case 'Infographic': return Infographic;
      case 'Macarons': return Macarons;
      case 'Roma': return Roma;
      case 'CoolTheme': return CoolTheme;
      case 'Shine': return Shine;
      default: return Westeros;
    }
  };
  const getGroupByColumns = () => {
    // Get only the groupby columns from form_data
    return data.chartRequest.params.form_data.groupby?.map(g => 
      (g.label ? g.label.toLowerCase() : g.name.toLowerCase())
    ) || [];
  };
  
  const { categories, series, hasGroupBy, dimensions } = processData();
  const selectedTheme = getSelectedTheme(theme);
  const option: EChartsOption = {
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow',
        snap: true,
        animation: true,
        shadowStyle: {
          color: 'rgba(150,150,150,0.1)'
        }
      },
      enterable: true,
      position: function (point, params, dom, rect, size) {
        const gap = 20;
        const chartWidth = containerRef.current?.clientWidth || 0;
        const chartHeight = containerRef.current?.clientHeight || 0;
        const tooltipWidth = size.contentSize[0];
        const tooltipHeight = size.contentSize[1];
        
        let [x, y] = point;
        
        if (x + tooltipWidth + gap > chartWidth) {
          x = x - tooltipWidth - gap;
        } else {
          x = x + gap;
        }
        
        if (y + tooltipHeight + gap > chartHeight) {
          y = y - tooltipHeight - gap;
        } else {
          y = y + gap;
        }
        
        x = Math.max(gap, Math.min(x, chartWidth - tooltipWidth - gap));
        y = Math.max(gap, Math.min(y, chartHeight - tooltipHeight - gap));
        
        return [x, y];
      },
      backgroundColor: 'rgba(255, 255, 255, 0.95)',
      borderColor: '#ccc',
      borderWidth: 1,
      padding: [8, 12],
      textStyle: {
        color: '#333',
        fontSize: 12
      },
      extraCssText: 'box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); border-radius: 4px;',
      formatter: function(params: any) {
        if (!Array.isArray(params)) return '';
        
        const groupByColumns = getGroupByColumns();
        
        // Filter out params where series name contains any groupby column
        const filteredParams = params.filter((param: any) => {
          const seriesName = param.seriesName.toLowerCase();
          return !groupByColumns.some(column => {
            const columnValue = column.label?.toLowerCase() || column.name?.toLowerCase() || column.toLowerCase();
            return seriesName.startsWith(columnValue);
          });
        });
        

        // // Filter out zero values
        // const nonZeroParams = filteredParams.filter((param: any) => 
        //   param.data 
        // );
        const nonZeroParams = params.filter((param: any) => 
          param.data && param.data.value !== 0
        );

  
        let tooltipContent = `
          <div style="margin-bottom: 10px; padding-bottom: 6px; border-bottom: 1px solid #eee;">
            <span style="font-size: 13px; font-weight: 600; color: #666;">
              ${params[0].name}
            </span>
          </div>
        `;
  
        // Group by metric type
        const metricGroups = new Map();
        
        nonZeroParams.forEach((param: any) => {
          const data = param.data;
          if (!data || !data.metric) return;
          
          if (!metricGroups.has(data.metric)) {
            metricGroups.set(data.metric, []);
          }
          
          metricGroups.get(data.metric).push({
            name: param.seriesName,
            value: data.value,
            color: param.color,
            itemData: data.itemData
          });
        });
  
        // Add each metric group to tooltip
        metricGroups.forEach((items, metric) => {
          tooltipContent += `
            <div style="margin-top: 8px;">
              ${items.map((item: any) => `
                <div style="display: flex; justify-content: space-between; align-items: center; margin: 4px 0;">
                  <div style="display: flex; align-items: center; gap: 6px;">
                    <span style="color: ${item.color}; font-size: 16px;">●</span>
                    <span style="color: #666; font-size: 12px;">
                      ${item.name} : ${formatValue(item.value)}
                    </span>
                  </div>
                  <span style="font-size: 12px; color: #666;">
                  </span>
                </div>
              `).join('')}
            </div>
          `;
        });
  
        return `
          <div style="max-height: 200px; overflow-y: auto;">
            ${tooltipContent}
          </div>
        `;
      }
    },
    legend: {
      show: data.showLegend,
      type: data.legendType,
      ...(hasGroupBy ? {
        orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' 
          ? 'vertical' 
          : 'horizontal',
        top: data.legendOrientation === 'top' ? '0' : 'auto',
        bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
        left: data.legendOrientation === 'left' ? '0' : 'auto',
        right: data.legendOrientation === 'right' ? '0' : 'auto',
        textStyle: {
          fontSize: 12
        }
      } : {
        top: data.legendOrientation === 'top' ? '0' : 'auto',
        bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
        left: data.legendOrientation === 'left' ? '0' : 'auto',
        right: data.legendOrientation === 'right' ? '0' : 'auto',
      }),
      
    },
    grid: {
      left: '3%',
      right: '3%',
      bottom: data.showDataZoom ? '15%' : '3%',
      top: data.legendOrientation === 'top' ? '15%' : '8%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      data: categories,
      axisLine: {
        show: true,
        lineStyle: {
          color: '#333',
          width: 1
        }
      },
      axisTick: {
        show: true,
        alignWithLabel: true
      },
      axisLabel: {
        rotate: categories.length > 12 ? 45 : 0,
        show: true,
        hideOverlap: true,
        interval: 'auto'
      },
      splitLine: {
        show: false
      }
    },
    yAxis: {
      type: 'value',
      axisLine: {
        show: true,
        lineStyle: {
          color: '#333',
          width: 1
        }
      },
      axisTick: {
        show: true
      },
      axisLabel: {
        show: true,
        formatter: formatValue
      },
      splitLine: {
        show: true,
        lineStyle: {
          type: 'dashed',
          color: '#ddd'
        }
      }
    },
    dataZoom: data.showDataZoom ? [
      {
        type: 'slider',
        show: true,
        start: 0,
        end: 100,
        bottom: 10
      },
      {
        type: 'inside',
        start: 0,
        end: 100
      }
    ] : [],
    series
  };
  console.log("series",series);
  console.log("option",option);

  useEffect(() => {
    if (chartRef.current) {
      const chart = chartRef.current.getEchartsInstance();
      chart.resize();
    }
  }, [data]);

  return (
    <div ref={containerRef} className="w-full h-full flex flex-col">
      {data.hideDataTable ? (
        <div className="flex-grow">
          <EChartsReact
            ref={chartRef}
            option={option}
            theme={selectedTheme}
            style={{ height: '100%', width: '100%' }}
            notMerge={true}
            opts={{ renderer: 'canvas' }}
          />
        </div>
      ) : (
        <div className="flex-grow">
          <EChartsReact
            ref={chartRef}
            option={option}
            theme={selectedTheme}
            style={{ height: '400px', width: '100%' }}
            notMerge={true}
            opts={{ renderer: 'canvas' }}
          />
        </div>
      )}

      {!data.hideDataTable && (
        <div className="flex-shrink-0 overflow-auto">
          <Tabs defaultValue="results">
            <TabsList className="mb-2">
              <TabsTrigger value="results">RESULTS</TabsTrigger>
            </TabsList>
            <TabsContent value="results" className="h-full overflow-auto">
              <BarDataTable data={data.chartData} />
            </TabsContent>
          </Tabs>
        </div>
      )}
    </div>
  );
};

export default Bar;