// import React, { useEffect, useState } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';

// interface AreaProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//   };
//   theme: string;
// }

// const Area: React.FC<AreaProps> = ({ data, theme }) => {
//   const [elapsedTime, setElapsedTime] = useState(0);

//   useEffect(() => {
//     const timer = setInterval(() => {
//       setElapsedTime((prevTime) => prevTime + 1);
//     }, 1000);

//     return () => clearInterval(timer);
//   }, []);

//   useEffect(() => {
//     console.log("Number of rows in API response:", data.chartData.length);
//   }, [data.chartData]);

//   const processedData = data.chartData.map(item => {
//     const keys = Object.keys(item);
//     return {
//       name: String(item[keys[0]]),
//       value: Number(item[keys[1]])
//     };
//   }).filter(item => !isNaN(item.value));

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const selectedTheme = getSelectedTheme(theme);

//   const option: echarts.EChartsOption = {
//     tooltip: {
//       trigger: 'axis',
//       axisPointer: {
//         type: 'cross',
//       }
//     },
//     legend: {
//       show: data.showLegend,
//       orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' ? 'vertical' : 'horizontal',
//       [data.legendOrientation]: 10,
//       type: data.legendType,
//     },
//     dataZoom: data.showDataZoom
//       ? [
//           {
//             id: 'dataZoomX',
//             type: 'slider',
//             xAxisIndex: [0],
//             filterMode: 'filter',
//           },
//           {
//             id: 'dataZoomY',
//             type: 'slider',
//             yAxisIndex: [0],
//             filterMode: 'empty',
//           },
//         ]
//       : [],
//     xAxis: {
//       type: 'category',
//       data: processedData.map(item => item.name),
//       axisLabel: {
//         rotate: 45,
//         interval: 0,
//       }
//     },
//     yAxis: {
//       type: 'value',
//     },
//     series: [
//       {
//         name: 'Data',
//         type: 'line',
//         data: processedData.map(item => item.value),
//         areaStyle: {}, // This enables the area chart style
//         itemStyle: {
//           color: selectedTheme.color[0]
//         }
//       }
//     ],
//     color: selectedTheme.color,
//   };

//   return (
//     <div className="relative" style={{ height: '600px', width: '100%' }}>
//       <div className="absolute top-2 right-2 flex items-center space-x-2 z-10">
//         <div className="bg-red-500 mt-5 text-white px-3 py-1 rounded-full text-sm font-semibold">
//           {data.chartData.length} rows
//         </div>
//       </div>
//       <EChartsReact
//         option={option}
//         style={{ height: '100%', width: '100%' }}
//         theme={selectedTheme}
//       />
//     </div>
//   );
// };

// // export default Area;
// import React, { useEffect, useState, useRef } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import AreaDataTable from './AreaDataTable'; // Assuming you have this component

// interface AreaProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//     hideDataTable?: boolean;
//   };
//   theme: string;
// }

// const Area: React.FC<AreaProps> = ({ data, theme }) => {
//   const [elapsedTime, setElapsedTime] = useState(0);
//   const chartRef = useRef<EChartsReact>(null);
//   const containerRef = useRef<HTMLDivElement>(null);
//   const [containerSize, setContainerSize] = useState({ width: 0, height: 0 });

//   useEffect(() => {
//     const timer = setInterval(() => {
//       setElapsedTime((prevTime) => prevTime + 1);
//     }, 1000);

//     return () => clearInterval(timer);
//   }, []);

//   useEffect(() => {
//     console.log("Number of rows in API response:", data.chartData.length);
//   }, [data.chartData]);

//   useEffect(() => {
//     const resizeObserver = new ResizeObserver(entries => {
//       for (let entry of entries) {
//         const { width, height } = entry.contentRect;
//         setContainerSize({ width, height });
//       }
//     });

//     if (containerRef.current) {
//       resizeObserver.observe(containerRef.current);
//     }

//     return () => {
//       resizeObserver.disconnect();
//     };
//   }, []);

//   useEffect(() => {
//     if (chartRef.current) {
//       chartRef.current.getEchartsInstance().resize();
//     }
//   }, [containerSize]);

//   const processedData = data.chartData.map(item => {
//     const keys = Object.keys(item);
//     return {
//       name: String(item[keys[0]]),
//       value: Number(item[keys[1]])
//     };
//   }).filter(item => !isNaN(item.value));

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const selectedTheme = getSelectedTheme(theme);

//   const option: echarts.EChartsOption = {
//     tooltip: {
//       trigger: 'axis',
//       axisPointer: {
//         type: 'cross',
//       }
//     },
//     legend: {
//       show: data.showLegend,
//       type: data.legendType,
//       top: data.legendOrientation === 'top' ? '0' : 'auto',
//       bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//       left: data.legendOrientation === 'left' ? '0' : 'auto',
//       right: data.legendOrientation === 'right' ? '0' : 'auto',
//     },
//     grid: {
//       left: '3%',
//       right: '4%',
//       bottom: data.showDataZoom ? '15%' : '3%',
//       containLabel: true
//     },
//     xAxis: {
//       type: 'category',
//       data: processedData.map(item => item.name),
//       axisLabel: {
//         rotate: 45,
//         interval: 0,
//       }
//     },
//     yAxis: {
//       type: 'value',
//     },
//     series: [
//       {
//         name: 'Data',
//         type: 'line',
//         data: processedData.map(item => item.value),
//         areaStyle: {}, // This enables the area chart style
//         itemStyle: {
//           color: selectedTheme.color[0]
//         }
//       }
//     ],
//     dataZoom: data.showDataZoom ? [
//       {
//         type: 'slider',
//         show: true,
//         start: 0,
//         end: 100,
//         height: 30
//       },
//       {
//         type: 'inside',
//         start: 0,
//         end: 100
//       }
//     ] : [],
//     color: selectedTheme.color,
//   };

//   return (
//     <div ref={containerRef} className="flex flex-col h-full">
//       <div className="relative" style={{ height: '400px', width: '100%' }}>
//         <div className="absolute top-2 right-2 flex items-center space-x-2 z-10">
//           <div className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
//             {data.chartData.length} rows
//           </div>
//         </div>
//         <EChartsReact
//           ref={chartRef}
//           option={option}
//           style={{ height: '100%', width: '100%' }}
//           theme={selectedTheme}
//           notMerge={true}
//           lazyUpdate={false}
//         />
//       </div>

//       {!data.hideDataTable && (
//         <div className="mt-4">
//           <Tabs defaultValue="results">
//             <TabsList>
//               <TabsTrigger value="results">RESULTS</TabsTrigger>
//               {/* <TabsTrigger value="samples">SAMPLES</TabsTrigger> */}
//             </TabsList>
//             <TabsContent value="results" className="h-64 overflow-auto">
//               <AreaDataTable data={data.chartData} />
//             </TabsContent>
//             {/* <TabsContent value="samples"> */}
//               {/* Add sample content here */}
//             {/* </TabsContent> */}
//           </Tabs>
//         </div>
//       )}
//     </div>
//   );
// };

// export default Area;


// import React, { useEffect, useState, useRef } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import AreaDataTable from './AreaDataTable';
// import { EChartsOption, SeriesOption } from 'echarts';

// interface AreaProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//     hideDataTable?: boolean;
//   };
//   theme: string;
// }

// const Area: React.FC<AreaProps> = ({ data, theme }) => {
//   const [elapsedTime, setElapsedTime] = useState(0);
//   const chartRef = useRef<EChartsReact>(null);
//   const containerRef = useRef<HTMLDivElement>(null);
//   const [containerSize, setContainerSize] = useState({ width: 0, height: 0 });

//   useEffect(() => {
//     const timer = setInterval(() => {
//       setElapsedTime((prevTime) => prevTime + 1);
//     }, 1000);

//     return () => clearInterval(timer);
//   }, []);

//   useEffect(() => {
//     console.log("Number of rows in API response:", data.chartData.length);
//   }, [data.chartData]);

//   useEffect(() => {
//     const resizeObserver = new ResizeObserver(entries => {
//       for (let entry of entries) {
//         const { width, height } = entry.contentRect;
//         setContainerSize({ width, height });
//       }
//     });

//     if (containerRef.current) {
//       resizeObserver.observe(containerRef.current);
//     }

//     return () => {
//       resizeObserver.disconnect();
//     };
//   }, []);

//   useEffect(() => {
//     if (chartRef.current) {
//       chartRef.current.getEchartsInstance().resize();
//     }
//   }, [containerSize]);

//   const processData = () => {
//     const keys = Object.keys(data.chartData[0]);
//     const categoryKey = keys[0];
//     const valueKeys = keys.slice(1);

//     const categories = data.chartData.map(item => String(item[categoryKey]));
//     const series: SeriesOption[] = valueKeys.map(key => ({
//       name: key,
//       type: 'line',
//       data: data.chartData.map(item => Number(item[key])),
//       areaStyle: {},
//     }));

//     return { categories, series };
//   };

//   const { categories, series } = processData();

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const selectedTheme = getSelectedTheme(theme);

//   const option: EChartsOption = {
//     tooltip: {
//       trigger: 'axis',
//       axisPointer: {
//         type: 'cross',
//       }
//     },
//     legend: {
//       show: data.showLegend,
//       type: data.legendType,
//       top: data.legendOrientation === 'top' ? '0' : 'auto',
//       bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//       left: data.legendOrientation === 'left' ? '0' : 'auto',
//       right: data.legendOrientation === 'right' ? '0' : 'auto',
//     },
//     grid: {
//       left: '3%',
//       right: '4%',
//       bottom: data.showDataZoom ? '15%' : '3%',
//       containLabel: true
//     },
//     xAxis: {
//       type: 'category',
//       data: categories,
//       axisLabel: {
//         rotate: 45,
//         interval: 0,
//       }
//     },
//     yAxis: {
//       type: 'value',
//     },
//     series: series,
//     dataZoom: data.showDataZoom ? [
//       {
//         type: 'slider',
//         show: true,
//         start: 0,
//         end: 100,
//         height: 30
//       },
//       {
//         type: 'inside',
//         start: 0,
//         end: 100
//       }
//     ] : [],
//     color: selectedTheme.color,
//   };

//   return (
//     <div ref={containerRef} className="flex flex-col h-full">
//       <div className="relative" style={{ height: '400px', width: '100%' }}>
//         <div className="absolute top-2 right-2 flex items-center space-x-2 z-10">
//           <div className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
//             {data.chartData.length} rows
//           </div>
//         </div>
//         <EChartsReact
//           ref={chartRef}
//           option={option}
//           style={{ height: '100%', width: '100%' }}
//           theme={selectedTheme}
//           notMerge={true}
//           lazyUpdate={false}
//         />
//       </div>

//       {!data.hideDataTable && (
//         <div className="mt-4">
//           <Tabs defaultValue="results">
//             <TabsList>
//               <TabsTrigger value="results">RESULTS</TabsTrigger>
//             </TabsList>
//             <TabsContent value="results" className="h-64 overflow-auto">
//               <AreaDataTable data={data.chartData} />
//             </TabsContent>
//           </Tabs>
//         </div>
//       )}
//     </div>
//   );
// };

// export default Area;



// import React, { useEffect, useRef } from 'react';
// import EChartsReact from 'echarts-for-react';
// import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
// import AreaDataTable from './AreaDataTable';
// import { LineSeriesOption } from 'echarts/charts';
// import { EChartsOption } from 'echarts-for-react';

// interface LineChartProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//     showLegend: boolean;
//     legendOrientation: 'top' | 'bottom' | 'left' | 'right';
//     legendType: 'plain' | 'scroll';
//     chartRequest: any;
//     showDataZoom: boolean;
//     hideDataTable?: boolean;
//     showSymbol?: boolean;
//     smooth?: boolean;
//     areaStyle?: boolean;
//     showMarkLine?: boolean;
//     showMarkPoint?: boolean;
//   };
//   theme: string;
// }

// const AreaChart: React.FC<LineChartProps> = ({ data, theme }) => {
//   const chartRef = useRef<EChartsReact>(null);
//   const containerRef = useRef<HTMLDivElement>(null);

//   const formatValue = (value: any): string => {
//     if (value === null || value === undefined) return '-';
    
//     if (typeof value === 'number') {
//       if (Math.abs(value) > 1000000) {
//         return new Intl.NumberFormat('en-US', {
//           notation: 'compact'
//         }).format(value);
//       }
      
//       if (Math.abs(value) < 1) {
//         if (value < 0.5) return '0';
//         if (value >= 0.5) return '1';
//       }
      
//       return new Intl.NumberFormat('en-US', {
//         maximumFractionDigits: 2
//       }).format(value);
//     }
    
//     return String(value);
//   };

//   const processData = () => {
//     const keys = Object.keys(data.chartData[0] || {});
//     const categoryKey = keys[0];
//     const valueKeys = keys.slice(1);
//     const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => g.name) || [];
//     const hasGroupBy = groupByFields.length > 0;
//     const dimensions = groupByFields.length;

//     const uniqueCategories = Array.from(new Set(
//       data.chartData.map(item => String(item[categoryKey]))
//     ));

//     if (hasGroupBy) {
//       const getDimensionKey = (item: any) => 
//         groupByFields.map(field => item[field]).join('|');

//       const uniqueDimensions = Array.from(new Set(
//         data.chartData.map(getDimensionKey)
//       )).map(key => ({
//         key,
//         values: key.split('|')
//       }));

//       const series = uniqueDimensions.flatMap(dimension =>
//         valueKeys.map(metricKey => {
//           const seriesName = dimension.values.join(' - ');
//           const seriesData = uniqueCategories.map(category => {
//             const matchingItem = data.chartData.find(item => 
//               String(item[categoryKey]) === category && 
//               getDimensionKey(item) === dimension.key
//             );

//             return {
//               value: matchingItem?.[metricKey] ?? 0,
//               itemData: matchingItem,
//               dimensions: groupByFields.map((field, index) => ({
//                 field,
//                 value: dimension.values[index]
//               })),
//               metric: metricKey,
//               dimensionDisplay: seriesName
//             };
//           });

//           return {
//             name: `${seriesName} - ${metricKey}`,
//             type: 'line' as const,
//             data: seriesData,
//             smooth: data.smooth ?? false,
//             showSymbol: data.showSymbol ?? true,
//             symbolSize: 6,
//             ...(data.areaStyle && {
//               areaStyle: {
//                 opacity: 0.1
//               }
//             }),
//             ...(data.showMarkPoint && {
//               markPoint: {
//                 data: [
//                   { type: 'max', name: 'Maximum' },
//                   { type: 'min', name: 'Minimum' }
//                 ]
//               }
//             }),
//             ...(data.showMarkLine && {
//               markLine: {
//                 data: [{ type: 'average', name: 'Average' }]
//               }
//             })
//           };
//         })
//       );

//       return { categories: uniqueCategories, series, hasGroupBy, dimensions };
//     } else {
//       const series: LineSeriesOption[] = valueKeys.map(key => ({
//         name: key,
//         type: 'line',
//         data: uniqueCategories.map(category => {
//           const matchingItem = data.chartData.find(item => 
//             String(item[categoryKey]) === category
//           );
//           return {
//             value: matchingItem ? Number(matchingItem[key]) : 0,
//             itemData: matchingItem,
//             metric: key
//           };
//         }),
//         smooth: data.smooth ?? false,
//         showSymbol: data.showSymbol ?? true,
//         symbolSize: 6,
//         ...(data.areaStyle && {
//           areaStyle: {
//             opacity: 0.1
//           }
//         }),
//         ...(data.showMarkPoint && {
//           markPoint: {
//             data: [
//               { type: 'max', name: 'Maximum' },
//               { type: 'min', name: 'Minimum' }
//             ]
//           }
//         }),
//         ...(data.showMarkLine && {
//           markLine: {
//             data: [{ type: 'average', name: 'Average' }]
//           }
//         })
//       }));

//       return { categories: uniqueCategories, series, hasGroupBy, dimensions: 0 };
//     }
//   };

//   const getSelectedTheme = (themeName: string) => {
//     switch (themeName) {
//       case 'Essos': return Essos;
//       case 'Wonderland': return Wonderland;
//       case 'Walden': return Walden;
//       case 'Infographic': return Infographic;
//       case 'Macarons': return Macarons;
//       case 'Roma': return Roma;
//       case 'CoolTheme': return CoolTheme;
//       case 'Shine': return Shine;
//       default: return Westeros;
//     }
//   };

//   const { categories, series, hasGroupBy, dimensions } = processData();
//   const selectedTheme = getSelectedTheme(theme);


//   const option: EChartsOption = {
//     tooltip: {
//       trigger: 'axis',
//       axisPointer: {
//         type: 'line',
//         lineStyle: {
//           type: 'dashed',
//           width: 1
//         },
//         crossStyle: {
//           show: false
//         },
//         shadowStyle: {
//           show: false
//         },
//         label: {
//           show: false
//         }
//       },
//       position: function (point, params, dom, rect, size) {
//         // Calculate available space
//         const gap = 20;
//         const chartWidth = containerRef.current?.clientWidth || 0;
//         const chartHeight = containerRef.current?.clientHeight || 0;
//         const tooltipWidth = size.contentSize[0];
//         const tooltipHeight = size.contentSize[1];
        
//         // Initial position
//         let [x, y] = point;
        
//         // Adjust horizontal position
//         if (x + tooltipWidth + gap > chartWidth) {
//           x = x - tooltipWidth - gap;
//         } else {
//           x = x + gap;
//         }
        
//         // Adjust vertical position
//         if (y + tooltipHeight + gap > chartHeight) {
//           y = y - tooltipHeight - gap;
//         } else {
//           y = y + gap;
//         }
        
//         // Ensure tooltip stays within bounds
//         x = Math.max(gap, Math.min(x, chartWidth - tooltipWidth - gap));
//         y = Math.max(gap, Math.min(y, chartHeight - tooltipHeight - gap));
        
//         return [x, y];
//       },
//       backgroundColor: 'rgba(255, 255, 255, 0.95)',
//       borderColor: '#ccc',
//       borderWidth: 1,
//       padding: [8, 12],
//       textStyle: {
//         color: '#333',
//         fontSize: 12
//       },
//       extraCssText: 'box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15); border-radius: 4px; z-index: 100;',
//       formatter: function(params: any) {
//         const xAxisField = data.chartRequest.params.form_data.x_axis.name;
//         const xAxisLabel = data.chartRequest.params.form_data.x_axis.label || xAxisField;
        
//         let tooltipContent = `
//           <div style="font-weight: 600; margin-bottom: 8px; font-size: 13px;">
//             ${xAxisLabel}: ${params[0].name}
//           </div>
//         `;

//         params.forEach((param: any) => {
//           tooltipContent += `
//             <div style="display: flex; align-items: center; justify-content: space-between; margin: 4px 0;">
//               <span style="color: ${param.color}; display: flex; align-items: center;">
//                 <span style="display: inline-block; width: 6px; height: 6px; border-radius: 50%; background-color: ${param.color}; margin-right: 6px;"></span>
//                 ${param.seriesName}:
//               </span>
//               <span style="margin-left: 24px; font-weight: 500;">${formatValue(param.value)}</span>
//             </div>
//           `;
//         });

//         return tooltipContent;
//       }
//     },
//         legend: {
//       show: data.showLegend,
//       type: data.legendType,
//       ...(hasGroupBy ? {
//         orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' 
//           ? 'vertical' 
//           : 'horizontal',
//         top: data.legendOrientation === 'top' ? '0' : 'auto',
//         bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//         left: data.legendOrientation === 'left' ? '0' : 'auto',
//         right: data.legendOrientation === 'right' ? '0' : 'auto',
//         textStyle: {
//           fontSize: 12
//         }
//       } : {
//         top: data.legendOrientation === 'top' ? '0' : 'auto',
//         bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
//         left: data.legendOrientation === 'left' ? '0' : 'auto',
//         right: data.legendOrientation === 'right' ? '0' : 'auto',
//       })
//     },
//     grid: {
//       left: '3%',
//       right: '4%',
//       bottom: data.showDataZoom ? '15%' : '3%',
//       top: data.legendOrientation === 'top' ? '15%' : '8%',
//       containLabel: true
//     },
//     xAxis: {
//       type: 'category',
//       boundaryGap: false,
//       data: categories,
//       axisLine: {
//         show: true,
//         lineStyle: {
//           color: '#333',
//           width: 1
//         }
//       },
//       axisTick: {
//         show: true,
//         alignWithLabel: true
//       },
//       axisLabel: {
//         rotate: categories.length > 12 ? 45 : 0,
//         show: true,
//         hideOverlap: true,
//         interval: 'auto'
//       },
//       splitLine: {
//         show: false
//       }
//     },
//     yAxis: {
//       type: 'value',
//       axisLine: {
//         show: true,
//         lineStyle: {
//           color: '#333',
//           width: 1
//         }
//       },
//       axisTick: {
//         show: true
//       },
//       axisLabel: {
//         show: true,
//         formatter: formatValue
//       },
//       splitLine: {
//         show: true,
//         lineStyle: {
//           type: 'dashed',
//           color: '#ddd'
//         }
//       }
//     },
//     series: series,
//     dataZoom: data.showDataZoom ? [
//       {
//         type: 'slider',
//         show: true,
//         start: 0,
//         end: 100,
//         bottom: 10
//       },
//       {
//         type: 'inside',
//         start: 0,
//         end: 100
//       }
//     ] : []
//   };

//   useEffect(() => {
//     if (chartRef.current) {
//       const chart = chartRef.current.getEchartsInstance();
//       chart.resize();
//     }
//   }, [data]);

//   return (
//     <div ref={containerRef} className="w-full h-full flex flex-col">
//       {data.hideDataTable ? (
//         <div className="flex-grow">
//           <EChartsReact
//             ref={chartRef}
//             option={option}
//             theme={selectedTheme}
//             style={{ height: '100%', width: '100%' }}
//             notMerge={true}
//             opts={{ renderer: 'canvas' }}
//           />
//         </div>
//       ) : (
//         <div className="flex-grow">
//           <EChartsReact
//             ref={chartRef}
//             option={option}
//             theme={selectedTheme}
//             style={{ height: '400px', width: '100%' }}
//             notMerge={true}
//             opts={{ renderer: 'canvas' }}
//           />
//         </div>
//       )}

//       {!data.hideDataTable && (
//         <div className="flex-shrink-0 overflow-auto">
//           <Tabs defaultValue="results">
//             <TabsList className="mb-2">
//               <TabsTrigger value="results">RESULTS</TabsTrigger>
//             </TabsList>
//             <TabsContent value="results" className="h-full overflow-auto">
//               <AreaDataTable data={data.chartData} />
//             </TabsContent>
//           </Tabs>
//         </div>
//       )}
//     </div>
//   );
// };

// export default AreaChart;

import React, { useEffect, useRef } from 'react';
import EChartsReact from 'echarts-for-react';
import { Westeros, Essos, Wonderland, Walden, Infographic, Macarons, Roma, CoolTheme, Shine } from '../../../_Chart/ChartTheme/ChartTheme';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../../../../@/components/ui/tabs';
import AreaDataTable from './AreaDataTable';
import { LineSeriesOption } from 'echarts/charts';
import { EChartsOption } from 'echarts-for-react';

interface AreaChartProps {
  data: {
    chartType: string;
    chartData: Array<Record<string, any>>;
    showLegend: boolean;
    legendOrientation: 'top' | 'bottom' | 'left' | 'right';
    legendType: 'plain' | 'scroll';
    chartRequest: any;
    showDataZoom: boolean;
    hideDataTable?: boolean;
    showSymbol?: boolean;
    smooth?: boolean;
    stackedArea?: boolean;
    gradientArea?: boolean;
    showMarkLine?: boolean;
    showMarkPoint?: boolean;
  };
  theme: string;
}

const AreaChart: React.FC<AreaChartProps> = ({ data, theme }) => {
  const chartRef = useRef<EChartsReact>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const formatValue = (value: any): string => {
    if (value === null || value === undefined) return '-';
    
    if (typeof value === 'number') {
      if (Math.abs(value) > 1000000) {
        return new Intl.NumberFormat('en-US', {
          notation: 'compact'
        }).format(value);
      }
      
      if (Math.abs(value) < 1) {
        if (value < 0.5) return '0';
        if (value >= 0.5) return '1';
      }
      
      return new Intl.NumberFormat('en-US', {
        maximumFractionDigits: 2
      }).format(value);
    }
    
    return String(value);
  };

  const processData = () => {
    const keys = Object.keys(data.chartData[0] || {});
    const categoryKey = keys[0];
    const valueKeys = keys.slice(1);
    const groupByFields = data.chartRequest.params.form_data.groupby?.map(g => g.name) || [];
    const hasGroupBy = groupByFields.length > 0;
    const dimensions = groupByFields.length;

    const uniqueCategories = Array.from(new Set(
      data.chartData.map(item => String(item[categoryKey]))
    ));

    if (hasGroupBy) {
      const getDimensionKey = (item: any) => 
        groupByFields.map(field => item[field]).join('|');

      const uniqueDimensions = Array.from(new Set(
        data.chartData.map(getDimensionKey)
      )).map(key => ({
        key,
        values: key.split('|')
      }));

      const series = uniqueDimensions.flatMap(dimension =>
        valueKeys.map(metricKey => {
          const seriesName = dimension.values.join(' - ');
          const seriesData = uniqueCategories.map(category => {
            const matchingItem = data.chartData.find(item => 
              String(item[categoryKey]) === category && 
              getDimensionKey(item) === dimension.key
            );

            return {
              value: matchingItem?.[metricKey] ?? 0,
              itemData: matchingItem,
              dimensions: groupByFields.map((field, index) => ({
                field,
                value: dimension.values[index]
              })),
              metric: metricKey,
              dimensionDisplay: seriesName
            };
          });

          return {
            // name: `${seriesName} - ${metricKey}`,
            name: `${metricKey},${dimension.values.join(' - ')} :`,

            type: 'line' as const,
            data: seriesData,
            smooth: data.smooth ?? false,
            showSymbol: data.showSymbol ?? false,
            symbolSize: 4,
            stack: data.stackedArea ? 'total' : undefined,
            areaStyle: {
              opacity: data.gradientArea ? 0.3 : 0.7,
              ...(data.gradientArea && {
                color: {
                  type: 'linear',
                  x: 0,
                  y: 0,
                  x2: 0,
                  y2: 1,
                  colorStops: [{
                    offset: 0,
                    color: 'rgba(var(--color), 0.5)'
                  }, {
                    offset: 1,
                    color: 'rgba(var(--color), 0.05)'
                  }]
                }
              })
            },
            emphasis: {
              focus: 'series',
              areaStyle: {
                opacity: data.gradientArea ? 0.5 : 0.9
              }
            },
            ...(data.showMarkPoint && {
              markPoint: {
                data: [
                  { type: 'max', name: 'Maximum' },
                  { type: 'min', name: 'Minimum' }
                ]
              }
            }),
            ...(data.showMarkLine && {
              markLine: {
                data: [{ type: 'average', name: 'Average' }]
              }
            })
          };
        })
      );

      return { categories: uniqueCategories, series, hasGroupBy, dimensions };
    } else {
      const series: LineSeriesOption[] = valueKeys.map(key => ({
        name: key,
        type: 'line',
        data: uniqueCategories.map(category => {
          const matchingItem = data.chartData.find(item => 
            String(item[categoryKey]) === category
          );
          return {
            value: matchingItem ? Number(matchingItem[key]) : 0,
            itemData: matchingItem,
            metric: key
          };
        }),
        smooth: data.smooth ?? false,
        showSymbol: data.showSymbol ?? false,
        symbolSize: 4,
        stack: data.stackedArea ? 'total' : undefined,
        areaStyle: {
          opacity: data.gradientArea ? 0.3 : 0.7,
          ...(data.gradientArea && {
            color: {
              type: 'linear',
              x: 0,
              y: 0,
              x2: 0,
              y2: 1,
              colorStops: [{
                offset: 0,
                color: 'rgba(var(--color), 0.5)'
              }, {
                offset: 1,
                color: 'rgba(var(--color), 0.05)'
              }]
            }
          })
        },
        emphasis: {
          focus: 'series',
          areaStyle: {
            opacity: data.gradientArea ? 0.5 : 0.9
          }
        },
        ...(data.showMarkPoint && {
          markPoint: {
            data: [
              { type: 'max', name: 'Maximum' },
              { type: 'min', name: 'Minimum' }
            ]
          }
        }),
        ...(data.showMarkLine && {
          markLine: {
            data: [{ type: 'average', name: 'Average' }]
          }
        })
      }));

      return { categories: uniqueCategories, series, hasGroupBy, dimensions: 0 };
    }
  };

  const getSelectedTheme = (themeName: string) => {
    switch (themeName) {
      case 'Essos': return Essos;
      case 'Wonderland': return Wonderland;
      case 'Walden': return Walden;
      case 'Infographic': return Infographic;
      case 'Macarons': return Macarons;
      case 'Roma': return Roma;
      case 'CoolTheme': return CoolTheme;
      case 'Shine': return Shine;
      default: return Westeros;
    }
  };
 const getGroupByColumns = () => {
    // Get only the groupby columns from form_data
    return data.chartRequest.params.form_data.groupby?.map(g => g.name.toLowerCase()) || [];
  };
  const { categories, series, hasGroupBy, dimensions } = processData();
  const selectedTheme = getSelectedTheme(theme);
  const option: EChartsOption = {
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow',
        snap: true,
        animation: true,
        shadowStyle: {
          color: 'rgba(150,150,150,0.1)'
        }
      },
      enterable: true,
      position: function (point, params, dom, rect, size) {
        const gap = 20;
        const chartWidth = containerRef.current?.clientWidth || 0;
        const chartHeight = containerRef.current?.clientHeight || 0;
        const tooltipWidth = size.contentSize[0];
        const tooltipHeight = size.contentSize[1];
        
        let [x, y] = point;
        
        if (x + tooltipWidth + gap > chartWidth) {
          x = x - tooltipWidth - gap;
        } else {
          x = x + gap;
        }
        
        if (y + tooltipHeight + gap > chartHeight) {
          y = y - tooltipHeight - gap;
        } else {
          y = y + gap;
        }
        
        x = Math.max(gap, Math.min(x, chartWidth - tooltipWidth - gap));
        y = Math.max(gap, Math.min(y, chartHeight - tooltipHeight - gap));
        
        return [x, y];
      },
      backgroundColor: 'rgba(255, 255, 255, 0.95)',
      borderColor: '#ccc',
      borderWidth: 1,
      padding: [8, 12],
      textStyle: {
        color: '#333',
        fontSize: 12
      },
      extraCssText: 'box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); border-radius: 4px;',
      formatter: function(params: any) {
        if (!Array.isArray(params)) return '';
        
        const groupByColumns = getGroupByColumns();
        
        // Filter out params where series name contains any groupby column
        const filteredParams = params.filter((param: any) => {
          const seriesName = param.seriesName.toLowerCase();
          return !groupByColumns.some(column => seriesName.startsWith(column));
        });

        // Filter out zero values
        const nonZeroParams = filteredParams.filter((param: any) => 
          param.data
        );
  
        let tooltipContent = `
          <div style="margin-bottom: 10px; padding-bottom: 6px; border-bottom: 1px solid #eee;">
            <span style="font-size: 13px; font-weight: 600; color: #666;">
              ${params[0].name}
            </span>
          </div>
        `;
  
        // Group by metric type
        const metricGroups = new Map();
        
        nonZeroParams.forEach((param: any) => {
          const data = param.data;
          if (!data || !data.metric) return;
          
          if (!metricGroups.has(data.metric)) {
            metricGroups.set(data.metric, []);
          }
          
          metricGroups.get(data.metric).push({
            name: param.seriesName,
            value: data.value,
            color: param.color,
            itemData: data.itemData
          });
        });
  
        // Add each metric group to tooltip
        metricGroups.forEach((items, metric) => {
          tooltipContent += `
            <div style="margin-top: 8px;">
              ${items.map((item: any) => `
                <div style="display: flex; justify-content: space-between; align-items: center; margin: 4px 0;">
                  <div style="display: flex; align-items: center; gap: 6px;">
                    <span style="color: ${item.color}; font-size: 16px;">●</span>
                    <span style="color: #666; font-size: 12px;">
                      ${item.name} ${formatValue(item.value)}
                    </span>
                  </div>
                  <span style="font-size: 12px; color: #666;">
                  </span>
                </div>
              `).join('')}
            </div>
          `;
        });
  
        return `
          <div style="max-height: 200px; overflow-y: auto;">
            ${tooltipContent}
          </div>
        `;
      }
    },
    legend: {
      show: data.showLegend,
      type: data.legendType,
      ...(hasGroupBy ? {
        orient: data.legendOrientation === 'left' || data.legendOrientation === 'right' 
          ? 'vertical' 
          : 'horizontal',
        top: data.legendOrientation === 'top' ? '0' : 'auto',
        bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
        left: data.legendOrientation === 'left' ? '0' : 'auto',
        right: data.legendOrientation === 'right' ? '0' : 'auto',
        textStyle: {
          fontSize: 12
        }
      } : {
        top: data.legendOrientation === 'top' ? '0' : 'auto',
        bottom: data.legendOrientation === 'bottom' ? '0' : 'auto',
        left: data.legendOrientation === 'left' ? '0' : 'auto',
        right: data.legendOrientation === 'right' ? '0' : 'auto',
      })
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: data.showDataZoom ? '15%' : '3%',
      top: data.legendOrientation === 'top' ? '15%' : '8%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: categories,
      axisLine: {
        show: true,
        lineStyle: {
          color: '#333',
          width: 1
        }
      },
      axisTick: {
        show: true,
        alignWithLabel: true
      },
      axisLabel: {
        rotate: categories.length > 12 ? 45 : 0,
        show: true,
        hideOverlap: true,
        interval: 'auto'
      },
      splitLine: {
        show: false
      }
    },
    yAxis: {
      type: 'value',
      axisLine: {
        show: true,
        lineStyle: {
          color: '#333',
          width: 1
        }
      },
      axisTick: {
        show: true
      },
      axisLabel: {
        show: true,
        formatter: formatValue
      },
      splitLine: {
        show: true,
        lineStyle: {
          type: 'dashed',
          color: '#ddd'
        }
      }
    },
    series: series,
    dataZoom: data.showDataZoom ? [
      {
        type: 'slider',
        show: true,
        start: 0,
        end: 100,
        bottom: 10
      },
      {
        type: 'inside',
        start: 0,
        end: 100
      }
    ] : []
  };

  useEffect(() => {
    if (chartRef.current) {
      const chart = chartRef.current.getEchartsInstance();
      chart.resize();
    }
  }, [data]);
  return (
    <div ref={containerRef} className="w-full h-full flex flex-col">
      {data.hideDataTable ? (
        <div className="flex-grow">
          <EChartsReact
            ref={chartRef}
            option={option}
            theme={selectedTheme}
            style={{ height: '100%', width: '100%' }}
            notMerge={true}
            opts={{ renderer: 'canvas' }}
          />
        </div>
      ) : (
        <div className="flex-grow">
          <EChartsReact
            ref={chartRef}
            option={option}
            theme={selectedTheme}
            style={{ height: '400px', width: '100%' }}
            notMerge={true}
            opts={{ renderer: 'canvas' }}
          />
        </div>
      )}

      {!data.hideDataTable && (
        <div className="flex-shrink-0 overflow-auto">
          <Tabs defaultValue="results">
            <TabsList className="mb-2">
              <TabsTrigger value="results">RESULTS</TabsTrigger>
            </TabsList>
            <TabsContent value="results" className="h-full overflow-auto">
              <AreaDataTable data={data.chartData} />
            </TabsContent>
          </Tabs>
        </div>
      )}
    </div>
  );
};

export default AreaChart;