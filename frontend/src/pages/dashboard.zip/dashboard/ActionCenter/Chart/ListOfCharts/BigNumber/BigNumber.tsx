// import React from 'react';
// import { Card, CardContent } from "../../../../../../@/components/ui/card";

// interface BigNumberProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//   };
//   title?: string;
// }

// const BigNumber: React.FC<BigNumberProps> = ({ data, title }) => {
//   // Extract the value from the chartData
//   const value = data.chartData[0] ? Object.values(data.chartData[0])[0] : 'N/A';

//   // Format the number
//   const formattedValue = typeof value === 'number' 
//     ? value.toLocaleString(undefined, { maximumFractionDigits: 2 })
//     : value;
//     return (
//         <Card className="w-full max-w-sm mx-auto h-80"> {/* Increased height to 16rem (64px * 4) */}
//           <CardContent className="flex flex-col items-center justify-center p-6 h-full">
//             {title && (
//               <h2 className="text-xl font-semibold text-gray-700 mb-4">{title}</h2>
//             )}
//             <div className="text-6xl font-bold text-blue-600">{formattedValue}</div>
//           </CardContent>
//         </Card>
//       );
//     };
    
//     export default BigNumber;


// import React from 'react';

// interface BigNumberProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//   };
//   title?: string;
// }

// const BigNumber: React.FC<BigNumberProps> = ({ data, title }) => {
//   // Extract the value from the chartData
//   const value = data.chartData[0] ? Object.values(data.chartData[0])[0] : 'N/A';

//   // Format the number
//   const formattedValue = typeof value === 'number' 
//     ? value.toLocaleString(undefined, { maximumFractionDigits: 2 })
//     : value;

//   return (
//     <div className="w-full max-w-sm mx-auto h-80"> {/* Increased height to 16rem (64px * 4) */}
//       <div className="flex flex-col items-center justify-center p-6 h-full">
//         {title && (
//           <h2 className="text-xl font-semibold text-gray-700 mb-4">{title}</h2>
//         )}
//         <div className="text-6xl font-bold text-blue-600">{formattedValue}</div>
//       </div>
//     </div>
//   );
// };

// // export default BigNumber;
// import React, { useRef, useState, useEffect } from 'react';

// interface BigNumberProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//   };
//   title?: string;
// }

// const BigNumber: React.FC<BigNumberProps> = ({ data, title }) => {
//   const containerRef = useRef<HTMLDivElement>(null);
//   const [fontSize, setFontSize] = useState(48); // Initial font size

//   // Extract the value from the chartData
//   const value = data.chartData[0] ? Object.values(data.chartData[0])[0] : 'N/A';

//   // Format the number
//   const formattedValue = typeof value === 'number'
//     ? value.toLocaleString(undefined, { maximumFractionDigits: 2 })
//     : value;

//   useEffect(() => {
//     const updateFontSize = () => {
//       if (containerRef.current) {
//         const containerWidth = containerRef.current.offsetWidth;
//         const containerHeight = containerRef.current.offsetHeight;
//         const newFontSize = Math.min(containerWidth / 8, containerHeight / 3);
//         setFontSize(Math.max(24, Math.min(newFontSize, 72))); // Min 24px, Max 72px
//       }
//     };

//     updateFontSize();
//     window.addEventListener('resize', updateFontSize);
//     return () => window.removeEventListener('resize', updateFontSize);
//   }, []);

//   return (
//     <div ref={containerRef} className="w-full h-full min-h-[12rem] flex flex-col items-center justify-center p-4">
//       {title && (
//         <h2 className="text-xl font-semibold text-gray-700 mb-4">{title}</h2>
//       )}
//       <div
//         className="font-bold text-blue-600 text-center break-words"
//         style={{
//           fontSize: `${fontSize}px`,
//           lineHeight: '1.2',
//           maxWidth: '100%',
//         }}
//       >
//         {formattedValue}
//       </div>
//     </div>
//   );
// };

// export default BigNumber;


// import React, { useRef, useState, useEffect } from 'react';

// interface BigNumberProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//   };
//   title?: string;
// }

// const BigNumber: React.FC<BigNumberProps> = ({ data, title }) => {
//   const containerRef = useRef<HTMLDivElement>(null);
//   const valueRef = useRef<HTMLDivElement>(null);
//   const [fontSize, setFontSize] = useState(48);

//   // Extract the value from the chartData
//   const value = data.chartData[0] ? Object.values(data.chartData[0])[0] : 'N/A';

//   // Format the number
//   const formattedValue = typeof value === 'number'
//     ? value.toLocaleString(undefined, { maximumFractionDigits: 2 })
//     : value;

//   useEffect(() => {
//     const updateFontSize = () => {
//       if (containerRef.current && valueRef.current) {
//         const containerWidth = containerRef.current.offsetWidth;
//         const containerHeight = containerRef.current.offsetHeight;

//         // Start with a large font size
//         let testSize = 100;
//         valueRef.current.style.fontSize = `${testSize}px`;

//         // Reduce font size until it fits
//         while (
//           (valueRef.current.offsetWidth > containerWidth * 0.9 ||
//            valueRef.current.offsetHeight > containerHeight * 0.6) &&
//           testSize > 24
//         ) {
//           testSize -= 1;
//           valueRef.current.style.fontSize = `${testSize}px`;
//         }

//         setFontSize(Math.max(24, Math.min(testSize, 72))); // Min 24px, Max 72px
//       }
//     };

//     updateFontSize();
//     window.addEventListener('resize', updateFontSize);
//     return () => window.removeEventListener('resize', updateFontSize);
//   }, [formattedValue]); // Re-run when formattedValue changes

//   return (
//     <div ref={containerRef} className="w-full h-full min-h-[12rem] flex flex-col items-center justify-center p-4">
//       {title && (
//         <h2 className="text-xl font-semibold text-gray-700 mb-4 text-center">{title}</h2>
//       )}
//       <div
//         ref={valueRef}
//         className="font-bold text-blue-600 text-center break-words"
//         style={{
//           fontSize: `${fontSize}px`,
//           lineHeight: '1.2',
//           maxWidth: '100%',
//         }}
//       >
//         {formattedValue}
//       </div>
//     </div>
//   );
// };

// // export default BigNumber;
// import React, { useRef, useState, useEffect } from 'react';

// interface BigNumberProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//   };
//   title?: string;
// }

// const BigNumber: React.FC<BigNumberProps> = ({ data, title }) => {
//   const containerRef = useRef<HTMLDivElement>(null);
//   const valueRef = useRef<HTMLDivElement>(null);
//   const [fontSize, setFontSize] = useState(48);

//   // Extract the value from the chartData
//   const value = data.chartData[0] ? Object.values(data.chartData[0])[0] : 'N/A';

//   // Format the number
//   const formattedValue = typeof value === 'number'
//     ? value.toLocaleString(undefined, { maximumFractionDigits: 2 })
//     : value;

//   useEffect(() => {
//     const updateFontSize = () => {
//       if (containerRef.current && valueRef.current) {
//         const containerWidth = containerRef.current.offsetWidth;
//         const containerHeight = containerRef.current.offsetHeight;

//         // Calculate the maximum possible font size
//         let maxFontSize = Math.min(containerWidth / 4, containerHeight / 2);

//         // Adjust for text length
//         const textLength = formattedValue.length;
//         maxFontSize *= Math.max(1 - (textLength - 5) * 0.1, 0.5);

//         // Set a minimum font size
//         const minFontSize = 20;

//         // Ensure font size is within bounds
//         const newFontSize = Math.max(minFontSize, Math.min(maxFontSize, 120));

//         setFontSize(newFontSize);
//       }
//     };

//     updateFontSize();
//     window.addEventListener('resize', updateFontSize);
//     return () => window.removeEventListener('resize', updateFontSize);
//   }, [formattedValue]);

//   return (
//     <div ref={containerRef} className="w-full h-full flex flex-col items-center justify-center p-4 overflow-hidden">
//       {title && (
//         <h2 className="text-xl font-semibold text-gray-700 mb-2 text-center">{title}</h2>
//       )}
//       <div
//         ref={valueRef}
//         className="font-bold text-blue-600 text-center break-words transition-all duration-300 ease-in-out"
//         style={{
//           fontSize: `${fontSize}px`,
//           lineHeight: '1.2',
//           maxWidth: '100%',
//         }}
//       >
//         {formattedValue}
//       </div>
//     </div>
//   );
// };

// export default BigNumber;

// import React, { useRef, useState, useEffect } from 'react';

// interface BigNumberProps {
//   data: {
//     chartType: string;
//     chartData: Array<Record<string, any>>;
//   };
//   title?: string;
// }

// const BigNumber: React.FC<BigNumberProps> = ({ data, title }) => {
//   const containerRef = useRef<HTMLDivElement>(null);
//   const valueRef = useRef<HTMLDivElement>(null);
//   const [fontSize, setFontSize] = useState(48);

//   // Extract the value from the chartData
//   const value = data.chartData[0] ? Object.values(data.chartData[0])[0] : 'N/A';

//   // Format the number
//   const formattedValue = typeof value === 'number'
//     ? value.toLocaleString(undefined, { maximumFractionDigits: 2 })
//     : value;

//   useEffect(() => {
//     const updateFontSize = () => {
//       if (containerRef.current && valueRef.current) {
//         const containerWidth = containerRef.current.offsetWidth;
//         const containerHeight = containerRef.current.offsetHeight;

//         // Calculate the area of the container
//         const containerArea = containerWidth * containerHeight;

//         // Base font size on the square root of the area
//         // This makes the font size more sensitive to both dimensions
//         let baseFontSize = Math.sqrt(containerArea) / 4;

//         // Adjust for text length
//         const textLength = formattedValue.length;
//         baseFontSize *= Math.max(1 - (textLength - 5) * 0.1, 0.5);

//         // Ensure font size is within bounds
//         const minFontSize = 12; // Smaller minimum font size
//         const maxFontSize = 120;
//         const newFontSize = Math.max(minFontSize, Math.min(baseFontSize, maxFontSize));

//         setFontSize(newFontSize);
//       }
//     };

//     updateFontSize();

//     // Use ResizeObserver for more precise size change detection
//     const resizeObserver = new ResizeObserver(updateFontSize);
//     if (containerRef.current) {
//       resizeObserver.observe(containerRef.current);
//     }

//     return () => resizeObserver.disconnect();
//   }, [formattedValue]);

//   return (
//     <div 
//       ref={containerRef} 
//       className="w-full h-full flex flex-col items-center justify-center p-2 overflow-hidden"
//       style={{ minHeight: '50px', minWidth: '50px' }} // Ensure a minimum size
//     >
//       {title && (
//         <h2 className="text-sm sm:text-base md:text-lg lg:text-xl font-semibold text-gray-700 mb-1 text-center">
//           {title}
//         </h2>
//       )}
//       <div
//         ref={valueRef}
//         className="font-bold text-blue-600 text-center break-words transition-all duration-200 ease-in-out"
//         style={{
//           fontSize: `${fontSize}px`,
//           lineHeight: '1.2',
//           maxWidth: '100%',
//         }}
//       >
//         {formattedValue}
//       </div>
//     </div>
//   );
// };

// export default BigNumber;

import React, { useRef, useState, useEffect } from 'react';

interface BigNumberProps {
  data: {
    chartType: string;
    chartData: Array<Record<string, any>>;
  };
  title?: string;
}

const BigNumber: React.FC<BigNumberProps> = ({ data, title }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const valueRef = useRef<HTMLDivElement>(null);
  const [fontSize, setFontSize] = useState(48);

  // Extract the value from the chartData with better null checking
  const value = data?.chartData?.[0] ? Object.values(data.chartData[0])[0] : '0';

  // Format the number with null checking
  const formattedValue = typeof value === 'number'
    ? value.toLocaleString(undefined, { maximumFractionDigits: 2 })
    : String(value || '0'); // Convert to string and provide fallback

  useEffect(() => {
    const updateFontSize = () => {
      if (!containerRef.current || !formattedValue) {
        return; // Early return if refs or value not available
      }

      const containerWidth = containerRef.current.offsetWidth;
      const containerHeight = containerRef.current.offsetHeight;

      // Skip calculation if container dimensions are not available
      if (!containerWidth || !containerHeight) {
        return;
      }

      // Calculate the area of the container
      const containerArea = containerWidth * containerHeight;

      // Base font size on the square root of the area
      let baseFontSize = Math.sqrt(containerArea) / 4;

      // Adjust for text length - with safe access to length
      const textLength = String(formattedValue).length;
      baseFontSize *= Math.max(1 - (textLength - 5) * 0.1, 0.5);

      // Ensure font size is within bounds
      const minFontSize = 12;
      const maxFontSize = 120;
      const newFontSize = Math.max(minFontSize, Math.min(baseFontSize, maxFontSize));

      setFontSize(newFontSize);
    };

    // Initial update
    updateFontSize();

    // Use ResizeObserver for more precise size change detection
    const resizeObserver = new ResizeObserver(() => {
      requestAnimationFrame(updateFontSize); // Use requestAnimationFrame for smoother updates
    });

    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }

    return () => resizeObserver.disconnect();
  }, [formattedValue]); // Only depend on formattedValue

  return (
    <div 
      ref={containerRef} 
      className="w-full h-full flex flex-col items-center justify-center p-2 overflow-hidden"
      style={{ minHeight: '50px', minWidth: '50px' }}
    >
      {title && (
        <h2 className="text-sm sm:text-base md:text-lg lg:text-xl font-semibold text-gray-700 mb-1 text-center">
          {title}
        </h2>
      )}
      <div
        ref={valueRef}
        className="font-bold text-blue-600 text-center break-words transition-all duration-200 ease-in-out"
        style={{
          fontSize: `${fontSize}px`,
          lineHeight: '1.2',
          maxWidth: '100%',
        }}
      >
        {formattedValue}
      </div>
    </div>
  );
};

export default BigNumber;