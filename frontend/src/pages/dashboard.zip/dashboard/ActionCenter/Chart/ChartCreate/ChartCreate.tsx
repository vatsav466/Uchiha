// import React, { useEffect, useState } from "react";
// import { Container, Divider, ListItemIcon, ListItemText, MenuItem, MenuList } from "@mui/material";
// import { Card } from "../../../../../@/components/ui/card";
// import { Button } from "../../../../../@/components/ui/button";
// import { useNavigate } from "react-router-dom";
// import axios from "axios";
// import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from "../../../../../@/components/ui/select";
// import { IconHash } from "@tabler/icons-react";
// import GlobalSearch from "../../../../../components/common/GlobalSearch/GlobalSearch";
// import { RadioGroup, RadioGroupItem } from "../../../../../@/components/ui/radio-group";
// import { Label } from "../../../../../@/components/ui/label";

// // Import all chart images
// import BarChart from "../../../../../assets/viz_thumbnails/bar.png";
// import PieChart from "../../../../../assets/viz_thumbnails/pie.png";
// import LineChart from "../../../../../assets/viz_thumbnails/line.png";
// import AreaChart from "../../../../../assets/viz_thumbnails/area.png";
// import SunburstChart from "../../../../../assets/viz_thumbnails/sunburst.png";
// import BigNumber from "../../../../../assets/viz_thumbnails/big_number.png";
// import Table from "../../../../../assets/viz_thumbnails/table.png";
// import PivotTable from "../../../../../assets/viz_thumbnails/pivot_table.png";

// // Create a mapping of unique IDs to their corresponding images
// const chartImages: { [key: string]: string } = {
//   pie: PieChart,
//   sunburst: SunburstChart,
//   line: LineChart,
//   area: AreaChart,
//   bar: BarChart,
//   big_number: BigNumber,
//   table: Table,
//   pivot_table: PivotTable,
// };

// interface ChartComponent {
//   key: string;
//   name: string;
//   unique_id: string;
//   image: string;
//   execute_action: string;
//   tags: string[];
// }

// interface ChartSection {
//   section: string;
//   components: ChartComponent[];
// }

// interface ChartData {
//   status: boolean;
//   message: string;
//   data: ChartSection[];
// }

// export const ChartCreate = () => {
//   const navigate = useNavigate();
//   const [loading, setLoading] = useState(true);
//   const [tableData, setTableData] = useState<string[]>([]);
//   const [dataset, setDataset] = useState("");
//   const [chartData, setChartData] = useState<ChartData>({ status: false, message: "", data: [] });
//   const [activeSection, setActiveSection] = useState<ChartSection | null>(null);
//   const [selectedChart, setSelectedChart] = useState("");

//   useEffect(() => {
//     const fetchData = async () => {
//       setLoading(true);
//       try {
//         const tablesRes = await axios.post('/api/charts/get_tables', { database: "zolix_c2o", schema: "public" });
//         setTableData(tablesRes.data.data);
//       } catch (error) {
//         console.error("Error fetching tables:", error);
//         setTableData([]);
//       }

//       try {
//         const chartsRes = await axios.post<ChartData>('/api/charts/dashboard_charts', {});
//         setChartData(chartsRes.data);
//         if (chartsRes.data.data.length > 0) {
//           setActiveSection(chartsRes.data.data[0]);
//         }
//       } catch (error) {
//         console.error("Error fetching charts:", error);
//         setChartData({ status: false, message: "Error fetching charts", data: [] });
//       }

//       setLoading(false);
//     };

//     fetchData();
//   }, []);

//   const handleSectionClick = (section: ChartSection) => {
//     setActiveSection(section);
//   };

//   const handleChartClick = (chart: ChartComponent) => {
//     setSelectedChart(chart.unique_id);
//   };

//   const handleCreateChart = () => {
//     navigate('/action-center/create-chart', {
//       state: { dataset, chart: selectedChart }
//     });
//     console.log("chart create", dataset, selectedChart);
//   };
//   const handleDoubleClick = (chart: ChartComponent) => {
//     setSelectedChart(chart.unique_id);
//     handleCreateChart();
//   };

//   return (
//     <div>
//       <Container maxWidth="lg">
//         <Card>
//           <div className="flex flex-col">
//             <div className="p-3">
//               <p className="text-xl font-semibold">Create a New Chart</p>
//             </div>
            
//             {/* Dataset Selection */}
//             <div className="flex flex-row gap-2 p-3">
//               <div className="flex item-center justify-center rounded-full bg-purple-300 w-6">
//                 <span>1</span>
//               </div>
//               <div className="grid content-center text-sm font-semibold">Choose a dataset</div>
//             </div>
//             <div className="w-full p-3">
//               {loading ? (
//                 <div>Loading...</div>
//               ) : (
//                 <Select onValueChange={setDataset}>
//                   <SelectTrigger className="w-[350px]">
//                     <SelectValue placeholder="Select a dataset" />
//                   </SelectTrigger>
//                   <SelectContent>
//                     <SelectGroup>
//                       <SelectLabel>Table List</SelectLabel>
//                       {tableData.length === 0 ? (
//                         <SelectItem value="No data">No data</SelectItem>
//                       ) : (
//                         tableData.map((item) => (
//                           <SelectItem key={item} value={item}>
//                             {item}
//                           </SelectItem>
//                         ))
//                       )}
//                     </SelectGroup>
//                   </SelectContent>
//                 </Select>
//               )}
//             </div>

//             {/* Chart Type Selection */}
//             <div className="flex flex-row gap-2 p-3">
//               <div className="flex item-center justify-center rounded-full bg-purple-300 w-6">
//                 <span>2</span>
//               </div>
//               <div className="grid content-center text-sm font-semibold">Choose chart type</div>
//             </div>

//             <div className="w-full p-3">
//               <div className="w-full flex gap-3 h-[400px] border border-gray-300 rounded-md">
//                 {/* Chart Sections */}
//                 <div className="w-1/5 p-3">
//                   {loading ? (
//                     <div>Loading...</div>
//                   ) : (
//                     <MenuList>
//                       {chartData.data.map((section) => (
//                         <MenuItem
//                           onClick={() => handleSectionClick(section)}
//                           key={section.section}
//                           sx={{
//                             borderRadius: '8px',
//                             backgroundColor: activeSection?.section === section.section ? '#67037a' : '#fff',
//                             color: activeSection?.section === section.section ? '#fff' : '#111',
//                             marginBottom: '6px',
//                             '&:hover': {
//                               backgroundColor: '#67037a',
//                               color: '#fff',
//                             },
//                             '&:hover svg': {
//                               backgroundColor: '#67037a',
//                               color: '#fff',
//                             }
//                           }}
//                         >
//                           <ListItemIcon>
//                             <IconHash
//                               stroke={1.5}
//                               className="h-4 w-4"
//                               color={activeSection?.section === section.section ? '#fff' : 'currentColor'}
//                             />
//                           </ListItemIcon>
//                           <ListItemText sx={{ '& span': { fontSize: '.85rem' } }}>
//                             {section.section}
//                           </ListItemText>
//                         </MenuItem>
//                       ))}
//                     </MenuList>
//                   )}
//                 </div>
//                 <Divider orientation="vertical" flexItem />
//                 {/* Chart Components */}
//                 <div className="w-4/5 p-3">
//                   <div className="flex flex-col">
//                     <GlobalSearch style="pl-8 w-96" />
//                      <div className="flex flex-row gap-2 mt-2">
//         {activeSection && (
//           <RadioGroup
//             defaultValue="card"
//             onValueChange={setSelectedChart}
//             className="grid grid-cols-3 gap-4"
//           >
//             {activeSection.components.map((chart) => (
//               <div key={chart.unique_id}>
//                 <RadioGroupItem
//                   value={chart.unique_id}
//                   id={chart.unique_id}
//                   className="peer sr-only"
//                 />
//                 <Label
//                   htmlFor={chart.unique_id}
//                   className="cursor-pointer flex flex-col items-center justify-between rounded-md border-2 bg-popover p-2 hover:border-md hover:text-accent-foreground peer-data-[state=checked]:border-fuchsia-900 [&:has([data-state=checked])]:border-fuchsia-900"
//                   onClick={() => handleChartClick(chart)}
//                   onDoubleClick={() => handleDoubleClick(chart)}
//                 >
//                   <img
//                     className="mb-3 h-20 w-20"
//                     src={chartImages[chart.unique_id] || BarChart}
//                     alt={chart.name}
//                   />
//                   {chart.name}
//                 </Label>
//               </div>
//             ))}
//           </RadioGroup>
//         )}
//       </div>
//                   </div>
//                 </div>
//               </div>
//             </div>

//             {/* Create Chart Button */}
//             <div className="w-full p-3">
//               <div className="flex gap-2 justify-end">
//                 <p className="text-xs text-slate-500 font-medium my-auto">
//                   Please select both a Dataset and a Chart type to proceed
//                 </p>
//                 <Button
//                   variant="secondary"
//                   onClick={handleCreateChart}
//                   disabled={!dataset || !selectedChart}
//                 >
//                   CREATE CHART
//                 </Button>
//               </div>
//             </div>
//           </div>
//         </Card>
//       </Container>
//     </div>
//   );
// // };
// import React, { useEffect, useState } from "react";
// import { Container } from "@mui/material";
// import { Card } from "../../../../../@/components/ui/card";
// import { Button } from "../../../../../@/components/ui/button";
// import { useNavigate } from "react-router-dom";
// import axios from "axios";
// import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from "../../../../../@/components/ui/select";
// import { RadioGroup, RadioGroupItem } from "../../../../../@/components/ui/radio-group";
// import { Label } from "../../../../../@/components/ui/label";
// import { Input } from "../../../../../@/components/ui/input";

// // Import all chart images
// import BarChart from "../../../../../assets/viz_thumbnails/bar.png";
// import PieChart from "../../../../../assets/viz_thumbnails/pie.png";
// import LineChart from "../../../../../assets/viz_thumbnails/line.png";
// import AreaChart from "../../../../../assets/viz_thumbnails/area.png";
// import SunburstChart from "../../../../../assets/viz_thumbnails/sunburst.png";
// import BigNumber from "../../../../../assets/viz_thumbnails/big_number.png";
// import Table from "../../../../../assets/viz_thumbnails/table.png";
// import PivotTable from "../../../../../assets/viz_thumbnails/pivot_table.png";

// // Create a mapping of unique IDs to their corresponding images
// const chartImages: { [key: string]: string } = {
//   pie: PieChart,
//   sunburst: SunburstChart,
//   line: LineChart,
//   area: AreaChart,
//   bar: BarChart,
//   big_number: BigNumber,
//   table: Table,
//   pivot_table: PivotTable,
// };

// interface ChartComponent {
//   key: string;
//   name: string;
//   unique_id: string;
//   image: string;
//   execute_action: string;
//   tags: string[];
// }

// interface ChartData {
//   status: boolean;
//   message: string;
//   data: { components: ChartComponent[] }[];
// }

// export const ChartCreate = () => {
//   const navigate = useNavigate();
//   const [loading, setLoading] = useState(true);
//   const [tableData, setTableData] = useState<string[]>([]);
//   const [dataset, setDataset] = useState("");
//   const [chartData, setChartData] = useState<ChartComponent[]>([]);
//   const [selectedChart, setSelectedChart] = useState("");
//   const [searchTerm, setSearchTerm] = useState("");

//   useEffect(() => {
//     const fetchData = async () => {
//       setLoading(true);
//       try {
//         const tablesRes = await axios.post('/api/charts/get_tables', { database: "zolix_c2o", schema: "public" });
//         setTableData(tablesRes.data.data);
//       } catch (error) {
//         console.error("Error fetching tables:", error);
//         setTableData([]);
//       }

//       try {
//         const chartsRes = await axios.post<ChartData>('/api/charts/dashboard_charts', {});
//         const allCharts = chartsRes.data.data.flatMap(section => section.components);
//         setChartData(allCharts);
//       } catch (error) {
//         console.error("Error fetching charts:", error);
//         setChartData([]);
//       }

//       setLoading(false);
//     };

//     fetchData();
//   }, []);

//   const handleChartClick = (chart: ChartComponent) => {
//     setSelectedChart(chart.unique_id);
//   };

//   const handleCreateChart = () => {
//     navigate('/action-center/create-chart', {
//       state: { dataset, chart: selectedChart }
//     });
//     console.log("chart create", dataset, selectedChart);
//   };

//   const handleDoubleClick = (chart: ChartComponent) => {
//     setSelectedChart(chart.unique_id);
//     handleCreateChart();
//   };

//   const filteredCharts = chartData.filter(chart => 
//     chart.name.toLowerCase().includes(searchTerm.toLowerCase())
//   );

//   return (
//     <div>
//       <Container maxWidth="lg">
//         <Card>
//           <div className="flex flex-col">
//             <div className="p-3">
//               <p className="text-xl font-semibold">Create a New Chart</p>
//             </div>
            
//             {/* Dataset Selection */}
//             <div className="flex flex-row gap-2 p-3">
//               <div className="flex item-center justify-center rounded-full bg-purple-300 w-6">
//                 <span>1</span>
//               </div>
//               <div className="grid content-center text-sm font-semibold">Choose a dataset</div>
//             </div>
//             <div className="w-full p-3">
//               {loading ? (
//                 <div>Loading...</div>
//               ) : (
//                 <Select onValueChange={setDataset}>
//                   <SelectTrigger className="w-[350px]">
//                     <SelectValue placeholder="Select a dataset" />
//                   </SelectTrigger>
//                   <SelectContent>
//                     <SelectGroup>
//                       <SelectLabel>Table List</SelectLabel>
//                       {tableData.length === 0 ? (
//                         <SelectItem value="No data">No data</SelectItem>
//                       ) : (
//                         tableData.map((item) => (
//                           <SelectItem key={item} value={item}>
//                             {item}
//                           </SelectItem>
//                         ))
//                       )}
//                     </SelectGroup>
//                   </SelectContent>
//                 </Select>
//               )}
//             </div>

//             {/* Chart Type Selection */}
//             <div className="flex flex-row gap-2 p-3">
//               <div className="flex item-center justify-center rounded-full bg-purple-300 w-6">
//                 <span>2</span>
//               </div>
//               <div className="grid content-center text-sm font-semibold">Choose chart type</div>
//             </div>

//             <div className="w-full p-3">
//               <div className="w-full flex flex-col gap-3 border border-gray-300 rounded-md p-3">
//                 {/* Search Bar */}
//                 <Input
//                   type="text"
//                   placeholder="Search charts..."
//                   value={searchTerm}
//                   onChange={(e) => setSearchTerm(e.target.value)}
//                   className="w-full"
//                 />

//                 {/* Chart Components */}
//                 {loading ? (
//                   <div>Loading...</div>
//                 ) : (
//                   <RadioGroup
//                     defaultValue="card"
//                     onValueChange={setSelectedChart}
//                     className="grid grid-cols-3 gap-4"
//                   >
//                     {filteredCharts.map((chart) => (
//                       <div key={chart.unique_id}>
//                         <RadioGroupItem
//                           value={chart.unique_id}
//                           id={chart.unique_id}
//                           className="peer sr-only"
//                         />
//                         <Label
//                           htmlFor={chart.unique_id}
//                           className="cursor-pointer flex flex-col items-center justify-between rounded-md border-2 bg-popover p-2 hover:border-md hover:text-accent-foreground peer-data-[state=checked]:border-fuchsia-900 [&:has([data-state=checked])]:border-fuchsia-900"
//                           onClick={() => handleChartClick(chart)}
//                           onDoubleClick={() => handleDoubleClick(chart)}
//                         >
//                           <img
//                             className="mb-3 h-20 w-20"
//                             src={chartImages[chart.unique_id] || BarChart}
//                             alt={chart.name}
//                           />
//                           {chart.name}
//                         </Label>
//                       </div>
//                     ))}
//                   </RadioGroup>
//                 )}
//               </div>
//             </div>

//             {/* Create Chart Button */}
//             <div className="w-full p-3">
//               <div className="flex gap-2 justify-end">
//                 <p className="text-xs text-slate-500 font-medium my-auto">
//                   Please select both a Dataset and a Chart type to proceed
//                 </p>
//                 <Button
//                   variant="secondary"
//                   onClick={handleCreateChart}
//                   disabled={!dataset || !selectedChart}
//                 >
//                   CREATE CHART
//                 </Button>
//               </div>
//             </div>
//           </div>
//         </Card>
//       </Container>
//     </div>
//   );
// // };
// import React, { useEffect, useState } from "react";
// import { Container } from "@mui/material";
// import { Card } from "../../../../../@/components/ui/card";
// import { Button } from "../../../../../@/components/ui/button";
// import { useNavigate } from "react-router-dom";
// import axios from "axios";
// import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from "../../../../../@/components/ui/select";
// import { RadioGroup, RadioGroupItem } from "../../../../../@/components/ui/radio-group";
// import { Label } from "../../../../../@/components/ui/label";
// import { Input } from "../../../../../@/components/ui/input";

// // Import all chart images
// import BarChart from "../../../../../assets/viz_thumbnails/bar.png";
// import PieChart from "../../../../../assets/viz_thumbnails/pie.png";
// import LineChart from "../../../../../assets/viz_thumbnails/line.png";
// import AreaChart from "../../../../../assets/viz_thumbnails/area.png";
// import SunburstChart from "../../../../../assets/viz_thumbnails/sunburst.png";
// import BigNumber from "../../../../../assets/viz_thumbnails/big_number.png";
// import Table from "../../../../../assets/viz_thumbnails/table.png";
// import PivotTable from "../../../../../assets/viz_thumbnails/pivot_table.png";

// // Create a mapping of unique IDs to their corresponding images
// const chartImages: { [key: string]: string } = {
//   pie: PieChart,
//   sunburst: SunburstChart,
//   line: LineChart,
//   area: AreaChart,
//   bar: BarChart,
//   big_number: BigNumber,
//   table: Table,
//   pivot_table: PivotTable,
// };

// interface ChartComponent {
//   key: string;
//   name: string;
//   unique_id: string;
//   image: string;
//   execute_action: string;
//   tags: string[];
// }

// interface ChartData {
//   status: boolean;
//   message: string;
//   data: { components: ChartComponent[] }[];
// }

// export const ChartCreate = () => {
//   const navigate = useNavigate();
//   const [loading, setLoading] = useState(true);
//   const [tableData, setTableData] = useState<string[]>([]);
//   const [dataset, setDataset] = useState("");
//   const [chartData, setChartData] = useState<ChartComponent[]>([]);
//   const [selectedChart, setSelectedChart] = useState("");
//   const [searchTerm, setSearchTerm] = useState("");

//   useEffect(() => {
//     const fetchData = async () => {
//       setLoading(true);
//       try {
//         const tablesRes = await axios.post('/api/charts/get_tables', { database: "zolix_c2o", schema: "public" });
//         setTableData(tablesRes.data.data);
//       } catch (error) {
//         console.error("Error fetching tables:", error);
//         setTableData([]);
//       }

//       try {
//         const chartsRes = await axios.post<ChartData>('/api/charts/dashboard_charts', {});
//         const allCharts = chartsRes.data.data.flatMap(section => section.components);
//         setChartData(allCharts);
//       } catch (error) {
//         console.error("Error fetching charts:", error);
//         setChartData([]);
//       }

//       setLoading(false);
//     };

//     fetchData();
//   }, []);

//   const handleChartClick = (chart: ChartComponent) => {
//     setSelectedChart(chart.unique_id);
//   };

//   const handleCreateChart = () => {
//     navigate('/action-center/create-chart', {
//       state: { dataset, chart: selectedChart }
//     });
//     console.log("chart create", dataset, selectedChart);
//   };

//   const handleDoubleClick = (chart: ChartComponent) => {
//     setSelectedChart(chart.unique_id);
//     handleCreateChart();
//   };

//   const filteredCharts = chartData.filter(chart => 
//     chart.name.toLowerCase().includes(searchTerm.toLowerCase())
//   );

//   return (
//     <div>
//       <Container maxWidth="lg">
//         <Card>
//           <div className="flex flex-col">
//             <div className="p-3">
//               <p className="text-xl font-semibold">Create a New Chart</p>
//             </div>
            
//             {/* Dataset Selection */}
//             <div className="flex flex-row gap-2 p-3">
//               <div className="flex item-center justify-center rounded-full bg-purple-300 w-6">
//                 <span>1</span>
//               </div>
//               <div className="grid content-center text-sm font-semibold">Choose a dataset</div>
//             </div>
//             <div className="w-full p-3">
//               {loading ? (
//                 <div>Loading...</div>
//               ) : (
//                 <Select onValueChange={setDataset}>
//                   <SelectTrigger className="w-[350px]">
//                     <SelectValue placeholder="Select a dataset" />
//                   </SelectTrigger>
//                   <SelectContent>
//                     <SelectGroup>
//                       <SelectLabel>Table List</SelectLabel>
//                       {tableData.length === 0 ? (
//                         <SelectItem value="No data">No data</SelectItem>
//                       ) : (
//                         tableData.map((item) => (
//                           <SelectItem key={item} value={item}>
//                             {item}
//                           </SelectItem>
//                         ))
//                       )}
//                     </SelectGroup>
//                   </SelectContent>
//                 </Select>
//               )}
//             </div>

//             {/* Chart Type Selection */}
//             <div className="flex flex-row gap-2 p-3">
//               <div className="flex item-center justify-center rounded-full bg-purple-300 w-6">
//                 <span>2</span>
//               </div>
//               <div className="grid content-center text-sm font-semibold">Choose chart type</div>
//             </div>

//             <div className="w-full p-3">
//               <div className="w-full flex flex-col gap-3 border border-gray-300 rounded-md p-3">
//                 {/* Search Bar */}
//                 <Input
//                   type="text"
//                   placeholder="Search charts..."
//                   value={searchTerm}
//                   onChange={(e) => setSearchTerm(e.target.value)}
//                   className="w-full"
//                 />

//                 {/* Chart Components */}
//                 {loading ? (
//                   <div>Loading...</div>
//                 ) : (
//                   <RadioGroup
//                     defaultValue="card"
//                     onValueChange={setSelectedChart}
//                     className="grid grid-cols-4 gap-4" // Changed to grid-cols-4 for four charts in one line
//                   >
//                     {filteredCharts.map((chart) => (
//                       <div key={chart.unique_id}>
//                         <RadioGroupItem
//                           value={chart.unique_id}
//                           id={chart.unique_id}
//                           className="peer sr-only"
//                         />
//                         <Label
//                           htmlFor={chart.unique_id}
//                           className="cursor-pointer flex flex-col items-center justify-between rounded-md border-2 bg-popover p-2 hover:border-md hover:text-accent-foreground peer-data-[state=checked]:border-fuchsia-900 [&:has([data-state=checked])]:border-fuchsia-900"
//                           onClick={() => handleChartClick(chart)}
//                           onDoubleClick={() => handleDoubleClick(chart)}
//                         >
//                           <img
//                             className="mb-3 h-16 w-16" // Slightly reduced image size to fit four in a row
//                             src={chartImages[chart.unique_id] || BarChart}
//                             alt={chart.name}
//                           />
//                           <span className="text-sm text-center">{chart.name}</span> 
//                         </Label>
//                       </div>
//                     ))}
//                   </RadioGroup>
//                 )}
//               </div>
//             </div>

//             {/* Create Chart Button */}
//             <div className="w-full p-3">
//               <div className="flex gap-2 justify-end">
//                 <p className="text-xs text-slate-500 font-medium my-auto">
//                   Please select both a Dataset and a Chart type to proceed
//                 </p>
//                 <Button
//                   variant="secondary"
//                   onClick={handleCreateChart}
//                   disabled={!dataset || !selectedChart}
//                 >
//                   CREATE CHART
//                 </Button>
//               </div>
//             </div>
//           </div>
//         </Card>
//       </Container>
//     </div>
//   );
// };
import React, { useEffect, useState } from "react";
import { Container } from "@mui/material";
import { Card } from "../../../../../@/components/ui/card";
import { Button } from "../../../../../@/components/ui/button";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { RadioGroup, RadioGroupItem } from "../../../../../@/components/ui/radio-group";
import { Label } from "../../../../../@/components/ui/label";
import { Input } from "../../../../../@/components/ui/input";
import { CaretSortIcon, CheckIcon } from "@radix-ui/react-icons";
import { cn } from "../../../../../@/lib/utils";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "../../../../../@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "../../../../../@/components/ui/popover";

// Import all chart images
import BarChart from "../../../../../assets/viz_thumbnails/bar.png";
import PieChart from "../../../../../assets/viz_thumbnails/pie.png";
import LineChart from "../../../../../assets/viz_thumbnails/line.png";
import AreaChart from "../../../../../assets/viz_thumbnails/area.png";
import SunburstChart from "../../../../../assets/viz_thumbnails/sunburst.png";
import BigNumber from "../../../../../assets/viz_thumbnails/big_number.png";
import Table from "../../../../../assets/viz_thumbnails/table.png";
import PivotTable from "../../../../../assets/viz_thumbnails/pivot_table.png";
import DonutChart from "../../../../../assets/viz_thumbnails/donut.png";
import CustomBarChart from "../../../../../assets/viz_thumbnails/custom_bar.png";
import GaugeChart from "../../../../../assets/viz_thumbnails/gauge.png";
import StackedBarChart from "../../../../../assets/viz_thumbnails/stacked_bar.png";

import TimeSeriesBarChart from "../../../../../assets/viz_thumbnails/time_series_bar.png";

// Create a mapping of unique IDs to their corresponding images
const chartImages: { [key: string]: string } = {
  pie: PieChart,
  donut: DonutChart,
  sunburst: SunburstChart,
  line: LineChart,
  area: AreaChart,
  bar: BarChart,
  custom_bar:CustomBarChart,
  stacked_bar:StackedBarChart,
  big_number: BigNumber,
  table: Table,
  pivot_table: PivotTable,
  gauge:GaugeChart,
  time_series_bar: TimeSeriesBarChart,

};

interface ChartComponent {
  key: string;
  name: string;
  unique_id: string;
  image: string;
  execute_action: string;
  tags: string[];
}

interface ChartData {
  status: boolean;
  message: string;
  data: { components: ChartComponent[] }[];
}

export const ChartCreate = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [tableData, setTableData] = useState<string[]>([]);
  const [dataset, setDataset] = useState("");
  const [chartData, setChartData] = useState<ChartComponent[]>([]);
  const [selectedChart, setSelectedChart] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const tablesRes = await axios.post('/api/charts/get_tables', { database: "zolix_c2o", schema: "public" });
        setTableData(tablesRes.data.data);
      } catch (error) {
        console.error("Error fetching tables:", error);
        setTableData([]);
      }

      try {
        const chartsRes = await axios.post<ChartData>('/api/charts/dashboard_charts', {});
        const allCharts = chartsRes.data.data.flatMap(section => section.components);
        setChartData(allCharts);
      } catch (error) {
        console.error("Error fetching charts:", error);
        setChartData([]);
      }

      setLoading(false);
    };

    fetchData();
  }, []);

  const handleChartClick = (chart: ChartComponent) => {
    setSelectedChart(chart.unique_id);
  };

  const handleCreateChart = () => {
    navigate('/action-center/create-chart', {
      state: { dataset, chart: selectedChart }
    });
    console.log("chart create", dataset, selectedChart);
  };

  const handleDoubleClick = (chart: ChartComponent) => {
    setSelectedChart(chart.unique_id);
    handleCreateChart();
  };

  const filteredCharts = chartData.filter(chart => 
    chart.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div>
      <Container maxWidth="lg">
        <Card>
          <div className="flex flex-col">
            <div className="p-3">
              <p className="text-xl font-semibold">Create a New Chart</p>
            </div>
            
            {/* Dataset Selection */}
            <div className="flex flex-row gap-2 p-3">
              <div className="flex item-center justify-center rounded-full bg-purple-300 w-6">
                <span>1</span>
              </div>
              <div className="grid content-center text-sm font-semibold">Choose a dataset</div>
            </div>
            <div className="w-full p-3">
              {loading ? (
                <div>Loading...</div>
              ) : (
                <Popover open={open} onOpenChange={setOpen}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      role="combobox"
                      aria-expanded={open}
                      className="w-[350px] justify-between"
                    >
                      {dataset
                        ? tableData.find((item) => item === dataset)
                        : "Select a dataset..."}
                      <CaretSortIcon className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-[350px] p-0">
                    <Command>
                      <CommandInput placeholder="Search dataset..." className="h-9" />
                      <CommandList>
                        <CommandEmpty>No dataset found.</CommandEmpty>
                        <CommandGroup>
                          {tableData.map((item) => (
                            <CommandItem
                              key={item}
                              value={item}
                              onSelect={(currentValue) => {
                                setDataset(currentValue === dataset ? "" : currentValue);
                                setOpen(false);
                              }}
                            >
                              {item}
                              <CheckIcon
                                className={cn(
                                  "ml-auto h-4 w-4",
                                  dataset === item ? "opacity-100" : "opacity-0"
                                )}
                              />
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
              )}
            </div>

            {/* Chart Type Selection */}
            <div className="flex flex-row gap-2 p-3">
              <div className="flex item-center justify-center rounded-full bg-purple-300 w-6">
                <span>2</span>
              </div>
              <div className="grid content-center text-sm font-semibold">Choose chart type</div>
            </div>

            <div className="w-full p-3">
              <div className="w-full flex flex-col gap-3 border border-gray-300 rounded-md p-3">
                {/* Search Bar */}
                <Input
                  type="text"
                  placeholder="Search charts..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full"
                />

                {/* Chart Components */}
                {loading ? (
                  <div>Loading...</div>
                ) : (
                  <RadioGroup
                    defaultValue="card"
                    onValueChange={setSelectedChart}
                    className="grid grid-cols-4 gap-4"
                  >
                    {filteredCharts.map((chart) => (
                      <div key={chart.unique_id}>
                        <RadioGroupItem
                          value={chart.unique_id}
                          id={chart.unique_id}
                          className="peer sr-only"
                        />
                        <Label
                          htmlFor={chart.unique_id}
                          className="cursor-pointer flex flex-col items-center justify-between rounded-md border-2 bg-popover p-2 hover:border-md hover:text-accent-foreground peer-data-[state=checked]:border-fuchsia-900 [&:has([data-state=checked])]:border-fuchsia-900"
                          onClick={() => handleChartClick(chart)}
                          onDoubleClick={() => handleDoubleClick(chart)}
                        >
                          <img
                            className="mb-3 h-16 w-16"
                            src={chartImages[chart.unique_id] || BarChart}
                            alt={chart.name}
                          />
                          <span className="text-sm text-center">{chart.name}</span> 
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>
                )}
              </div>
            </div>

            {/* Create Chart Button */}
            <div className="w-full p-3">
              <div className="flex gap-2 justify-end">
                <p className="text-xs text-slate-500 font-medium my-auto">
                  Please select both a Dataset and a Chart type to proceed
                </p>
                <Button
                  variant="secondary"
                  onClick={handleCreateChart}
                  disabled={!dataset || !selectedChart}
                >
                  CREATE CHART
                </Button>
              </div>
            </div>
          </div>
        </Card>
      </Container>
    </div>
  );
};