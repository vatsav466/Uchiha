// import axios from 'axios';

// interface ChartMetric {
//   expression_type: string;
//   column: {
//     column_name: string;
//     type: string;
//   };
//   aggregate: string;
//   label: string;
// }

// interface Filter {
//   col?: string;
//   op?: string;
//   val?: string[];
// }

// interface FormData {
//   dimensions?: Array<{ column: string }>;
//   metrics?: Array<{ column: string; aggregate: string }>;
//   orderBy?: Array<{ column: string; descending: boolean }>;
// }

// export const createBarChartRequest = async (
//   dataset: string,
//   filters: Filter[],
//   chartMetric: ChartMetric | null,
//   formData: FormData,
//   defaultRowLimit: number
// ) => {
//   const chartRequest = {
//     database: "zolix_c2o",
//     schema: "public",
//     table: dataset,
//     visualization_name: "bar",
//     name: "Bar Chart",
//     description: "",
//     params: {
//       queries: [
//         {
//           filters: filters.map(filter => ({
//             col: filter.col,
//             op: filter.op,
//             val: filter.val
//           })),
//           columns: [],
//           metrics: [chartMetric],
//           orderby: formData.orderBy?.map(order => ({
//             order_by: order.descending,
//             expression_type: "SIMPLE",
//             column: {
//               column_name: order.column,
//               type: "UNKNOWN" // You might want to determine the actual type
//             },
//             aggregate: chartMetric?.aggregate || "SUM",
//             label: order.column
//           })) || [],
//           row_limit: defaultRowLimit,
//           series_columns: [],
//           series_limit: 0,
//           order_descending: formData.orderBy?.[0]?.descending || false
//         }
//       ],
//       form_data: {
//         x_axis: {},
//         metrics: [],
//         groupby: formData.dimensions?.map(dim => ({ name: dim.column, label: dim.column })) || [],
//         order_descending: formData.orderBy?.[0]?.descending || false,
//         row_limit: defaultRowLimit,
//         show_legend: false
//       }
//     }
//   };

//   console.log("Bar Chart API Request Body:", JSON.stringify(chartRequest, null, 2));

//   const response = await axios.post('/api/charts/chart', chartRequest);
//   console.log("Bar Chart API Response Body:", response.data);

//   if (response.data.status === true && response.data.data) {
//     return {
//       chartType: 'bar',
//       chartData: response.data.data
//     };
//   } else {
//     throw new Error("Invalid response format for bar chart");
//   }
// // };
// import axios from 'axios';

// interface ChartMetric {
//   expression_type: string;
//   column: {
//     column_name: string;
//     type: string;
//   };
//   aggregate: string;
//   label: string;
// }

// interface Filter {
//   col?: string;
//   op?: string;
//   val?: string[];
// }

// interface FormData {
//   dimensions?: Array<{ id: string; name: string }>;
// }

// export const createBarChartRequest = async (
//   dataset: string,
//   filters: Filter[],
//   chartMetric: ChartMetric | null,
//   formData: FormData,
//   defaultRowLimit: number,
//   showLegend: boolean,
//   legendOrientation: string,
//   legendType: string
// ) => {
//   const chartRequest = {
//     "database": "zolix_c2o",
//     "schema": "public",
//     "table": dataset,
//     "visualization_name": "bar",
//     "name": "Bar Chart",
//     "description": "",
//     "params": {
//       "queries": [
//         {
//           "filters": filters.map(filter => ({
//             col: filter.col,
//             op: filter.op,
//             val: filter.val ? filter.val.flat() : [] // Flatten the val array
//           })),
//           "columns": [],
//           "metrics": chartMetric ? [chartMetric] : [],
//           "orderby": chartMetric ? [
//             {
//               "order_by": false,
//               ...chartMetric
//             }
//           ] : [],
//           "row_limit": defaultRowLimit,
//           "series_columns": [],
//           "series_limit": 0,
//           "order_descending": true
//         }
//       ],
//       "form_data": {
//         "x_axis": {},
//         "metrics": [],
//         "groupby": formData.dimensions?.map(dim => ({
//           name: dim.name,
//           label: dim.name
//         })) || [],
//         "order_descending": false,
//         "row_limit": defaultRowLimit,
//         "show_legend": showLegend,
//         "legend_orientation": legendOrientation,
//         "legend_type": legendType
//       }
//     }
//   };

//   console.log("Bar Chart API Request Body:", JSON.stringify(chartRequest, null, 2));

//   const response = await axios.post('/api/charts/chart', chartRequest);
//   console.log("Bar Chart API Response Body:", response.data);

//   if (response.data.status === true && response.data.data) {
//     return {
//       chartType: 'bar',
//       chartData: response.data.data,
//       chartRequest: chartRequest,
//       showLegend,
//       legendOrientation,
//       legendType
//     };
//   } else {
//     throw new Error("Invalid response format for bar chart");
//   }
// // };
// import axios from 'axios';

// interface ChartMetric {
//   expression_type: string;
//   column: {
//     column_name: string;
//     type: string;
//   };
//   aggregate: string;
//   label: string;
// }

// interface Filter {
//   col?: string;
//   op?: string;
//   val?: string[];
// }

// interface FormData {
//   dimensions?: Array<{ id: string; name: string }>;
//   x_axis?: {
//     name: string;
//     label: string;
//     sort_ascending: boolean;
//   };
// }

// export const createBarChartRequest = async (
// dataset: string, filters: Filter[], chartMetric: ChartMetric | null, formData: FormData, defaultRowLimit: number, showLegend: boolean, showDataZoom: boolean, legendOrientation: string, legendType: string) => {
//   const chartRequest = {
//     "database": "zolix_c2o",
//     "schema": "public",
//     "table": dataset,
//     "visualization_name": "bar",
//     "name": "Bar Chart",
//     "description": "",
//     "params": {
//       "queries": [
//         {
//           "filters": filters.map(filter => ({
//             col: filter.col,
//             op: filter.op,
//             val: filter.val ? filter.val.flat() : []
//           })),
//           "metrics": chartMetric ? [chartMetric] : [],
//           "orderby": chartMetric ? [
//             {
//               "order_by": false,
//               ...chartMetric
//             }
//           ] : [],
//           "row_limit": defaultRowLimit,
//           "series_columns": [],
//           "series_limit": 0,
//           "order_descending": true
//         }
//       ],
//       "form_data": {
//         "x_axis": formData.x_axis || {},
//         "groupby": formData.dimensions?.map(dim => ({
//           name: dim.name,
//           label: dim.name
//         })) || [],
//         "query_mode": "",
//         "show_legend": showLegend
//       }
//     }
//   };

//   console.log("API Request Body:", JSON.stringify(chartRequest, null, 2));

//   const response = await axios.post('/api/charts/chart', chartRequest);
//   console.log("API Response Body:", response.data);

//   if (response.data.status === true && response.data.data) {
//     return {
//       chartType: 'bar',
//       chartData: response.data.data,
//       chartRequest: chartRequest,
//       showLegend
//     };
//   } else {
//     throw new Error("Invalid response format");
//   }
// };


// import axios from 'axios';

// interface ChartMetric {
//   expression_type: string;
//   column: {
//     column_name: string;
//     type: string;
//   };
//   aggregate: string;
//   label: string;
// }

// interface Filter {
//   col?: string;
//   op?: string;
//   val?: string[];
// }
// interface XAxisConfig {
//   name: string;
//   label: string;
//   sort_ascending: boolean;
// }

// interface FormData {
//   dimensions?: Array<{ id: string; name: string }>;
//   x_axis?: XAxisConfig;
// }

// export const createBarChartRequest = async (
//   dataset: string,
//   filters: Filter[],
//   chartMetrics: ChartMetric | null,
//   formData: FormData,
//   defaultRowLimit: number,
//   showLegend: boolean,
//   showDataZoom: boolean,
//   legendOrientation: string,
//   legendType: string
// ) => {
//   const chartRequest = {
//     "database": "zolix_c2o",
//     "schema": "public",
//     "table": dataset,
//     "visualization_name": "bar",
//     "name": "Bar Chart",
//     "description": "",
//     "params": {
//       "queries": [
//         {
//           "filters": filters.map(filter => ({
//             col: filter.col,
//             op: filter.op,
//             val: filter.val ? filter.val.flat() : []
//           })),
//           "metrics": chartMetrics ? chartMetrics : [],
//           "orderby": chartMetrics ? [
//             {
//               "order_by": false,
//               ...chartMetrics
//             }
//           ] : [],
//           "row_limit": defaultRowLimit,
//           "series_columns": [],
//           "series_limit": 0,
//           "order_descending": true
//         }
//       ],
//       "form_data": {
//         "x_axis": formData.x_axis ? {
//           name: formData.x_axis.name,
//           label: formData.x_axis.label || "",
//           sort_ascending: formData.x_axis.sort_ascending || false
//         } : {},
//         "time_grain": "",
//         "groupby": formData.dimensions?.map(dim => ({
//           name: dim.name,
//           label: dim.name
//         })) || [],
//         "query_mode": "",
//         "show_legend": showLegend,
//         "show_data_zoom": showDataZoom,
//         "legend_orientation": legendOrientation,
//         "legend_type": legendType
//       }
    
//     },
//     "tags": [
//       {
//         "name": "",
//         "value": ""
//       }
//     ],
//     "group_id": 0,
//     "group_name": "",
//     "type": "Manual",
//     "user_query": "",
//     "user_ai_text": "",
//     "created_by": "",
//     "hashed_value": ""
//   };
    

//   console.log("API Request Body:", JSON.stringify(chartRequest, null, 2));

//   const response = await axios.post('/api/charts/chart', chartRequest);
//   console.log("API Response Body:", response.data);

//   if (response.data.status === true && response.data.data) {
//     return {
//       chartType: 'bar',
//       chartData: response.data.data,
//       chartRequest: chartRequest,
//       showLegend,
//       showDataZoom,
//       legendOrientation,
//       legendType
//     };
//   } else {
//     throw new Error("Invalid response format");
//   }
// };


// import axios from 'axios';

// interface ChartMetric {
//   expression_type: string;
//   column: {
//     column_name: string;
//     type: string;
//   };
//   aggregate: string;
//   label: string;
// }

// interface Filter {
//   col?: string;
//   op?: string;
//   val?: string[];
// }

// interface XAxisConfig {
//   name: string;
//   label: string;
//   sort_ascending: boolean;
// }

// interface FormData {
//   dimensions?: Array<{ id: string; name: string }>;
//   x_axis?: XAxisConfig;
// }

// export const createBarChartRequest = async (
//   dataset: string,
//   filters: Filter[],
//   chartMetrics: ChartMetric[] | ChartMetric | null, // Updated to handle array or single metric
//   formData: FormData,
//   defaultRowLimit: number,
//   timeGrain: string,
//   showLegend: boolean,
//   showDataZoom: boolean,
//   legendOrientation: string,
//   legendType: string
// ) => {
//   // Convert chartMetrics to array if it's a single metric
//   const metricsArray = chartMetrics 
//     ? Array.isArray(chartMetrics) 
//       ? chartMetrics 
//       : [chartMetrics]
//     : [];

//   // Ensure we have at least one metric
//   if (metricsArray.length === 0) {
//     throw new Error("At least one metric is required for bar chart");
//   }

//   const chartRequest = {
//     "database": "zolix_c2o",
//     "schema": "public",
//     "table": dataset,
//     "visualization_name": "bar",
//     "name": "Bar Chart",
//     "description": "",
//     "params": {
//       "queries": [
//         {
//           "filters": filters.map(filter => ({
//             col: filter.col,
//             op: filter.op,
//             val: filter.val ? filter.val.flat() : []
//           })),
//           "metrics": metricsArray,
//           "orderby": metricsArray.map(metric => ({
//             order_by: false,
//             ...metric
//           })),
//           "row_limit": defaultRowLimit,
//           "series_columns": [],
//           "series_limit": 0,
//           "order_descending": true
//         }
//       ],
//       "form_data": {
//         "x_axis": formData.x_axis ? {
//           name: formData.x_axis.name,
//           label: formData.x_axis.label || "",
//           sort_ascending: formData.x_axis.sort_ascending || false
//         } : {},
//         "time_grain":timeGrain,
//         "groupby": formData.dimensions?.map(dim => ({
//           name: dim.name,
//           label: dim.name
//         })) || [],
//         "query_mode": "",
//         "show_legend": showLegend,
//         "show_data_zoom": showDataZoom,
//         "legend_orientation": legendOrientation,
//         "legend_type": legendType
//       }
//     },
//     "tags": [
//       {
//         "name": "",
//         "value": ""
//       }
//     ],
//     "group_id": 0,
//     "group_name": "",
//     "type": "Manual",
//     "user_query": "",
//     "user_ai_text": "",
//     "created_by": "",
//     "hashed_value": ""
//   };

//   try {
//     console.log("API Request Body:", JSON.stringify(chartRequest, null, 2));
//     const response = await axios.post('/api/charts/chart', chartRequest);
//     console.log("API Response Body:", response.data);

//     if (response.data.status === true && response.data.data) {
//       return {
//         chartType: 'bar',
//         chartData: response.data.data,
//         chartRequest: chartRequest,
//         showLegend,
//         showDataZoom,
//         legendOrientation,
//         legendType
//       };
//     } else {
//       throw new Error("Invalid response format");
//     }
//   } catch (error) {
//     console.error("Error creating bar chart:", error);
//     throw error;
//   }
// };

import axios from 'axios';

interface ChartMetric {
  expression_type: string;
  column: {
    column_name: string;
    type: string;
  };
  aggregate: string;
  label: string;
}

interface Filter {
  col?: string;
  op?: string;
  val?: string[];
}

interface XAxisConfig {
  name: string;
  label: string;
  alias:string;
  sort_ascending: boolean;
}

interface FormData {
  dimensions?: Array<{ id: string; name: string; label?: string ; alias:string;
  }>;
  x_axis?: XAxisConfig;

}
export const createBarChartRequest = async (
  dataset: string,
  filters: Filter[],
  chartMetrics: ChartMetric[] | ChartMetric | null,
  formData: FormData,
  defaultRowLimit: number,
  timeGrain: string,
  showLegend: boolean,
  showDataZoom: boolean,
  legendOrientation: string,
  legendType: string
) => {
  // Convert chartMetrics to array if it's a single metric
  const metricsArray: ChartMetric[] = chartMetrics
    ? Array.isArray(chartMetrics)
      ? chartMetrics
      : [chartMetrics]
    : [];

  // Ensure we have at least one metric
  if (metricsArray.length === 0) {
    throw new Error("At least one metric is required for bar chart");
  }

  const chartRequest = {
    "database": "zolix_c2o",
    "schema": "public",
    "table": dataset,
    "visualization_name": "bar",
    "organization_id": 6,
    "name": "Bar Chart",
    "description": "",
    "params": {
      "queries": [
        {
          "filters": filters.map(filter => ({
            col: filter.col,
            op: filter.op,
            val: filter.val ? filter.val.flat() : []
          })),
          "metrics": metricsArray.map(metric => ({
            // Use label if available, otherwise fall back to the column name
            label: metric.label || metric.column.column_name,
            ...metric
          })),
          "orderby": metricsArray.map(metric => ({
            order_by: false,
            // Use label if available, otherwise fall back to the column name
            label: metric.label || metric.column.column_name,
            ...metric
          })),
          "row_limit": defaultRowLimit,
          "series_columns": [],
          "series_limit": 0,
          "order_descending": false
        }
      ],
      "form_data": {
        "x_axis": formData.x_axis
          ? {
              name: formData.x_axis.name,
              // Use label if available, otherwise fall back to name
              label: (!formData.x_axis.label || formData.x_axis.label === '') ? formData.x_axis.name : formData.x_axis.label,
              sort_ascending: formData.x_axis.sort_ascending || false,
            }
          : {},
        "time_grain": timeGrain,
        "groupby": formData.dimensions?.map((dim) => ({
          name: dim.name,
          // Use label if available, otherwise fall back to name
          label: dim.alias || dim.name,
        })) || [],
        "query_mode": "",
        "show_legend": showLegend,
        "show_data_zoom": showDataZoom,
        "legend_orientation": legendOrientation,
        "legend_type": legendType
      }
    },
    "tags": [
      {
        "name": "",
        "value": ""
      }
    ],
    "group_id": 0,
    "group_name": "",
    "type": "Manual",
    "user_query": "",
    "user_ai_text": "",
    "created_by": "",
    "hashed_value": ""
  };

  try {
    console.log("API Request Body:", JSON.stringify(chartRequest, null, 2));
    const response = await axios.post('/api/charts/chart', chartRequest);
    console.log("API Response Body:", response.data);
    const organizationId=chartRequest.organization_id;
    if (response.data.status === true && response.data.data) {
      return {
        chartType: 'bar',
        chartData: response.data.data,
        chartRequest: chartRequest,
        showLegend,
        showDataZoom,
        legendOrientation,
        legendType,
        organizationId
      };
    } else {
      throw new Error("Invalid response format");
    }
  } catch (error) {
    console.error("Error creating bar chart:", error);
    throw error;
  }
};