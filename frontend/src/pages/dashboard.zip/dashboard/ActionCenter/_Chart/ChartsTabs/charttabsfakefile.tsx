

// // // // // import React, { useState, useEffect, ReactNode } from "react";
// // // // // import axios from 'axios';
// // // // // import { useDrop } from "react-dnd";
// // // // // import { IconX, IconArrowBarToRight, IconPencil, IconSettings } from '@tabler/icons-react';
// // // // // import { MdBarChart, MdPivotTableChart } from "react-icons/md";
// // // // // import { FaChartLine } from "react-icons/fa6";
// // // // // import { AiOutlineAreaChart, AiOutlinePieChart } from "react-icons/ai";
// // // // // import { LiaTableSolid } from "react-icons/lia";
// // // // // import { RiDonutChartFill } from "react-icons/ri";
// // // // // import { PiChartBarHorizontalFill } from "react-icons/pi";

// // // // // import {
// // // // //   Popover,
// // // // //   PopoverContent,
// // // // //   PopoverTrigger,
// // // // // } from "../../../../../@/components/ui/popover";
// // // // // import { Button } from "../../../../../@/components/ui/button";
// // // // // import { Label } from "../../../../../@/components/ui/label";
// // // // // import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from "../../../../../@/components/ui/select";
// // // // // import { Card, CardContent, CardFooter } from "../../../../../@/components/ui/card";
// // // // // import { createPieChart } from "../ChartRequests/PieChartRequest";
// // // // // import { createBarChartRequest } from "../ChartRequests/BarChartRequest";
// // // // // import { createBigNumberRequest } from "../ChartRequests/BigNumberChartRequest";
// // // // // import { createLineChartRequest } from "../ChartRequests/LineChartRequest";
// // // // // import { createAreaChartRequest } from "../ChartRequests/AreaChartRequest";
// // // // // import { createTableRequest } from "../ChartRequests/TableRequest";
// // // // // import ExpressionEditor from './ExpressionEditor';
// // // // // import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "../../../../../@/components/ui/tooltip";
// // // // // import MultiSelect from "../../../../../@/components/ui/multi-select";
// // // // // import { createPivotTableRequest } from "../ChartRequests/PivotTableRequest";
// // // // // import AskAITab from "./AskAITab";
// // // // // import QueryTab from "./QueryTab";
// // // // // import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../../../../@/components/ui/tabs";
// // // // // import { useLocation } from "react-router-dom";
// // // // // import { createDonutChart } from "../ChartRequests/DonutChartRequest";
// // // // // import { createCustomBarChartRequest } from "../ChartRequests/CustomBarChartRequest";
// // // // // import { useSelector } from "react-redux";
// // // // // import { RootState } from "../../../../../redux/store";
// // // // // interface DroppedItem {
// // // // //   id: string;
// // // // //   name: string;
// // // // //   type: string;
// // // // // }
// // // // // interface Option {
// // // // //   value: string;
// // // // //   label: string;
// // // // // }

// // // // // interface ChartType {
// // // // //   unique_id: string;
// // // // //   name: string;
// // // // //   icon: ReactNode;
// // // // //   hasData?: boolean;
// // // // // }

// // // // // interface FormField {
// // // // //   key: string;
// // // // //   label: string;
// // // // //   type: string;
// // // // //   placeholder?: string;
// // // // //   options?: string[];
// // // // //   popover?: {
// // // // //     [key: string]: any[];
// // // // //   };
// // // // // }

// // // // // interface ChartForm {
// // // // //   parameters: FormField[];
// // // // // }

// // // // // interface ChartTabsProps {
// // // // //   dataset: string;
// // // // //   chartType: string;
// // // // //   onChartCreated: (chartOptions: any) => void;
// // // // //   onThemeChange: (theme: string) => void;
// // // // //   selectedTheme: string;
// // // // //   onClearChartPreview: () => void;  // Add this line
// // // // // }
// // // // // interface Column {
// // // // //   name: string;
// // // // //   type: string;
// // // // // }

// // // // // interface Dimension {
// // // // //   id: string;
// // // // //   name: string;
// // // // //   type?: string;
// // // // // }
// // // // // interface Metric {
// // // // //   expression_type: string;
// // // // //   column: {
// // // // //     column_name: string;
// // // // //     type: string;
// // // // //   };
// // // // //   aggregate: string;
// // // // //   label: string;
// // // // // }

// // // // // interface Filter {
// // // // //   id: string;
// // // // //   col?: string;
// // // // //   op?: string;
// // // // //   val?: string[];
// // // // //   alias?: string;  // Add this line
// // // // // }
// // // // // interface FormData {
// // // // //   dimensions?: DroppedItem[];
// // // // //   metrics?: DroppedItem[];
// // // // //   x_axis?: DroppedItem;
// // // // //   [key: string]: any;
// // // // // }
// // // // // const ChartTabs: React.FC<ChartTabsProps> = ({ 
// // // // //   dataset, 
// // // // //   chartType, 
// // // // //   onChartCreated, 
// // // // //   onThemeChange,
// // // // //   selectedTheme ,
// // // // //   onClearChartPreview  // Add this line

// // // }) => {const [activeChartType, setActiveChartType] = useState<string>("");
// // // // //   const [chartTypes, setChartTypes] = useState<ChartType[]>([]);
// // // // //   const [chartForms, setChartForms] = useState<{[key: string]: ChartForm}>({});
// // // // //   const [columns, setColumns] = useState<Column[]>([]);
// // // // //   const [formData, setFormData] = useState<{[key: string]: any}>({});
// // // // //     const [popoverSelections, setPopoverSelections] = useState<{[key: string]: any}>({});
// // // // //   const [uniqueValues, setUniqueValues] = useState<any>({});
// // // // //   const [defaultRowLimit, setDefaultRowLimit] = useState(10);
// // // // //   const [chartMetric, setChartMetric] = useState<Metric | null>(null);
// // // // //   const [filters, setFilters] = useState<Filter[]>([]);
// // // // //   const [chartDataModel, setChartDataModel] = useState<any>(null);
// // // // //   const [isLoading, setIsLoading] = useState(false);
// // // // //   const [error, setError] = useState<string | null>(null);
// // // // //   const [showLegend, setShowLegend] = useState(true);
// // // // // const [legendOrientation, setLegendOrientation] = useState("top");
// // // // // const [legendType, setLegendType] = useState("scroll");
// // // // // const [showDataZoom, setShowDataZoom] = useState(false);
// // // // // const [isExpressionEditorOpen, setIsExpressionEditorOpen] = useState(false);
// // // // // const [showLabelLines, setShowLabelLines] = useState(false);
// // // // // const [activeTab, setActiveTab] = useState<string>("default");
// // // // // const [isChartCreated, setIsChartCreated] = useState(false);
// // // // // const location = useLocation();
// // // // // const { state } = location;
// // // // // const [chartData, setChartData] = useState(null);
// // // // // const [xAxisData, setXAxisData] = useState<any>(null);

// // // // // const chartDetails: any = useSelector((state: RootState) => state.chart);

// // // // // const handleEditClick = () => {
// // // // //   setIsExpressionEditorOpen(true);
// // // // // };

// // // // // const handleExpressionEditorClose = () => {
// // // // //   setIsExpressionEditorOpen(false);
// // // // // };

// // // // // const handleExpressionEditorSave = () => {
// // // // //   // Handle saving the expressions
// // // // //   setIsExpressionEditorOpen(false);
// // // // // };

// // // // // useEffect(() => {
// // // // //   if(chartDetails?.id) {
// // // // //     setFilters(chartDetails?.chart?.params?.queries[0].filters);
// // // // //   }
// // // // //   fetchChartTypes();
// // // // //   fetchTableData();
// // // // // }, [dataset]);

// // // // // useEffect(() => {
// // // // //   if (state && state.chart) {
// // // // //     setActiveChartType(state.chart);
// // // // //   }
// // // // // }, [state]);

// // // // // const fetchChartTypes = async () => {
// // // // //   try {
// // // // //     const response = await axios.post('/api/charts/dashboard_charts', {});
// // // // //     const allChartTypes = response.data.data.flatMap((section: any) => section.components);

// // // // //     const filteredChartTypes = allChartTypes.filter((chart: ChartType) => {
// // // // //       if (chart.name.toLowerCase() === 'sunburst chart') {
// // // // //         return chart.hasData === true;
// // // // //       }
// // // // //       return true;
// // // // //     });

// // // // //     const chartTypesWithIcons = filteredChartTypes.map((chart: ChartType) => ({
// // // // //       ...chart,
// // // // //       icon: getChartIcon(chart.name)
// // // // //     }));

// // // // //     setChartTypes(chartTypesWithIcons);
// // // // //     if (chartTypesWithIcons.length > 0 && !state?.chart) {
// // // // //       setActiveChartType(chartTypesWithIcons[0].unique_id);
// // // // //     }
// // // // //     fetchChartForms(chartTypesWithIcons);
// // // // //   } catch (error) {
// // // // //     console.error("Error fetching chart types:", error);
// // // // //   }
// // // // // };
// // // // //   const getChartIcon = (chartName: string) => {
// // // // //     switch (chartName.toLowerCase()) {
// // // // //       case 'bar chart': return <MdBarChart size={16} />;
// // // // //       case 'custom bar chart': return <PiChartBarHorizontalFill size={16} />;
// // // // //       case 'line chart': return <FaChartLine size={16} />;
// // // // //       case 'area chart': return <AiOutlineAreaChart size={16} />;
// // // // //       case 'pie chart': return <AiOutlinePieChart size={16} />;
// // // // //       case 'table': return <LiaTableSolid size={16} />;
// // // // //       case 'big number': return "4k";
// // // // //       case 'donut chart': return <RiDonutChartFill size={16}/>;
// // // // //       default: return <MdPivotTableChart size={16} />;
// // // // //     }
// // // // //   };

// // // // //   const fetchChartForms = async (chartTypes: ChartType[]) => {
// // // // //     const forms: {[key: string]: ChartForm} = {};
// // // // //     for (const chart of chartTypes) {
// // // // //       try {
// // // // //         const response = await axios.post('/api/charts/get_chart_form', {
// // // // //           unique_id: chart.unique_id
// // // // //         });
// // // // //         forms[chart.unique_id] = response.data.data;
// // // // //       } catch (error) {
// // // // //         console.error(`Error fetching form for ${chart.unique_id}:`, error);
// // // // //       }
// // // // //     }
// // // // //     setChartForms(forms);
// // // // //   };

// // // // //   const fetchTableData = async () => {
// // // // //     let params = {
// // // // //       "database": "zolix_c2o",
// // // // //       "schema": "public",
// // // // //       "table": dataset
// // // // //     }
// // // // //     try {
// // // // //       const response = await axios.post(
// // // // //         '/api/charts/get_columns',
// // // // //         params
// // // // //       );
// // // // //       const columnData: Column[] = response.data.data.map((col: any) => ({
// // // // //         name: col.name,
// // // // //         type: col.type
// // // // //       }));
// // // // //       setColumns(columnData);
// // // // //       // Fetch unique values for each column
// // // // //       columnData.forEach((column: Column) => fetchUniqueValues(column.name));
// // // // //     } catch (error) {
// // // // //       console.error('Error fetching columns:', error);
// // // // //       alert('Failed to fetch columns. Please check the console for more details.');
// // // // //     }
// // // // //   };

// // // // //   const fetchUniqueValues = async (column: string) => {
// // // // //     try {
// // // // //       const response = await axios.post('/api/charts/get_unique_values', {
// // // // //         database: "zolix_c2o",
// // // // //         schema: "public",
// // // // //         table: dataset,
// // // // //         column: [column]
// // // // //       });

// // // // //       setUniqueValues(prev => ({
// // // // //         ...prev,
// // // // //         ...response.data.data
// // // // //       }));
// // // // //     } catch (error) {
// // // // //       console.error(`Error fetching unique values for ${column}:`, error);
// // // // //     }
// // // // //   };
// //   // const handleChartTypeChange = (type: string) => {
// //   //   setActiveChartType(type);
// //   //   // Reset form data when changing chart type
// //   //   setFormData({});
// //   //   setChartMetric(null);
// //   //   setFilters([]);
// //   // };
// // // // //   const handleFormChange = (key: string, value: any, openPopover = false) => {
// // // // //     setFormData(prevData => ({
// // // // //       ...prevData,
// // // // //       [key]: value
// // // // //     }));
  
// // // // //     if (key === 'x_axis' && value) {
// // // // //       setXAxisData({
// // // // //         name: value.name,
// // // // //         label: value.name,
// // // // //         sort_ascending: true
// // // // //       });
// // // // //     }
// // // // //     if (openPopover && value) {
// // // // //       if (!Array.isArray(value)) {
// // // // //         setPopoverSelections(prev => ({
// // // // //           ...prev,
// // // // //           [value.id]: { isOpen: true, column: value.name }
// // // // //         }));
// // // // //       } else if (Array.isArray(value) && value.length > 0) {
// // // // //         const lastItem = value[value.length - 1];
// // // // //         setPopoverSelections(prev => ({
// // // // //           ...prev,
// // // // //           [lastItem.id]: { isOpen: true, column: lastItem.name }
// // // // //         }));
// // // // //       }
// // // // //     }
// // // // //   };
// // // // //   const handlePopoverSave = (fieldKey: string, itemId: string, data: any) => {
// // // // //     let savedData: any = {
// // // // //       id: data.id,
// // // // //       type: data.type,
// // // // //       column: data.column,
// // // // //       alias: data.alias
// // // // //     };
  
// // // // //     let displayText = data.alias || data.column;
  
// // // // //     switch (fieldKey) {
// // // // //       case 'x_axis':
// // // // //         displayText = data.alias || data.column;
// // // // //         setXAxisData({
// // // // //           name: data.column,
// // // // //           label: data.alias || data.column,
// // // // //           sort_ascending: true
// // // // //         });
// // // // //         setFormData(prevData => ({
// // // // //           ...prevData,
// // // // //           x_axis: {
// // // // //             name: data.column,
// // // // //             label: data.alias || data.column,
// // // // //             sort_ascending: true
// // // // //           }
// // // // //         }));
// // // // //         break;
// // // // //       case 'metric':
// // // // //         displayText = data.alias || (data.aggregate && data.column 
// // // // //           ? `${data.column} (${data.aggregate})`
// // // // //           : data.column);
// // // // //         // Set chartMetric for the bar chart
// // // // //         const columnData = columns.find(col => col.name === data.column);
// // // // //         setChartMetric({
// // // // //           expression_type: "SIMPLE",
// // // // //           column: {
// // // // //             column_name: data.column,
// // // // //             type: columnData?.type || "UNKNOWN",
// // // // //           },
// // // // //           aggregate: data.aggregate,
// // // // //           label: data.alias || data.column
// // // // //         });
// // // // //         break;
     
// // // // //       case 'dimensions':
// // // // //         displayText = data.alias || data.column;
// // // // //         // Update dimensions in formData
// // // // //         setFormData(prevData => {
// // // // //           const updatedDimensions = Array.isArray(prevData.dimensions) 
// // // // //             ? prevData.dimensions.map((dim: any) => 
// // // // //                 dim.id === itemId 
// // // // //                   ? { ...dim, name: data.column, alias: data.alias }
// // // // //                   : dim
// // // // //               )
// // // // //             : [];
// // // // //           return { ...prevData, dimensions: updatedDimensions };
// // // // //         });
// // // // //         break;
// // // // //       default:
// // // // //         displayText = data.alias || data.column;
// // // // //     }
  
// // // // //     setPopoverSelections(prev => ({
// // // // //       ...prev,
// // // // //       [itemId]: { ...savedData, displayText, isOpen: false }
// // // // //     }));
  
// // // // //     console.log("Saved x-axis data:", formData.x_axis); // Add this log
// // // // //   };

// // // // //   const saveMetric = (selectedColumn: string, selectedAggregate: string, item: DroppedItem, alias: string) => {
// // // // //     if (!selectedColumn || !selectedAggregate || !item) {
// // // // //       alert("Please select a column and aggregate function.");
// // // // //       return;
// // // // //     }
// // // // //     const columnData = columns.find(col => col.name === selectedColumn);
// // // // //     const newMetric: Metric = {
// // // // //       expression_type: "SIMPLE",
// // // // //       column: {
// // // // //         column_name: selectedColumn,
// // // // //         type: columnData ? columnData.type : "UNKNOWN",
// // // // //       },
// // // // //       aggregate: selectedAggregate,
// // // // //       label: alias || selectedColumn
// // // // //     };
// // // // //     setChartMetric(newMetric);
// // // // //   };
// // // // //   const handleFilterChange = (id: string, col?: string, op?: string, val?: string[], alias?: string) => {
// // // // //     setFilters(prevFilters => {
// // // // //       const existingFilterIndex = prevFilters.findIndex(filter => filter.id === id);
// // // // //       const columnData = columns.find(column => column.name === col);
// // // // //       const newFilter = { 
// // // // //         id, 
// // // // //         col: col || '', 
// // // // //         op: op || '', 
// // // // //         val: val || [], 
// // // // //         alias: alias || '',
// // // // //         type: columnData ? columnData.type : "UNKNOWN"
// // // // //       };
// // // // //       if (existingFilterIndex !== -1) {
// // // // //         // Update existing filter
// // // // //         const updatedFilters = [...prevFilters];
// // // // //         updatedFilters[existingFilterIndex] = newFilter;
// // // // //         return updatedFilters;
// // // // //       } else {
// // // // //         // Add new filter
// // // // //         return [...prevFilters, newFilter];
// // // // //       }
// // // // //     });
// // // // //   };

// // // // //   const getDisplayText = (item: DroppedItem, fieldKey: string) => {
// // // // //     const selection = popoverSelections[item.id];
// // // // //     if (!selection) return item.name || '';

// // // // //     return selection.alias || selection.column || item.name;
// // // // //   };
// //   // const renderChartDropdown = () => (
// //   //   <Select value={activeChartType} onValueChange={handleChartTypeChange}>
// //   //     <SelectTrigger className="w-full">
// //   //       <SelectValue placeholder="Select a chart type">
// //   //         {activeChartType && (
// //   //           <div className="flex items-center">
// //   //             {getChartIcon(chartTypes.find(ct => ct.unique_id === activeChartType)?.name || "")}
// //   //             <span className="ml-2">{chartTypes.find(ct => ct.unique_id === activeChartType)?.name}</span>
// //   //           </div>
// //   //         )}
// //   //       </SelectValue>
// //   //     </SelectTrigger>
// //   //     <SelectContent>
// //   //       {chartTypes.map((chartType) => (
// //   //         <SelectItem key={chartType.unique_id} value={chartType.unique_id}>
// //   //           <div className="flex items-center">
// //   //             {chartType.icon}
// //   //             <span className="ml-2">{chartType.name}</span>
// //   //           </div>
// //   //         </SelectItem>
// //   //       ))}
// //   //     </SelectContent>
// //   //   </Select>
// //   // );
// // // // //   const DynamicPopoverContent: React.FC<{ field: FormField; item: DroppedItem; onClose: () => void; onSave: (data: any) => void }> = ({ field, item, onClose, onSave }) => {
// // // // //     const storedData = popoverSelections[item.id] || {};
// // // // //     const [popoverData, setPopoverData] = useState<{[key: string]: string | any}>({
// // // // //       columns: storedData.column || item.name,
// // // // //       aggregate: storedData.aggregate || '',
// // // // //       operator: storedData.operator || '',
// // // // //       value: storedData.value || [],
// // // // //       row_limit: defaultRowLimit,
// // // // //       alias: storedData.alias || ''
// // // // //     });
    
// // // // //     const handlePopoverChange = (key: string, value: string | Option[]) => {
// // // // //       setPopoverData(prev => ({ ...prev, [key]: value }));
// // // // //     };
    
    
// // // // //     const handleSave = () => {
// // // // //       const baseData = {
// // // // //         id: item.id,
// // // // //         type: item.type,
// // // // //         column: popoverData['columns'],
// // // // //         alias: popoverData['alias']
// // // // //       };
  
// // // // //       switch (field.key) {
// // // // //         case 'metrics':
// // // // //         case 'metric':
// // // // //           onSave({
// // // // //             ...baseData,
// // // // //             aggregate: popoverData['aggregate']
// // // // //           });
// // // // //           break;
// // // // //         case 'filters':
// // // // //           onSave({
// // // // //             ...baseData,
// // // // //             operator: popoverData['operator'],
// // // // //             value: (popoverData['value'] as Option[]).map(option => option.value)
// // // // //           });
// // // // //           break;
// // // // //         default:
// // // // //           onSave(baseData);
// // // // //       }
// // // // //     };
  
  
// // // // //     const renderPopoverField = (popoverField: any) => {
// // // // //       switch (popoverField.key) {
// // // // //         case 'columns':
// // // // //         case 'operator':
// // // // //         case 'aggregate':
// // // // //           return (
// // // // //             <Select 
// // // // //               value={popoverData[popoverField.key] as string} 
// // // // //               onValueChange={(value) => handlePopoverChange(popoverField.key, value)}
// // // // //             >
// // // // //               <SelectTrigger className="w-full">
// // // // //                 <SelectValue placeholder={popoverField.placeholder} />
// // // // //               </SelectTrigger>
// // // // //               <SelectContent>
// // // // //               {popoverField.key === 'columns' 
// // // // //   ? columns.map((column: Column) => (
// // // // //       <SelectItem key={column.name} value={column.name}>{column.name}</SelectItem>
// // // // //     ))
// // // // //   : popoverField.options?.filter((option: string) => option !== '').map((option: string) => (
// // // // //       <SelectItem key={option} value={option}>{option}</SelectItem>
// // // // //     ))
// // // // // }
// // // // //               </SelectContent>
// // // // //             </Select>
// // // // //           );
// // // // //         case 'value':
// // // // //           if (popoverData['columns']) {
// // // // //             const options = (Array.isArray(uniqueValues[popoverData['columns'] as string]) 
// // // // //               ? uniqueValues[popoverData['columns'] as string].filter((value: string) => value !== '')
// // // // //               : []
// // // // //             ).map((value: string) => ({ value, label: value }));
        
// // // // //             return (
// // // // //               <MultiSelect
// // // // //                 options={options}
// // // // //                 value={popoverData[popoverField.key]}
// // // // //                 onChange={(selected: Option[]) => handlePopoverChange(popoverField.key, selected)}
// // // // //               />
// // // // //             );
// // // // //           }
// // // // //           return null;
// // // // //         case 'alias':
// // // // //           return (
// // // // //             <input
// // // // //               type="text"
// // // // //               value={popoverData[popoverField.key] as string}
// // // // //               onChange={(e) => handlePopoverChange(popoverField.key, e.target.value)}
// // // // //               placeholder="Enter alias"
// // // // //               className="w-full p-2 border rounded"
// // // // //             />
// // // // //           );
// // // // //         default:
// // // // //           return (
// // // // //             <input
// // // // //               type="text"
// // // // //               value={popoverData[popoverField.key] as string}
// // // // //               onChange={(e) => handlePopoverChange(popoverField.key, e.target.value)}
// // // // //               placeholder={popoverField.placeholder}
// // // // //               className="w-full p-2 border rounded"
// // // // //             />
// // // // //           );
// // // // //       }
// // // // //     };
  
// // // // //     return (
// // // // //       <Tabs defaultValue="SIMPLE" className="w-full">
// // // // //         <TabsList className={`grid w-full ${Object.keys(field.popover || {}).length === 1 ? 'grid-cols-1' : 'grid-cols-2'}`}>
// // // // //           {Object.keys(field.popover || {}).map((tabKey) => (
// // // // //             <TabsTrigger
// // // // //               key={tabKey}
// // // // //               value={tabKey}
// // // // //               className={tabKey === "SIMPLE" ? 'shadow-lg' : ''}
// // // // //             >
// // // // //               {tabKey}
// // // // //             </TabsTrigger>
// // // // //           ))}
// // // // //         </TabsList>

// // // // //         {Object.entries(field.popover || {}).map(([tabKey, tabFields]) => (
// // // // //           <TabsContent key={tabKey} value={tabKey}>
// // // // //             <Card className="border-none shadow-none mt-2">
// // // // //               <CardContent>
// // // // //                 <div className="grid gap-4">
// // // // //                   {tabFields.map((popoverField: any) => (
// // // // //                     <div key={popoverField.key} className="grid gap-2">
// // // // //                       <Label>{popoverField.label}</Label>
// // // // //                       {renderPopoverField(popoverField)}
// // // // //                     </div>
// // // // //                   ))}
                  
// // // // //                 </div>
// // // // //               </CardContent>
// // // // //               <CardFooter className="flex justify-between">
// // // // //                 <Button className="bg-slate-400 hover:bg-slate-600" onClick={onClose}>
// // // // //                   Close
// // // // //                 </Button>
// // // // //                 <Button className="bg-slate-400 hover:bg-slate-600" onClick={handleSave}>
// // // // //                   Save
// // // // //                 </Button>
// // // // //               </CardFooter>
// // // // //             </Card>
// // // // //           </TabsContent>
// // // // //         ))}
// // // // //       </Tabs>
// // // // //     );
// // // // //   };

// // // // //   const SingleDropZone: React.FC<{
// // // // //     onDrop: (item: DroppedItem) => void;
// // // // //     item: DroppedItem | null;
// // // // //     onRemove: () => void;
// // // // //     placeholder: string;
// // // // //     field: FormField;
// // // // //     acceptTypes: string[];
// // // // //   }> = ({ onDrop, item, onRemove, placeholder, field, acceptTypes }) => {
// // // // //     const [{ isOver }, drop] = useDrop(() => ({
// // // // //       accept: acceptTypes,
// // // // //       drop: (droppedItem: DroppedItem) => {
// // // // //         onDrop(droppedItem);
// // // // //         setPopoverSelections(prev => ({
// // // // //           ...prev,
// // // // //           [droppedItem.id]: { ...prev[droppedItem.id], isOpen: true }
// // // // //         }));
// // // // //       },
// // // // //       collect: (monitor) => ({
// // // // //         isOver: !!monitor.isOver(),
// // // // //       }),
// // // // //     }));

// // // // //     return (
// // // // //       <div
// // // // //         ref={drop}
// // // // //         className={`border border-gray-300 rounded-md overflow-hidden text-sm ${
// // // // //           isOver ? "bg-blue-50" : "bg-white"
// // // // //         }`}
// // // // //       >
// // // // //         {!item ? (
// // // // //           <div className="p-1 text-gray-400">{placeholder}</div>
// // // // //         ) : (
// // // // //           <div className="flex items-center p-1  border-gray-200">
// // // // //             <Button
// // // // //               variant="icon"
// // // // //               className="text-gray-500 hover:text-red-500 px-2 px-1"
// // // // //               onClick={onRemove}
// // // // //             >
// // // // //               <IconX stroke={1.5} size={14} />
// // // // //             </Button>
// // // // //             <div className="flex-grow px-2 py-1 bg-white rounded text-gray-800">
// // // // //               {getDisplayText(item, field.key)}
// // // // //             </div>
// // // // //             {field.popover && (
// // // // //               <Popover 
// // // // //                 open={popoverSelections[item.id]?.isOpen} 
// // // // //                 onOpenChange={(open) => setPopoverSelections(prev => ({
// // // // //                   ...prev,
// // // // //                   [item.id]: { ...prev[item.id], isOpen: open }
// // // // //                 }))}
// // // // //               >
// // // // //                 <PopoverTrigger asChild>
// // // // //                   <Button variant="icon" className="px-2 px-1">
// // // // //                     <IconArrowBarToRight stroke={1.5} size={14} />
// // // // //                   </Button>
// // // // //                 </PopoverTrigger>
// // // // //                 <PopoverContent className="w-96 bg-white border border-gray-300">
// // // // //                   <DynamicPopoverContent
// // // // //                     field={field}
// // // // //                     item={item}
// // // // //                     onClose={() => setPopoverSelections(prev => ({
// // // // //                       ...prev,
// // // // //                       [item.id]: { ...prev[item.id], isOpen: false }
// // // // //                     }))}
// // // // //                     onSave={(data) => {
// // // // //                       handlePopoverSave(field.key, item.id, data);
// // // // //                     }}
// // // // //                   />
// // // // //                 </PopoverContent>
// // // // //               </Popover>
// // // // //             )}
// // // // //           </div>
// // // // //         )}
// // // // //       </div>
// // // // //     );
// // // // //   };
// // // // //   const MultipleDropZone: React.FC<{
// // // // //     onDrop: (item: DroppedItem) => void;
// // // // //     items: DroppedItem[];
// // // // //     onRemove: (id: string) => void;
// // // // //     placeholder: string;
// // // // //     field: FormField;
// // // // //     acceptTypes: string[];
// // // // //   }> = ({ onDrop, items, onRemove, placeholder, field, acceptTypes }) => {
// // // // //     const [{ isOver }, drop] = useDrop(() => ({
// // // // //       accept: acceptTypes,
// // // // //       drop: (item: DroppedItem) => {
// // // // //         if (!items.some(existingItem => existingItem.id === item.id)) {
// // // // //           onDrop(item);
// // // // //           setPopoverSelections(prev => ({
// // // // //             ...prev,
// // // // //             [item.id]: { ...prev[item.id], isOpen: true }
// // // // //           }));
// // // // //         }
// // // // //       },
// // // // //       collect: (monitor) => ({
// // // // //         isOver: !!monitor.isOver(),
// // // // //       }),
// // // // //     }));

// // // // //     return (
// // // // //       <div
// // // // //         ref={drop}
// // // // //         className={`border border-gray-300 rounded-md overflow-hidden text-sm ${
// // // // //           isOver ? "bg-blue-50" : "bg-white"
// // // // //         }`}
// // // // //       >
// // // // //         {items.length === 0 ? (
// // // // //           <div className="p-1 text-gray-400">{placeholder}</div>
// // // // //         ) : (
// // // // //           <div>
// // // // //             {items.map((item) => (
// // // // //               <div key={item.id} className="flex items-center p-1 border-b border-gray-200 last:border-b-0">
// // // // //                 <Button
// // // // //                   variant="icon"
// // // // //                   className="text-black-500 hover:text-red-500 px-2 px-1"
// // // // //                   onClick={() => onRemove(item.id)}
// // // // //                 >
// // // // //                   <IconX stroke={1.5} size={14} />
// // // // //                 </Button>
// // // // //                <div className="flex-grow px-2 py-1 bg-white rounded text-gray-800">
// // // // //               {getDisplayText(item, field.key)}
// // // // //             </div>
// // // // //                 {field.popover && (
// // // // //                   <Popover 
// // // // //                     open={popoverSelections[item.id]?.isOpen} 
// // // // //                     onOpenChange={(open) => setPopoverSelections(prev => ({
// // // // //                       ...prev,
// // // // //                       [item.id]: { ...prev[item.id], isOpen: open }
// // // // //                     }))}
// // // // //                   >
// // // // //                     <PopoverTrigger asChild>
// // // // //                       <Button variant="icon" className="px-2 px-1">
// // // // //                         <IconArrowBarToRight stroke={1.5} size={14} />
// // // // //                       </Button>
// // // // //                     </PopoverTrigger>
// // // // //                     <PopoverContent className="w-96">
// // // // //                       <DynamicPopoverContent
// // // // //                         field={field}
// // // // //                         item={item}
// // // // //                         onClose={() => setPopoverSelections(prev => ({
// // // // //                           ...prev,
// // // // //                           [item.id]: { ...prev[item.id], isOpen: false }
// // // // //                         }))}
// // // // //                         onSave={(data) => {
// // // // //                           handlePopoverSave(field.key, item.id, data);
// // // // //                         }}
// // // // //                       />
// // // // //                     </PopoverContent>
// // // // //                   </Popover>
// // // // //                 )}
// // // // //               </div>
// // // // //             ))}
// // // // //           </div>
// // // // //         )}
// // // // //       </div>
// // // // //     );
// // // // //   };

// // // // //   const renderFormField = (field: FormField) => {
// // // // //     switch (field.type) {
// // // // //       case 'select':
// // // // //         return (
// // // // //           <Select value={formData[field.key] || ''} onValueChange={(value) => handleFormChange(field.key, value)}>
// // // // //             <SelectTrigger className="w-full bg-white">
// // // // //               <SelectValue placeholder={field.placeholder || `Select ${field.label}`} />
// // // // //             </SelectTrigger>
// // // // //             <SelectContent>
// // // // //               <SelectGroup>
// // // // //                 <SelectLabel>{field.label}</SelectLabel>
// // // // //                 {field.options?.map((option) => (
// // // // //                   <SelectItem key={option} value={option}>{option}</SelectItem>
// // // // //                 ))}
// // // // //               </SelectGroup>
// // // // //             </SelectContent>
// // // // //           </Select>
// // // // //         );
// // // // //         case 'drag_and_drop_or_select_single':
// // // // //           return (
// // // // //             <SingleDropZone
// // // // //               onDrop={(item) => handleFormChange(field.key === 'metric' ? 'metric' : field.key, item, true)}
// // // // //               item={formData[field.key] || null}
// // // // //               onRemove={() => {
// // // // //                 handleFormChange(field.key, null);
// // // // //                 if (field.key === 'metric') {
// // // // //                   setChartMetric(null);
// // // // //                 }
// // // // //               }}
// // // // //               placeholder={field.placeholder || "Drop item here"}
// // // // //               field={field}
// // // // //               acceptTypes={['METRIC', 'COLUMN']}
// // // // //             />
// // // // //           );
// // // // //       case 'drag_and_drop_or_select_multiple':
// // // // //         return (
// // // // //           <MultipleDropZone
// // // // //             onDrop={(item) => handleFormChange(field.key, [...(formData[field.key] || []), item], true)}
// // // // //             items={formData[field.key] || []}
// // // // //             onRemove={(id) => handleFormChange(field.key, (formData[field.key] || []).filter((item: DroppedItem) => item.id !== id))}
// // // // //             placeholder={field.placeholder || "Drop items here"}
// // // // //             field={field}
// // // // //             acceptTypes={['METRIC', 'COLUMN']}
// // // // //           />
// // // // //         );
// // // // //       case 'checkbox':
// // // // //         return (
// // // // //           <div className="items-top flex space-x-2">
// // // // //             <input
// // // // //               type="checkbox"
// // // // //               id={field.key}
// // // // //               checked={formData[field.key] || false}
// // // // //               onChange={(e) => handleFormChange(field.key, e.target.checked)}
// // // // //               className="form-checkbox h-4 w-5 text-blue-600"
// // // // //             />
// // // // //             <div className="grid gap-1.5 leading-none">
// // // // //               <label
// // // // //                 htmlFor={field.key}
// // // // //                 className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
// // // // //               >
// // // // //               </label>
// // // // //             </div>
// // // // //           </div>
// // // // //         );
// // // // //       default:
// // // // //         return (
// // // // //           <input
// // // // //             type="text"
// // // // //             value={formData[field.key] || ''}
// // // // //             onChange={(e) => handleFormChange(field.key, e.target.value)}
// // // // //             placeholder={field.placeholder}
// // // // //             className="w-full p-2 border rounded"
// // // // //           />
// // // // //         );
// // // // //     }
// // // // //   };
  
// //   // const renderActiveSection = () => {
// //   //   const activeForm = chartForms[activeChartType];
// //   //   if (!activeForm) return null;

// // // // //     return (
// // // // //       <div className="space-y-4">
// // // // //         {activeForm.parameters.map((field: FormField) => (
// // // // //           <div key={field.key}>
// // // // //             <Label>{field.label}</Label>
// // // // //             {field.key === 'x_axis' ? (
// // // // //   <SingleDropZone
// // // // //     onDrop={(item) => handleFormChange('x_axis', item, true)}
// // // // //     item={formData.x_axis || null}
// // // // //     onRemove={() => {
// // // // //       handleFormChange('x_axis', null);
// // // // //       setXAxisData(null);
// // // // //     }}
// // // // //     placeholder="Drop column for X-axis"
// // // // //     field={field}
// // // // //     acceptTypes={['COLUMN']}
// // // // //   />
// // // // // ) : (
// // // // //   renderFormField(field)
// // // // // )}
// // // // //           </div>
// // // // //         ))}
// // // // //       </div>
// // // // //     );
// // // // //   };

// // // // //   const handleCreateChart = async () => {
// // // // //     setIsLoading(true);
// // // // //     setError(null);
  
// // // // //     try {
// // // // //       let chartData;
// // // // //       if (activeTab === "default") {
// // // // //         switch (activeChartType) {
// // // // //           case 'pie':
// // // // //             chartData = await createPieChart(
// // // // //               dataset,
// // // // //               filters,
// // // // //               chartMetric,
// // // // //               {
// // // // //                 dimensions: (formData.dimensions as Dimension[])?.map(dim => ({
// // // // //                   ...dim,
// // // // //                   type: columns.find(col => col.name === dim.name)?.type
// // // // //                 }))
// // // // //               },
// // // // //               defaultRowLimit,
// // // // //               showLegend,
// // // // //               legendOrientation,
// // // // //               legendType
// // // // //             );
// // // // //             break;
// // // // //             case 'donut':
// // // // //             chartData = await createDonutChart(
// // // // //               dataset,
// // // // //               filters,
// // // // //               chartMetric,
// // // // //               {
// // // // //                 dimensions: (formData.dimensions as Dimension[])?.map(dim => ({
// // // // //                   ...dim,
// // // // //                   type: columns.find(col => col.name === dim.name)?.type
// // // // //                 }))
// // // // //               },
// // // // //               defaultRowLimit,
// // // // //               showLegend,
// // // // //               legendOrientation,
// // // // //               legendType
// // // // //             );
// // // // //             break;
// // // // //             case 'bar':
// // // // //           console.log("X-axis data before creating bar chart:", formData.x_axis); // Add this log
// // // // //           chartData = await createBarChartRequest(
// // // // //             dataset,
// // // // //             filters,
// // // // //             chartMetric,
// // // // //             {
// // // // //               dimensions: formData.dimensions,
// // // // //               x_axis: formData['x-axis']  // Use formData.x_axis instead of xAxisData
// // // // //             },
// // // // //             defaultRowLimit,
// // // // //             showLegend,
// // // // //             showDataZoom,
// // // // //             legendOrientation,
// // // // //             legendType
// // // // //           );
// // // // //           break;
// // // // //             case 'custom_bar':
// // // // //               chartData = await createCustomBarChartRequest(
// // // // //                 dataset,
// // // // //                 filters,
// // // // //                 chartMetric,
// // // // //                 {
// // // // //                   dimensions: formData.dimensions
// // // // //                 },
// // // // //                 defaultRowLimit,
// // // // //                 showLegend,
// // // // //                 legendOrientation,
// // // // //                 legendType
// // // // //               );
// // // // //               break;
// // // // //           case 'line':
// // // // //             chartData = await createLineChartRequest(
// // // // //               dataset,
// // // // //               filters,
// // // // //               chartMetric,
// // // // //               {
// // // // //                 dimensions: formData.dimensions
// // // // //               },
// // // // //               defaultRowLimit,
// // // // //               showLegend,
// // // // //               legendOrientation,
// // // // //               legendType
// // // // //             );
// // // // //             break;
// // // // //           case 'area':
// // // // //             chartData = await createAreaChartRequest(
// // // // //               dataset,
// // // // //               filters,
// // // // //               chartMetric,
// // // // //               {
// // // // //                 dimensions: formData.dimensions
// // // // //               },
// // // // //               defaultRowLimit,
// // // // //               showLegend,
// // // // //               legendOrientation,
// // // // //               legendType
// // // // //             );
// // // // //             break;
// // // // //           case 'table':
// // // // //             chartData = await createTableRequest(
// // // // //               dataset,
// // // // //               filters,
// // // // //               chartMetric,
// // // // //               {
// // // // //                 dimensions: formData.dimensions
// // // // //               },
// // // // //               defaultRowLimit,
// // // // //               showLegend,
// // // // //               legendOrientation,
// // // // //               legendType
// // // // //             );
// // // // //             break;
// // // // //           case 'pivot_table':
// // // // //             chartData = await createPivotTableRequest(
// // // // //               dataset,
// // // // //               filters,
// // // // //               chartMetric,
// // // // //               {
// // // // //                 dimensions: formData.dimensions
// // // // //               },
// // // // //               defaultRowLimit,
// // // // //               showLegend,
// // // // //               legendOrientation,
// // // // //               legendType
// // // // //             );
// // // // //             break;
// // // // //             case 'big_number':
// // // // //               chartData = await createBigNumberRequest(
// // // // //                 dataset,
// // // // //                 filters,
// // // // //                 chartMetric,
// // // // //                 {
// // // // //                   metric: formData.metric
// // // // //                 },
// // // // //                 defaultRowLimit
// // // // //               );
// // // // //               break;
// // // // //           default:
// // // // //             throw new Error("Unsupported chart type: " + activeChartType);
// // // // //         }
// // // // //       } else if (activeTab === "ask-ai") {
// // // // //         // The chart creation is handled within the AskAITab component
// // // // //         return;
// // // // //       }
  
// // // // //       console.log("Chart data before sending:", { ...chartData, showDataZoom });
// // // // //       onChartCreated({ ...chartData, showLegend, legendOrientation, legendType, showDataZoom, showLabelLines });
// // // // //     } catch (error) {
// // // // //       console.error("Error creating chart:", error);
// // // // //       setError("Failed to create chart. Please try again.");
// // // // //     } finally {
// // // // //       setIsLoading(false);
// // // // //     }
// // // // //   };

// // // // // const SettingsIcon = () => (
// // // // //   <div className="flex items-center space-x-2">
// // // // //     <TooltipProvider>
// // // // //       <Tooltip>
// // // // //         <TooltipTrigger asChild>
         
// // // // //         </TooltipTrigger>
// // // // //         <TooltipContent>
// // // // //           <p>Customize</p>
// // // // //         </TooltipContent>
// // // // //       </Tooltip>
// // // // //     </TooltipProvider>
// // // // //     <Button variant="ghost" size="icon" onClick={handleEditClick} className="p-2">
// // // // //       <IconPencil size={24} style={{ color: '#682a7a' }} />
// // // // //     </Button>
// // // // //   </div>
// // // // //  );

// // // // // return (
// // // // //   <div className="bg-white flex flex-col h-full w-80 border-r border-gray-200">
// // // // //     <div className="p-2 flex justify-between items-center">
      
// // // // //       <div className="w-80 ">
// // // // //       {/* <AskAITab onChartCreated={setChartData} /> */}

// // // // //         {renderChartDropdown()}
// // // // //       </div>
// // // // //       {/* <SettingsIcon /> */}
// // // // //     </div>
// // // // //     <div className="flex-grow overflow-y-auto bg-white">
// // // // //       <div className="p-2 bg-white">
// // // // //         {renderActiveSection()}
// // // // //       </div>
// // // // //     </div>
// // // // //     <div className="p-2 border-t border-gray-200 bg-white">
// // // // //       {error && <p className="text-red-500 mb-2">{error}</p>}
// // // // //       <Button
// // // // //         className="w-full bg-[#0047AB] text-white hover:bg-[#0047AB]"
// // // // //         onClick={handleCreateChart}
// // // // //         disabled={isLoading}
// // // // //       >
// // // // //         {isLoading ? "CREATING CHART..." : "CREATE CHART"}
// // // // //       </Button>
// // // // //     </div>
// // // // //     <ExpressionEditor
// // // // //       isOpen={isExpressionEditorOpen}
// // // // //       onClose={handleExpressionEditorClose}
// // // // //       onSave={handleExpressionEditorSave}
// // // // //       dataset={dataset}
// // // // //     />
// // // // //   </div>
// // // // // );
// // // // // };

// // // // //  export default ChartTabs;



// // // // import React, { useState, useEffect, ReactNode } from "react";
// // // // import axios from 'axios';
// // // // import { useDrop } from "react-dnd";
// // // // import { IconX, IconArrowBarToRight, IconPencil, IconSettings } from '@tabler/icons-react';
// // // // import { MdBarChart, MdPivotTableChart } from "react-icons/md";
// // // // import { FaChartLine } from "react-icons/fa6";
// // // // import { AiOutlineAreaChart, AiOutlinePieChart } from "react-icons/ai";
// // // // import { LiaTableSolid } from "react-icons/lia";
// // // // import { RiDonutChartFill } from "react-icons/ri";
// // // // import { PiChartBarHorizontalFill } from "react-icons/pi";

// // // // import {
// // // //   Popover,
// // // //   PopoverContent,
// // // //   PopoverTrigger,
// // // // } from "../../../../../@/components/ui/popover";
// // // // import { Button } from "../../../../../@/components/ui/button";
// // // // import { Label } from "../../../../../@/components/ui/label";
// // // // import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from "../../../../../@/components/ui/select";
// // // // import { Card, CardContent, CardFooter } from "../../../../../@/components/ui/card";
// // // // import { createPieChart } from "../ChartRequests/PieChartRequest";
// // // // import { createBarChartRequest } from "../ChartRequests/BarChartRequest";
// // // // import { createBigNumberRequest } from "../ChartRequests/BigNumberChartRequest";
// // // // import { createLineChartRequest } from "../ChartRequests/LineChartRequest";
// // // // import { createAreaChartRequest } from "../ChartRequests/AreaChartRequest";
// // // // import { createTableRequest } from "../ChartRequests/TableRequest";
// // // // import ExpressionEditor from './ExpressionEditor';
// // // // import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "../../../../../@/components/ui/tooltip";
// // // // import MultiSelect from "../../../../../@/components/ui/multi-select";
// // // // import { createPivotTableRequest } from "../ChartRequests/PivotTableRequest";
// // // // import AskAITab from "./AskAITab";
// // // // import QueryTab from "./QueryTab";
// // // // import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../../../../@/components/ui/tabs";
// // // // import { useLocation } from "react-router-dom";
// // // // import { createDonutChart } from "../ChartRequests/DonutChartRequest";
// // // // import { createCustomBarChartRequest } from "../ChartRequests/CustomBarChartRequest";
// // // // import { useSelector } from "react-redux";
// // // // import { RootState } from "../../../../../redux/store";
// // // // interface DroppedItem {
// // // //   id: string;
// // // //   name: string;
// // // //   type: string;
// // // // }
// // // // interface Option {
// // // //   value: string;
// // // //   label: string;
// // // // }

// // // // interface ChartType {
// // // //   unique_id: string;
// // // //   name: string;
// // // //   icon: ReactNode;
// // // //   hasData?: boolean;
// // // // }

// // // // interface FormField {
// // // //   key: string;
// // // //   label: string;
// // // //   type: string;
// // // //   placeholder?: string;
// // // //   options?: string[];
// // // //   popover?: {
// // // //     [key: string]: any[];
// // // //   };
// // // // }

// // // // interface ChartForm {
// // // //   parameters: FormField[];
// // // // }

// // // // interface ChartTabsProps {
// // // //   dataset: string;
// // // //   chartType: string;
// // // //   onChartCreated: (chartOptions: any) => void;
// // // //   onThemeChange: (theme: string) => void;
// // // //   selectedTheme: string;
// // // //   onClearChartPreview: () => void;  // Add this line
// // // // }
// // // // interface Column {
// // // //   name: string;
// // // //   type: string;
// // // // }

// // // // interface Dimension {
// // // //   id: string;
// // // //   name: string;
// // // //   type?: string;
// // // // }
// // // // interface Metric {
// // // //   expression_type: string;
// // // //   column: {
// // // //     column_name: string;
// // // //     type: string;
// // // //   };
// // // //   aggregate: string;
// // // //   label: string;
// // // // }

// // // // interface Filter {
// // // //   id: string;
// // // //   col?: string;
// // // //   op?: string;
// // // //   val?: string[];
// // // //   alias?: string;  // Add this line
// // // // }
// // // // interface FormData {
// // // //   dimensions?: DroppedItem[];
// // // //   metrics?: DroppedItem[];
// // // //   x_axis?: DroppedItem;
// // // //   [key: string]: any;
// // // // }
// // // // const ChartTabs: React.FC<ChartTabsProps> = ({ 
// // // //   dataset, 
// // // //   chartType, 
// // // //   onChartCreated, 
// // // //   onThemeChange,
// // // //   selectedTheme ,
// // // //   onClearChartPreview  // Add this line

// // // // }) => {const [activeChartType, setActiveChartType] = useState<string>("");
// // // //   const [chartTypes, setChartTypes] = useState<ChartType[]>([]);
// // // //   const [chartForms, setChartForms] = useState<{[key: string]: ChartForm}>({});
// // // //   const [columns, setColumns] = useState<Column[]>([]);
// // // //   const [formData, setFormData] = useState<{[key: string]: any}>({});
// // // //     const [popoverSelections, setPopoverSelections] = useState<{[key: string]: any}>({});
// // // //   const [uniqueValues, setUniqueValues] = useState<any>({});
// // // //   const [defaultRowLimit, setDefaultRowLimit] = useState(10);
// // // //   const [chartMetric, setChartMetric] = useState<Metric | null>(null);
// // // //   const [filters, setFilters] = useState<Filter[]>([]);
// // // //   const [chartDataModel, setChartDataModel] = useState<any>(null);
// // // //   const [isLoading, setIsLoading] = useState(false);
// // // //   const [error, setError] = useState<string | null>(null);
// // // //   const [showLegend, setShowLegend] = useState(true);
// // // // const [legendOrientation, setLegendOrientation] = useState("top");
// // // // const [legendType, setLegendType] = useState("scroll");
// // // // const [showDataZoom, setShowDataZoom] = useState(false);
// // // // const [isExpressionEditorOpen, setIsExpressionEditorOpen] = useState(false);
// // // // const [showLabelLines, setShowLabelLines] = useState(false);
// // // // const [activeTab, setActiveTab] = useState<string>("default");
// // // // const [isChartCreated, setIsChartCreated] = useState(false);
// // // // const location = useLocation();
// // // // const { state } = location;
// // // // const [chartData, setChartData] = useState(null);
// // // // const [xAxisData, setXAxisData] = useState<any>(null);

// // // // const chartDetails: any = useSelector((state: RootState) => state.chart);

// // // // const handleEditClick = () => {
// // // //   setIsExpressionEditorOpen(true);
// // // // };

// // // // const handleExpressionEditorClose = () => {
// // // //   setIsExpressionEditorOpen(false);
// // // // };

// // // // const handleExpressionEditorSave = () => {
// // // //   // Handle saving the expressions
// // // //   setIsExpressionEditorOpen(false);
// // // // };

// // // // useEffect(() => {
// // // //   if(chartDetails?.id) {
// // // //     setFilters(chartDetails?.chart?.params?.queries[0].filters);
// // // //   }
// // // //   fetchChartTypes();
// // // //   fetchTableData();
// // // // }, [dataset]);

// // // // useEffect(() => {
// // // //   if (state && state.chart) {
// // // //     setActiveChartType(state.chart);
// // // //   }
// // // // }, [state]);

// // // // const fetchChartTypes = async () => {
// // // //   try {
// // // //     const response = await axios.post('/api/charts/dashboard_charts', {});
// // // //     const allChartTypes = response.data.data.flatMap((section: any) => section.components);

// // // //     const filteredChartTypes = allChartTypes.filter((chart: ChartType) => {
// // // //       if (chart.name.toLowerCase() === 'sunburst chart') {
// // // //         return chart.hasData === true;
// // // //       }
// // // //       return true;
// // // //     });

// // // //     const chartTypesWithIcons = filteredChartTypes.map((chart: ChartType) => ({
// // // //       ...chart,
// // // //       icon: getChartIcon(chart.name)
// // // //     }));

// // // //     setChartTypes(chartTypesWithIcons);
// // // //     if (chartTypesWithIcons.length > 0 && !state?.chart) {
// // // //       setActiveChartType(chartTypesWithIcons[0].unique_id);
// // // //     }
// // // //     fetchChartForms(chartTypesWithIcons);
// // // //   } catch (error) {
// // // //     console.error("Error fetching chart types:", error);
// // // //   }
// // // // };
// // // //   const getChartIcon = (chartName: string) => {
// // // //     switch (chartName.toLowerCase()) {
// // // //       case 'bar chart': return <MdBarChart size={16} />;
// // // //       case 'custom bar chart': return <PiChartBarHorizontalFill size={16} />;
// // // //       case 'line chart': return <FaChartLine size={16} />;
// // // //       case 'area chart': return <AiOutlineAreaChart size={16} />;
// // // //       case 'pie chart': return <AiOutlinePieChart size={16} />;
// // // //       case 'table': return <LiaTableSolid size={16} />;
// // // //       case 'big number': return "4k";
// // // //       case 'donut chart': return <RiDonutChartFill size={16}/>;
// // // //       default: return <MdPivotTableChart size={16} />;
// // // //     }
// // // //   };

// // // //   const fetchChartForms = async (chartTypes: ChartType[]) => {
// // // //     const forms: {[key: string]: ChartForm} = {};
// // // //     for (const chart of chartTypes) {
// // // //       try {
// // // //         const response = await axios.post('/api/charts/get_chart_form', {
// // // //           unique_id: chart.unique_id
// // // //         });
// // // //         forms[chart.unique_id] = response.data.data;
// // // //       } catch (error) {
// // // //         console.error(`Error fetching form for ${chart.unique_id}:`, error);
// // // //       }
// // // //     }
// // // //     setChartForms(forms);
// // // //   };

// // // //   const fetchTableData = async () => {
// // // //     let params = {
// // // //       "database": "zolix_c2o",
// // // //       "schema": "public",
// // // //       "table": dataset
// // // //     }
// // // //     try {
// // // //       const response = await axios.post(
// // // //         '/api/charts/get_columns',
// // // //         params
// // // //       );
// // // //       const columnData: Column[] = response.data.data.map((col: any) => ({
// // // //         name: col.name,
// // // //         type: col.type
// // // //       }));
// // // //       setColumns(columnData);
// // // //       // Fetch unique values for each column
// // // //       columnData.forEach((column: Column) => fetchUniqueValues(column.name));
// // // //     } catch (error) {
// // // //       console.error('Error fetching columns:', error);
// // // //       alert('Failed to fetch columns. Please check the console for more details.');
// // // //     }
// // // //   };

// // // //   const fetchUniqueValues = async (column: string) => {
// // // //     try {
// // // //       const response = await axios.post('/api/charts/get_unique_values', {
// // // //         database: "zolix_c2o",
// // // //         schema: "public",
// // // //         table: dataset,
// // // //         column: [column]
// // // //       });

// // // //       setUniqueValues(prev => ({
// // // //         ...prev,
// // // //         ...response.data.data
// // // //       }));
// // // //     } catch (error) {
// // // //       console.error(`Error fetching unique values for ${column}:`, error);
// // // //     }
// // // //   };
// // // //   const handleChartTypeChange = (type: string) => {
// // // //     setActiveChartType(type);
// // // //     // Reset form data when changing chart type
// // // //     setFormData({});
// // // //     setChartMetric(null);
// // // //     setFilters([]);
// // // //   };
// // // //   const handleFormChange = (key: string, value: any, openPopover = false) => {
// // // //     setFormData(prevData => ({
// // // //       ...prevData,
// // // //       [key]: value
// // // //     }));
  
// // // //     if (key === 'x_axis' && value) {
// // // //       setXAxisData({
// // // //         name: value.name,
// // // //         label: value.name,
// // // //         sort_ascending: true
// // // //       });
// // // //     }
// // // //     if (openPopover && value) {
// // // //       if (!Array.isArray(value)) {
// // // //         setPopoverSelections(prev => ({
// // // //           ...prev,
// // // //           [value.id]: { isOpen: true, column: value.name }
// // // //         }));
// // // //       } else if (Array.isArray(value) && value.length > 0) {
// // // //         const lastItem = value[value.length - 1];
// // // //         setPopoverSelections(prev => ({
// // // //           ...prev,
// // // //           [lastItem.id]: { isOpen: true, column: lastItem.name }
// // // //         }));
// // // //       }
// // // //     }
// // // //   };
// // // //   const handlePopoverSave = (fieldKey: string, itemId: string, data: any) => {
// // // //     let savedData: any = {
// // // //       id: data.id,
// // // //       type: data.type,
// // // //       column: data.column,
// // // //       alias: data.alias
// // // //     };
  
// // // //     let displayText = data.alias || data.column;
  
// // // //     switch (fieldKey) {
// // // //       case 'x_axis':
// // // //         displayText = data.alias || data.column;
// // // //         setXAxisData({
// // // //           name: data.column,
// // // //           label: data.alias || data.column,
// // // //           sort_ascending: true
// // // //         });
// // // //         setFormData(prevData => ({
// // // //           ...prevData,
// // // //           x_axis: {
// // // //             name: data.column,
// // // //             label: data.alias || data.column,
// // // //             sort_ascending: true
// // // //           }
// // // //         }));
// // // //         break;
// // // //       case 'metric':
// // // //         displayText = data.alias || (data.aggregate && data.column 
// // // //           ? `${data.column} (${data.aggregate})`
// // // //           : data.column);
// // // //         // Set chartMetric for the bar chart
// // // //         const columnData = columns.find(col => col.name === data.column);
// // // //         setChartMetric({
// // // //           expression_type: "SIMPLE",
// // // //           column: {
// // // //             column_name: data.column,
// // // //             type: columnData?.type || "UNKNOWN",
// // // //           },
// // // //           aggregate: data.aggregate,
// // // //           label: data.alias || data.column
// // // //         });
// // // //         break;
     
// // // //       case 'dimensions':
// // // //         displayText = data.alias || data.column;
// // // //         // Update dimensions in formData
// // // //         setFormData(prevData => {
// // // //           const updatedDimensions = Array.isArray(prevData.dimensions) 
// // // //             ? prevData.dimensions.map((dim: any) => 
// // // //                 dim.id === itemId 
// // // //                   ? { ...dim, name: data.column, alias: data.alias }
// // // //                   : dim
// // // //               )
// // // //             : [];
// // // //           return { ...prevData, dimensions: updatedDimensions };
// // // //         });
// // // //         break;
// // // //       default:
// // // //         displayText = data.alias || data.column;
// // // //     }
  
// // // //     setPopoverSelections(prev => ({
// // // //       ...prev,
// // // //       [itemId]: { ...savedData, displayText, isOpen: false }
// // // //     }));
  
// // // //     console.log("Saved x-axis data:", formData.x_axis); // Add this log
// // // //   };

// // // //   const saveMetric = (selectedColumn: string, selectedAggregate: string, item: DroppedItem, alias: string) => {
// // // //     if (!selectedColumn || !selectedAggregate || !item) {
// // // //       alert("Please select a column and aggregate function.");
// // // //       return;
// // // //     }
// // // //     const columnData = columns.find(col => col.name === selectedColumn);
// // // //     const newMetric: Metric = {
// // // //       expression_type: "SIMPLE",
// // // //       column: {
// // // //         column_name: selectedColumn,
// // // //         type: columnData ? columnData.type : "UNKNOWN",
// // // //       },
// // // //       aggregate: selectedAggregate,
// // // //       label: alias || selectedColumn
// // // //     };
// // // //     setChartMetric(newMetric);
// // // //   };
// // // //   const handleFilterChange = (id: string, col?: string, op?: string, val?: string[], alias?: string) => {
// // // //     setFilters(prevFilters => {
// // // //       const existingFilterIndex = prevFilters.findIndex(filter => filter.id === id);
// // // //       const columnData = columns.find(column => column.name === col);
// // // //       const newFilter = { 
// // // //         id, 
// // // //         col: col || '', 
// // // //         op: op || '', 
// // // //         val: val || [], 
// // // //         alias: alias || '',
// // // //         type: columnData ? columnData.type : "UNKNOWN"
// // // //       };
// // // //       if (existingFilterIndex !== -1) {
// // // //         // Update existing filter
// // // //         const updatedFilters = [...prevFilters];
// // // //         updatedFilters[existingFilterIndex] = newFilter;
// // // //         return updatedFilters;
// // // //       } else {
// // // //         // Add new filter
// // // //         return [...prevFilters, newFilter];
// // // //       }
// // // //     });
// // // //   };

// // // //   const getDisplayText = (item: DroppedItem, fieldKey: string) => {
// // // //     const selection = popoverSelections[item.id];
// // // //     if (!selection) return item.name || '';

// // // //     return selection.alias || selection.column || item.name;
// // // //   };
// // // //   const renderChartDropdown = () => (
// // // //     <Select value={activeChartType} onValueChange={handleChartTypeChange}>
// // // //       <SelectTrigger className="w-full">
// // // //         <SelectValue placeholder="Select a chart type">
// // // //           {activeChartType && (
// // // //             <div className="flex items-center">
// // // //               {getChartIcon(chartTypes.find(ct => ct.unique_id === activeChartType)?.name || "")}
// // // //               <span className="ml-2">{chartTypes.find(ct => ct.unique_id === activeChartType)?.name}</span>
// // // //             </div>
// // // //           )}
// // // //         </SelectValue>
// // // //       </SelectTrigger>
// // // //       <SelectContent>
// // // //         {chartTypes.map((chartType) => (
// // // //           <SelectItem key={chartType.unique_id} value={chartType.unique_id}>
// // // //             <div className="flex items-center">
// // // //               {chartType.icon}
// // // //               <span className="ml-2">{chartType.name}</span>
// // // //             </div>
// // // //           </SelectItem>
// // // //         ))}
// // // //       </SelectContent>
// // // //     </Select>
// // // //   );
// // // //   const DynamicPopoverContent: React.FC<{ field: FormField; item: DroppedItem; onClose: () => void; onSave: (data: any) => void }> = ({ field, item, onClose, onSave }) => {
// // // //     const storedData = popoverSelections[item.id] || {};
// // // //     const [popoverData, setPopoverData] = useState<{[key: string]: string | any}>({
// // // //       columns: storedData.column || item.name,
// // // //       aggregate: storedData.aggregate || '',
// // // //       operator: storedData.operator || '',
// // // //       value: storedData.value || [],
// // // //       row_limit: defaultRowLimit,
// // // //       alias: storedData.alias || ''
// // // //     });
    
// // // //     const handlePopoverChange = (key: string, value: string | Option[]) => {
// // // //       setPopoverData(prev => ({ ...prev, [key]: value }));
// // // //     };
    
    
// // // //     const handleSave = () => {
// // // //       const baseData = {
// // // //         id: item.id,
// // // //         type: item.type,
// // // //         column: popoverData['columns'],
// // // //         alias: popoverData['alias']
// // // //       };
  
// // // //       switch (field.key) {
// // // //         case 'metrics':
// // // //         case 'metric':
// // // //           onSave({
// // // //             ...baseData,
// // // //             aggregate: popoverData['aggregate']
// // // //           });
// // // //           break;
// // // //         case 'filters':
// // // //           onSave({
// // // //             ...baseData,
// // // //             operator: popoverData['operator'],
// // // //             value: (popoverData['value'] as Option[]).map(option => option.value)
// // // //           });
// // // //           break;
// // // //         default:
// // // //           onSave(baseData);
// // // //       }
// // // //     };
  
  
// // // //     const renderPopoverField = (popoverField: any) => {
// // // //       switch (popoverField.key) {
// // // //         case 'columns':
// // // //         case 'operator':
// // // //         case 'aggregate':
// // // //           return (
// // // //             <Select 
// // // //               value={popoverData[popoverField.key] as string} 
// // // //               onValueChange={(value) => handlePopoverChange(popoverField.key, value)}
// // // //             >
// // // //               <SelectTrigger className="w-full">
// // // //                 <SelectValue placeholder={popoverField.placeholder} />
// // // //               </SelectTrigger>
// // // //               <SelectContent>
// // // //               {popoverField.key === 'columns' 
// // // //   ? columns.map((column: Column) => (
// // // //       <SelectItem key={column.name} value={column.name}>{column.name}</SelectItem>
// // // //     ))
// // // //   : popoverField.options?.filter((option: string) => option !== '').map((option: string) => (
// // // //       <SelectItem key={option} value={option}>{option}</SelectItem>
// // // //     ))
// // // // }
// // // //               </SelectContent>
// // // //             </Select>
// // // //           );
// // // //         case 'value':
// // // //           if (popoverData['columns']) {
// // // //             const options = (Array.isArray(uniqueValues[popoverData['columns'] as string]) 
// // // //               ? uniqueValues[popoverData['columns'] as string].filter((value: string) => value !== '')
// // // //               : []
// // // //             ).map((value: string) => ({ value, label: value }));
        
// // // //             return (
// // // //               <MultiSelect
// // // //                 options={options}
// // // //                 value={popoverData[popoverField.key]}
// // // //                 onChange={(selected: Option[]) => handlePopoverChange(popoverField.key, selected)}
// // // //               />
// // // //             );
// // // //           }
// // // //           return null;
// // // //         case 'alias':
// // // //           return (
// // // //             <input
// // // //               type="text"
// // // //               value={popoverData[popoverField.key] as string}
// // // //               onChange={(e) => handlePopoverChange(popoverField.key, e.target.value)}
// // // //               placeholder="Enter alias"
// // // //               className="w-full p-2 border rounded"
// // // //             />
// // // //           );
// // // //         default:
// // // //           return (
// // // //             <input
// // // //               type="text"
// // // //               value={popoverData[popoverField.key] as string}
// // // //               onChange={(e) => handlePopoverChange(popoverField.key, e.target.value)}
// // // //               placeholder={popoverField.placeholder}
// // // //               className="w-full p-2 border rounded"
// // // //             />
// // // //           );
// // // //       }
// // // //     };
  
// // // //     return (
// // // //       <Tabs defaultValue="SIMPLE" className="w-full">
// // // //         <TabsList className={`grid w-full ${Object.keys(field.popover || {}).length === 1 ? 'grid-cols-1' : 'grid-cols-2'}`}>
// // // //           {Object.keys(field.popover || {}).map((tabKey) => (
// // // //             <TabsTrigger
// // // //               key={tabKey}
// // // //               value={tabKey}
// // // //               className={tabKey === "SIMPLE" ? 'shadow-lg' : ''}
// // // //             >
// // // //               {tabKey}
// // // //             </TabsTrigger>
// // // //           ))}
// // // //         </TabsList>

// // // //         {Object.entries(field.popover || {}).map(([tabKey, tabFields]) => (
// // // //           <TabsContent key={tabKey} value={tabKey}>
// // // //             <Card className="border-none shadow-none mt-2">
// // // //               <CardContent>
// // // //                 <div className="grid gap-4">
// // // //                   {tabFields.map((popoverField: any) => (
// // // //                     <div key={popoverField.key} className="grid gap-2">
// // // //                       <Label>{popoverField.label}</Label>
// // // //                       {renderPopoverField(popoverField)}
// // // //                     </div>
// // // //                   ))}
                  
// // // //                 </div>
// // // //               </CardContent>
// // // //               <CardFooter className="flex justify-between">
// // // //                 <Button className="bg-slate-400 hover:bg-slate-600" onClick={onClose}>
// // // //                   Close
// // // //                 </Button>
// // // //                 <Button className="bg-slate-400 hover:bg-slate-600" onClick={handleSave}>
// // // //                   Save
// // // //                 </Button>
// // // //               </CardFooter>
// // // //             </Card>
// // // //           </TabsContent>
// // // //         ))}
// // // //       </Tabs>
// // // //     );
// // // //   };

// // // //   const SingleDropZone: React.FC<{
// // // //     onDrop: (item: DroppedItem) => void;
// // // //     item: DroppedItem | null;
// // // //     onRemove: () => void;
// // // //     placeholder: string;
// // // //     field: FormField;
// // // //     acceptTypes: string[];
// // // //   }> = ({ onDrop, item, onRemove, placeholder, field, acceptTypes }) => {
// // // //     const [{ isOver }, drop] = useDrop(() => ({
// // // //       accept: acceptTypes,
// // // //       drop: (droppedItem: DroppedItem) => {
// // // //         onDrop(droppedItem);
// // // //         setPopoverSelections(prev => ({
// // // //           ...prev,
// // // //           [droppedItem.id]: { ...prev[droppedItem.id], isOpen: true }
// // // //         }));
// // // //       },
// // // //       collect: (monitor) => ({
// // // //         isOver: !!monitor.isOver(),
// // // //       }),
// // // //     }));

// // // //     return (
// // // //       <div
// // // //         ref={drop}
// // // //         className={`border border-gray-300 rounded-md overflow-hidden text-sm ${
// // // //           isOver ? "bg-blue-50" : "bg-white"
// // // //         }`}
// // // //       >
// // // //         {!item ? (
// // // //           <div className="p-1 text-gray-400">{placeholder}</div>
// // // //         ) : (
// // // //           <div className="flex items-center p-1  border-gray-200">
// // // //             <Button
// // // //               variant="icon"
// // // //               className="text-gray-500 hover:text-red-500 px-2 px-1"
// // // //               onClick={onRemove}
// // // //             >
// // // //               <IconX stroke={1.5} size={14} />
// // // //             </Button>
// // // //             <div className="flex-grow px-2 py-1 bg-white rounded text-gray-800">
// // // //               {getDisplayText(item, field.key)}
// // // //             </div>
// // // //             {field.popover && (
// // // //               <Popover 
// // // //                 open={popoverSelections[item.id]?.isOpen} 
// // // //                 onOpenChange={(open) => setPopoverSelections(prev => ({
// // // //                   ...prev,
// // // //                   [item.id]: { ...prev[item.id], isOpen: open }
// // // //                 }))}
// // // //               >
// // // //                 <PopoverTrigger asChild>
// // // //                   <Button variant="icon" className="px-2 px-1">
// // // //                     <IconArrowBarToRight stroke={1.5} size={14} />
// // // //                   </Button>
// // // //                 </PopoverTrigger>
// // // //                 <PopoverContent className="w-96 bg-white border border-gray-300">
// // // //                   <DynamicPopoverContent
// // // //                     field={field}
// // // //                     item={item}
// // // //                     onClose={() => setPopoverSelections(prev => ({
// // // //                       ...prev,
// // // //                       [item.id]: { ...prev[item.id], isOpen: false }
// // // //                     }))}
// // // //                     onSave={(data) => {
// // // //                       handlePopoverSave(field.key, item.id, data);
// // // //                     }}
// // // //                   />
// // // //                 </PopoverContent>
// // // //               </Popover>
// // // //             )}
// // // //           </div>
// // // //         )}
// // // //       </div>
// // // //     );
// // // //   };
// // // //   const MultipleDropZone: React.FC<{
// // // //     onDrop: (item: DroppedItem) => void;
// // // //     items: DroppedItem[];
// // // //     onRemove: (id: string) => void;
// // // //     placeholder: string;
// // // //     field: FormField;
// // // //     acceptTypes: string[];
// // // //   }> = ({ onDrop, items, onRemove, placeholder, field, acceptTypes }) => {
// // // //     const [{ isOver }, drop] = useDrop(() => ({
// // // //       accept: acceptTypes,
// // // //       drop: (item: DroppedItem) => {
// // // //         if (!items.some(existingItem => existingItem.id === item.id)) {
// // // //           onDrop(item);
// // // //           setPopoverSelections(prev => ({
// // // //             ...prev,
// // // //             [item.id]: { ...prev[item.id], isOpen: true }
// // // //           }));
// // // //         }
// // // //       },
// // // //       collect: (monitor) => ({
// // // //         isOver: !!monitor.isOver(),
// // // //       }),
// // // //     }));

// // // //     return (
// // // //       <div
// // // //         ref={drop}
// // // //         className={`border border-gray-300 rounded-md overflow-hidden text-sm ${
// // // //           isOver ? "bg-blue-50" : "bg-white"
// // // //         }`}
// // // //       >
// // // //         {items.length === 0 ? (
// // // //           <div className="p-1 text-gray-400">{placeholder}</div>
// // // //         ) : (
// // // //           <div>
// // // //             {items.map((item) => (
// // // //               <div key={item.id} className="flex items-center p-1 border-b border-gray-200 last:border-b-0">
// // // //                 <Button
// // // //                   variant="icon"
// // // //                   className="text-black-500 hover:text-red-500 px-2 px-1"
// // // //                   onClick={() => onRemove(item.id)}
// // // //                 >
// // // //                   <IconX stroke={1.5} size={14} />
// // // //                 </Button>
// // // //                <div className="flex-grow px-2 py-1 bg-white rounded text-gray-800">
// // // //               {getDisplayText(item, field.key)}
// // // //             </div>
// // // //                 {field.popover && (
// // // //                   <Popover 
// // // //                     open={popoverSelections[item.id]?.isOpen} 
// // // //                     onOpenChange={(open) => setPopoverSelections(prev => ({
// // // //                       ...prev,
// // // //                       [item.id]: { ...prev[item.id], isOpen: open }
// // // //                     }))}
// // // //                   >
// // // //                     <PopoverTrigger asChild>
// // // //                       <Button variant="icon" className="px-2 px-1">
// // // //                         <IconArrowBarToRight stroke={1.5} size={14} />
// // // //                       </Button>
// // // //                     </PopoverTrigger>
// // // //                     <PopoverContent className="w-96">
// // // //                       <DynamicPopoverContent
// // // //                         field={field}
// // // //                         item={item}
// // // //                         onClose={() => setPopoverSelections(prev => ({
// // // //                           ...prev,
// // // //                           [item.id]: { ...prev[item.id], isOpen: false }
// // // //                         }))}
// // // //                         onSave={(data) => {
// // // //                           handlePopoverSave(field.key, item.id, data);
// // // //                         }}
// // // //                       />
// // // //                     </PopoverContent>
// // // //                   </Popover>
// // // //                 )}
// // // //               </div>
// // // //             ))}
// // // //           </div>
// // // //         )}
// // // //       </div>
// // // //     );
// // // //   };

// // // //   const renderFormField = (field: FormField) => {
// // // //     switch (field.type) {
// // // //       case 'select':
// // // //         return (
// // // //           <Select value={formData[field.key] || ''} onValueChange={(value) => handleFormChange(field.key, value)}>
// // // //             <SelectTrigger className="w-full bg-white">
// // // //               <SelectValue placeholder={field.placeholder || `Select ${field.label}`} />
// // // //             </SelectTrigger>
// // // //             <SelectContent>
// // // //               <SelectGroup>
// // // //                 <SelectLabel>{field.label}</SelectLabel>
// // // //                 {field.options?.map((option) => (
// // // //                   <SelectItem key={option} value={option}>{option}</SelectItem>
// // // //                 ))}
// // // //               </SelectGroup>
// // // //             </SelectContent>
// // // //           </Select>
// // // //         );
// // // //         case 'drag_and_drop_or_select_single':
// // // //           return (
// // // //             <SingleDropZone
// // // //               onDrop={(item) => handleFormChange(field.key === 'metric' ? 'metric' : field.key, item, true)}
// // // //               item={formData[field.key] || null}
// // // //               onRemove={() => {
// // // //                 handleFormChange(field.key, null);
// // // //                 if (field.key === 'metric') {
// // // //                   setChartMetric(null);
// // // //                 }
// // // //               }}
// // // //               placeholder={field.placeholder || "Drop item here"}
// // // //               field={field}
// // // //               acceptTypes={['METRIC', 'COLUMN']}
// // // //             />
// // // //           );
// // // //       case 'drag_and_drop_or_select_multiple':
// // // //         return (
// // // //           <MultipleDropZone
// // // //             onDrop={(item) => handleFormChange(field.key, [...(formData[field.key] || []), item], true)}
// // // //             items={formData[field.key] || []}
// // // //             onRemove={(id) => handleFormChange(field.key, (formData[field.key] || []).filter((item: DroppedItem) => item.id !== id))}
// // // //             placeholder={field.placeholder || "Drop items here"}
// // // //             field={field}
// // // //             acceptTypes={['METRIC', 'COLUMN']}
// // // //           />
// // // //         );
// // // //       case 'checkbox':
// // // //         return (
// // // //           <div className="items-top flex space-x-2">
// // // //             <input
// // // //               type="checkbox"
// // // //               id={field.key}
// // // //               checked={formData[field.key] || false}
// // // //               onChange={(e) => handleFormChange(field.key, e.target.checked)}
// // // //               className="form-checkbox h-4 w-5 text-blue-600"
// // // //             />
// // // //             <div className="grid gap-1.5 leading-none">
// // // //               <label
// // // //                 htmlFor={field.key}
// // // //                 className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
// // // //               >
// // // //               </label>
// // // //             </div>
// // // //           </div>
// // // //         );
// // // //       default:
// // // //         return (
// // // //           <input
// // // //             type="text"
// // // //             value={formData[field.key] || ''}
// // // //             onChange={(e) => handleFormChange(field.key, e.target.value)}
// // // //             placeholder={field.placeholder}
// // // //             className="w-full p-2 border rounded"
// // // //           />
// // // //         );
// // // //     }
// // // //   };
  
// // // //   const renderActiveSection = () => {
// // // //     const activeForm = chartForms[activeChartType];
// // // //     if (!activeForm) return null;

// // // //     return (
// // // //       <div className="space-y-4">
// // // //         {activeForm.parameters.map((field: FormField) => (
// // // //           <div key={field.key}>
// // // //             <Label>{field.label}</Label>
// // // //             {field.key === 'x_axis' ? (
// // // //   <SingleDropZone
// // // //     onDrop={(item) => handleFormChange('x_axis', item, true)}
// // // //     item={formData.x_axis || null}
// // // //     onRemove={() => {
// // // //       handleFormChange('x_axis', null);
// // // //       setXAxisData(null);
// // // //     }}
// // // //     placeholder="Drop column for X-axis"
// // // //     field={field}
// // // //     acceptTypes={['COLUMN']}
// // // //   />
// // // // ) : (
// // // //   renderFormField(field)
// // // // )}
// // // //           </div>
// // // //         ))}
// // // //       </div>
// // // //     );
// // // //   };

// // // //   const handleCreateChart = async () => {
// // // //     setIsLoading(true);
// // // //     setError(null);
  
// // // //     try {
// // // //       let chartData;
// // // //       if (activeTab === "default") {
// // // //         switch (activeChartType) {
// // // //           case 'pie':
// // // //             chartData = await createPieChart(
// // // //               dataset,
// // // //               filters,
// // // //               chartMetric,
// // // //               {
// // // //                 dimensions: (formData.dimensions as Dimension[])?.map(dim => ({
// // // //                   ...dim,
// // // //                   type: columns.find(col => col.name === dim.name)?.type
// // // //                 }))
// // // //               },
// // // //               defaultRowLimit,
// // // //               showLegend,
// // // //               legendOrientation,
// // // //               legendType
// // // //             );
// // // //             break;
// // // //             case 'donut':
// // // //             chartData = await createDonutChart(
// // // //               dataset,
// // // //               filters,
// // // //               chartMetric,
// // // //               {
// // // //                 dimensions: (formData.dimensions as Dimension[])?.map(dim => ({
// // // //                   ...dim,
// // // //                   type: columns.find(col => col.name === dim.name)?.type
// // // //                 }))
// // // //               },
// // // //               defaultRowLimit,
// // // //               showLegend,
// // // //               legendOrientation,
// // // //               legendType
// // // //             );
// // // //             break;
// // // //             case 'bar':
// // // //           console.log("X-axis data before creating bar chart:", formData.x_axis); // Add this log
// // // //           chartData = await createBarChartRequest(
// // // //             dataset,
// // // //             filters,
// // // //             chartMetric,
// // // //             {
// // // //               dimensions: formData.dimensions,
// // // //               x_axis: formData['x-axis']  // Use formData.x_axis instead of xAxisData
// // // //             },
// // // //             defaultRowLimit,
// // // //             showLegend,
// // // //             showDataZoom,
// // // //             legendOrientation,
// // // //             legendType
// // // //           );
// // // //           break;
// // // //             case 'custom_bar':
// // // //               chartData = await createCustomBarChartRequest(
// // // //                 dataset,
// // // //                 filters,
// // // //                 chartMetric,
// // // //                 {
// // // //                   dimensions: formData.dimensions
// // // //                 },
// // // //                 defaultRowLimit,
// // // //                 showLegend,
// // // //                 legendOrientation,
// // // //                 legendType
// // // //               );
// // // //               break;
// // // //           case 'line':
// // // //             chartData = await createLineChartRequest(
// // // //               dataset,
// // // //               filters,
// // // //               chartMetric,
// // // //               {
// // // //                 dimensions: formData.dimensions
// // // //               },
// // // //               defaultRowLimit,
// // // //               showLegend,
// // // //               legendOrientation,
// // // //               legendType
// // // //             );
// // // //             break;
// // // //           case 'area':
// // // //             chartData = await createAreaChartRequest(
// // // //               dataset,
// // // //               filters,
// // // //               chartMetric,
// // // //               {
// // // //                 dimensions: formData.dimensions
// // // //               },
// // // //               defaultRowLimit,
// // // //               showLegend,
// // // //               legendOrientation,
// // // //               legendType
// // // //             );
// // // //             break;
// // // //           case 'table':
// // // //             chartData = await createTableRequest(
// // // //               dataset,
// // // //               filters,
// // // //               chartMetric,
// // // //               {
// // // //                 dimensions: formData.dimensions
// // // //               },
// // // //               defaultRowLimit,
// // // //               showLegend,
// // // //               legendOrientation,
// // // //               legendType
// // // //             );
// // // //             break;
// // // //           case 'pivot_table':
// // // //             chartData = await createPivotTableRequest(
// // // //               dataset,
// // // //               filters,
// // // //               chartMetric,
// // // //               {
// // // //                 dimensions: formData.dimensions
// // // //               },
// // // //               defaultRowLimit,
// // // //               showLegend,
// // // //               legendOrientation,
// // // //               legendType
// // // //             );
// // // //             break;
// // // //             case 'big_number':
// // // //               chartData = await createBigNumberRequest(
// // // //                 dataset,
// // // //                 filters,
// // // //                 chartMetric,
// // // //                 {
// // // //                   metric: formData.metric
// // // //                 },
// // // //                 defaultRowLimit
// // // //               );
// // // //               break;
// // // //           default:
// // // //             throw new Error("Unsupported chart type: " + activeChartType);
// // // //         }
// // // //       } else if (activeTab === "ask-ai") {
// // // //         // The chart creation is handled within the AskAITab component
// // // //         return;
// // // //       }
  
// // // //       console.log("Chart data before sending:", { ...chartData, showDataZoom });
// // // //       onChartCreated({ ...chartData, showLegend, legendOrientation, legendType, showDataZoom, showLabelLines });
// // // //     } catch (error) {
// // // //       console.error("Error creating chart:", error);
// // // //       setError("Failed to create chart. Please try again.");
// // // //     } finally {
// // // //       setIsLoading(false);
// // // //     }
// // // //   };

// // // // const SettingsIcon = () => (
// // // //   <div className="flex items-center space-x-2">
// // // //     <TooltipProvider>
// // // //       <Tooltip>
// // // //         <TooltipTrigger asChild>
         
// // // //         </TooltipTrigger>
// // // //         <TooltipContent>
// // // //           <p>Customize</p>
// // // //         </TooltipContent>
// // // //       </Tooltip>
// // // //     </TooltipProvider>
// // // //     <Button variant="ghost" size="icon" onClick={handleEditClick} className="p-2">
// // // //       <IconPencil size={24} style={{ color: '#682a7a' }} />
// // // //     </Button>
// // // //   </div>
// // // //  );

// // // // return (
// // // //   <div className="bg-white flex flex-col h-full w-80 border-r border-gray-200">
// // // //     <div className="p-2 flex justify-between items-center">
      
// // // //       <div className="w-80 ">
// // // //       {/* <AskAITab onChartCreated={setChartData} /> */}

// // // //         {renderChartDropdown()}
// // // //       </div>
// // // //       {/* <SettingsIcon /> */}
// // // //     </div>
// // // //     <div className="flex-grow overflow-y-auto bg-white">
// // // //       <div className="p-2 bg-white">
// // // //         {renderActiveSection()}
// // // //       </div>
// // // //     </div>
// // // //     <div className="p-2 border-t border-gray-200 bg-white">
// // // //       {error && <p className="text-red-500 mb-2">{error}</p>}
// // // //       <Button
// // // //         className="w-full bg-[#0047AB] text-white hover:bg-[#0047AB]"
// // // //         onClick={handleCreateChart}
// // // //         disabled={isLoading}
// // // //       >
// // // //         {isLoading ? "CREATING CHART..." : "CREATE CHART"}
// // // //       </Button>
// // // //     </div>
// // // //     <ExpressionEditor
// // // //       isOpen={isExpressionEditorOpen}
// // // //       onClose={handleExpressionEditorClose}
// // // //       onSave={handleExpressionEditorSave}
// // // //       dataset={dataset}
// // // //     />
// // // //   </div>
// // // // );
// // // // };

// // // //  export default ChartTabs;


// // // // import React, { useState, useEffect, ReactNode } from "react";
// // // // import axios from 'axios';
// // // // import { useDrop } from "react-dnd";
// // // // import { IconX, IconArrowBarToRight, IconPencil, IconSettings } from '@tabler/icons-react';
// // // // import { MdBarChart, MdPivotTableChart } from "react-icons/md";
// // // // import { FaChartLine } from "react-icons/fa6";
// // // // import { AiOutlineAreaChart, AiOutlinePieChart } from "react-icons/ai";
// // // // import { LiaTableSolid } from "react-icons/lia";
// // // // import { RiDonutChartFill } from "react-icons/ri";
// // // // import { PiChartBarHorizontalFill } from "react-icons/pi";

// // // // import {
// // // //   Popover,
// // // //   PopoverContent,
// // // //   PopoverTrigger,
// // // // } from "../../../../../@/components/ui/popover";
// // // // import { Button } from "../../../../../@/components/ui/button";
// // // // import { Label } from "../../../../../@/components/ui/label";
// // // // import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from "../../../../../@/components/ui/select";
// // // // import { Card, CardContent, CardFooter } from "../../../../../@/components/ui/card";
// // // // import { createPieChart } from "../ChartRequests/PieChartRequest";
// // // // import { createBarChartRequest } from "../ChartRequests/BarChartRequest";
// // // // import { createBigNumberRequest } from "../ChartRequests/BigNumberChartRequest";
// // // // import { createLineChartRequest } from "../ChartRequests/LineChartRequest";
// // // // import { createAreaChartRequest } from "../ChartRequests/AreaChartRequest";
// // // // import { createTableRequest } from "../ChartRequests/TableRequest";
// // // // import ExpressionEditor from './ExpressionEditor';
// // // // import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "../../../../../@/components/ui/tooltip";
// // // // import MultiSelect from "../../../../../@/components/ui/multi-select";
// // // // import { createPivotTableRequest } from "../ChartRequests/PivotTableRequest";
// // // // import AskAITab from "./AskAITab";
// // // // import QueryTab from "./QueryTab";
// // // // import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../../../../@/components/ui/tabs";
// // // // import { useLocation } from "react-router-dom";
// // // // import { createDonutChart } from "../ChartRequests/DonutChartRequest";
// // // // import { createCustomBarChartRequest } from "../ChartRequests/CustomBarChartRequest";
// // // // import { useSelector } from "react-redux";
// // // // import { RootState } from "../../../../../redux/store";
// // // // interface DroppedItem {
// // // //   id: string;
// // // //   name: string;
// // // //   type: string;
// // // // }
// // // // interface Option {
// // // //   value: string;
// // // //   label: string;
// // // // }

// // // // interface ChartType {
// // // //   unique_id: string;
// // // //   name: string;
// // // //   icon: ReactNode;
// // // //   hasData?: boolean;
// // // // }

// // // // interface FormField {
// // // //   key: string;
// // // //   label: string;
// // // //   type: string;
// // // //   placeholder?: string;
// // // //   options?: string[];
// // // //   popover?: {
// // // //     [key: string]: any[];
// // // //   };
// // // // }

// // // // interface ChartForm {
// // // //   parameters: FormField[];
// // // // }

// // // // interface ChartTabsProps {
// // // //   dataset: string;
// // // //   chartType: string;
// // // //   onChartCreated: (chartOptions: any) => void;
// // // //   onThemeChange: (theme: string) => void;
// // // //   selectedTheme: string;
// // // //   onClearChartPreview: () => void;  // Add this line
// // // // }
// // // // interface Column {
// // // //   name: string;
// // // //   type: string;
// // // // }

// // // // interface Dimension {
// // // //   id: string;
// // // //   name: string;
// // // //   type?: string;
// // // // }
// // // // interface Metric {
// // // //   expression_type: string;
// // // //   column: {
// // // //     column_name: string;
// // // //     type: string;
// // // //   };
// // // //   aggregate: string;
// // // //   label: string;
// // // // }

// // // // interface Filter {
// // // //   id: string;
// // // //   col?: string;
// // // //   op?: string;
// // // //   val?: string[];
// // // //   alias?: string;  // Add this line
// // // // }
// // // // interface FormData {
// // // //   dimensions?: DroppedItem[];
// // // //   metrics?: DroppedItem[];
// // // //   x_axis?: DroppedItem;
// // // //   [key: string]: any;
// // // // }
// // // // const ChartTabs: React.FC<ChartTabsProps> = ({ 
// // // //   dataset, 
// // // //   chartType, 
// // // //   onChartCreated, 
// // // //   onThemeChange,
// // // //   selectedTheme ,
// // // //   onClearChartPreview  // Add this line

// // // // }) => {const [activeChartType, setActiveChartType] = useState<string>("");
// // // //   const [chartTypes, setChartTypes] = useState<ChartType[]>([]);
// // // //   const [chartForms, setChartForms] = useState<{[key: string]: ChartForm}>({});
// // // //   const [columns, setColumns] = useState<Column[]>([]);
// // // //   const [formData, setFormData] = useState<{[key: string]: any}>({});
// // // //     const [popoverSelections, setPopoverSelections] = useState<{[key: string]: any}>({});
// // // //   const [uniqueValues, setUniqueValues] = useState<any>({});
// // // //   const [defaultRowLimit, setDefaultRowLimit] = useState(10);
// // // //   const [chartMetric, setChartMetric] = useState<Metric | null>(null);
// // // //   const [filters, setFilters] = useState<Filter[]>([]);
// // // //   const [chartDataModel, setChartDataModel] = useState<any>(null);
// // // //   const [isLoading, setIsLoading] = useState(false);
// // // //   const [error, setError] = useState<string | null>(null);
// // // //   const [showLegend, setShowLegend] = useState(true);
// // // // const [legendOrientation, setLegendOrientation] = useState("top");
// // // // const [legendType, setLegendType] = useState("scroll");
// // // // const [showDataZoom, setShowDataZoom] = useState(false);
// // // // const [isExpressionEditorOpen, setIsExpressionEditorOpen] = useState(false);
// // // // const [showLabelLines, setShowLabelLines] = useState(false);
// // // // const [activeTab, setActiveTab] = useState<string>("default");
// // // // const [isChartCreated, setIsChartCreated] = useState(false);
// // // // const location = useLocation();
// // // // const { state } = location;
// // // // const [chartData, setChartData] = useState(null);
// // // // const [xAxisData, setXAxisData] = useState<any>(null);

// // // // const chartDetails: any = useSelector((state: RootState) => state.chart);

// // // // const handleEditClick = () => {
// // // //   setIsExpressionEditorOpen(true);
// // // // };

// // // // const handleExpressionEditorClose = () => {
// // // //   setIsExpressionEditorOpen(false);
// // // // };

// // // // const handleExpressionEditorSave = () => {
// // // //   // Handle saving the expressions
// // // //   setIsExpressionEditorOpen(false);
// // // // };

// // // // useEffect(() => {
// // // //   if(chartDetails?.id) {
// // // //     setFilters(chartDetails?.chart?.params?.queries[0].filters);
// // // //   }
// // // //   fetchChartTypes();
// // // //   fetchTableData();
// // // // }, [dataset]);

// // // // useEffect(() => {
// // // //   if (state && state.chart) {
// // // //     setActiveChartType(state.chart);
// // // //   }
// // // // }, [state]);

// // // // const fetchChartTypes = async () => {
// // // //   try {
// // // //     const response = await axios.post('/api/charts/dashboard_charts', {});
// // // //     const allChartTypes = response.data.data.flatMap((section: any) => section.components);

// // // //     const filteredChartTypes = allChartTypes.filter((chart: ChartType) => {
// // // //       if (chart.name.toLowerCase() === 'sunburst chart') {
// // // //         return chart.hasData === true;
// // // //       }
// // // //       return true;
// // // //     });

// // // //     const chartTypesWithIcons = filteredChartTypes.map((chart: ChartType) => ({
// // // //       ...chart,
// // // //       icon: getChartIcon(chart.name)
// // // //     }));

// // // //     setChartTypes(chartTypesWithIcons);
// // // //     if (chartTypesWithIcons.length > 0 && !state?.chart) {
// // // //       setActiveChartType(chartTypesWithIcons[0].unique_id);
// // // //     }
// // // //     fetchChartForms(chartTypesWithIcons);
// // // //   } catch (error) {
// // // //     console.error("Error fetching chart types:", error);
// // // //   }
// // // // };
// // // //   const getChartIcon = (chartName: string) => {
// // // //     switch (chartName.toLowerCase()) {
// // // //       case 'bar chart': return <MdBarChart size={16} />;
// // // //       case 'custom bar chart': return <PiChartBarHorizontalFill size={16} />;
// // // //       case 'line chart': return <FaChartLine size={16} />;
// // // //       case 'area chart': return <AiOutlineAreaChart size={16} />;
// // // //       case 'pie chart': return <AiOutlinePieChart size={16} />;
// // // //       case 'table': return <LiaTableSolid size={16} />;
// // // //       case 'big number': return "4k";
// // // //       case 'donut chart': return <RiDonutChartFill size={16}/>;
// // // //       default: return <MdPivotTableChart size={16} />;
// // // //     }
// // // //   };

// // // //   const fetchChartForms = async (chartTypes: ChartType[]) => {
// // // //     const forms: {[key: string]: ChartForm} = {};
// // // //     for (const chart of chartTypes) {
// // // //       try {
// // // //         const response = await axios.post('/api/charts/get_chart_form', {
// // // //           unique_id: chart.unique_id
// // // //         });
// // // //         forms[chart.unique_id] = response.data.data;
// // // //       } catch (error) {
// // // //         console.error(`Error fetching form for ${chart.unique_id}:`, error);
// // // //       }
// // // //     }
// // // //     setChartForms(forms);
// // // //   };

// // // //   const fetchTableData = async () => {
// // // //     let params = {
// // // //       "database": "zolix_c2o",
// // // //       "schema": "public",
// // // //       "table": dataset
// // // //     }
// // // //     try {
// // // //       const response = await axios.post(
// // // //         '/api/charts/get_columns',
// // // //         params
// // // //       );
// // // //       const columnData: Column[] = response.data.data.map((col: any) => ({
// // // //         name: col.name,
// // // //         type: col.type
// // // //       }));
// // // //       setColumns(columnData);
// // // //       // Fetch unique values for each column
// // // //       columnData.forEach((column: Column) => fetchUniqueValues(column.name));
// // // //     } catch (error) {
// // // //       console.error('Error fetching columns:', error);
// // // //       alert('Failed to fetch columns. Please check the console for more details.');
// // // //     }
// // // //   };

// // // //   const fetchUniqueValues = async (column: string) => {
// // // //     try {
// // // //       const response = await axios.post('/api/charts/get_unique_values', {
// // // //         database: "zolix_c2o",
// // // //         schema: "public",
// // // //         table: dataset,
// // // //         column: [column]
// // // //       });

// // // //       setUniqueValues(prev => ({
// // // //         ...prev,
// // // //         ...response.data.data
// // // //       }));
// // // //     } catch (error) {
// // // //       console.error(`Error fetching unique values for ${column}:`, error);
// // // //     }
// // // //   };
// // // //   const handleChartTypeChange = (type: string) => {
// // // //     setActiveChartType(type);
// // // //     // Reset form data when changing chart type
// // // //     setFormData({});
// // // //     setChartMetric(null);
// // // //     setFilters([]);
// // // //   };
// // // //   const handleFormChange = (key: string, value: any, openPopover = false) => {
// // // //     setFormData(prevData => ({
// // // //       ...prevData,
// // // //       [key]: value
// // // //     }));
  
// // // //     if (key === 'x_axis' && value) {
// // // //       setXAxisData({
// // // //         name: value.name,
// // // //         label: value.name,
// // // //         sort_ascending: true
// // // //       });
// // // //     }
// // // //     if (openPopover && value) {
// // // //       if (!Array.isArray(value)) {
// // // //         setPopoverSelections(prev => ({
// // // //           ...prev,
// // // //           [value.id]: { isOpen: true, column: value.name }
// // // //         }));
// // // //       } else if (Array.isArray(value) && value.length > 0) {
// // // //         const lastItem = value[value.length - 1];
// // // //         setPopoverSelections(prev => ({
// // // //           ...prev,
// // // //           [lastItem.id]: { isOpen: true, column: lastItem.name }
// // // //         }));
// // // //       }
// // // //     }
// // // //   };
// // // //   const handlePopoverSave = (fieldKey: string, itemId: string, data: any) => {
// // // //     let savedData: any = {
// // // //       id: data.id,
// // // //       type: data.type,
// // // //       column: data.column,
// // // //       alias: data.alias
// // // //     };
  
// // // //     let displayText = data.alias || data.column;
  
// // // //     switch (fieldKey) {
// // // //       case 'x_axis':
// // // //         displayText = data.alias || data.column;
// // // //         setXAxisData({
// // // //           name: data.column,
// // // //           label: data.alias || data.column,
// // // //           sort_ascending: true
// // // //         });
// // // //         setFormData(prevData => ({
// // // //           ...prevData,
// // // //           x_axis: {
// // // //             name: data.column,
// // // //             label: data.alias || data.column,
// // // //             sort_ascending: true
// // // //           }
// // // //         }));
// // // //         break;
// // // //       case 'metric':
// // // //         displayText = data.alias || (data.aggregate && data.column 
// // // //           ? `${data.column} (${data.aggregate})`
// // // //           : data.column);
// // // //         // Set chartMetric for the bar chart
// // // //         const columnData = columns.find(col => col.name === data.column);
// // // //         setChartMetric({
// // // //           expression_type: "SIMPLE",
// // // //           column: {
// // // //             column_name: data.column,
// // // //             type: columnData?.type || "UNKNOWN",
// // // //           },
// // // //           aggregate: data.aggregate,
// // // //           label: data.alias || data.column
// // // //         });
// // // //         break;
     
// // // //       case 'dimensions':
// // // //         displayText = data.alias || data.column;
// // // //         // Update dimensions in formData
// // // //         setFormData(prevData => {
// // // //           const updatedDimensions = Array.isArray(prevData.dimensions) 
// // // //             ? prevData.dimensions.map((dim: any) => 
// // // //                 dim.id === itemId 
// // // //                   ? { ...dim, name: data.column, alias: data.alias }
// // // //                   : dim
// // // //               )
// // // //             : [];
// // // //           return { ...prevData, dimensions: updatedDimensions };
// // // //         });
// // // //         break;
// // // //       default:
// // // //         displayText = data.alias || data.column;
// // // //     }
  
// // // //     setPopoverSelections(prev => ({
// // // //       ...prev,
// // // //       [itemId]: { ...savedData, displayText, isOpen: false }
// // // //     }));
  
// // // //     console.log("Saved x-axis data:", formData.x_axis); // Add this log
// // // //   };

// // // //   const saveMetric = (selectedColumn: string, selectedAggregate: string, item: DroppedItem, alias: string) => {
// // // //     if (!selectedColumn || !selectedAggregate || !item) {
// // // //       alert("Please select a column and aggregate function.");
// // // //       return;
// // // //     }
// // // //     const columnData = columns.find(col => col.name === selectedColumn);
// // // //     const newMetric: Metric = {
// // // //       expression_type: "SIMPLE",
// // // //       column: {
// // // //         column_name: selectedColumn,
// // // //         type: columnData ? columnData.type : "UNKNOWN",
// // // //       },
// // // //       aggregate: selectedAggregate,
// // // //       label: alias || selectedColumn
// // // //     };
// // // //     setChartMetric(newMetric);
// // // //   };
// // // //   const handleFilterChange = (id: string, col?: string, op?: string, val?: string[], alias?: string) => {
// // // //     setFilters(prevFilters => {
// // // //       const existingFilterIndex = prevFilters.findIndex(filter => filter.id === id);
// // // //       const columnData = columns.find(column => column.name === col);
// // // //       const newFilter = { 
// // // //         id, 
// // // //         col: col || '', 
// // // //         op: op || '', 
// // // //         val: val || [], 
// // // //         alias: alias || '',
// // // //         type: columnData ? columnData.type : "UNKNOWN"
// // // //       };
// // // //       if (existingFilterIndex !== -1) {
// // // //         // Update existing filter
// // // //         const updatedFilters = [...prevFilters];
// // // //         updatedFilters[existingFilterIndex] = newFilter;
// // // //         return updatedFilters;
// // // //       } else {
// // // //         // Add new filter
// // // //         return [...prevFilters, newFilter];
// // // //       }
// // // //     });
// // // //   };

// // // //   const getDisplayText = (item: DroppedItem, fieldKey: string) => {
// // // //     const selection = popoverSelections[item.id];
// // // //     if (!selection) return item.name || '';

// // // //     return selection.alias || selection.column || item.name;
// // // //   };
// // // //   const renderChartDropdown = () => (
// // // //     <Select value={activeChartType} onValueChange={handleChartTypeChange}>
// // // //       <SelectTrigger className="w-full">
// // // //         <SelectValue placeholder="Select a chart type">
// // // //           {activeChartType && (
// // // //             <div className="flex items-center">
// // // //               {getChartIcon(chartTypes.find(ct => ct.unique_id === activeChartType)?.name || "")}
// // // //               <span className="ml-2">{chartTypes.find(ct => ct.unique_id === activeChartType)?.name}</span>
// // // //             </div>
// // // //           )}
// // // //         </SelectValue>
// // // //       </SelectTrigger>
// // // //       <SelectContent>
// // // //         {chartTypes.map((chartType) => (
// // // //           <SelectItem key={chartType.unique_id} value={chartType.unique_id}>
// // // //             <div className="flex items-center">
// // // //               {chartType.icon}
// // // //               <span className="ml-2">{chartType.name}</span>
// // // //             </div>
// // // //           </SelectItem>
// // // //         ))}
// // // //       </SelectContent>
// // // //     </Select>
// // // //   );
// // // //   const DynamicPopoverContent: React.FC<{ field: FormField; item: DroppedItem; onClose: () => void; onSave: (data: any) => void }> = ({ field, item, onClose, onSave }) => {
// // // //     const storedData = popoverSelections[item.id] || {};
// // // //     const [popoverData, setPopoverData] = useState<{[key: string]: string | any}>({
// // // //       columns: storedData.column || item.name,
// // // //       aggregate: storedData.aggregate || '',
// // // //       operator: storedData.operator || '',
// // // //       value: storedData.value || [],
// // // //       row_limit: defaultRowLimit,
// // // //       alias: storedData.alias || ''
// // // //     });
    
// // // //     const handlePopoverChange = (key: string, value: string | Option[]) => {
// // // //       setPopoverData(prev => ({ ...prev, [key]: value }));
// // // //     };
    
    
// // // //     const handleSave = () => {
// // // //       const baseData = {
// // // //         id: item.id,
// // // //         type: item.type,
// // // //         column: popoverData['columns'],
// // // //         alias: popoverData['alias']
// // // //       };
  
// // // //       switch (field.key) {
// // // //         case 'metrics':
// // // //         case 'metric':
// // // //           onSave({
// // // //             ...baseData,
// // // //             aggregate: popoverData['aggregate']
// // // //           });
// // // //           break;
// // // //         case 'filters':
// // // //           onSave({
// // // //             ...baseData,
// // // //             operator: popoverData['operator'],
// // // //             value: (popoverData['value'] as Option[]).map(option => option.value)
// // // //           });
// // // //           break;
// // // //         default:
// // // //           onSave(baseData);
// // // //       }
// // // //     };
  
  
// // // //     const renderPopoverField = (popoverField: any) => {
// // // //       switch (popoverField.key) {
// // // //         case 'columns':
// // // //         case 'operator':
// // // //         case 'aggregate':
// // // //           return (
// // // //             <Select 
// // // //               value={popoverData[popoverField.key] as string} 
// // // //               onValueChange={(value) => handlePopoverChange(popoverField.key, value)}
// // // //             >
// // // //               <SelectTrigger className="w-full">
// // // //                 <SelectValue placeholder={popoverField.placeholder} />
// // // //               </SelectTrigger>
// // // //               <SelectContent>
// // // //               {popoverField.key === 'columns' 
// // // //   ? columns.map((column: Column) => (
// // // //       <SelectItem key={column.name} value={column.name}>{column.name}</SelectItem>
// // // //     ))
// // // //   : popoverField.options?.filter((option: string) => option !== '').map((option: string) => (
// // // //       <SelectItem key={option} value={option}>{option}</SelectItem>
// // // //     ))
// // // // }
// // // //               </SelectContent>
// // // //             </Select>
// // // //           );
// // // //         case 'value':
// // // //           if (popoverData['columns']) {
// // // //             const options = (Array.isArray(uniqueValues[popoverData['columns'] as string]) 
// // // //               ? uniqueValues[popoverData['columns'] as string].filter((value: string) => value !== '')
// // // //               : []
// // // //             ).map((value: string) => ({ value, label: value }));
        
// // // //             return (
// // // //               <MultiSelect
// // // //                 options={options}
// // // //                 value={popoverData[popoverField.key]}
// // // //                 onChange={(selected: Option[]) => handlePopoverChange(popoverField.key, selected)}
// // // //               />
// // // //             );
// // // //           }
// // // //           return null;
// // // //         case 'alias':
// // // //           return (
// // // //             <input
// // // //               type="text"
// // // //               value={popoverData[popoverField.key] as string}
// // // //               onChange={(e) => handlePopoverChange(popoverField.key, e.target.value)}
// // // //               placeholder="Enter alias"
// // // //               className="w-full p-2 border rounded"
// // // //             />
// // // //           );
// // // //         default:
// // // //           return (
// // // //             <input
// // // //               type="text"
// // // //               value={popoverData[popoverField.key] as string}
// // // //               onChange={(e) => handlePopoverChange(popoverField.key, e.target.value)}
// // // //               placeholder={popoverField.placeholder}
// // // //               className="w-full p-2 border rounded"
// // // //             />
// // // //           );
// // // //       }
// // // //     };
  
// // // //     return (
// // // //       <Tabs defaultValue="SIMPLE" className="w-full">
// // // //         <TabsList className={`grid w-full ${Object.keys(field.popover || {}).length === 1 ? 'grid-cols-1' : 'grid-cols-2'}`}>
// // // //           {Object.keys(field.popover || {}).map((tabKey) => (
// // // //             <TabsTrigger
// // // //               key={tabKey}
// // // //               value={tabKey}
// // // //               className={tabKey === "SIMPLE" ? 'shadow-lg' : ''}
// // // //             >
// // // //               {tabKey}
// // // //             </TabsTrigger>
// // // //           ))}
// // // //         </TabsList>

// // // //         {Object.entries(field.popover || {}).map(([tabKey, tabFields]) => (
// // // //           <TabsContent key={tabKey} value={tabKey}>
// // // //             <Card className="border-none shadow-none mt-2">
// // // //               <CardContent>
// // // //                 <div className="grid gap-4">
// // // //                   {tabFields.map((popoverField: any) => (
// // // //                     <div key={popoverField.key} className="grid gap-2">
// // // //                       <Label>{popoverField.label}</Label>
// // // //                       {renderPopoverField(popoverField)}
// // // //                     </div>
// // // //                   ))}
                  
// // // //                 </div>
// // // //               </CardContent>
// // // //               <CardFooter className="flex justify-between">
// // // //                 <Button className="bg-slate-400 hover:bg-slate-600" onClick={onClose}>
// // // //                   Close
// // // //                 </Button>
// // // //                 <Button className="bg-slate-400 hover:bg-slate-600" onClick={handleSave}>
// // // //                   Save
// // // //                 </Button>
// // // //               </CardFooter>
// // // //             </Card>
// // // //           </TabsContent>
// // // //         ))}
// // // //       </Tabs>
// // // //     );
// // // //   };

// // // //   const SingleDropZone: React.FC<{
// // // //     onDrop: (item: DroppedItem) => void;
// // // //     item: DroppedItem | null;
// // // //     onRemove: () => void;
// // // //     placeholder: string;
// // // //     field: FormField;
// // // //     acceptTypes: string[];
// // // //   }> = ({ onDrop, item, onRemove, placeholder, field, acceptTypes }) => {
// // // //     const [{ isOver }, drop] = useDrop(() => ({
// // // //       accept: acceptTypes,
// // // //       drop: (droppedItem: DroppedItem) => {
// // // //         onDrop(droppedItem);
// // // //         setPopoverSelections(prev => ({
// // // //           ...prev,
// // // //           [droppedItem.id]: { ...prev[droppedItem.id], isOpen: true }
// // // //         }));
// // // //       },
// // // //       collect: (monitor) => ({
// // // //         isOver: !!monitor.isOver(),
// // // //       }),
// // // //     }));

// // // //     return (
// // // //       <div
// // // //         ref={drop}
// // // //         className={`border border-gray-300 rounded-md overflow-hidden text-sm ${
// // // //           isOver ? "bg-blue-50" : "bg-white"
// // // //         }`}
// // // //       >
// // // //         {!item ? (
// // // //           <div className="p-1 text-gray-400">{placeholder}</div>
// // // //         ) : (
// // // //           <div className="flex items-center p-1  border-gray-200">
// // // //             <Button
// // // //               variant="icon"
// // // //               className="text-gray-500 hover:text-red-500 px-2 px-1"
// // // //               onClick={onRemove}
// // // //             >
// // // //               <IconX stroke={1.5} size={14} />
// // // //             </Button>
// // // //             <div className="flex-grow px-2 py-1 bg-white rounded text-gray-800">
// // // //               {getDisplayText(item, field.key)}
// // // //             </div>
// // // //             {field.popover && (
// // // //               <Popover 
// // // //                 open={popoverSelections[item.id]?.isOpen} 
// // // //                 onOpenChange={(open) => setPopoverSelections(prev => ({
// // // //                   ...prev,
// // // //                   [item.id]: { ...prev[item.id], isOpen: open }
// // // //                 }))}
// // // //               >
// // // //                 <PopoverTrigger asChild>
// // // //                   <Button variant="icon" className="px-2 px-1">
// // // //                     <IconArrowBarToRight stroke={1.5} size={14} />
// // // //                   </Button>
// // // //                 </PopoverTrigger>
// // // //                 <PopoverContent className="w-96 bg-white border border-gray-300">
// // // //                   <DynamicPopoverContent
// // // //                     field={field}
// // // //                     item={item}
// // // //                     onClose={() => setPopoverSelections(prev => ({
// // // //                       ...prev,
// // // //                       [item.id]: { ...prev[item.id], isOpen: false }
// // // //                     }))}
// // // //                     onSave={(data) => {
// // // //                       handlePopoverSave(field.key, item.id, data);
// // // //                     }}
// // // //                   />
// // // //                 </PopoverContent>
// // // //               </Popover>
// // // //             )}
// // // //           </div>
// // // //         )}
// // // //       </div>
// // // //     );
// // // //   };
// // // //   const MultipleDropZone: React.FC<{
// // // //     onDrop: (item: DroppedItem) => void;
// // // //     items: DroppedItem[];
// // // //     onRemove: (id: string) => void;
// // // //     placeholder: string;
// // // //     field: FormField;
// // // //     acceptTypes: string[];
// // // //   }> = ({ onDrop, items, onRemove, placeholder, field, acceptTypes }) => {
// // // //     const [{ isOver }, drop] = useDrop(() => ({
// // // //       accept: acceptTypes,
// // // //       drop: (item: DroppedItem) => {
// // // //         if (!items.some(existingItem => existingItem.id === item.id)) {
// // // //           onDrop(item);
// // // //           setPopoverSelections(prev => ({
// // // //             ...prev,
// // // //             [item.id]: { ...prev[item.id], isOpen: true }
// // // //           }));
// // // //         }
// // // //       },
// // // //       collect: (monitor) => ({
// // // //         isOver: !!monitor.isOver(),
// // // //       }),
// // // //     }));

// // // //     return (
// // // //       <div
// // // //         ref={drop}
// // // //         className={`border border-gray-300 rounded-md overflow-hidden text-sm ${
// // // //           isOver ? "bg-blue-50" : "bg-white"
// // // //         }`}
// // // //       >
// // // //         {items.length === 0 ? (
// // // //           <div className="p-1 text-gray-400">{placeholder}</div>
// // // //         ) : (
// // // //           <div>
// // // //             {items.map((item) => (
// // // //               <div key={item.id} className="flex items-center p-1 border-b border-gray-200 last:border-b-0">
// // // //                 <Button
// // // //                   variant="icon"
// // // //                   className="text-black-500 hover:text-red-500 px-2 px-1"
// // // //                   onClick={() => onRemove(item.id)}
// // // //                 >
// // // //                   <IconX stroke={1.5} size={14} />
// // // //                 </Button>
// // // //                <div className="flex-grow px-2 py-1 bg-white rounded text-gray-800">
// // // //               {getDisplayText(item, field.key)}
// // // //             </div>
// // // //                 {field.popover && (
// // // //                   <Popover 
// // // //                     open={popoverSelections[item.id]?.isOpen} 
// // // //                     onOpenChange={(open) => setPopoverSelections(prev => ({
// // // //                       ...prev,
// // // //                       [item.id]: { ...prev[item.id], isOpen: open }
// // // //                     }))}
// // // //                   >
// // // //                     <PopoverTrigger asChild>
// // // //                       <Button variant="icon" className="px-2 px-1">
// // // //                         <IconArrowBarToRight stroke={1.5} size={14} />
// // // //                       </Button>
// // // //                     </PopoverTrigger>
// // // //                     <PopoverContent className="w-96">
// // // //                       <DynamicPopoverContent
// // // //                         field={field}
// // // //                         item={item}
// // // //                         onClose={() => setPopoverSelections(prev => ({
// // // //                           ...prev,
// // // //                           [item.id]: { ...prev[item.id], isOpen: false }
// // // //                         }))}
// // // //                         onSave={(data) => {
// // // //                           handlePopoverSave(field.key, item.id, data);
// // // //                         }}
// // // //                       />
// // // //                     </PopoverContent>
// // // //                   </Popover>
// // // //                 )}
// // // //               </div>
// // // //             ))}
// // // //           </div>
// // // //         )}
// // // //       </div>
// // // //     );
// // // //   };

// // // //   const renderFormField = (field: FormField) => {
// // // //     switch (field.type) {
// // // //       case 'select':
// // // //         return (
// // // //           <Select value={formData[field.key] || ''} onValueChange={(value) => handleFormChange(field.key, value)}>
// // // //             <SelectTrigger className="w-full bg-white">
// // // //               <SelectValue placeholder={field.placeholder || `Select ${field.label}`} />
// // // //             </SelectTrigger>
// // // //             <SelectContent>
// // // //               <SelectGroup>
// // // //                 <SelectLabel>{field.label}</SelectLabel>
// // // //                 {field.options?.map((option) => (
// // // //                   <SelectItem key={option} value={option}>{option}</SelectItem>
// // // //                 ))}
// // // //               </SelectGroup>
// // // //             </SelectContent>
// // // //           </Select>
// // // //         );
// // // //         case 'drag_and_drop_or_select_single':
// // // //           return (
// // // //             <SingleDropZone
// // // //               onDrop={(item) => handleFormChange(field.key === 'metric' ? 'metric' : field.key, item, true)}
// // // //               item={formData[field.key] || null}
// // // //               onRemove={() => {
// // // //                 handleFormChange(field.key, null);
// // // //                 if (field.key === 'metric') {
// // // //                   setChartMetric(null);
// // // //                 }
// // // //               }}
// // // //               placeholder={field.placeholder || "Drop item here"}
// // // //               field={field}
// // // //               acceptTypes={['METRIC', 'COLUMN']}
// // // //             />
// // // //           );
// // // //       case 'drag_and_drop_or_select_multiple':
// // // //         return (
// // // //           <MultipleDropZone
// // // //             onDrop={(item) => handleFormChange(field.key, [...(formData[field.key] || []), item], true)}
// // // //             items={formData[field.key] || []}
// // // //             onRemove={(id) => handleFormChange(field.key, (formData[field.key] || []).filter((item: DroppedItem) => item.id !== id))}
// // // //             placeholder={field.placeholder || "Drop items here"}
// // // //             field={field}
// // // //             acceptTypes={['METRIC', 'COLUMN']}
// // // //           />
// // // //         );
// // // //       case 'checkbox':
// // // //         return (
// // // //           <div className="items-top flex space-x-2">
// // // //             <input
// // // //               type="checkbox"
// // // //               id={field.key}
// // // //               checked={formData[field.key] || false}
// // // //               onChange={(e) => handleFormChange(field.key, e.target.checked)}
// // // //               className="form-checkbox h-4 w-5 text-blue-600"
// // // //             />
// // // //             <div className="grid gap-1.5 leading-none">
// // // //               <label
// // // //                 htmlFor={field.key}
// // // //                 className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
// // // //               >
// // // //               </label>
// // // //             </div>
// // // //           </div>
// // // //         );
// // // //       default:
// // // //         return (
// // // //           <input
// // // //             type="text"
// // // //             value={formData[field.key] || ''}
// // // //             onChange={(e) => handleFormChange(field.key, e.target.value)}
// // // //             placeholder={field.placeholder}
// // // //             className="w-full p-2 border rounded"
// // // //           />
// // // //         );
// // // //     }
// // // //   };
  
// // // //   const renderActiveSection = () => {
// // // //     const activeForm = chartForms[activeChartType];
// // // //     if (!activeForm) return null;

// // // //     return (
// // // //       <div className="space-y-4">
// // // //         {activeForm.parameters.map((field: FormField) => (
// // // //           <div key={field.key}>
// // // //             <Label>{field.label}</Label>
// // // //             {field.key === 'x_axis' ? (
// // // //   <SingleDropZone
// // // //     onDrop={(item) => handleFormChange('x_axis', item, true)}
// // // //     item={formData.x_axis || null}
// // // //     onRemove={() => {
// // // //       handleFormChange('x_axis', null);
// // // //       setXAxisData(null);
// // // //     }}
// // // //     placeholder="Drop column for X-axis"
// // // //     field={field}
// // // //     acceptTypes={['COLUMN']}
// // // //   />
// // // // ) : (
// // // //   renderFormField(field)
// // // // )}
// // // //           </div>
// // // //         ))}
// // // //       </div>
// // // //     );
// // // //   };

// // // //   const handleCreateChart = async () => {
// // // //     setIsLoading(true);
// // // //     setError(null);
  
// // // //     try {
// // // //       let chartData;
// // // //       if (activeTab === "default") {
// // // //         switch (activeChartType) {
// // // //           case 'pie':
// // // //             chartData = await createPieChart(
// // // //               dataset,
// // // //               filters,
// // // //               chartMetric,
// // // //               {
// // // //                 dimensions: (formData.dimensions as Dimension[])?.map(dim => ({
// // // //                   ...dim,
// // // //                   type: columns.find(col => col.name === dim.name)?.type
// // // //                 }))
// // // //               },
// // // //               defaultRowLimit,
// // // //               showLegend,
// // // //               legendOrientation,
// // // //               legendType
// // // //             );
// // // //             break;
// // // //             case 'donut':
// // // //             chartData = await createDonutChart(
// // // //               dataset,
// // // //               filters,
// // // //               chartMetric,
// // // //               {
// // // //                 dimensions: (formData.dimensions as Dimension[])?.map(dim => ({
// // // //                   ...dim,
// // // //                   type: columns.find(col => col.name === dim.name)?.type
// // // //                 }))
// // // //               },
// // // //               defaultRowLimit,
// // // //               showLegend,
// // // //               legendOrientation,
// // // //               legendType
// // // //             );
// // // //             break;
// // // //             case 'bar':
// // // //           console.log("X-axis data before creating bar chart:", formData.x_axis); // Add this log
// // // //           chartData = await createBarChartRequest(
// // // //             dataset,
// // // //             filters,
// // // //             chartMetric,
// // // //             {
// // // //               dimensions: formData.dimensions,
// // // //               x_axis: formData['x-axis']  // Use formData.x_axis instead of xAxisData
// // // //             },
// // // //             defaultRowLimit,
// // // //             showLegend,
// // // //             showDataZoom,
// // // //             legendOrientation,
// // // //             legendType
// // // //           );
// // // //           break;
// // // //             case 'custom_bar':
// // // //               chartData = await createCustomBarChartRequest(
// // // //                 dataset,
// // // //                 filters,
// // // //                 chartMetric,
// // // //                 {
// // // //                   dimensions: formData.dimensions
// // // //                 },
// // // //                 defaultRowLimit,
// // // //                 showLegend,
// // // //                 legendOrientation,
// // // //                 legendType
// // // //               );
// // // //               break;
// // // //           case 'line':
// // // //             chartData = await createLineChartRequest(
// // // //               dataset,
// // // //               filters,
// // // //               chartMetric,
// // // //               {
// // // //                 dimensions: formData.dimensions
// // // //               },
// // // //               defaultRowLimit,
// // // //               showLegend,
// // // //               legendOrientation,
// // // //               legendType
// // // //             );
// // // //             break;
// // // //           case 'area':
// // // //             chartData = await createAreaChartRequest(
// // // //               dataset,
// // // //               filters,
// // // //               chartMetric,
// // // //               {
// // // //                 dimensions: formData.dimensions
// // // //               },
// // // //               defaultRowLimit,
// // // //               showLegend,
// // // //               legendOrientation,
// // // //               legendType
// // // //             );
// // // //             break;
// // // //           case 'table':
// // // //             chartData = await createTableRequest(
// // // //               dataset,
// // // //               filters,
// // // //               chartMetric,
// // // //               {
// // // //                 dimensions: formData.dimensions
// // // //               },
// // // //               defaultRowLimit,
// // // //               showLegend,
// // // //               legendOrientation,
// // // //               legendType
// // // //             );
// // // //             break;
// // // //           case 'pivot_table':
// // // //             chartData = await createPivotTableRequest(
// // // //               dataset,
// // // //               filters,
// // // //               chartMetric,
// // // //               {
// // // //                 dimensions: formData.dimensions
// // // //               },
// // // //               defaultRowLimit,
// // // //               showLegend,
// // // //               legendOrientation,
// // // //               legendType
// // // //             );
// // // //             break;
// // // //             case 'big_number':
// // // //               chartData = await createBigNumberRequest(
// // // //                 dataset,
// // // //                 filters,
// // // //                 chartMetric,
// // // //                 {
// // // //                   metric: formData.metric
// // // //                 },
// // // //                 defaultRowLimit
// // // //               );
// // // //               break;
// // // //           default:
// // // //             throw new Error("Unsupported chart type: " + activeChartType);
// // // //         }
// // // //       } else if (activeTab === "ask-ai") {
// // // //         // The chart creation is handled within the AskAITab component
// // // //         return;
// // // //       }
  
// // // //       console.log("Chart data before sending:", { ...chartData, showDataZoom });
// // // //       onChartCreated({ ...chartData, showLegend, legendOrientation, legendType, showDataZoom, showLabelLines });
// // // //     } catch (error) {
// // // //       console.error("Error creating chart:", error);
// // // //       setError("Failed to create chart. Please try again.");
// // // //     } finally {
// // // //       setIsLoading(false);
// // // //     }
// // // //   };

// // // // const SettingsIcon = () => (
// // // //   <div className="flex items-center space-x-2">
// // // //     <TooltipProvider>
// // // //       <Tooltip>
// // // //         <TooltipTrigger asChild>
         
// // // //         </TooltipTrigger>
// // // //         <TooltipContent>
// // // //           <p>Customize</p>
// // // //         </TooltipContent>
// // // //       </Tooltip>
// // // //     </TooltipProvider>
// // // //     <Button variant="ghost" size="icon" onClick={handleEditClick} className="p-2">
// // // //       <IconPencil size={24} style={{ color: '#682a7a' }} />
// // // //     </Button>
// // // //   </div>
// // // //  );

// // // // return (
// // // //   <div className="bg-white flex flex-col h-full w-80 border-r border-gray-200">
// // // //     <div className="p-2 flex justify-between items-center">
      
// // // //       <div className="w-80 ">
// // // //       {/* <AskAITab onChartCreated={setChartData} /> */}

// // // //         {renderChartDropdown()}
// // // //       </div>
// // // //       {/* <SettingsIcon /> */}
// // // //     </div>
// // // //     <div className="flex-grow overflow-y-auto bg-white">
// // // //       <div className="p-2 bg-white">
// // // //         {renderActiveSection()}
// // // //       </div>
// // // //     </div>
// // // //     <div className="p-2 border-t border-gray-200 bg-white">
// // // //       {error && <p className="text-red-500 mb-2">{error}</p>}
// // // //       <Button
// // // //         className="w-full bg-[#0047AB] text-white hover:bg-[#0047AB]"
// // // //         onClick={handleCreateChart}
// // // //         disabled={isLoading}
// // // //       >
// // // //         {isLoading ? "CREATING CHART..." : "CREATE CHART"}
// // // //       </Button>
// // // //     </div>
// // // //     <ExpressionEditor
// // // //       isOpen={isExpressionEditorOpen}
// // // //       onClose={handleExpressionEditorClose}
// // // //       onSave={handleExpressionEditorSave}
// // // //       dataset={dataset}
// // // //     />
// // // //   </div>
// // // // );
// // // // };

// // // //  export default ChartTabs;





// // // // import axios from 'axios';

// // // // interface ChartMetric {
// // // //   expression_type: string;
// // // //   column: {
// // // //     column_name: string;
// // // //     type: string;
// // // //   };
// // // //   aggregate: string;
// // // //   label: string;
// // // // }

// // // // interface Filter {
// // // //   col?: string;
// // // //   op?: string;
// // // //   val?: string[];
// // // // }

// // // // interface XAxisConfig {
// // // //   name: string;
// // // //   label: string;
// // // //   sort_ascending: boolean;
// // // // }

// // // // interface FormData {
// // // //   dimensions?: Array<{ id: string; name: string }>;
// // // //   x_axis?: XAxisConfig;
// // // // }
// // // // export const createBarChartRequest = async (
// // // //   dataset: string,
// // // //   filters: Filter[],
// // // //   chartMetric: ChartMetric | null,
// // // //   formData: FormData,
// // // //   defaultRowLimit: number,
// // // //   showLegend: boolean,
// // // //   showDataZoom: boolean,
// // // //   legendOrientation: string,
// // // //   legendType: string
// // // // ) => {
// // // //   console.log("Received form data in createBarChartRequest:", formData); // Add this log

// // // //   const chartRequest = {
// // // //     "database": "zolix_c2o",
// // // //     "schema": "public",
// // // //     "table": dataset,
// // // //     "visualization_name": "bar",
// // // //     "name": "Bar Chart",
// // // //     "description": "",
// // // //     "params": {
// // // //       "queries": [
// // // //         {
// // // //           "filters": filters.map(filter => ({
// // // //             col: filter.col,
// // // //             op: filter.op,
// // // //             val: filter.val ? filter.val.flat() : []
// // // //           })),
// // // //           "metrics": chartMetric ? [chartMetric] : [],
// // // //           "orderby": chartMetric ? [
// // // //             {
// // // //               "order_by": false,
// // // //               ...chartMetric
// // // //             }
// // // //           ] : [],
// // // //           "row_limit": defaultRowLimit,
// // // //           "series_columns": [],
// // // //           "series_limit": 0,
// // // //           "order_descending": true
// // // //         }
// // // //       ],
// // // //       "form_data": {
// // // //         "x_axis": formData.x_axis ? {
// // // //           name: formData.x_axis.name,
// // // //           label: formData.x_axis.label,
// // // //           sort_ascending: formData.x_axis.sort_ascending
// // // //         } : {},
// // // //         "time_grain": "",
// // // //         "groupby": formData.dimensions?.map(dim => ({
// // // //           name: dim.name,
// // // //           label: dim.name
// // // //         })) || [],
// // // //         "query_mode": "",
// // // //         "show_legend": showLegend,
// // // //         "show_data_zoom": showDataZoom,
// // // //         "legend_orientation": legendOrientation,
// // // //         "legend_type": legendType
// // // //       }
// // // //     },
// // // //     "tags": [
// // // //       {
// // // //         "name": "",
// // // //         "value": ""
// // // //       }
// // // //     ],
// // // //     "group_id": 0,
// // // //     "group_name": "",
// // // //     "type": "Manual",
// // // //     "user_query": "",
// // // //     "user_ai_text": "",
// // // //     "created_by": "",
// // // //     "hashed_value": ""
// // // //   };

// // // //   console.log("API Request Body:", JSON.stringify(chartRequest, null, 2));

// // // //   const response = await axios.post('/api/charts/chart', chartRequest);
// // // //   console.log("API Response Body:", response.data);

// // // //   if (response.data.status === true && response.data.data) {
// // // //     return {
// // // //       chartType: 'bar',
// // // //       chartData: response.data.data,
// // // //       chartRequest: chartRequest,
// // // //       showLegend,
// // // //       showDataZoom,
// // // //       legendOrientation,
// // // //       legendType
// // // //     };
// // // //   } else {
// // // //     throw new Error("Invalid response format");
// // // //   }
// // // // };





// // // // const getDisplayText = (item: any, fieldKey: string) => {
    // if ((fieldKey === 'metrics' || fieldKey === 'metric') && chartMetric) {
    //   return `${chartMetric.column.column_name} (${chartMetric.aggregate})`;
    // }
// // // //     if ((fieldKey === 'dimensions') && formData.dimensions) {
// // // //       return `${item.name}`; // ${formData.dimensions.map((dim) => dim.name).join(', ')} - 
// // // //     }
// // // //     if (fieldKey === 'filters' && 'column' in item) {
// // // //       if (Array.isArray(item.value)) {
// // // //         return `${item.column} ${item.operator} (${item.value.join(', ')})`; // Use join() if val is an array
// // // //       } else {
// // // //         return `${item.column} ${item.operator} (${item.value})`; // Handle non-array values
// // // //       }
// // // //     }
// // // //   }





// // // // import React, { useState, useEffect, ReactNode } from "react";
// // // // import axios from 'axios';
// // // // import { useDrop } from "react-dnd";
// // // // import { IconX, IconArrowBarToRight, IconPencil, IconSettings } from '@tabler/icons-react';
// // // // import {
// // // //   Popover,
// // // //   PopoverContent,
// // // //   PopoverTrigger,
// // // // } from "../../../../../@/components/ui/popover";
// // // // import { Button } from "../../../../../@/components/ui/button";
// // // // import { Label } from "../../../../../@/components/ui/label";
// // // // import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from "../../../../../@/components/ui/select";
// // // // import { Card, CardContent, CardFooter } from "../../../../../@/components/ui/card";
// // // // import { createPieChart } from "../ChartRequests/PieChartRequest";
// // // // import { createBarChartRequest } from "../ChartRequests/BarChartRequest";
// // // // import { createBigNumberRequest } from "../ChartRequests/BigNumberChartRequest";
// // // // import { createLineChartRequest } from "../ChartRequests/LineChartRequest";
// // // // import { createAreaChartRequest } from "../ChartRequests/AreaChartRequest";
// // // // import { createTableRequest } from "../ChartRequests/TableRequest";
// // // // import ExpressionEditor from './ExpressionEditor';
// // // // import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "../../../../../@/components/ui/tooltip";
// // // // import MultiSelect from "../../../../../@/components/ui/multi-select";
// // // // import { createPivotTableRequest } from "../ChartRequests/PivotTableRequest";
// // // // import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../../../../@/components/ui/tabs";
// // // // import { useLocation } from "react-router-dom";
// // // // import { createDonutChart } from "../ChartRequests/DonutChartRequest";
// // // // import { createCustomBarChartRequest } from "../ChartRequests/CustomBarChartRequest";
// // // // import { useSelector } from "react-redux";
// // // // import { RootState } from "../../../../../redux/store";
// // // // // Import all chart images
// // // // import BarChart from "../../../../../assets/viz_thumbnails/bar.png";
// // // // import PieChart from "../../../../../assets/viz_thumbnails/pie.png";
// // // // import LineChart from "../../../../../assets/viz_thumbnails/line.png";
// // // // import AreaChart from "../../../../../assets/viz_thumbnails/area.png";
// // // // import SunburstChart from "../../../../../assets/viz_thumbnails/sunburst.png";
// // // // import BigNumber from "../../../../../assets/viz_thumbnails/big_number.png";
// // // // import CustomTable from "../../../../../assets/viz_thumbnails/table.png";
// // // // import PivotTable from "../../../../../assets/viz_thumbnails/pivot_table.png";
// // // // import DonutChart from "../../../../../assets/viz_thumbnails/donut.png";
// // // // import CustomBarChart from "../../../../../assets/viz_thumbnails/custom_bar.png";


// // // // interface DroppedItem {
// // // //   id: string;
// // // //   name: string;
// // // //   type: string;
// // // // }
// // // // interface Option {
// // // //   value: string;
// // // //   label: string;
// // // // }



// // // // interface ChartType {
// // // //   unique_id: string;
// // // //   name: string;
// // // //   icon: string;  // Changed from ReactNode to string
// // // //   hasData?: boolean;
// // // // }

// // // // interface FormField {
// // // //   key: string;
// // // //   label: string;
// // // //   type: string;
// // // //   placeholder?: string;
// // // //   options?: string[];
// // // //   popover?: {
// // // //     [key: string]: any[];
// // // //   };
// // // // }

// // // // interface ChartForm {
// // // //   parameters: FormField[];
// // // // }

// // // // interface ChartTabsProps {
// // // //   dataset: string;
// // // //   chartType: string;
// // // //   onChartCreated: (chartOptions: any) => void;
// // // //   onThemeChange: (theme: string) => void;
// // // //   selectedTheme: string;
// // // //   onClearChartPreview: () => void;  // Add this line
// // // // }
// // // // interface Column {
// // // //   name: string;
// // // //   type: string;
// // // // }

// // // // interface Dimension {
// // // //   id: string;
// // // //   name: string;
// // // //   type?: string;
// // // // }
// // // // interface Metric {
// // // //   expression_type: string;
// // // //   column: {
// // // //     column_name: string;
// // // //     type: string;
// // // //   };
// // // //   aggregate: string;
// // // //   label: string;
// // // // }

// // // // interface Filter {
// // // //   id: string;
// // // //   col?: string;
// // // //   op?: string;
// // // //   val?: string[];
// // // //   alias?: string;  // Add this line
// // // // }
// // // // interface FormData {
// // // //   dimensions?: DroppedItem[];
// // // //   metrics?: DroppedItem[];
// // // //   x_axis?: DroppedItem;
// // // //   [key: string]: any;
// // // // }
// // // // const ChartTabs: React.FC<ChartTabsProps> = ({ 
// // // //   dataset, 
// // // //   chartType, 
// // // //   onChartCreated, 
// // // //   onThemeChange,
// // // //   selectedTheme ,
// // // //   onClearChartPreview  // Add this line

// // // // }) => {const [activeChartType, setActiveChartType] = useState<string>("");
// // // //   const [chartTypes, setChartTypes] = useState<ChartType[]>([]);
// // // //   const [chartForms, setChartForms] = useState<{[key: string]: ChartForm}>({});
// // // //   const [columns, setColumns] = useState<Column[]>([]);
// // // //   const [formData, setFormData] = useState<{[key: string]: any}>({});
// // // //     const [popoverSelections, setPopoverSelections] = useState<{[key: string]: any}>({});
// // // //   const [uniqueValues, setUniqueValues] = useState<any>({});
// // // //   const [defaultRowLimit, setDefaultRowLimit] = useState(10);
// // // //   const [chartMetric, setChartMetric] = useState<Metric | null>(null);
// // // //   const [filters, setFilters] = useState<Filter[]>([]);
// // // //   const [chartDataModel, setChartDataModel] = useState<any>(null);
// // // //   const [isLoading, setIsLoading] = useState(false);
// // // //   const [error, setError] = useState<string | null>(null);
// // // //   const [showLegend, setShowLegend] = useState(true);
// // // // const [legendOrientation, setLegendOrientation] = useState("top");
// // // // const [legendType, setLegendType] = useState("scroll");
// // // // const [showDataZoom, setShowDataZoom] = useState(false);
// // // // const [isExpressionEditorOpen, setIsExpressionEditorOpen] = useState(false);
// // // // const [showLabelLines, setShowLabelLines] = useState(false);
// // // // const [activeTab, setActiveTab] = useState<string>("default");
// // // // const [isChartCreated, setIsChartCreated] = useState(false);
// // // // const location = useLocation();
// // // // const { state } = location;
// // // // const [chartData, setChartData] = useState(null);
// // // // const [xAxisData, setXAxisData] = useState<any>(null);

// // // // const chartDetails: any = useSelector((state: RootState) => state.chart);

// // // // const handleEditClick = () => {
// // // //   setIsExpressionEditorOpen(true);
// // // // };

// // // // const handleExpressionEditorClose = () => {
// // // //   setIsExpressionEditorOpen(false);
// // // // };

// // // // const handleExpressionEditorSave = () => {
// // // //   // Handle saving the expressions
// // // //   setIsExpressionEditorOpen(false);
// // // // };

// // // // useEffect(() => {
// // // //   if(chartDetails?.id) {
// // // //     setFilters(chartDetails?.chart?.params?.queries[0].filters);
// // // //   }
// // // //   fetchChartTypes();
// // // //   fetchTableData();
// // // // }, [dataset]);

// // // // useEffect(() => {
// // // //   if (state && state.chart) {
// // // //     setActiveChartType(state.chart);
// // // //   }
// // // // }, [state]);
// // // // const fetchChartTypes = async () => {
// // // //   try {
// // // //     const response = await axios.post('/api/charts/dashboard_charts', {});
// // // //     const allChartTypes = response.data.data.flatMap((section: any) => section.components);

// // // //     const filteredChartTypes = allChartTypes.filter((chart: ChartType) => {
// // // //       if (chart.name.toLowerCase() === 'sunburst chart') {
// // // //         return chart.hasData === true;
// // // //       }
// // // //       return true;
// // // //     });

// // // //     const chartTypesWithIcons = filteredChartTypes.map((chart: ChartType) => ({
// // // //       ...chart,
// // // //       icon: getChartIcon(chart.name)
// // // //     }));

// // // //     setChartTypes(chartTypesWithIcons);
// // // //     if (chartTypesWithIcons.length > 0 && !state?.chart) {
// // // //       setActiveChartType(chartTypesWithIcons[0].unique_id);
// // // //     }
// // // //     fetchChartForms(chartTypesWithIcons);
// // // //   } catch (error) {
// // // //     console.error("Error fetching chart types:", error);
// // // //   }
// // // // };

// // // // const getChartIcon = (chartName: string): string => {
// // // //   switch (chartName.toLowerCase()) {
// // // //     case 'bar chart': return BarChart;
// // // //     case 'custom bar chart': return CustomBarChart;
// // // //     case 'line chart': return LineChart;
// // // //     case 'area chart': return AreaChart;
// // // //     case 'pie chart': return PieChart;
// // // //     case 'table': return CustomTable;
// // // //     case 'big number': return BigNumber;
// // // //     case 'donut chart': return DonutChart;
// // // //     case 'sunburst chart': return SunburstChart;
// // // //     case 'pivot table': return PivotTable;
// // // //     default: return CustomTable;  // Default to table icon
// // // //   }
// // // // };

// // // //   const fetchChartForms = async (chartTypes: ChartType[]) => {
// // // //     const forms: {[key: string]: ChartForm} = {};
// // // //     for (const chart of chartTypes) {
// // // //       try {
// // // //         const response = await axios.post('/api/charts/get_chart_form', {
// // // //           unique_id: chart.unique_id
// // // //         });
// // // //         forms[chart.unique_id] = response.data.data;
// // // //       } catch (error) {
// // // //         console.error(`Error fetching form for ${chart.unique_id}:`, error);
// // // //       }
// // // //     }
// // // //     setChartForms(forms);
// // // //   };

// // // //   const fetchTableData = async () => {
// // // //     let params = {
// // // //       "database": "zolix_c2o",
// // // //       "schema": "public",
// // // //       "table": dataset
// // // //     }
// // // //     try {
// // // //       const response = await axios.post(
// // // //         '/api/charts/get_columns',
// // // //         params
// // // //       );
// // // //       const columnData: Column[] = response.data.data.map((col: any) => ({
// // // //         name: col.name,
// // // //         type: col.type
// // // //       }));
// // // //       setColumns(columnData);
// // // //       // Fetch unique values for each column
// // // //       columnData.forEach((column: Column) => fetchUniqueValues(column.name));
// // // //     } catch (error) {
// // // //       console.error('Error fetching columns:', error);
// // // //       alert('Failed to fetch columns. Please check the console for more details.');
// // // //     }
// // // //   };

// // // //   const fetchUniqueValues = async (column: string) => {
// // // //     try {
// // // //       const response = await axios.post('/api/charts/get_unique_values', {
// // // //         database: "zolix_c2o",
// // // //         schema: "public",
// // // //         table: dataset,
// // // //         column: [column]
// // // //       });

// // // //       setUniqueValues(prev => ({
// // // //         ...prev,
// // // //         ...response.data.data
// // // //       }));
// // // //     } catch (error) {
// // // //       console.error(`Error fetching unique values for ${column}:`, error);
// // // //     }
// // // //   };
// // // //   const handleChartTypeChange = (type: string) => {
// // // //     setActiveChartType(type);
// // // //     // Reset form data when changing chart type
// // // //     setFormData({});
// // // //     setChartMetric(null);
// // // //     setFilters([]);
// // // //   };
  
// // // //   const handleFormChange = (key: string, value: any, openPopover = false) => {
// // // //     setFormData(prevData => ({
// // // //       ...prevData,
// // // //       [key]: value
// // // //     }));
  
// // // //     if (key === 'x_axis' && value) {
// // // //       setXAxisData({
// // // //         name: value.name,
// // // //         label: value.name,
// // // //         sort_ascending: true
// // // //       });
// // // //     }
// // // //     if (openPopover && value) {
// // // //       if (!Array.isArray(value)) {
// // // //         setPopoverSelections(prev => ({
// // // //           ...prev,
// // // //           [value.id]: { isOpen: true, column: value.name }
// // // //         }));
// // // //       } else if (Array.isArray(value) && value.length > 0) {
// // // //         const lastItem = value[value.length - 1];
// // // //         setPopoverSelections(prev => ({
// // // //           ...prev,
// // // //           [lastItem.id]: { isOpen: true, column: lastItem.name }
// // // //         }));
// // // //       }
// // // //     }
// // // //   };
// // // //   const handleRemoveItem = (key: string, id?: string) => {
// // // //     setFormData(prevData => {
// // // //       if (Array.isArray(prevData[key])) {
// // // //         return {
// // // //           ...prevData,
// // // //           [key]: prevData[key].filter((item: DroppedItem) => item.id !== id)
// // // //         };
// // // //       } else {
// // // //         const { [key]: _, ...rest } = prevData;
// // // //         return rest;
// // // //       }
// // // //     });

// // // //     if (id) {
// // // //       setPopoverSelections(prev => {
// // // //         const { [id]: _, ...rest } = prev;
// // // //         return rest;
// // // //       });
// // // //     }

// // // //     if (key === 'x_axis') {
// // // //       setXAxisData(null);
// // // //     }
// // // //   };

// // // //   const handlePopoverSave = (fieldKey: string, itemId: string, data: any) => {
// // // //     console.log("Handling popover save:", fieldKey, itemId, data);
    
// // // //     let savedData: any = {
// // // //       id: data.id,
// // // //       type: data.type,
// // // //       column: data.column,
// // // //       alias: data.alias,
// // // //       aggregate: data.aggregate,
// // // //       operator: data.operator,
// // // //       value: data.value
// // // //     };
// // // //     let displayText = data.alias || data.column;
  
// // // //     switch (fieldKey) {
// // // //       case 'x_axis':
// // // //         displayText = data.alias || data.column;
// // // //         setXAxisData({
// // // //           name: data.column,
// // // //           label: data.alias || data.column,
// // // //           sort_ascending: true
// // // //         });
// // // //         setFormData(prevData => ({
// // // //           ...prevData,
// // // //           x_axis: {
// // // //             name: data.column,
// // // //             label: data.alias || data.column,
// // // //             sort_ascending: true
// // // //           }
// // // //         }));
// // // //         break;
// // // //       case 'metric':
// // // //         displayText = data.alias || (data.aggregate && data.column 
// // // //           ? `${data.column} (${data.aggregate})`
// // // //           : data.column);
// // // //         // Set chartMetric for the bar chart
// // // //         const columnData = columns.find(col => col.name === data.column);
// // // //         setChartMetric({
// // // //           expression_type: "SIMPLE",
// // // //           column: {
// // // //             column_name: data.column,
// // // //             type: columnData?.type || "UNKNOWN",
// // // //           },
// // // //           aggregate: data.aggregate,
// // // //           label: data.alias || data.column
// // // //         });
// // // //         break;
// // // //         case 'metrics':
// // // //           displayText = data.alias || (data.aggregate && data.column 
// // // //             ? `${data.column} (${data.aggregate})`
// // // //             : data.column);
// // // //           const columnsData = columns.find(col => col.name === data.column);
// // // //           setChartMetric({
// // // //             expression_type: "SIMPLE",
// // // //             column: {
// // // //               column_name: data.column,
// // // //               type: columnsData?.type || "UNKNOWN",
// // // //             },
// // // //             aggregate: data.aggregate,
// // // //             label: data.alias || data.column
// // // //           });
// // // //           break;
// // // //       case 'dimensions':
// // // //         displayText = data.alias || data.column;
// // // //         // Update dimensions in formData
// // // //         setFormData(prevData => {
// // // //           const updatedDimensions = Array.isArray(prevData.dimensions) 
// // // //             ? prevData.dimensions.map((dim: any) => 
// // // //                 dim.id === itemId 
// // // //                   ? { ...dim, name: data.column, alias: data.alias }
// // // //                   : dim
// // // //               )
// // // //             : [];
// // // //           return { ...prevData, dimensions: updatedDimensions };
// // // //         });
// // // //         break;
// // // //         case 'filters':
// // // //         displayText = `${data.alias || data.column} ${data.operator} (${Array.isArray(data.value) ? data.value.join(', ') : data.value})`;
// // // //         handleFilterChange(itemId, data.column, data.operator, Array.isArray(data.value) ? data.value : [data.value], data.alias);
// // // //         break;
// // // //       default:
// // // //         displayText = data.alias || data.column;
// // // //     }
// // // //     setPopoverSelections(prev => ({
// // // //       ...prev,
// // // //       [itemId]: { ...savedData, isOpen: false }
// // // //     }));
  
// // // //     console.log("Saved x-axis data:", formData.x_axis); // Add this log
// // // //   };

// // // //   const saveMetric = (selectedColumn: string, selectedAggregate: string, item: DroppedItem, alias: string) => {
// // // //     if (!selectedColumn || !selectedAggregate || !item) {
// // // //       alert("Please select a column and aggregate function.");
// // // //       return;
// // // //     }
// // // //     const columnData = columns.find(col => col.name === selectedColumn);
// // // //     const newMetric: Metric = {
// // // //       expression_type: "SIMPLE",
// // // //       column: {
// // // //         column_name: selectedColumn,
// // // //         type: columnData ? columnData.type : "UNKNOWN",
// // // //       },
// // // //       aggregate: selectedAggregate,
// // // //       label: alias || selectedColumn
// // // //     };
// // // //     setChartMetric(newMetric);
// // // //   };
// // // //   const handleFilterChange = (id: string, col?: string, op?: string, val?: string[], alias?: string) => {
// // // //     setFilters(prevFilters => {
// // // //       const existingFilterIndex = prevFilters.findIndex(filter => filter.id === id);
// // // //       const columnData = columns.find(column => column.name === col);
// // // //       const newFilter = { 
// // // //         id, 
// // // //         col: col || '', 
// // // //         op: op || '', 
// // // //         val: val || [], 
// // // //         alias: alias || '',
// // // //         type: columnData ? columnData.type : "UNKNOWN"
// // // //       };
// // // //       if (existingFilterIndex !== -1) {
// // // //         // Update existing filter
// // // //         const updatedFilters = [...prevFilters];
// // // //         updatedFilters[existingFilterIndex] = newFilter;
// // // //         return updatedFilters;
// // // //       } else {
// // // //         // Add new filter
// // // //         return [...prevFilters, newFilter];
// // // //       }
// // // //     });
// // // //   };

// // // //   // const getDisplayText = (item: DroppedItem, fieldKey: string) => {
// // // //   //   const selection = popoverSelections[item.id];
// // // //   //   if (!selection) return item.name || '';

// // // //   //   return selection.alias || selection.column || item.name;
// // // //   // };
 

// // // //   const getDisplayText = (item: any, fieldKey: string) => {
// // // //     if (fieldKey === 'x_axis' && item) {
// // // //       return item.name || item.label || 'X-Axis';
// // // //     }
// // // //     if ((fieldKey === 'metrics' || fieldKey === 'metric') && item) {
// // // //       const selection = popoverSelections[item.id];
// // // //       const aggregate = selection?.aggregate || '';
// // // //       const column = selection?.column || item.name || '';
// // // //       const alias = selection?.alias || '';
// // // //       return alias || (aggregate ? `${column} (${aggregate})` : column);
// // // //     }
// // // //     if ((fieldKey === 'dimensions') && item) {
// // // //       return `${item.name}`;
// // // //     }
// // // //     if (fieldKey === 'filters' && item) {
// // // //       const selection = popoverSelections[item.id];
// // // //       const column = selection?.column || item.name || '';
// // // //       const operator = selection?.operator || '';
// // // //       const value = Array.isArray(selection?.value) 
// // // //         ? selection.value.map((v: Option) => v.value || v).join(', ')
// // // //         : selection?.value || '';
// // // //       return `${column} ${operator} ${value ? `(${value})` : ''}`;
// // // //     }
// // // //     return item.name || '';
// // // //   }

// // // //   const renderChartDropdown = () => (
// // // //     <Select value={activeChartType} onValueChange={handleChartTypeChange}>
// // // //       <SelectTrigger className="w-full">
// // // //         <SelectValue placeholder="Select a chart type">
// // // //           {activeChartType && (
// // // //             <div className="flex items-center">
// // // //               <img 
// // // //                 src={chartTypes.find(ct => ct.unique_id === activeChartType)?.icon} 
// // // //                 alt={chartTypes.find(ct => ct.unique_id === activeChartType)?.name} 
// // // //                 className="w-6 h-6 mr-2"
// // // //               />
// // // //               <span>{chartTypes.find(ct => ct.unique_id === activeChartType)?.name}</span>
// // // //             </div>
// // // //           )}
// // // //         </SelectValue>
// // // //       </SelectTrigger>
// // // //       <SelectContent>
// // // //         {chartTypes.map((chartType) => (
// // // //           <SelectItem key={chartType.unique_id} value={chartType.unique_id}>
// // // //             <div className="flex items-center">
// // // //               <img src={chartType.icon} alt={chartType.name} className="w-6 h-6 mr-2" />
// // // //               <span>{chartType.name}</span>
// // // //             </div>
// // // //           </SelectItem>
// // // //         ))}
// // // //       </SelectContent>
// // // //     </Select>
// // // //   );
// // // //   const DynamicPopoverContent: React.FC<{ field: FormField; item: DroppedItem; onClose: () => void; onSave: (data: any) => void }> = ({ field, item, onClose, onSave }) => {
// // // //     const storedData = popoverSelections[item.id] || {};
// // // //     const [popoverData, setPopoverData] = useState<{[key: string]: string | any}>({
// // // //       columns: storedData.column || item.name,
// // // //       aggregate: storedData.aggregate || '',
// // // //       operator: storedData.operator || '',
// // // //       value: storedData.value || [],
// // // //       row_limit: defaultRowLimit,
// // // //       alias: storedData.alias || ''
// // // //     });
    
// // // //     const handlePopoverChange = (key: string, value: string | Option[]) => {
// // // //       setPopoverData(prev => ({ ...prev, [key]: value }));
// // // //     };
    
// // // //     const handleSave = () => {
// // // //       try {
// // // //         const baseData = {
// // // //           id: item.id,
// // // //           type: item.type,
// // // //           column: popoverData['columns'],
// // // //           alias: popoverData['alias']
// // // //         };
    
// // // //         let saveData;
// // // //         switch (field.key) {
// // // //           case 'metrics':
// // // //           case 'metric':
// // // //             saveData = {
// // // //               ...baseData,
// // // //               aggregate: popoverData['aggregate']
// // // //             };
// // // //             break;
// // // //           case 'filters':
// // // //             saveData = {
// // // //               ...baseData,
// // // //               operator: popoverData['operator'],
// // // //               value: Array.isArray(popoverData['value']) 
// // // //                 ? popoverData['value'].map((option: Option) => option.value) 
// // // //                 : popoverData['value']
// // // //             };
// // // //             break;
// // // //           default:
// // // //             saveData = baseData;
// // // //         }
        
// // // //         console.log("Saving popover data:", saveData);
// // // //         onSave(saveData);
// // // //         onClose(); // Close the popover after successful save
// // // //       } catch (error) {
// // // //         console.error("Error saving popover data:", error);
// // // //         // You might want to show an error message to the user here
// // // //       }
// // // //     };
  
  
// // // //     const renderPopoverField = (popoverField: any) => {
// // // //       switch (popoverField.key) {
// // // //         case "columns":
// // // //         case "operator":
// // // //         case "aggregate":
// // // //           return (
// // // //             <Select
// // // //               value={popoverData[popoverField.key] as string}
// // // //               onValueChange={(value) =>
// // // //                 handlePopoverChange(popoverField.key, value)
// // // //               }
// // // //             >
// // // //               <SelectTrigger className="w-full">
// // // //                 <SelectValue placeholder={popoverField.placeholder} />
// // // //               </SelectTrigger>
// // // //               <SelectContent>
// // // //                 {popoverField.key === "columns"
// // // //                   ? columns.map((column: Column) => (
// // // //                       <SelectItem key={column.name} value={column.name}>
// // // //                         {column.name}
// // // //                       </SelectItem>
// // // //                     ))
// // // //                   : popoverField.options
// // // //                       ?.filter((option: string) => option !== "")
// // // //                       .map((option: string) => (
// // // //                         <SelectItem key={option} value={option}>
// // // //                           {option}
// // // //                         </SelectItem>
// // // //                       ))}
// // // //               </SelectContent>
// // // //             </Select>
// // // //           );
// // // //         case "value":
// // // //           if (popoverData["columns"]) {
// // // //             const options = (
// // // //               Array.isArray(uniqueValues[popoverData["columns"] as string])
// // // //                 ? uniqueValues[popoverData["columns"] as string].filter(
// // // //                     (value: string) => value !== ""
// // // //                   )
// // // //                 : []
// // // //             ).map((value: string) => ({ value, label: value }));

// // // //             return (
// // // //               <MultiSelect
// // // //                 options={options}
// // // //                 value={popoverData[popoverField.key]}
// // // //                 onChange={(selected: Option[]) =>
// // // //                   handlePopoverChange(popoverField.key, selected)
// // // //                 }
// // // //               />
// // // //             );
// // // //           }
// // // //           return null;
// // // //         case "alias":
// // // //           return (
// // // //             <input
// // // //               type="text"
// // // //               value={popoverData[popoverField.key] as string}
// // // //               onChange={(e) =>
// // // //                 handlePopoverChange(popoverField.key, e.target.value)
// // // //               }
// // // //               placeholder="Enter alias"
// // // //               className="w-full p-2 border rounded"
// // // //             />
// // // //           );
// // // //         default:
// // // //           return (
// // // //             <input
// // // //               type="text"
// // // //               value={popoverData[popoverField.key] as string}
// // // //               onChange={(e) =>
// // // //                 handlePopoverChange(popoverField.key, e.target.value)
// // // //               }
// // // //               placeholder={popoverField.placeholder}
// // // //               className="w-full p-2 border rounded"
// // // //             />
// // // //           );
// // // //       }
// // // //     };
  
// // // //     return (
// // // //       <Tabs defaultValue="SIMPLE" className="w-full">
// // // //         <TabsList className={`grid w-full ${Object.keys(field.popover || {}).length === 1 ? 'grid-cols-1' : 'grid-cols-2'}`}>
// // // //           {Object.keys(field.popover || {}).map((tabKey) => (
// // // //             <TabsTrigger
// // // //               key={tabKey}
// // // //               value={tabKey}
// // // //               className={tabKey === "SIMPLE" ? 'shadow-lg' : ''}
// // // //             >
// // // //               {tabKey}
// // // //             </TabsTrigger>
// // // //           ))}
// // // //         </TabsList>

// // // //         {Object.entries(field.popover || {}).map(([tabKey, tabFields]) => (
// // // //           <TabsContent key={tabKey} value={tabKey}>
// // // //             <Card className="border-none shadow-none mt-2">
// // // //               <CardContent>
// // // //                 <div className="grid gap-4">
// // // //                   {tabFields.map((popoverField: any) => (
// // // //                     <div key={popoverField.key} className="grid gap-2">
// // // //                       <Label>{popoverField.label}</Label>
// // // //                       {renderPopoverField(popoverField)}
// // // //                     </div>
// // // //                   ))}
                  
// // // //                 </div>
// // // //               </CardContent>
// // // //               <CardFooter className="flex justify-between">
// // // //                 <Button className="bg-slate-400 hover:bg-slate-600" onClick={onClose}>
// // // //                   Close
// // // //                 </Button>
// // // //                 <Button className="bg-slate-400 hover:bg-slate-600" onClick={handleSave}>
// // // //                   Save
// // // //                 </Button>
// // // //               </CardFooter>
// // // //             </Card>
// // // //           </TabsContent>
// // // //         ))}
// // // //       </Tabs>
// // // //     );
// // // //   };

// // // //   const SingleDropZone: React.FC<{
// // // //     onDrop: (item: DroppedItem) => void;
// // // //     item: DroppedItem | null;
// // // //     onRemove: () => void;
// // // //     placeholder: string;
// // // //     field: FormField;
// // // //     acceptTypes: string[];
// // // //   }> = ({ onDrop, item, onRemove, placeholder, field, acceptTypes }) => {
// // // //     const [{ isOver }, drop] = useDrop(() => ({
// // // //       accept: acceptTypes,
// // // //       drop: (droppedItem: DroppedItem) => {
// // // //         onDrop(droppedItem);
// // // //         setPopoverSelections(prev => ({
// // // //           ...prev,
// // // //           [droppedItem.id]: { ...prev[droppedItem.id], isOpen: true }
// // // //         }));
// // // //       },
// // // //       collect: (monitor) => ({
// // // //         isOver: !!monitor.isOver(),
// // // //       }),
// // // //     }));

// // // //     return (
// // // //       <div ref={drop} className={`border border-gray-300 rounded-md overflow-hidden text-sm ${isOver ? "bg-blue-50" : "bg-white"}`}>
// // // //       {!item ? (
// // // //         <div className="p-1 text-gray-400">{placeholder}</div>
// // // //       ) : (
// // // //         <div className="flex items-center p-1 border-gray-200">
// // // //           <Button
// // // //             variant="icon"
// // // //             className="text-gray-500 hover:text-red-500 px-2 px-1"
// // // //             onClick={() => handleRemoveItem(field.key)}
// // // //           >
// // // //             <IconX stroke={1.5} size={14} />
// // // //           </Button>
// // // //           <div className="flex-grow px-2 py-1 bg-white rounded text-gray-800">
// // // //             {getDisplayText(item, field.key)}
// // // //           </div>
// // // //             {field.popover && (
// // // //               <Popover 
// // // //                 open={popoverSelections[item.id]?.isOpen} 
// // // //                 onOpenChange={(open) => setPopoverSelections(prev => ({
// // // //                   ...prev,
// // // //                   [item.id]: { ...prev[item.id], isOpen: open }
// // // //                 }))}
// // // //               >
// // // //                 <PopoverTrigger asChild>
// // // //                   <Button variant="icon" className="px-2 px-1">
// // // //                     <IconArrowBarToRight stroke={1.5} size={14} />
// // // //                   </Button>
// // // //                 </PopoverTrigger>
// // // //                 <PopoverContent className="w-96 bg-white border border-gray-300">
// // // //                   <DynamicPopoverContent
// // // //                     field={field}
// // // //                     item={item}
// // // //                     onClose={() => setPopoverSelections(prev => ({
// // // //                       ...prev,
// // // //                       [item.id]: { ...prev[item.id], isOpen: false }
// // // //                     }))}
// // // //                     onSave={(data) => {
// // // //                       handlePopoverSave(field.key, item.id, data);
// // // //                     }}
// // // //                   />
// // // //                 </PopoverContent>
// // // //               </Popover>
// // // //             )}
// // // //           </div>
// // // //         )}
// // // //       </div>
// // // //     );
// // // //   };
// // // //   const MultipleDropZone: React.FC<{
// // // //     onDrop: (item: DroppedItem) => void;
// // // //     items: DroppedItem[];
// // // //     onRemove: (id: string) => void;
// // // //     placeholder: string;
// // // //     field: FormField;
// // // //     acceptTypes: string[];
// // // //   }> = ({ onDrop, items, onRemove, placeholder, field, acceptTypes }) => {
// // // //     const [{ isOver }, drop] = useDrop(() => ({
// // // //       accept: acceptTypes,
// // // //       drop: (item: DroppedItem) => {
// // // //         if (!items.some(existingItem => existingItem.id === item.id)) {
// // // //           onDrop(item);
// // // //           setPopoverSelections(prev => ({
// // // //             ...prev,
// // // //             [item.id]: { ...prev[item.id], isOpen: true }
// // // //           }));
// // // //         }
// // // //       },
// // // //       collect: (monitor) => ({
// // // //         isOver: !!monitor.isOver(),
// // // //       }),
// // // //     }));

// // // //     return (
// // // //       <div ref={drop} className={`border border-gray-300 rounded-md overflow-hidden text-sm ${isOver ? "bg-blue-50" : "bg-white"}`}>
// // // //       {items.length === 0 ? (
// // // //         <div className="p-1 text-gray-400">{placeholder}</div>
// // // //       ) : (
// // // //         <div>
// // // //           {items.map((item) => (
// // // //             <div key={item.id} className="flex items-center p-1 border-b border-gray-200 last:border-b-0">
// // // //               <Button
// // // //                 variant="icon"
// // // //                 className="text-black-500 hover:text-red-500 px-2 px-1"
// // // //                 onClick={() => handleRemoveItem(field.key, item.id)}
// // // //               >
// // // //                 <IconX stroke={1.5} size={14} />
// // // //               </Button>
// // // //               <div className="flex-grow px-2 py-1 bg-white rounded text-gray-800">
// // // //                 {getDisplayText(item, field.key)}
// // // //               </div>
// // // //                 {field.popover && (
// // // //                   <Popover 
// // // //                     open={popoverSelections[item.id]?.isOpen} 
// // // //                     onOpenChange={(open) => setPopoverSelections(prev => ({
// // // //                       ...prev,
// // // //                       [item.id]: { ...prev[item.id], isOpen: open }
// // // //                     }))}
// // // //                   >
// // // //                     <PopoverTrigger asChild>
// // // //                       <Button variant="icon" className="px-2 px-1">
// // // //                         <IconArrowBarToRight stroke={1.5} size={14} />
// // // //                       </Button>
// // // //                     </PopoverTrigger>
// // // //                     <PopoverContent className="w-96">
// // // //                       <DynamicPopoverContent
// // // //                         field={field}
// // // //                         item={item}
// // // //                         onClose={() => setPopoverSelections(prev => ({
// // // //                           ...prev,
// // // //                           [item.id]: { ...prev[item.id], isOpen: false }
// // // //                         }))}
// // // //                         onSave={(data) => {
// // // //                           handlePopoverSave(field.key, item.id, data);
// // // //                         }}
// // // //                       />
// // // //                     </PopoverContent>
// // // //                   </Popover>
// // // //                 )}
// // // //               </div>
// // // //             ))}
// // // //           </div>
// // // //         )}
// // // //       </div>
// // // //     );
// // // //   };

// // // //   const renderFormField = (field: FormField) => {
// // // //     switch (field.type) {
// // // //       case 'select':
// // // //         return (
// // // //           <Select value={formData[field.key] || ''} onValueChange={(value) => handleFormChange(field.key, value)}>
// // // //             <SelectTrigger className="w-full bg-white">
// // // //               <SelectValue placeholder={field.placeholder || `Select ${field.label}`} />
// // // //             </SelectTrigger>
// // // //             <SelectContent>
// // // //               <SelectGroup>
// // // //                 <SelectLabel>{field.label}</SelectLabel>
// // // //                 {field.options?.map((option) => (
// // // //                   <SelectItem key={option} value={option}>{option}</SelectItem>
// // // //                 ))}
// // // //               </SelectGroup>
// // // //             </SelectContent>
// // // //           </Select>
// // // //         );
// // // //         case 'drag_and_drop_or_select_single':
// // // //           return (
// // // //             <SingleDropZone
// // // //               onDrop={(item) => handleFormChange(field.key === 'metric' ? 'metric' : field.key, item, true)}
// // // //               item={formData[field.key] || null}
// // // //               onRemove={() => {
// // // //                 handleFormChange(field.key, null);
// // // //                 if (field.key === 'metric') {
// // // //                   setChartMetric(null);
// // // //                 }
// // // //               }}
// // // //               placeholder={field.placeholder || "Drop item here"}
// // // //               field={field}
// // // //               acceptTypes={['METRIC', 'COLUMN']}
// // // //             />
// // // //           );
// // // //       case 'drag_and_drop_or_select_multiple':
// // // //         return (
// // // //           <MultipleDropZone
// // // //             onDrop={(item) => handleFormChange(field.key, [...(formData[field.key] || []), item], true)}
// // // //             items={formData[field.key] || []}
// // // //             onRemove={(id) => handleFormChange(field.key, (formData[field.key] || []).filter((item: DroppedItem) => item.id !== id))}
// // // //             placeholder={field.placeholder || "Drop items here"}
// // // //             field={field}
// // // //             acceptTypes={['METRIC', 'COLUMN']}
// // // //           />
// // // //         );
// // // //       case 'checkbox':
// // // //         return (
// // // //           <div className="items-top flex space-x-2">
// // // //             <input
// // // //               type="checkbox"
// // // //               id={field.key}
// // // //               checked={formData[field.key] || false}
// // // //               onChange={(e) => handleFormChange(field.key, e.target.checked)}
// // // //               className="form-checkbox h-4 w-5 text-blue-600"
// // // //             />
// // // //             <div className="grid gap-1.5 leading-none">
// // // //               <label
// // // //                 htmlFor={field.key}
// // // //                 className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
// // // //               >
// // // //               </label>
// // // //             </div>
// // // //           </div>
// // // //         );
// // // //       default:
// // // //         return (
// // // //           <input
// // // //             type="text"
// // // //             value={formData[field.key] || ''}
// // // //             onChange={(e) => handleFormChange(field.key, e.target.value)}
// // // //             placeholder={field.placeholder}
// // // //             className="w-full p-2 border rounded"
// // // //           />
// // // //         );
// // // //     }
// // // //   };
  
// // // //   const renderActiveSection = () => {
// // // //     const activeForm = chartForms[activeChartType];
// // // //     if (!activeForm) return null;

// // // //     return (
// // // //       <div className="space-y-4">
// // // //         {activeForm.parameters.map((field: FormField) => (
// // // //           <div key={field.key}>
// // // //             <Label>{field.label}</Label>
// // // //             {field.key === "x_axis" ? (
// // // //               <SingleDropZone
// // // //                 onDrop={(item) => handleFormChange("x_axis", item, true)}
// // // //                 item={formData.x_axis || null}
// // // //                 onRemove={() => {
// // // //                   handleFormChange("x_axis", null);
// // // //                   setXAxisData(null);
// // // //                 }}
// // // //                 placeholder="Drop column for X-axis"
// // // //                 field={field}
// // // //                 acceptTypes={["COLUMN"]}
// // // //               />
// // // //             ) : (
// // // //               renderFormField(field)
// // // //             )}
// // // //           </div>
// // // //         ))}
// // // //       </div>
// // // //     );
// // // //   };

// // // //   const handleCreateChart = async () => {
// // // //     setIsLoading(true);
// // // //     setError(null);
  
// // // //     try {
// // // //       let chartData;
// // // //       if (activeTab === "default") {
// // // //         switch (activeChartType) {
// // // //           case 'pie':
// // // //             chartData = await createPieChart(
// // // //               dataset,
// // // //               filters,
// // // //               chartMetric,
// // // //               {
// // // //                 dimensions: (formData.dimensions as Dimension[])?.map(dim => ({
// // // //                   ...dim,
// // // //                   type: columns.find(col => col.name === dim.name)?.type
// // // //                 }))
// // // //               },
// // // //               defaultRowLimit,
// // // //               showLegend,
// // // //               legendOrientation,
// // // //               legendType
// // // //             );
// // // //             break;
// // // //             case 'donut':
// // // //             chartData = await createDonutChart(
// // // //               dataset,
// // // //               filters,
// // // //               chartMetric,
// // // //               {
// // // //                 dimensions: (formData.dimensions as Dimension[])?.map(dim => ({
// // // //                   ...dim,
// // // //                   type: columns.find(col => col.name === dim.name)?.type
// // // //                 }))
// // // //               },
// // // //               defaultRowLimit,
// // // //               showLegend,
// // // //               legendOrientation,
// // // //               legendType
// // // //             );
// // // //             break;
// // // //             case 'bar':
// // // //           console.log("X-axis data before creating bar chart:", formData.x_axis); // Add this log
// // // //           chartData = await createBarChartRequest(
// // // //             dataset,
// // // //             filters,
// // // //             chartMetric,
// // // //             {
// // // //               dimensions: formData.dimensions,
// // // //               x_axis: formData['x-axis']  // Use formData.x_axis instead of xAxisData
// // // //             },
// // // //             defaultRowLimit,
// // // //             showLegend,
// // // //             showDataZoom,
// // // //             legendOrientation,
// // // //             legendType
// // // //           );
// // // //           break;
// // // //             case 'custom_bar':
// // // //          console.log("X-axis data before creating custom bar chart:", formData.x_axis); // Add this log
// // // //           chartData = await createCustomBarChartRequest(
// // // //             dataset,
// // // //             filters,
// // // //             chartMetric,
// // // //             {
// // // //               dimensions: formData.dimensions,
// // // //               x_axis: formData['x-axis']  // Use formData.x_axis instead of xAxisData
// // // //             },
// // // //             defaultRowLimit,
// // // //             showLegend,
// // // //             showDataZoom,
// // // //             legendOrientation,
// // // //             legendType
// // // //               );
// // // //               break;
// // // //           case 'line':
// // // //             chartData = await createLineChartRequest(
// // // //               dataset,
// // // //               filters,
// // // //               chartMetric,
// // // //               {
// // // //                 dimensions: formData.dimensions,
// // // //                 x_axis: formData['x-axis']  // Use formData.x_axis instead of xAxisData
// // // //               },
// // // //               defaultRowLimit,
// // // //               showLegend,
// // // //               showDataZoom,
// // // //               legendOrientation,
// // // //               legendType
// // // //             );
// // // //             break;
// // // //           case 'area':
// // // //             chartData = await createAreaChartRequest(
// // // //               dataset,
// // // //               filters,
// // // //               chartMetric,
// // // //               {
// // // //                 dimensions: formData.dimensions,
// // // //                 x_axis: formData['x-axis']  // Use formData.x_axis instead of xAxisData
// // // //               },
// // // //               defaultRowLimit,
// // // //               showLegend,
// // // //               showDataZoom,
// // // //               legendOrientation,
// // // //               legendType
// // // //             );
// // // //             break;
// // // //           case 'table':
// // // //             chartData = await createTableRequest(
// // // //               dataset,
// // // //               filters,
// // // //               chartMetric,
// // // //               {
// // // //                 dimensions: formData.dimensions
// // // //               },
// // // //               defaultRowLimit,
// // // //               showLegend,
// // // //               legendOrientation,
// // // //               legendType
// // // //             );
// // // //             break;
// // // //           case 'pivot_table':
// // // //             chartData = await createPivotTableRequest(
// // // //               dataset,
// // // //               filters,
// // // //               chartMetric,
// // // //               {
// // // //                 dimensions: formData.dimensions
// // // //               },
// // // //               defaultRowLimit,
// // // //               showLegend,
// // // //               legendOrientation,
// // // //               legendType
// // // //             );
// // // //             break;
// // // //             case 'big_number':
// // // //               chartData = await createBigNumberRequest(
// // // //                 dataset,
// // // //                 filters,
// // // //                 chartMetric,
// // // //                 {
// // // //                   dimensions: formData.dimensions,
// // // //                   x_axis: formData['x-axis']  // Use formData.x_axis instead of xAxisData
// // // //                 },
// // // //                 defaultRowLimit,
// // // //               );
// // // //               break;
// // // //           default:
// // // //             throw new Error("Unsupported chart type: " + activeChartType);
// // // //         }
// // // //       } else if (activeTab === "ask-ai") {
// // // //         // The chart creation is handled within the AskAITab component
// // // //         return;
// // // //       }
  
// // // //       console.log("Chart data before sending:", { ...chartData, showDataZoom });
// // // //       onChartCreated({ ...chartData, showLegend, legendOrientation, legendType, showDataZoom, showLabelLines });
// // // //     } catch (error) {
// // // //       console.error("Error creating chart:", error);
// // // //       setError("Failed to create chart. Please try again.");
// // // //     } finally {
// // // //       setIsLoading(false);
// // // //     }
// // // //   };

// // // // const SettingsIcon = () => (
// // // //   <div className="flex items-center space-x-2">
// // // //     <TooltipProvider>
// // // //       <Tooltip>
// // // //         <TooltipTrigger asChild>
         
// // // //         </TooltipTrigger>
// // // //         <TooltipContent>
// // // //           <p>Customize</p>
// // // //         </TooltipContent>
// // // //       </Tooltip>
// // // //     </TooltipProvider>
// // // //     <Button variant="ghost" size="icon" onClick={handleEditClick} className="p-2">
// // // //       <IconPencil size={24} style={{ color: '#682a7a' }} />
// // // //     </Button>
// // // //   </div>
// // // //  );

// // // // return (
// // // //   <div className="bg-white flex flex-col h-full w-80 border-r border-gray-200">
// // // //     <div className="p-2 flex justify-between items-center">
      
// // // //       <div className="w-80 ">
// // // //       {/* <AskAITab onChartCreated={setChartData} /> */}

// // // //         {renderChartDropdown()}
// // // //       </div>
// // // //       {/* <SettingsIcon /> */}
// // // //     </div>
// // // //     <div className="flex-grow overflow-y-auto bg-white">
// // // //       <div className="p-2 bg-white">
// // // //         {renderActiveSection()}
// // // //       </div>
// // // //     </div>
// // // //     <div className="p-2 border-t border-gray-200 bg-white">
// // // //       {error && <p className="text-red-500 mb-2">{error}</p>}
// // // //       <Button
// // // //         className="w-full bg-[#0047AB] text-white hover:bg-[#0047AB]"
// // // //         onClick={handleCreateChart}
// // // //         disabled={isLoading}
// // // //       >
// // // //         {isLoading ? "CREATING CHART..." : "CREATE CHART"}
// // // //       </Button>
// // // //     </div>
// // // //     <ExpressionEditor
// // // //       isOpen={isExpressionEditorOpen}
// // // //       onClose={handleExpressionEditorClose}
// // // //       onSave={handleExpressionEditorSave}
// // // //       dataset={dataset}
// // // //     />
// // // //   </div>
// // // // );
// // // // };

// // // //  export default ChartTabs;















// // // import React, { useState, useEffect, ReactNode } from "react";
// // // import axios from "axios";
// // // import { useDrop } from "react-dnd";
// // // import {
// // //   IconX,
// // //   IconArrowBarToRight,
// // //   IconPencil,
// // //   IconSettings,
// // // } from "@tabler/icons-react";
// // // import {
// // //   Popover,
// // //   PopoverContent,
// // //   PopoverTrigger,
// // // } from "../../../../../@/components/ui/popover";
// // // import { Button } from "../../../../../@/components/ui/button";
// // // import { Label } from "../../../../../@/components/ui/label";
// // // import {
// // //   Select,
// // //   SelectContent,
// // //   SelectGroup,
// // //   SelectItem,
// // //   SelectLabel,
// // //   SelectTrigger,
// // //   SelectValue,
// // // } from "../../../../../@/components/ui/select";
// // // import {
// // //   Card,
// // //   CardContent,
// // //   CardFooter,
// // // } from "../../../../../@/components/ui/card";
// // // import { createPieChart } from "../ChartRequests/PieChartRequest";
// // // import { createBarChartRequest } from "../ChartRequests/BarChartRequest";
// // // import { createBigNumberRequest } from "../ChartRequests/BigNumberChartRequest";
// // // import { createLineChartRequest } from "../ChartRequests/LineChartRequest";
// // // import { createAreaChartRequest } from "../ChartRequests/AreaChartRequest";
// // // import { createTableRequest } from "../ChartRequests/TableRequest";
// // // import ExpressionEditor from "./ExpressionEditor";
// // // import {
// // //   Tooltip,
// // //   TooltipContent,
// // //   TooltipProvider,
// // //   TooltipTrigger,
// // // } from "../../../../../@/components/ui/tooltip";
// // // import MultiSelect from "../../../../../@/components/ui/multi-select";
// // // import { createPivotTableRequest } from "../ChartRequests/PivotTableRequest";
// // // import {
// // //   Tabs,
// // //   TabsContent,
// // //   TabsList,
// // //   TabsTrigger,
// // // } from "../../../../../@/components/ui/tabs";
// // // import { useLocation } from "react-router-dom";
// // // import { createDonutChart } from "../ChartRequests/DonutChartRequest";
// // // import { createCustomBarChartRequest } from "../ChartRequests/CustomBarChartRequest";
// // // import { useSelector } from "react-redux";
// // // import { RootState } from "../../../../../redux/store";
// // // // Import all chart images
// // // import BarChart from "../../../../../assets/viz_thumbnails/bar.png";
// // // import PieChart from "../../../../../assets/viz_thumbnails/pie.png";
// // // import LineChart from "../../../../../assets/viz_thumbnails/line.png";
// // // import AreaChart from "../../../../../assets/viz_thumbnails/area.png";
// // // import SunburstChart from "../../../../../assets/viz_thumbnails/sunburst.png";
// // // import BigNumber from "../../../../../assets/viz_thumbnails/big_number.png";
// // // import CustomTable from "../../../../../assets/viz_thumbnails/table.png";
// // // import PivotTable from "../../../../../assets/viz_thumbnails/pivot_table.png";
// // // import DonutChart from "../../../../../assets/viz_thumbnails/donut.png";
// // // import CustomBarChart from "../../../../../assets/viz_thumbnails/custom_bar.png";

// // // interface DroppedItem {
// // //   id: string;
// // //   name: string;
// // //   type: string;
// // // }
// // // interface Option {
// // //   value: string;
// // //   label: string;
// // // }

// // // interface ChartType {
// // //   unique_id: string;
// // //   name: string;
// // //   icon: string; // Changed from ReactNode to string
// // //   hasData?: boolean;
// // // }

// // // interface FormField {
// // //   key: string;
// // //   label: string;
// // //   type: string;
// // //   placeholder?: string;
// // //   options?: string[];
// // //   popover?: {
// // //     [key: string]: any[];
// // //   };
// // // }

// // // interface ChartForm {
// // //   parameters: FormField[];
// // // }

// // // interface ChartTabsProps {
// // //   dataset: string;
// // //   chartType: string;
// // //   onChartCreated: (chartOptions: any) => void;
// // //   onThemeChange: (theme: string) => void;
// // //   selectedTheme: string;
// // //   onClearChartPreview: () => void; // Add this line
// // // }
// // // interface Column {
// // //   name: string;
// // //   type: string;
// // // }

// // // interface Dimension {
// // //   id: string;
// // //   name: string;
// // //   type?: string;
// // // }
// // // interface Metric {
// // //   expression_type: string;
// // //   column: {
// // //     column_name: string;
// // //     type: string;
// // //   };
// // //   aggregate: string;
// // //   label: string;
// // // }

// // // interface Filter {
// // //   id: string;
// // //   col?: string;
// // //   op?: string;
// // //   val?: string[];
// // //   alias?: string; // Add this line
// // // }
// // // interface FormData {
// // //   dimensions?: DroppedItem[];
// // //   metrics?: DroppedItem[];
// // //   x_axis?: DroppedItem;
// // //   [key: string]: any;
// // // }
// // // const ChartTabs: React.FC<ChartTabsProps> = ({
// // //   dataset,
// // //   chartType,
// // //   onChartCreated,
// // //   onThemeChange,
// // //   selectedTheme,
// // //   onClearChartPreview, // Add this line
// // // }) => {
// // //   const [activeChartType, setActiveChartType] = useState<string>("");
// // //   const [chartTypes, setChartTypes] = useState<ChartType[]>([]);
// // //   const [chartForms, setChartForms] = useState<{ [key: string]: ChartForm }>(
// // //     {}
// // //   );
// // //   const [columns, setColumns] = useState<Column[]>([]);
// // //   const [formData, setFormData] = useState<{ [key: string]: any }>({});
// // //   const [popoverSelections, setPopoverSelections] = useState<{
// // //     [key: string]: any;
// // //   }>({});
// // //   const [uniqueValues, setUniqueValues] = useState<any>({});
// // //   const [defaultRowLimit, setDefaultRowLimit] = useState(10);
// // //   const [chartMetric, setChartMetric] = useState<Metric | null>(null);
// // //   const [filters, setFilters] = useState<Filter[]>([]);
// // //   const [chartDataModel, setChartDataModel] = useState<any>(null);
// // //   const [isLoading, setIsLoading] = useState(false);
// // //   const [error, setError] = useState<string | null>(null);
// // //   const [showLegend, setShowLegend] = useState(true);
// // //   const [legendOrientation, setLegendOrientation] = useState("top");
// // //   const [legendType, setLegendType] = useState("scroll");
// // //   const [showDataZoom, setShowDataZoom] = useState(false);
// // //   const [isExpressionEditorOpen, setIsExpressionEditorOpen] = useState(false);
// // //   const [showLabelLines, setShowLabelLines] = useState(false);
// // //   const [activeTab, setActiveTab] = useState<string>("default");
// // //   const [isChartCreated, setIsChartCreated] = useState(false);
// // //   const location = useLocation();
// // //   const { state } = location;
// // //   const [chartData, setChartData] = useState(null);
// // //   const [xAxisData, setXAxisData] = useState<any>(null);

// // //   const chartDetails: any = useSelector((state: RootState) => state.chart);

// // //   const handleEditClick = () => {
// // //     setIsExpressionEditorOpen(true);
// // //   };

// // //   const handleExpressionEditorClose = () => {
// // //     setIsExpressionEditorOpen(false);
// // //   };

// // //   const handleExpressionEditorSave = () => {
// // //     // Handle saving the expressions
// // //     setIsExpressionEditorOpen(false);
// // //   };

// // //   useEffect(() => {
// // //     fetchChartTypes();
// // //     fetchTableData();
// // //   }, [dataset]);

// // //   useEffect(() => {
// // //     if(chartDetails?.id) {
// // //       const { chart } = chartDetails;
// // //       const { queries } = chart?.params;
// // //       const { metrics } = queries[0];
// // //       const { filters: chartFilters } = queries[0];

// // //       saveMetric(
// // //         metrics[0]?.column?.column_name, metrics[0]?.aggregate, 
// // //         { id: metrics[0]?.column?.column_name, name: metrics[0]?.column?.column_name, type: metrics[0]?.column?.type}, 
// // //         ""
// // //       );
// // //       setTimeout(() => {
// // //         setChartMetric(metrics[0]);
// // //         setFilters(chartFilters);
// // //         // setFilterData(chartFilters);
// // //         // setActiveChartType(chart.visualization_name);
// // //         // chartMetric = metrics[0];
// // //         // metricData = metrics[0];
// // //         // filterData = chartFilters;
// // //         // filters = chartFilters;
// // //         // activeChartType = chart.visualization_name;
// // //         // defaultRowLimit = queries[0].row_limit.toString();
// // //         // formData.dimensions = chart?.params?.form_data?.groupby || [];
// // //       }, 1000);

// // //       // setTimeout(() => {
// // //       //   handleCreateChart();
// // //       // }, 2000);
// // //     }
// // //   }, [chartDetails]);

// // //   useEffect(() => {
// // //     if (state && state.chart) {
// // //       setActiveChartType(state.chart);
// // //     }
// // //   }, [state]);
// // //   const fetchChartTypes = async () => {
// // //     try {
// // //       const response = await axios.post("/api/charts/dashboard_charts", {});
// // //       const allChartTypes = response.data.data.flatMap(
// // //         (section: any) => section.components
// // //       );

// // //       const filteredChartTypes = allChartTypes.filter((chart: ChartType) => {
// // //         if (chart.name.toLowerCase() === "sunburst chart") {
// // //           return chart.hasData === true;
// // //         }
// // //         return true;
// // //       });

// // //       const chartTypesWithIcons = filteredChartTypes.map(
// // //         (chart: ChartType) => ({
// // //           ...chart,
// // //           icon: getChartIcon(chart.name),
// // //         })
// // //       );

// // //       setChartTypes(chartTypesWithIcons);
// // //       if (chartTypesWithIcons.length > 0 && !state?.chart) {
// // //         setActiveChartType(chartTypesWithIcons[0].unique_id);
// // //       }
// // //       fetchChartForms(chartTypesWithIcons);
// // //     } catch (error) {
// // //       console.error("Error fetching chart types:", error);
// // //     }
// // //   };

// // //   const getChartIcon = (chartName: string): string => {
// // //     switch (chartName.toLowerCase()) {
// // //       case "bar chart":
// // //         return BarChart;
// // //       case "custom bar chart":
// // //         return CustomBarChart;
// // //       case "line chart":
// // //         return LineChart;
// // //       case "area chart":
// // //         return AreaChart;
// // //       case "pie chart":
// // //         return PieChart;
// // //       case "table":
// // //         return CustomTable;
// // //       case "big number":
// // //         return BigNumber;
// // //       case "donut chart":
// // //         return DonutChart;
// // //       case "sunburst chart":
// // //         return SunburstChart;
// // //       case "pivot table":
// // //         return PivotTable;
// // //       default:
// // //         return CustomTable; // Default to table icon
// // //     }
// // //   };

// // //   const fetchChartForms = async (chartTypes: ChartType[]) => {
// // //     const forms: { [key: string]: ChartForm } = {};
// // //     for (const chart of chartTypes) {
// // //       try {
// // //         const response = await axios.post("/api/charts/get_chart_form", {
// // //           unique_id: chart.unique_id,
// // //         });
// // //         forms[chart.unique_id] = response.data.data;
// // //       } catch (error) {
// // //         console.error(`Error fetching form for ${chart.unique_id}:`, error);
// // //       }
// // //     }
// // //     setChartForms(forms);
// // //   };

// // //   const fetchTableData = async () => {
// // //     let params = {
// // //       database: "zolix_c2o",
// // //       schema: "public",
// // //       table: dataset,
// // //     };
// // //     try {
// // //       const response = await axios.post("/api/charts/get_columns", params);
// // //       const columnData: Column[] = response.data.data.map((col: any) => ({
// // //         name: col.name,
// // //         type: col.type,
// // //       }));
// // //       setColumns(columnData);
// // //       // Fetch unique values for each column
// // //       columnData.forEach((column: Column) => fetchUniqueValues(column.name));
// // //     } catch (error) {
// // //       console.error("Error fetching columns:", error);
// // //       alert(
// // //         "Failed to fetch columns. Please check the console for more details."
// // //       );
// // //     }
// // //   };

// // //   const fetchUniqueValues = async (column: string) => {
// // //     try {
// // //       const response = await axios.post("/api/charts/get_unique_values", {
// // //         database: "zolix_c2o",
// // //         schema: "public",
// // //         table: dataset,
// // //         column: [column],
// // //       });

// // //       setUniqueValues((prev) => ({
// // //         ...prev,
// // //         ...response.data.data,
// // //       }));
// // //     } catch (error) {
// // //       console.error(`Error fetching unique values for ${column}:`, error);
// // //     }
// // //   };
// // //   const handleChartTypeChange = (type: string) => {
// // //     setActiveChartType(type);
// // //     // Reset form data when changing chart type
// // //     setFormData({});
// // //     setChartMetric(null);
// // //     setFilters([]);
// // //   };

// // //   const handleFormChange = (key: string, value: any, openPopover = false) => {
// // //     setFormData((prevData) => ({
// // //       ...prevData,
// // //       [key]: value,
// // //     }));

// // //     if (key === "x_axis" && value) {
// // //       setXAxisData({
// // //         name: value.name,
// // //         label: value.name,
// // //         sort_ascending: true,
// // //       });
// // //     }
// // //     if (openPopover && value) {
// // //       if (!Array.isArray(value)) {
// // //         setPopoverSelections((prev) => ({
// // //           ...prev,
// // //           [value.id]: { isOpen: true, column: value.name },
// // //         }));
// // //       } else if (Array.isArray(value) && value.length > 0) {
// // //         const lastItem = value[value.length - 1];
// // //         setPopoverSelections((prev) => ({
// // //           ...prev,
// // //           [lastItem.id]: { isOpen: true, column: lastItem.name },
// // //         }));
// // //       }
// // //     }
// // //   };
// // //   const handleRemoveItem = (key: string, id?: string) => {
// // //     setFormData((prevData) => {
// // //       if (Array.isArray(prevData[key])) {
// // //         return {
// // //           ...prevData,
// // //           [key]: prevData[key].filter((item: DroppedItem) => item.id !== id),
// // //         };
// // //       } else {
// // //         const { [key]: _, ...rest } = prevData;
// // //         return rest;
// // //       }
// // //     });

// // //     if (id) {
// // //       setPopoverSelections((prev) => {
// // //         const { [id]: _, ...rest } = prev;
// // //         return rest;
// // //       });
// // //     }

// // //     if (key === "x_axis") {
// // //       setXAxisData(null);
// // //     }
// // //   };

// // //   const handlePopoverSave = (fieldKey: string, itemId: string, data: any) => {
// // //     console.log("Handling popover save:", fieldKey, itemId, data);

// // //     let savedData: any = {
// // //       id: data.id,
// // //       type: data.type,
// // //       column: data.column,
// // //       alias: data.alias,
// // //       aggregate: data.aggregate,
// // //       operator: data.operator,
// // //       value: data.value,
// // //     };
// // //     let displayText = data.alias || data.column;

// // //     switch (fieldKey) {
// // //       case "x_axis":
// // //         displayText = data.alias || data.column;
// // //         setXAxisData({
// // //           name: data.column,
// // //           label: data.alias || data.column,
// // //           sort_ascending: true,
// // //         });
// // //         setFormData((prevData) => ({
// // //           ...prevData,
// // //           x_axis: {
// // //             name: data.column,
// // //             label: data.alias || data.column,
// // //             sort_ascending: true,
// // //           },
// // //         }));
// // //         break;
// // //       case "metric":
// // //         displayText =
// // //           data.alias ||
// // //           (data.aggregate && data.column
// // //             ? `${data.column} (${data.aggregate})`
// // //             : data.column);
// // //         // Set chartMetric for the bar chart
// // //         const columnData = columns.find((col) => col.name === data.column);
// // //         setChartMetric({
// // //           expression_type: "SIMPLE",
// // //           column: {
// // //             column_name: data.column,
// // //             type: columnData?.type || "UNKNOWN",
// // //           },
// // //           aggregate: data.aggregate,
// // //           label: data.alias || data.column,
// // //         });
// // //         break;
// // //       case "metrics":
// // //         displayText =
// // //           data.alias ||
// // //           (data.aggregate && data.column
// // //             ? `${data.column} (${data.aggregate})`
// // //             : data.column);
// // //         const columnsData = columns.find((col) => col.name === data.column);
// // //         setChartMetric({
// // //           expression_type: "SIMPLE",
// // //           column: {
// // //             column_name: data.column,
// // //             type: columnsData?.type || "UNKNOWN",
// // //           },
// // //           aggregate: data.aggregate,
// // //           label: data.alias || data.column,
// // //         });
// // //         break;
// // //       case "dimensions":
// // //         displayText = data.alias || data.column;
// // //         // Update dimensions in formData
// // //         setFormData((prevData) => {
// // //           const updatedDimensions = Array.isArray(prevData.dimensions)
// // //             ? prevData.dimensions.map((dim: any) =>
// // //                 dim.id === itemId
// // //                   ? { ...dim, name: data.column, alias: data.alias }
// // //                   : dim
// // //               )
// // //             : [];
// // //           return { ...prevData, dimensions: updatedDimensions };
// // //         });
// // //         break;
// // //       case "filters":
// // //         displayText = `${data.alias || data.column} ${data.operator} (${
// // //           Array.isArray(data.value) ? data.value.join(", ") : data.value
// // //         })`;
// // //         handleFilterChange(
// // //           itemId,
// // //           data.column,
// // //           data.operator,
// // //           Array.isArray(data.value) ? data.value : [data.value],
// // //           data.alias
// // //         );
// // //         break;
// // //       default:
// // //         displayText = data.alias || data.column;
// // //     }
// // //     setPopoverSelections((prev) => ({
// // //       ...prev,
// // //       [itemId]: { ...savedData, isOpen: false },
// // //     }));

// // //     console.log("Saved x-axis data:", formData.x_axis); // Add this log
// // //   };

// // //   const saveMetric = (
// // //     selectedColumn: string,
// // //     selectedAggregate: string,
// // //     item: DroppedItem,
// // //     alias: string
// // //   ) => {
// // //     if (!selectedColumn || !selectedAggregate || !item) {
// // //       alert("Please select a column and aggregate function.");
// // //       return;
// // //     }
// // //     const columnData = columns.find((col) => col.name === selectedColumn);
// // //     const newMetric: Metric = {
// // //       expression_type: "SIMPLE",
// // //       column: {
// // //         column_name: selectedColumn,
// // //         type: columnData ? columnData.type : "UNKNOWN",
// // //       },
// // //       aggregate: selectedAggregate,
// // //       label: alias || selectedColumn,
// // //     };
// // //     setChartMetric(newMetric);
// // //   };
// // //   const handleFilterChange = (
// // //     id: string,
// // //     col?: string,
// // //     op?: string,
// // //     val?: string[],
// // //     alias?: string
// // //   ) => {
// // //     setFilters((prevFilters) => {
// // //       const existingFilterIndex = prevFilters.findIndex(
// // //         (filter) => filter.id === id
// // //       );
// // //       const columnData = columns.find((column) => column.name === col);
// // //       const newFilter = {
// // //         id,
// // //         col: col || "",
// // //         op: op || "",
// // //         val: val || [],
// // //         alias: alias || "",
// // //         type: columnData ? columnData.type : "UNKNOWN",
// // //       };
// // //       if (existingFilterIndex !== -1) {
// // //         // Update existing filter
// // //         const updatedFilters = [...prevFilters];
// // //         updatedFilters[existingFilterIndex] = newFilter;
// // //         return updatedFilters;
// // //       } else {
// // //         // Add new filter
// // //         return [...prevFilters, newFilter];
// // //       }
// // //     });
// // //   };

// // //   // const getDisplayText = (item: DroppedItem, fieldKey: string) => {
// // //   //   const selection = popoverSelections[item.id];
// // //   //   if (!selection) return item.name || '';

// // //   //   return selection.alias || selection.column || item.name;
// // //   // };

// // //   const getDisplayText = (item: any, fieldKey: string) => {
// // //     if (fieldKey === "x_axis" && item) {
// // //       return item.name || item.label || "X-Axis";
// // //     }
// // //     if ((fieldKey === "metrics" || fieldKey === "metric") && item) {
// // //       const selection = popoverSelections[item.id];
// // //       const aggregate = selection?.aggregate || item?.aggregate || "";
// // //       const column = selection?.column || item.name || item?.column?.column_name || "";
// // //       const alias = selection?.alias || item?.label || "";
// // //       return alias || (aggregate ? `${column} (${aggregate})` : column);
// // //     }
// // //     if (fieldKey === "dimensions" && item) {
// // //       return `${item.name}`;
// // //     }
// // //     if (fieldKey === "filters" && item) {
// // //       const selection = popoverSelections[item.id];
// // //       const column = selection?.column || item.name || "";
// // //       const operator = selection?.operator || "";
// // //       const value = Array.isArray(selection?.value)
// // //         ? selection.value.map((v: Option) => v.value || v).join(", ")
// // //         : selection?.value || "";
// // //       return `${column} ${operator} ${value ? `(${value})` : ""}`;
// // //     }
// // //     return item.name || "";
// // //   };

// // //   const renderChartDropdown = () => (
// // //     <Select value={activeChartType} onValueChange={handleChartTypeChange}>
// // //       <SelectTrigger className="w-full">
// // //         <SelectValue placeholder="Select a chart type">
// // //           {activeChartType && (
// // //             <div className="flex items-center">
// // //               <img
// // //                 src={
// // //                   chartTypes.find((ct) => ct.unique_id === activeChartType)
// // //                     ?.icon
// // //                 }
// // //                 alt={
// // //                   chartTypes.find((ct) => ct.unique_id === activeChartType)
// // //                     ?.name
// // //                 }
// // //                 className="w-6 h-6 mr-2"
// // //               />
// // //               <span>
// // //                 {
// // //                   chartTypes.find((ct) => ct.unique_id === activeChartType)
// // //                     ?.name
// // //                 }
// // //               </span>
// // //             </div>
// // //           )}
// // //         </SelectValue>
// // //       </SelectTrigger>
// // //       <SelectContent>
// // //         {chartTypes.map((chartType) => (
// // //           <SelectItem key={chartType.unique_id} value={chartType.unique_id}>
// // //             <div className="flex items-center">
// // //               <img
// // //                 src={chartType.icon}
// // //                 alt={chartType.name}
// // //                 className="w-6 h-6 mr-2"
// // //               />
// // //               <span>{chartType.name}</span>
// // //             </div>
// // //           </SelectItem>
// // //         ))}
// // //       </SelectContent>
// // //     </Select>
// // //   );
// // //   const DynamicPopoverContent: React.FC<{
// // //     field: FormField;
// // //     item: DroppedItem;
// // //     onClose: () => void;
// // //     onSave: (data: any) => void;
// // //   }> = ({ field, item, onClose, onSave }) => {
// // //     const storedData = popoverSelections[item.id] || {};
// // //     const [popoverData, setPopoverData] = useState<{
// // //       [key: string]: string | any;
// // //     }>({
// // //       columns: storedData.column || item.name,
// // //       aggregate: storedData.aggregate || "",
// // //       operator: storedData.operator || "",
// // //       value: storedData.value || [],
// // //       row_limit: defaultRowLimit,
// // //       alias: storedData.alias || "",
// // //     });

// // //     const handlePopoverChange = (key: string, value: string | Option[]) => {
// // //       setPopoverData((prev) => ({ ...prev, [key]: value }));
// // //     };

// // //     const handleSave = () => {
// // //       try {
// // //         const baseData = {
// // //           id: item.id,
// // //           type: item.type,
// // //           column: popoverData["columns"],
// // //           alias: popoverData["alias"],
// // //         };

// // //         let saveData;
// // //         switch (field.key) {
// // //           case "metrics":
// // //           case "metric":
// // //             saveData = {
// // //               ...baseData,
// // //               aggregate: popoverData["aggregate"],
// // //             };
// // //             break;
// // //           case "filters":
// // //             saveData = {
// // //               ...baseData,
// // //               operator: popoverData["operator"],
// // //               value: Array.isArray(popoverData["value"])
// // //                 ? popoverData["value"].map((option: Option) => option.value)
// // //                 : popoverData["value"],
// // //             };
// // //             break;
// // //           default:
// // //             saveData = baseData;
// // //         }

// // //         console.log("Saving popover data:", saveData);
// // //         onSave(saveData);
// // //         onClose(); // Close the popover after successful save
// // //       } catch (error) {
// // //         console.error("Error saving popover data:", error);
// // //         // You might want to show an error message to the user here
// // //       }
// // //     };

// // //     const renderPopoverField = (popoverField: any) => {
// // //       switch (popoverField.key) {
// // //         case "columns":
// // //         case "operator":
// // //         case "aggregate":
// // //           return (
// // //             <Select
// // //               value={popoverData[popoverField.key] as string}
// // //               onValueChange={(value) =>
// // //                 handlePopoverChange(popoverField.key, value)
// // //               }
// // //             >
// // //               <SelectTrigger className="w-full">
// // //                 <SelectValue placeholder={popoverField.placeholder} />
// // //               </SelectTrigger>
// // //               <SelectContent>
// // //                 {popoverField.key === "columns"
// // //                   ? columns.map((column: Column) => (
// // //                       <SelectItem key={column.name} value={column.name}>
// // //                         {column.name}
// // //                       </SelectItem>
// // //                     ))
// // //                   : popoverField.options
// // //                       ?.filter((option: string) => option !== "")
// // //                       .map((option: string) => (
// // //                         <SelectItem key={option} value={option}>
// // //                           {option}
// // //                         </SelectItem>
// // //                       ))}
// // //               </SelectContent>
// // //             </Select>
// // //           );
// // //         case "value":
// // //           if (popoverData["columns"]) {
// // //             const options = (
// // //               Array.isArray(uniqueValues[popoverData["columns"] as string])
// // //                 ? uniqueValues[popoverData["columns"] as string].filter(
// // //                     (value: string) => value !== ""
// // //                   )
// // //                 : []
// // //             ).map((value: string) => ({ value, label: value }));

// // //             return (
// // //               <MultiSelect
// // //                 options={options}
// // //                 value={popoverData[popoverField.key]}
// // //                 onChange={(selected: Option[]) =>
// // //                   handlePopoverChange(popoverField.key, selected)
// // //                 }
// // //               />
// // //             );
// // //           }
// // //           return null;
// // //         case "alias":
// // //           return (
// // //             <input
// // //               type="text"
// // //               value={popoverData[popoverField.key] as string}
// // //               onChange={(e) =>
// // //                 handlePopoverChange(popoverField.key, e.target.value)
// // //               }
// // //               placeholder="Enter alias"
// // //               className="w-full p-2 border rounded"
// // //             />
// // //           );
// // //         default:
// // //           return (
// // //             <input
// // //               type="text"
// // //               value={popoverData[popoverField.key] as string}
// // //               onChange={(e) =>
// // //                 handlePopoverChange(popoverField.key, e.target.value)
// // //               }
// // //               placeholder={popoverField.placeholder}
// // //               className="w-full p-2 border rounded"
// // //             />
// // //           );
// // //       }
// // //     };

// // //     return (
// // //       <Tabs defaultValue="SIMPLE" className="w-full">
// // //         <TabsList
// // //           className={`grid w-full ${
// // //             Object.keys(field.popover || {}).length === 1
// // //               ? "grid-cols-1"
// // //               : "grid-cols-2"
// // //           }`}
// // //         >
// // //           {Object.keys(field.popover || {}).map((tabKey) => (
// // //             <TabsTrigger
// // //               key={tabKey}
// // //               value={tabKey}
// // //               className={tabKey === "SIMPLE" ? "shadow-lg" : ""}
// // //             >
// // //               {tabKey}
// // //             </TabsTrigger>
// // //           ))}
// // //         </TabsList>

// // //         {Object.entries(field.popover || {}).map(([tabKey, tabFields]) => (
// // //           <TabsContent key={tabKey} value={tabKey}>
// // //             <Card className="border-none shadow-none mt-2">
// // //               <CardContent>
// // //                 <div className="grid gap-4">
// // //                   {tabFields.map((popoverField: any) => (
// // //                     <div key={popoverField.key} className="grid gap-2">
// // //                       <Label>{popoverField.label}</Label>
// // //                       {renderPopoverField(popoverField)}
// // //                     </div>
// // //                   ))}
// // //                 </div>
// // //               </CardContent>
// // //               <CardFooter className="flex justify-between">
// // //                 <Button
// // //                   className="bg-slate-400 hover:bg-slate-600"
// // //                   onClick={onClose}
// // //                 >
// // //                   Close
// // //                 </Button>
// // //                 <Button
// // //                   className="bg-slate-400 hover:bg-slate-600"
// // //                   onClick={handleSave}
// // //                 >
// // //                   Save
// // //                 </Button>
// // //               </CardFooter>
// // //             </Card>
// // //           </TabsContent>
// // //         ))}
// // //       </Tabs>
// // //     );
// // //   };

// // //   const SingleDropZone: React.FC<{
// // //     onDrop: (item: DroppedItem) => void;
// // //     item: DroppedItem | null;
// // //     onRemove: () => void;
// // //     placeholder: string;
// // //     field: FormField;
// // //     acceptTypes: string[];
// // //   }> = ({ onDrop, item, onRemove, placeholder, field, acceptTypes }) => {
// // //     const [{ isOver }, drop] = useDrop(() => ({
// // //       accept: acceptTypes,
// // //       drop: (droppedItem: DroppedItem) => {
// // //         onDrop(droppedItem);
// // //         setPopoverSelections((prev) => ({
// // //           ...prev,
// // //           [droppedItem.id]: { ...prev[droppedItem.id], isOpen: true },
// // //         }));
// // //       },
// // //       collect: (monitor) => ({
// // //         isOver: !!monitor.isOver(),
// // //       }),
// // //     }));

// // //     return (
// // //       <div
// // //         ref={drop}
// // //         className={`border border-gray-300 rounded-md overflow-hidden text-sm ${
// // //           isOver ? "bg-blue-50" : "bg-white"
// // //         }`}
// // //       >
// // //         {!item && !chartMetric ? (
// // //           <div className="p-1 text-gray-400">{placeholder}</div>
// // //         ) : (
// // //           <div className="flex items-center p-1 border-gray-200">
// // //             <Button
// // //               variant="icon"
// // //               className="text-gray-500 hover:text-red-500 px-2 px-1"
// // //               onClick={() => handleRemoveItem(field.key)}
// // //             >
// // //               <IconX stroke={1.5} size={14} />
// // //             </Button>
// // //             <div className="flex-grow px-2 py-1 bg-white rounded text-gray-800">
// // //               {getDisplayText(item || chartMetric, field.key)}
// // //             </div>
// // //             {field.popover && (
// // //               <Popover
// // //                 open={item ? popoverSelections[item.id]?.isOpen : false}
// // //                 onOpenChange={(open) =>
// // //                   setPopoverSelections((prev) => ({
// // //                     ...prev,
// // //                     [item.id]: { ...prev[item.id], isOpen: open },
// // //                   }))
// // //                 }
// // //               >
// // //                 <PopoverTrigger asChild>
// // //                   <Button variant="icon" className="px-2 px-1">
// // //                     <IconArrowBarToRight stroke={1.5} size={14} />
// // //                   </Button>
// // //                 </PopoverTrigger>
// // //                 <PopoverContent className="w-96 bg-white border border-gray-300">
// // //                   <DynamicPopoverContent
// // //                     field={field}
// // //                     item={item}
// // //                     onClose={() =>
// // //                       setPopoverSelections((prev) => ({
// // //                         ...prev,
// // //                         [item.id]: { ...prev[item.id], isOpen: false },
// // //                       }))
// // //                     }
// // //                     onSave={(data) => {
// // //                       handlePopoverSave(field.key, item.id, data);
// // //                     }}
// // //                   />
// // //                 </PopoverContent>
// // //               </Popover>
// // //             )}
// // //           </div>
// // //         )}
// // //       </div>
// // //     );
// // //   };
// // //   const MultipleDropZone: React.FC<{
// // //     onDrop: (item: DroppedItem) => void;
// // //     items: DroppedItem[];
// // //     onRemove: (id: string) => void;
// // //     placeholder: string;
// // //     field: FormField;
// // //     acceptTypes: string[];
// // //   }> = ({ onDrop, items, onRemove, placeholder, field, acceptTypes }) => {
// // //     const [{ isOver }, drop] = useDrop(() => ({
// // //       accept: acceptTypes,
// // //       drop: (item: DroppedItem) => {
// // //         if (!items.some((existingItem) => existingItem.id === item.id)) {
// // //           onDrop(item);
// // //           setPopoverSelections((prev) => ({
// // //             ...prev,
// // //             [item.id]: { ...prev[item.id], isOpen: true },
// // //           }));
// // //         }
// // //       },
// // //       collect: (monitor) => ({
// // //         isOver: !!monitor.isOver(),
// // //       }),
// // //     }));

// // //     return (
// // //       <div
// // //         ref={drop}
// // //         className={`border border-gray-300 rounded-md overflow-hidden text-sm ${
// // //           isOver ? "bg-blue-50" : "bg-white"
// // //         }`}
// // //       >
// // //         {items.length === 0 ? (
// // //           <div className="p-1 text-gray-400">{placeholder}</div>
// // //         ) : (
// // //           <div>
// // //             {items.map((item) => (
// // //               <div
// // //                 key={item.id}
// // //                 className="flex items-center p-1 border-b border-gray-200 last:border-b-0"
// // //               >
// // //                 <Button
// // //                   variant="icon"
// // //                   className="text-black-500 hover:text-red-500 px-2 px-1"
// // //                   onClick={() => handleRemoveItem(field.key, item.id)}
// // //                 >
// // //                   <IconX stroke={1.5} size={14} />
// // //                 </Button>
// // //                 <div className="flex-grow px-2 py-1 bg-white rounded text-gray-800">
// // //                   {getDisplayText(item || filters, field.key)}
// // //                 </div>
// // //                 {field.popover && (
// // //                   <Popover
// // //                     open={popoverSelections[item.id]?.isOpen}
// // //                     onOpenChange={(open) =>
// // //                       setPopoverSelections((prev) => ({
// // //                         ...prev,
// // //                         [item.id]: { ...prev[item.id], isOpen: open },
// // //                       }))
// // //                     }
// // //                   >
// // //                     <PopoverTrigger asChild>
// // //                       <Button variant="icon" className="px-2 px-1">
// // //                         <IconArrowBarToRight stroke={1.5} size={14} />
// // //                       </Button>
// // //                     </PopoverTrigger>
// // //                     <PopoverContent className="w-96">
// // //                       <DynamicPopoverContent
// // //                         field={field}
// // //                         item={item}
// // //                         onClose={() =>
// // //                           setPopoverSelections((prev) => ({
// // //                             ...prev,
// // //                             [item.id]: { ...prev[item.id], isOpen: false },
// // //                           }))
// // //                         }
// // //                         onSave={(data) => {
// // //                           handlePopoverSave(field.key, item.id, data);
// // //                         }}
// // //                       />
// // //                     </PopoverContent>
// // //                   </Popover>
// // //                 )}
// // //               </div>
// // //             ))}
// // //           </div>
// // //         )}
// // //       </div>
// // //     );
// // //   };

// // //   const renderFormField = (field: FormField) => {
// // //     switch (field.type) {
// // //       case "select":
// // //         return (
// // //           <Select
// // //             value={formData[field.key] || ""}
// // //             onValueChange={(value) => handleFormChange(field.key, value)}
// // //           >
// // //             <SelectTrigger className="w-full bg-white">
// // //               <SelectValue
// // //                 placeholder={field.placeholder || `Select ${field.label}`}
// // //               />
// // //             </SelectTrigger>
// // //             <SelectContent>
// // //               <SelectGroup>
// // //                 <SelectLabel>{field.label}</SelectLabel>
// // //                 {field.options?.map((option) => (
// // //                   <SelectItem key={option} value={option}>
// // //                     {option}
// // //                   </SelectItem>
// // //                 ))}
// // //               </SelectGroup>
// // //             </SelectContent>
// // //           </Select>
// // //         );
// // //       case "drag_and_drop_or_select_single":
// // //         return (
// // //           <SingleDropZone
// // //             onDrop={(item) =>
// // //               handleFormChange(
// // //                 field.key === "metric" ? "metric" : field.key,
// // //                 item,
// // //                 true
// // //               )
// // //             }
// // //             item={formData[field.key] || null}
// // //             onRemove={() => {
// // //               handleFormChange(field.key, null);
// // //               if (field.key === "metric") {
// // //                 setChartMetric(null);
// // //               }
// // //             }}
// // //             placeholder={field.placeholder || "Drop item here"}
// // //             field={field}
// // //             acceptTypes={["METRIC", "COLUMN"]}
// // //           />
// // //         );
// // //       case "drag_and_drop_or_select_multiple":
// // //         return (
// // //           <MultipleDropZone
// // //             onDrop={(item) =>
// // //               handleFormChange(
// // //                 field.key,
// // //                 [...(formData[field.key] || []), item],
// // //                 true
// // //               )
// // //             }
// // //             items={formData[field.key] || []}
// // //             onRemove={(id) =>
// // //               handleFormChange(
// // //                 field.key,
// // //                 (formData[field.key] || []).filter(
// // //                   (item: DroppedItem) => item.id !== id
// // //                 )
// // //               )
// // //             }
// // //             placeholder={field.placeholder || "Drop items here"}
// // //             field={field}
// // //             acceptTypes={["METRIC", "COLUMN"]}
// // //           />
// // //         );
// // //       case "checkbox":
// // //         return (
// // //           <div className="items-top flex space-x-2">
// // //             <input
// // //               type="checkbox"
// // //               id={field.key}
// // //               checked={formData[field.key] || false}
// // //               onChange={(e) => handleFormChange(field.key, e.target.checked)}
// // //               className="form-checkbox h-4 w-5 text-blue-600"
// // //             />
// // //             <div className="grid gap-1.5 leading-none">
// // //               <label
// // //                 htmlFor={field.key}
// // //                 className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
// // //               ></label>
// // //             </div>
// // //           </div>
// // //         );
// // //       default:
// // //         return (
// // //           <input
// // //             type="text"
// // //             value={formData[field.key] || ""}
// // //             onChange={(e) => handleFormChange(field.key, e.target.value)}
// // //             placeholder={field.placeholder}
// // //             className="w-full p-2 border rounded"
// // //           />
// // //         );
// // //     }
// // //   };

// // //   const renderActiveSection = () => {
// // //     const activeForm = chartForms[activeChartType];
// // //     if (!activeForm) return null;

// // //     return (
// // //       <div className="space-y-4">
// // //         {activeForm.parameters.map((field: FormField) => (
// // //           <div key={field.key}>
// // //             <Label>{field.label}</Label>
// // //             {field.key === "x_axis" ? (
// // //               <SingleDropZone
// // //                 onDrop={(item) => handleFormChange("x_axis", item, true)}
// // //                 item={formData.x_axis || null}
// // //                 onRemove={() => {
// // //                   handleFormChange("x_axis", null);
// // //                   setXAxisData(null);
// // //                 }}
// // //                 placeholder="Drop column for X-axis"
// // //                 field={field}
// // //                 acceptTypes={["COLUMN"]}
// // //               />
// // //             ) : (
// // //               renderFormField(field)
// // //             )}
// // //           </div>
// // //         ))}
// // //       </div>
// // //     );
// // //   };

// // //   const handleCreateChart = async () => {
// // //     setIsLoading(true);
// // //     setError(null);

// // //     try {
// // //       let chartData;
// // //       if (activeTab === "default") {
// // //         switch (activeChartType) {
// // //           case "pie":
// // //             chartData = await createPieChart(
// // //               dataset,
// // //               filters,
// // //               chartMetric,
// // //               {
// // //                 dimensions: (formData.dimensions as Dimension[])?.map(
// // //                   (dim) => ({
// // //                     ...dim,
// // //                     type: columns.find((col) => col.name === dim.name)?.type,
// // //                   })
// // //                 ),
// // //               },
// // //               defaultRowLimit,
// // //               showLegend,
// // //               legendOrientation,
// // //               legendType
// // //             );
// // //             break;
// // //           case "donut":
// // //             chartData = await createDonutChart(
// // //               dataset,
// // //               filters,
// // //               chartMetric,
// // //               {
// // //                 dimensions: (formData.dimensions as Dimension[])?.map(
// // //                   (dim) => ({
// // //                     ...dim,
// // //                     type: columns.find((col) => col.name === dim.name)?.type,
// // //                   })
// // //                 ),
// // //               },
// // //               defaultRowLimit,
// // //               showLegend,
// // //               legendOrientation,
// // //               legendType
// // //             );
// // //             break;
// // //           case "bar":
// // //             console.log(
// // //               "X-axis data before creating bar chart:",
// // //               formData.x_axis
// // //             ); // Add this log
// // //             chartData = await createBarChartRequest(
// // //               dataset,
// // //               filters,
// // //               chartMetric,
// // //               {
// // //                 dimensions: formData.dimensions,
// // //                 x_axis: formData["x-axis"], // Use formData.x_axis instead of xAxisData
// // //               },
// // //               defaultRowLimit,
// // //               showLegend,
// // //               showDataZoom,
// // //               legendOrientation,
// // //               legendType
// // //             );
// // //             break;
// // //           case "custom_bar":
// // //             console.log(
// // //               "X-axis data before creating custom bar chart:",
// // //               formData.x_axis
// // //             ); // Add this log
// // //             chartData = await createCustomBarChartRequest(
// // //               dataset,
// // //               filters,
// // //               chartMetric,
// // //               {
// // //                 dimensions: formData.dimensions,
// // //                 x_axis: formData["x-axis"], // Use formData.x_axis instead of xAxisData
// // //               },
// // //               defaultRowLimit,
// // //               showLegend,
// // //               showDataZoom,
// // //               legendOrientation,
// // //               legendType
// // //             );
// // //             break;
// // //           case "line":
// // //             chartData = await createLineChartRequest(
// // //               dataset,
// // //               filters,
// // //               chartMetric,
// // //               {
// // //                 dimensions: formData.dimensions,
// // //                 x_axis: formData["x-axis"], // Use formData.x_axis instead of xAxisData
// // //               },
// // //               defaultRowLimit,
// // //               showLegend,
// // //               showDataZoom,
// // //               legendOrientation,
// // //               legendType
// // //             );
// // //             break;
// // //           case "area":
// // //             chartData = await createAreaChartRequest(
// // //               dataset,
// // //               filters,
// // //               chartMetric,
// // //               {
// // //                 dimensions: formData.dimensions,
// // //                 x_axis: formData["x-axis"], // Use formData.x_axis instead of xAxisData
// // //               },
// // //               defaultRowLimit,
// // //               showLegend,
// // //               showDataZoom,
// // //               legendOrientation,
// // //               legendType
// // //             );
// // //             break;
// // //           case "table":
// // //             chartData = await createTableRequest(
// // //               dataset,
// // //               filters,
// // //               chartMetric,
// // //               {
// // //                 dimensions: formData.dimensions,
// // //               },
// // //               defaultRowLimit,
// // //               showLegend,
// // //               legendOrientation,
// // //               legendType
// // //             );
// // //             break;
// // //           case "pivot_table":
// // //             chartData = await createPivotTableRequest(
// // //               dataset,
// // //               filters,
// // //               chartMetric,
// // //               {
// // //                 dimensions: formData.dimensions,
// // //               },
// // //               defaultRowLimit,
// // //               showLegend,
// // //               legendOrientation,
// // //               legendType
// // //             );
// // //             break;
// // //           case "big_number":
// // //             chartData = await createBigNumberRequest(
// // //               dataset,
// // //               filters,
// // //               chartMetric,
// // //               {
// // //                 dimensions: formData.dimensions,
// // //                 x_axis: formData["x-axis"], // Use formData.x_axis instead of xAxisData
// // //               },
// // //               defaultRowLimit
// // //             );
// // //             break;
// // //           default:
// // //             throw new Error("Unsupported chart type: " + activeChartType);
// // //         }
// // //       } else if (activeTab === "ask-ai") {
// // //         // The chart creation is handled within the AskAITab component
// // //         return;
// // //       }

// // //       console.log("Chart data before sending:", { ...chartData, showDataZoom });
// // //       onChartCreated({
// // //         ...chartData,
// // //         showLegend,
// // //         legendOrientation,
// // //         legendType,
// // //         showDataZoom,
// // //         showLabelLines,
// // //       });
// // //     } catch (error) {
// // //       console.error("Error creating chart:", error);
// // //       setError("Failed to create chart. Please try again.");
// // //     } finally {
// // //       setIsLoading(false);
// // //     }
// // //   };

// // //   const SettingsIcon = () => (
// // //     <div className="flex items-center space-x-2">
// // //       <TooltipProvider>
// // //         <Tooltip>
// // //           <TooltipTrigger asChild></TooltipTrigger>
// // //           <TooltipContent>
// // //             <p>Customize</p>
// // //           </TooltipContent>
// // //         </Tooltip>
// // //       </TooltipProvider>
// // //       <Button
// // //         variant="ghost"
// // //         size="icon"
// // //         onClick={handleEditClick}
// // //         className="p-2"
// // //       >
// // //         <IconPencil size={24} style={{ color: "#682a7a" }} />
// // //       </Button>
// // //     </div>
// // //   );

// // //   return (
// // //     <div className="bg-white flex flex-col h-full w-80 border-r border-gray-200">
// // //       <div className="p-2 flex justify-between items-center">
// // //         <div className="w-80 ">
// // //           {/* <AskAITab onChartCreated={setChartData} /> */}

// // //           {renderChartDropdown()}
// // //         </div>
// // //         {/* <SettingsIcon /> */}
// // //       </div>
// // //       <div className="flex-grow overflow-y-auto bg-white">
// // //         <div className="p-2 bg-white">{renderActiveSection()}</div>
// // //       </div>
// // //       <div className="p-2 border-t border-gray-200 bg-white">
// // //         {error && <p className="text-red-500 mb-2">{error}</p>}
// // //         <Button
// // //           className="w-full bg-[#0047AB] text-white hover:bg-[#0047AB]"
// // //           onClick={handleCreateChart}
// // //           disabled={isLoading}
// // //         >
// // //           {isLoading ? "CREATING CHART..." : "CREATE CHART"}
// // //         </Button>
// // //       </div>
// // //       <ExpressionEditor
// // //         isOpen={isExpressionEditorOpen}
// // //         onClose={handleExpressionEditorClose}
// // //         onSave={handleExpressionEditorSave}
// // //         dataset={dataset}
// // //       />
// // //     </div>
// // //   );
// // // };

// // // export default ChartTabs;



// // // // <div
// // // //         ref={drop}
// // // //         className={`border border-gray-300 rounded-md overflow-hidden text-sm ${
// // // //           isOver ? "bg-blue-50" : "bg-white"
// // // //         }`}
// // // //       >
// // // //         {filterItem.length === 0 && filters.length === 0 ? (
// // // //           <div className="p-1 text-gray-400">{placeholder}</div>
// // // //         ) : (
// // // //           <div>
// // // //             {filterItem.map((item) => (
// // // //               <div
// // // //                 key={item.id || item.col}
// // // //                 className="flex items-center p-1 border-b border-gray-200 last:border-b-0"
// // // //               >
// // // //                 <Button
// // // //                   variant="icon"
// // // //                   className="text-black-500 hover:text-red-500 px-2 px-1"
// // // //                   onClick={() => handleRemoveItem(field.key, item.id || item.col)}
// // // //                 >
// // // //                   <IconX stroke={1.5} size={14} />
// // // //                 </Button>
// // // //                 <div className="flex-grow px-2 py-1 bg-white rounded text-gray-800">
// // // //                   {getDisplayText(item, field.key)}
// // // //                 </div>
// // // //                 {field.popover && (
// // // //                   <Popover
// // // //                     open={popoverSelections[item.id]?.isOpen}
// // // //                     onOpenChange={(open) =>
// // // //                       setPopoverSelections((prev) => ({
// // // //                         ...prev,
// // // //                         [item.id]: { ...prev[item.id], isOpen: open },
// // // //                       }))
// // // //                     }
// // // //                   ></Popover>










// // // import React, { useState, useEffect, ReactNode } from "react";
// // // import axios from "axios";
// // // import { useDrop } from "react-dnd";
// // // import {
// // //   IconX,
// // //   IconArrowBarToRight,
// // //   IconPencil,
// // //   IconSettings,
// // // } from "@tabler/icons-react";
// // // import {
// // //   Popover,
// // //   PopoverContent,
// // //   PopoverTrigger,
// // // } from "../../../../../@/components/ui/popover";
// // // import { Button } from "../../../../../@/components/ui/button";
// // // import { Label } from "../../../../../@/components/ui/label";
// // // import {
// // //   Select,
// // //   SelectContent,
// // //   SelectGroup,
// // //   SelectItem,
// // //   SelectLabel,
// // //   SelectTrigger,
// // //   SelectValue,
// // // } from "../../../../../@/components/ui/select";
// // // import {
// // //   Card,
// // //   CardContent,
// // //   CardFooter,
// // // } from "../../../../../@/components/ui/card";
// // // import { createPieChart } from "../ChartRequests/PieChartRequest";
// // // import { createBarChartRequest } from "../ChartRequests/BarChartRequest";
// // // import { createBigNumberRequest } from "../ChartRequests/BigNumberChartRequest";
// // // import { createLineChartRequest } from "../ChartRequests/LineChartRequest";
// // // import { createAreaChartRequest } from "../ChartRequests/AreaChartRequest";
// // // import { createTableRequest } from "../ChartRequests/TableRequest";
// // // import ExpressionEditor from "./ExpressionEditor";
// // // import {
// // //   Tooltip,
// // //   TooltipContent,
// // //   TooltipProvider,
// // //   TooltipTrigger,
// // // } from "../../../../../@/components/ui/tooltip";
// // // import MultiSelect from "../../../../../@/components/ui/multi-select";
// // // import { createPivotTableRequest } from "../ChartRequests/PivotTableRequest";
// // // import {
// // //   Tabs,
// // //   TabsContent,
// // //   TabsList,
// // //   TabsTrigger,
// // // } from "../../../../../@/components/ui/tabs";
// // // import { useLocation } from "react-router-dom";
// // // import { createDonutChart } from "../ChartRequests/DonutChartRequest";
// // // import { createCustomBarChartRequest } from "../ChartRequests/CustomBarChartRequest";
// // // import { useSelector } from "react-redux";
// // // import { RootState } from "../../../../../redux/store";
// // // // Import all chart images
// // // import BarChart from "../../../../../assets/viz_thumbnails/bar.png";
// // // import PieChart from "../../../../../assets/viz_thumbnails/pie.png";
// // // import LineChart from "../../../../../assets/viz_thumbnails/line.png";
// // // import AreaChart from "../../../../../assets/viz_thumbnails/area.png";
// // // import SunburstChart from "../../../../../assets/viz_thumbnails/sunburst.png";
// // // import BigNumber from "../../../../../assets/viz_thumbnails/big_number.png";
// // // import CustomTable from "../../../../../assets/viz_thumbnails/table.png";
// // // import PivotTable from "../../../../../assets/viz_thumbnails/pivot_table.png";
// // // import DonutChart from "../../../../../assets/viz_thumbnails/donut.png";
// // // import CustomBarChart from "../../../../../assets/viz_thumbnails/custom_bar.png";

// // // interface DroppedItem {
// // //   id: string;
// // //   name: string;
// // //   type: string;
// // //   aggregate?: string;
// // //   label?: string;
// // // }
// // // interface Option {
// // //   value: string;
// // //   label: string;
// // // }

// // // interface ChartType {
// // //   unique_id: string;
// // //   name: string;
// // //   icon: string; // Changed from ReactNode to string
// // //   hasData?: boolean;
// // // }

// // // interface FormField {
// // //   key: string;
// // //   label: string;
// // //   type: string;
// // //   placeholder?: string;
// // //   options?: string[];
// // //   popover?: {
// // //     [key: string]: any[];
// // //   };
// // // }

// // // interface ChartForm {
// // //   parameters: FormField[];
// // // }

// // // interface ChartTabsProps {
// // //   dataset: string;
// // //   chartType: string;
// // //   onChartCreated: (chartOptions: any) => void;
// // //   onThemeChange: (theme: string) => void;
// // //   selectedTheme: string;
// // //   onClearChartPreview: () => void; // Add this line
// // // }
// // // interface Column {
// // //   name: string;
// // //   type: string;
// // // }

// // // interface Dimension {
// // //   id: string;
// // //   name: string;
// // //   type?: string;
// // // }
// // // interface Metric {
// // //   expression_type: string;
// // //   column: {
// // //     column_name: string;
// // //     type: string;
// // //   };
// // //   aggregate: string;
// // //   label: string;
// // // }

// // // interface Filter {
// // //   id: string;
// // //   col?: string;
// // //   op?: string;
// // //   val?: string[];
// // //   alias?: string; // Add this line
// // // }
// // // interface FormData {
// // //   dimensions?: DroppedItem[];
// // //   metrics?: DroppedItem[];
// // //   x_axis?: DroppedItem;
// // //   [key: string]: any;
// // // }
// // // const ChartTabs: React.FC<ChartTabsProps> = ({
// // //   dataset,
// // //   chartType,
// // //   onChartCreated,
// // //   onThemeChange,
// // //   selectedTheme,
// // //   onClearChartPreview, // Add this line
// // // }) => {
// // //   let [activeChartType, setActiveChartType] = useState<string>("");
// // //   const [chartTypes, setChartTypes] = useState<ChartType[]>([]);
// // //   const [chartForms, setChartForms] = useState<{ [key: string]: ChartForm }>(
// // //     {}
// // //   );
// // //   const [columns, setColumns] = useState<Column[]>([]);
// // //   const [formData, setFormData] = useState<{ [key: string]: any }>({});
// // //   const [popoverSelections, setPopoverSelections] = useState<{
// // //     [key: string]: any;
// // //   }>({});
// // //   const [uniqueValues, setUniqueValues] = useState<any>({});
// // //   let [defaultRowLimit, setDefaultRowLimit] = useState(10);
// // //   let [chartMetric, setChartMetric] = useState<Metric | null>(null);
// // //   let [filters, setFilters] = useState<Filter[]>([]);
// // //   const [chartDataModel, setChartDataModel] = useState<any>(null);
// // //   const [isLoading, setIsLoading] = useState(false);
// // //   const [error, setError] = useState<string | null>(null);
// // //   const [showLegend, setShowLegend] = useState(true);
// // //   const [legendOrientation, setLegendOrientation] = useState("top");
// // //   const [legendType, setLegendType] = useState("scroll");
// // //   const [showDataZoom, setShowDataZoom] = useState(false);
// // //   const [isExpressionEditorOpen, setIsExpressionEditorOpen] = useState(false);
// // //   const [showLabelLines, setShowLabelLines] = useState(false);
// // //   const [activeTab, setActiveTab] = useState<string>("default");
// // //   const [isChartCreated, setIsChartCreated] = useState(false);
// // //   const location = useLocation();
// // //   const { state } = location;
// // //   const [chartData, setChartData] = useState(null);
// // //   let [xAxisData, setXAxisData] = useState<any>(null);

// // //   const chartDetails: any = useSelector((state: RootState) => state.chart);

// // //   const handleEditClick = () => {
// // //     setIsExpressionEditorOpen(true);
// // //   };

// // //   const handleExpressionEditorClose = () => {
// // //     setIsExpressionEditorOpen(false);
// // //   };

// // //   const handleExpressionEditorSave = () => {
// // //     // Handle saving the expressions
// // //     setIsExpressionEditorOpen(false);
// // //   };

// // //   useEffect(() => {
// // //     fetchChartTypes();
// // //     fetchTableData();
// // //   }, [dataset]);

// // //   useEffect(() => {
// // //     if(chartDetails?.id) {
// // //       const { chart } = chartDetails;
// // //       const { queries, form_data } = chart?.params;
// // //       const { metrics } = queries[0];
// // //       const { filters: chartFilters } = queries[0];
// // //       if (metrics && metrics.length > 0) {
// // //         setChartMetric(metrics[0]);
// // //       }
  
// // //       saveMetric(
// // //         metrics[0]?.column?.column_name, metrics[0]?.aggregate, 
// // //         { id: metrics[0]?.column?.column_name, name: metrics[0]?.column?.column_name, type: metrics[0]?.column?.type}, 
// // //         ""
// // //       );
// // //       setTimeout(() => {
// // //         // setChartMetric(metrics[0]);
// // //         chartMetric = metrics[0];
// // //         setFilters(chartFilters);
// // //         filters = chartFilters;
// // //         activeChartType = chart.visualization_name;
// // //         defaultRowLimit = queries[0].row_limit.toString();
// // //         formData.dimensions = form_data?.groupby || [];
// // //         xAxisData = form_data?.x_axis || {};
// // //         formData["x-axis"] = form_data?.x_axis || {};
// // //       }, 1000);

// // //       setTimeout(() => {
// // //         handleCreateChart();
// // //       }, 2000);
// // //     }
// // //   }, [chartDetails]);

// // //   useEffect(() => {
// // //     if (state && state.chart) {
// // //       setActiveChartType(state.chart?.visualization_name);
// // //     }
// // //   }, [state]);
// // //   const fetchChartTypes = async () => {
// // //     try {
// // //       const response = await axios.post("/api/charts/dashboard_charts", {});
// // //       const allChartTypes = response.data.data.flatMap(
// // //         (section: any) => section.components
// // //       );

// // //       const filteredChartTypes = allChartTypes.filter((chart: ChartType) => {
// // //         if (chart.name.toLowerCase() === "sunburst chart") {
// // //           return chart.hasData === true;
// // //         }
// // //         return true;
// // //       });

// // //       const chartTypesWithIcons = filteredChartTypes.map(
// // //         (chart: ChartType) => ({
// // //           ...chart,
// // //           icon: getChartIcon(chart.name),
// // //         })
// // //       );

// // //       setChartTypes(chartTypesWithIcons);
// // //       if (chartTypesWithIcons.length > 0 && !state?.chart) {
// // //         setActiveChartType(chartTypesWithIcons[0].unique_id);
// // //       }
// // //       fetchChartForms(chartTypesWithIcons);
// // //     } catch (error) {
// // //       console.error("Error fetching chart types:", error);
// // //     }
// // //   };

// // //   const getChartIcon = (chartName: string): string => {
// // //     switch (chartName.toLowerCase()) {
// // //       case "bar chart":
// // //         return BarChart;
// // //       case "custom bar chart":
// // //         return CustomBarChart;
// // //       case "line chart":
// // //         return LineChart;
// // //       case "area chart":
// // //         return AreaChart;
// // //       case "pie chart":
// // //         return PieChart;
// // //       case "table":
// // //         return CustomTable;
// // //       case "big number":
// // //         return BigNumber;
// // //       case "donut chart":
// // //         return DonutChart;
// // //       case "sunburst chart":
// // //         return SunburstChart;
// // //       case "pivot table":
// // //         return PivotTable;
// // //       default:
// // //         return CustomTable; // Default to table icon
// // //     }
// // //   };

// // //   const fetchChartForms = async (chartTypes: ChartType[]) => {
// // //     const forms: { [key: string]: ChartForm } = {};
// // //     for (const chart of chartTypes) {
// // //       try {
// // //         const response = await axios.post("/api/charts/get_chart_form", {
// // //           unique_id: chart.unique_id,
// // //         });
// // //         forms[chart.unique_id] = response.data.data;
// // //       } catch (error) {
// // //         console.error(`Error fetching form for ${chart.unique_id}:`, error);
// // //       }
// // //     }
// // //     setChartForms(forms);
// // //   };

// // //   const fetchTableData = async () => {
// // //     let params = {
// // //       database: "zolix_c2o",
// // //       schema: "public",
// // //       table: dataset,
// // //     };
// // //     try {
// // //       const response = await axios.post("/api/charts/get_columns", params);
// // //       const columnData: Column[] = response.data.data.map((col: any) => ({
// // //         name: col.name,
// // //         type: col.type,
// // //       }));
// // //       setColumns(columnData);
// // //       // Fetch unique values for each column
// // //       columnData.forEach((column: Column) => fetchUniqueValues(column.name));
// // //     } catch (error) {
// // //       console.error("Error fetching columns:", error);
// // //       alert(
// // //         "Failed to fetch columns. Please check the console for more details."
// // //       );
// // //     }
// // //   };

// // //   const fetchUniqueValues = async (column: string) => {
// // //     try {
// // //       const response = await axios.post("/api/charts/get_unique_values", {
// // //         database: "zolix_c2o",
// // //         schema: "public",
// // //         table: dataset,
// // //         column: [column],
// // //       });

// // //       setUniqueValues((prev) => ({
// // //         ...prev,
// // //         ...response.data.data,
// // //       }));
// // //     } catch (error) {
// // //       console.error(`Error fetching unique values for ${column}:`, error);
// // //     }
// // //   };
// // //   const handleChartTypeChange = (type: string) => {
// // //     setActiveChartType(type);
// // //     // Reset form data when changing chart type
// // //     setFormData({});
// // //     setChartMetric(null);
// // //     setFilters([]);
// // //   };
// // //   const handleFormChange = (key: string, value: any, openPopover = false) => {
// // //     if (key === "filters") {
// // //       if (Array.isArray(value)) {
// // //         setFilters(value);
// // //       } else if (value) {
// // //         setFilters((prevFilters) => [...prevFilters, value]);
// // //       }
// // //     } else if (key === "x_axis") {
// // //       // Only update x_axis if the value is explicitly set for x_axis
// // //       setFormData((prevData) => ({
// // //         ...prevData,
// // //         x_axis: value,
// // //       }));
// // //       if (value) {
// // //         setXAxisData({
// // //           name: value.name,
// // //           label: value.name,
// // //           sort_ascending: true,
// // //         });
// // //       } else {
// // //         setXAxisData(null);
// // //       }
// // //     } else {
// // //       setFormData((prevData) => ({
// // //         ...prevData,
// // //         [key]: value,
// // //       }));
// // //     }

// // //     if (openPopover && value) {
// // //       if (!Array.isArray(value)) {
// // //         setPopoverSelections((prev) => ({
// // //           ...prev,
// // //           [value.id]: { isOpen: true, column: value.name },
// // //         }));
// // //       } else if (Array.isArray(value) && value.length > 0) {
// // //         const lastItem = value[value.length - 1];
// // //         setPopoverSelections((prev) => ({
// // //           ...prev,
// // //           [lastItem.id]: { isOpen: true, column: lastItem.name },
// // //         }));
// // //       }
// // //     }
// // //   };
// // //   const handleRemoveItem = (key: string, id?: string) => {
// // //     if (key === "filters") {
// // //       setFilters((prevFilters) => prevFilters.filter((filter) => filter.id !== id));
// // //     } else if (key === "x_axis") {
// // //       setFormData((prevData) => {
// // //         const { x_axis, ...rest } = prevData;
// // //         return rest;
// // //       });
// // //       setXAxisData(null);
// // //     } else if (key === "metric" || key === "metrics") {
// // //       setFormData((prevData) => {
// // //         const { [key]: _, ...rest } = prevData;
// // //         return rest;
// // //       });
// // //       setChartMetric(null);
// // //     } else {
// // //       setFormData((prevData) => {
// // //         if (Array.isArray(prevData[key])) {
// // //           return {
// // //             ...prevData,
// // //             [key]: prevData[key].filter((item: DroppedItem) => item.id !== id),
// // //           };
// // //         } else {
// // //           const { [key]: _, ...rest } = prevData;
// // //           return rest;
// // //         }
// // //       });
// // //     }
  
// // //     if (id) {
// // //       setPopoverSelections((prev) => {
// // //         const { [id]: _, ...rest } = prev;
// // //         return rest;
// // //       });
// // //     }
// // //   };
// // //   const handlePopoverSave = (fieldKey: string, itemId: string, data: any) => {
// // //     console.log("Handling popover save:", fieldKey, itemId, data);

// // //     let savedData: any = {
// // //       id: data.id,
// // //       type: data.type,
// // //       column: data.column,
// // //       alias: data.alias,
// // //       aggregate: data.aggregate,
// // //       operator: data.operator,
// // //       value: data.value,
// // //     };
// // //     let displayText = data.alias || data.column;

// // //     switch (fieldKey) {
// // //       case "x_axis":
// // //         displayText = data.alias || data.column;
// // //         setXAxisData({
// // //           name: data.column,
// // //           label: data.alias || data.column,
// // //           sort_ascending: true,
// // //         });
// // //         setFormData((prevData) => ({
// // //           ...prevData,
// // //           x_axis: {
// // //             name: data.column,
// // //             label: data.alias || data.column,
// // //             sort_ascending: true,
// // //           },
// // //         }));
// // //         break;
// // //       case "metric":
// // //         displayText =
// // //           data.alias ||
// // //           (data.aggregate && data.column
// // //             ? `${data.column} (${data.aggregate})`
// // //             : data.column);
// // //         // Set chartMetric for the bar chart
// // //         const columnData = columns.find((col) => col.name === data.column);
// // //         setChartMetric({
// // //           expression_type: "SIMPLE",
// // //           column: {
// // //             column_name: data.column,
// // //             type: columnData?.type || "UNKNOWN",
// // //           },
// // //           aggregate: data.aggregate,
// // //           label: data.alias || data.column,
// // //         });
// // //         break;
// // //       case "metrics":
// // //         displayText =
// // //           data.alias ||
// // //           (data.aggregate && data.column
// // //             ? `${data.column} (${data.aggregate})`
// // //             : data.column);
// // //         const columnsData = columns.find((col) => col.name === data.column);
// // //         setChartMetric({
// // //           expression_type: "SIMPLE",
// // //           column: {
// // //             column_name: data.column,
// // //             type: columnsData?.type || "UNKNOWN",
// // //           },
// // //           aggregate: data.aggregate,
// // //           label: data.alias || data.column,
// // //         });
// // //         break;
// // //       case "dimensions":
// // //         displayText = data.alias || data.column;
// // //         // Update dimensions in formData
// // //         setFormData((prevData) => {
// // //           const updatedDimensions = Array.isArray(prevData.dimensions)
// // //             ? prevData.dimensions.map((dim: any) =>
// // //                 dim.id === itemId
// // //                   ? { ...dim, name: data.column, alias: data.alias }
// // //                   : dim
// // //               )
// // //             : [];
// // //           return { ...prevData, dimensions: updatedDimensions };
// // //         });
// // //         break;
// // //       case "filters":
// // //         displayText = `${data.alias || data.column} ${data.operator} (${
// // //           Array.isArray(data.value) ? data.value.join(", ") : data.value
// // //         })`;
// // //         handleFilterChange(
// // //           itemId,
// // //           data.column,
// // //           data.operator,
// // //           Array.isArray(data.value) ? data.value : [data.value],
// // //           data.alias
// // //         );
// // //         break;
// // //       default:
// // //         displayText = data.alias || data.column;
// // //     }
// // //     setPopoverSelections((prev) => ({
// // //       ...prev,
// // //       [itemId]: { ...savedData, isOpen: false },
// // //     }));

// // //     console.log("Saved x-axis data:", formData.x_axis); // Add this log
// // //   };

// // //   const saveMetric = (
// // //     selectedColumn: string,
// // //     selectedAggregate: string,
// // //     item: DroppedItem,
// // //     alias: string
// // //   ) => {
// // //     if (!selectedColumn || !selectedAggregate || !item) {
// // //       alert("Please select a column and aggregate function.");
// // //       return;
// // //     }
// // //     const columnData = columns.find((col) => col.name === selectedColumn);
// // //     const newMetric: Metric = {
// // //       expression_type: "SIMPLE",
// // //       column: {
// // //         column_name: selectedColumn,
// // //         type: columnData ? columnData.type : "UNKNOWN",
// // //       },
// // //       aggregate: selectedAggregate,
// // //       label: alias || selectedColumn,
// // //     };
// // //     setChartMetric(newMetric);
// // //   };
// // //   const handleFilterChange = (
// // //     id: string,
// // //     col?: string,
// // //     op?: string,
// // //     val?: string[],
// // //     alias?: string
// // //   ) => {
// // //     setFilters((prevFilters) => {
// // //       const existingFilterIndex = prevFilters.findIndex(
// // //         (filter) => filter.id === id
// // //       );
// // //       const columnData = columns.find((column) => column.name === col);
// // //       const newFilter = {
// // //         id,
// // //         col: col || "",
// // //         op: op || "",
// // //         val: val || [],
// // //         alias: alias || "",
// // //         type: columnData ? columnData.type : "UNKNOWN",
// // //       };
// // //       if (existingFilterIndex !== -1) {
// // //         // Update existing filter
// // //         const updatedFilters = [...prevFilters];
// // //         updatedFilters[existingFilterIndex] = newFilter;
// // //         return updatedFilters;
// // //       } else {
// // //         // Add new filter
// // //         return [...prevFilters, newFilter];
// // //       }
// // //     });
// // //   };

// // //   const getDisplayText = (item: any, fieldKey: string) => {
// // //     if (fieldKey === "x_axis" && item) {
// // //       return item.name || item.label || "X-Axis";
// // //     }
// // //     if (fieldKey === "metrics" || fieldKey === "metric") {
// // //       // Check if the item is from Redux
// // //       if (item.column && item.aggregate) {
// // //         return `${item.column.column_name} (${item.aggregate})`;
// // //       }
// // //       // Check if the item is from popover selections
// // //       const selection = popoverSelections[item.id];
// // //       if (selection) {
// // //         const aggregate = selection.aggregate || "";
// // //         const column = selection.column || "";
// // //         const alias = selection.alias || "";
// // //         return alias || (aggregate ? `${column} (${aggregate})` : column);
// // //       }
// // //       // Fallback to item properties if neither Redux nor popover data is available
// // //       return item.label || (item.aggregate ? `${item.name} (${item.aggregate})` : item.name);
// // //     }
// // //     if (fieldKey === "dimensions" && item) {
// // //       const selection = popoverSelections[item.id];
// // //       return selection?.alias || item.name;
// // //     }
// // //     if (fieldKey === "filters" && item) {
// // //       const selection = popoverSelections[item.id];
// // //       if (selection) {
// // //         const column = selection.column || item.name || "";
// // //         const operator = selection.operator || "";
// // //         const value = Array.isArray(selection.value)
// // //           ? selection.value.map((v: Option) => v.value || v).join(", ")
// // //           : selection.value || "";
// // //         return `${column} ${operator} ${value ? `(${value})` : ""}`;
// // //       } else {
// // //         const column = item.col || "";
// // //         const operator = item.op || "";
// // //         const value = Array.isArray(item.val)
// // //           ? item.val.join(", ")
// // //           : item.val || "";
// // //         return `${column} ${operator} ${value ? `(${value})` : ""}`;
// // //       }
// // //     }
// // //     return item.name || "";
// // //   };
// // //   const renderChartDropdown = () => (
// // //     <Select value={activeChartType} onValueChange={handleChartTypeChange}>
// // //       <SelectTrigger className="w-full">
// // //         <SelectValue placeholder="Select a chart type">
// // //           {activeChartType && (
// // //             <div className="flex items-center">
// // //               <img
// // //                 src={
// // //                   chartTypes.find((ct) => ct.unique_id === activeChartType)
// // //                     ?.icon
// // //                 }
// // //                 alt={
// // //                   chartTypes.find((ct) => ct.unique_id === activeChartType)
// // //                     ?.name
// // //                 }
// // //                 className="w-6 h-6 mr-2"
// // //               />
// // //               <span>
// // //                 {
// // //                   chartTypes.find((ct) => ct.unique_id === activeChartType)
// // //                     ?.name
// // //                 }
// // //               </span>
// // //             </div>
// // //           )}
// // //         </SelectValue>
// // //       </SelectTrigger>
// // //       <SelectContent>
// // //         {chartTypes.map((chartType) => (
// // //           <SelectItem key={chartType.unique_id} value={chartType.unique_id}>
// // //             <div className="flex items-center">
// // //               <img
// // //                 src={chartType.icon}
// // //                 alt={chartType.name}
// // //                 className="w-6 h-6 mr-2"
// // //               />
// // //               <span>{chartType.name}</span>
// // //             </div>
// // //           </SelectItem>
// // //         ))}
// // //       </SelectContent>
// // //     </Select>
// // //   );
// // //   const DynamicPopoverContent: React.FC<{
// // //     field: FormField;
// // //     item: DroppedItem;
// // //     onClose: () => void;
// // //     onSave: (data: any) => void;
// // //   }> = ({ field, item, onClose, onSave }) => {
// // //     const storedData = popoverSelections[item.id] || {};
// // //     const [popoverData, setPopoverData] = useState<{
// // //       [key: string]: string | any;
// // //     }>({
// // //       columns: storedData.column || item.name,
// // //       aggregate: storedData.aggregate || "",
// // //       operator: storedData.operator || "",
// // //       value: storedData.value || [],
// // //       row_limit: defaultRowLimit,
// // //       alias: storedData.alias || "",
// // //     });

// // //     const handlePopoverChange = (key: string, value: string | Option[]) => {
// // //       setPopoverData((prev) => ({ ...prev, [key]: value }));
// // //     };

// // //     const handleSave = () => {
// // //       try {
// // //         const baseData = {
// // //           id: item.id,
// // //           type: item.type,
// // //           column: popoverData["columns"],
// // //           alias: popoverData["alias"],
// // //         };

// // //         let saveData;
// // //         switch (field.key) {
// // //           case "metrics":
// // //           case "metric":
// // //             saveData = {
// // //               ...baseData,
// // //               aggregate: popoverData["aggregate"],
// // //             };
// // //             break;
// // //           case "filters":
// // //             saveData = {
// // //               ...baseData,
// // //               operator: popoverData["operator"],
// // //               value: Array.isArray(popoverData["value"])
// // //                 ? popoverData["value"].map((option: Option) => option.value)
// // //                 : popoverData["value"],
// // //             };
// // //             break;
// // //           default:
// // //             saveData = baseData;
// // //         }

// // //         console.log("Saving popover data:", saveData);
// // //         onSave(saveData);
// // //         onClose(); // Close the popover after successful save
// // //       } catch (error) {
// // //         console.error("Error saving popover data:", error);
// // //         // You might want to show an error message to the user here
// // //       }
// // //     };

// // //     const renderPopoverField = (popoverField: any) => {
// // //       switch (popoverField.key) {
// // //         case "columns":
// // //         case "operator":
// // //         case "aggregate":
// // //           return (
// // //             <Select
// // //               value={popoverData[popoverField.key] as string}
// // //               onValueChange={(value) =>
// // //                 handlePopoverChange(popoverField.key, value)
// // //               }
// // //             >
// // //               <SelectTrigger className="w-full">
// // //                 <SelectValue placeholder={popoverField.placeholder} />
// // //               </SelectTrigger>
// // //               <SelectContent>
// // //                 {popoverField.key === "columns"
// // //                   ? columns.map((column: Column) => (
// // //                       <SelectItem key={column.name} value={column.name}>
// // //                         {column.name}
// // //                       </SelectItem>
// // //                     ))
// // //                   : popoverField.options
// // //                       ?.filter((option: string) => option !== "")
// // //                       .map((option: string) => (
// // //                         <SelectItem key={option} value={option}>
// // //                           {option}
// // //                         </SelectItem>
// // //                       ))}
// // //               </SelectContent>
// // //             </Select>
// // //           );
// // //         case "value":
// // //           if (popoverData["columns"]) {
// // //             const options = (
// // //               Array.isArray(uniqueValues[popoverData["columns"] as string])
// // //                 ? uniqueValues[popoverData["columns"] as string].filter(
// // //                     (value: string) => value !== ""
// // //                   )
// // //                 : []
// // //             ).map((value: string) => ({ value, label: value }));

// // //             return (
// // //               <MultiSelect
// // //                 options={options}
// // //                 value={popoverData[popoverField.key]}
// // //                 onChange={(selected: Option[]) =>
// // //                   handlePopoverChange(popoverField.key, selected)
// // //                 }
// // //               />
// // //             );
// // //           }
// // //           return null;
// // //         case "alias":
// // //           return (
// // //             <input
// // //               type="text"
// // //               value={popoverData[popoverField.key] as string}
// // //               onChange={(e) =>
// // //                 handlePopoverChange(popoverField.key, e.target.value)
// // //               }
// // //               placeholder="Enter alias"
// // //               className="w-full p-2 border rounded"
// // //             />
// // //           );
// // //         default:
// // //           return (
// // //             <input
// // //               type="text"
// // //               value={popoverData[popoverField.key] as string}
// // //               onChange={(e) =>
// // //                 handlePopoverChange(popoverField.key, e.target.value)
// // //               }
// // //               placeholder={popoverField.placeholder}
// // //               className="w-full p-2 border rounded"
// // //             />
// // //           );
// // //       }
// // //     };

// // //     return (
// // //       <Tabs defaultValue="SIMPLE" className="w-full">
// // //         <TabsList
// // //           className={`grid w-full ${
// // //             Object.keys(field.popover || {}).length === 1
// // //               ? "grid-cols-1"
// // //               : "grid-cols-2"
// // //           }`}
// // //         >
// // //           {Object.keys(field.popover || {}).map((tabKey) => (
// // //             <TabsTrigger
// // //               key={tabKey}
// // //               value={tabKey}
// // //               className={tabKey === "SIMPLE" ? "shadow-lg" : ""}
// // //             >
// // //               {tabKey}
// // //             </TabsTrigger>
// // //           ))}
// // //         </TabsList>

// // //         {Object.entries(field.popover || {}).map(([tabKey, tabFields]) => (
// // //           <TabsContent key={tabKey} value={tabKey}>
// // //             <Card className="border-none shadow-none mt-2">
// // //               <CardContent>
// // //                 <div className="grid gap-4">
// // //                   {tabFields.map((popoverField: any) => (
// // //                     <div key={popoverField.key} className="grid gap-2">
// // //                       <Label>{popoverField.label}</Label>
// // //                       {renderPopoverField(popoverField)}
// // //                     </div>
// // //                   ))}
// // //                 </div>
// // //               </CardContent>
// // //               <CardFooter className="flex justify-between">
// // //                 <Button
// // //                   className="bg-slate-400 hover:bg-slate-600"
// // //                   onClick={onClose}
// // //                 >
// // //                   Close
// // //                 </Button>
// // //                 <Button
// // //                   className="bg-slate-400 hover:bg-slate-600"
// // //                   onClick={handleSave}
// // //                 >
// // //                   Save
// // //                 </Button>
// // //               </CardFooter>
// // //             </Card>
// // //           </TabsContent>
// // //         ))}
// // //       </Tabs>
// // //     );
// // //   };
// // //   const SingleDropZone: React.FC<{
// // //     onDrop: (item: DroppedItem) => void;
// // //     item: DroppedItem | null;
// // //     onRemove: () => void;
// // //     placeholder: string;
// // //     field: FormField;
// // //     acceptTypes: string[];
// // //   }> = ({ onDrop, item, onRemove, placeholder, field, acceptTypes }) => {
// // //       const [{ isOver }, drop] = useDrop(() => ({
// // //       accept: acceptTypes,
// // //       drop: (droppedItem: DroppedItem) => {
// // //         onDrop(droppedItem);
// // //         setPopoverSelections((prev) => ({
// // //           ...prev,
// // //           [droppedItem.id]: { ...prev[droppedItem.id], isOpen: true },
// // //         }));
// // //       },
// // //       collect: (monitor) => ({
// // //         isOver: !!monitor.isOver(),
// // //       }),
// // //     }));
// // //     const isReduxMetric = field.key === "metric" && item && 'column' in item && 'aggregate' in item;

  
// // //     return (
// // //       <div
// // //         ref={drop}
// // //         className={`border border-gray-300 rounded-md overflow-hidden text-sm ${
// // //           isOver ? "bg-blue-50" : "bg-white"
// // //         }`}
// // //       >
// // //         {!item ? (
// // //           <div className="p-1 text-gray-400">{placeholder}</div>
// // //         ) : (
// // //           <div className="flex items-center p-1 border-gray-200">
// // //             <Button
// // //               variant="icon"
// // //               className="text-gray-500 hover:text-red-500 px-2 px-1"
// // //               onClick={() => {
// // //                 onRemove();
// // //                 handleRemoveItem(field.key, item.id);
// // //               }}
// // //             >
// // //               <IconX stroke={1.5} size={14} />
// // //             </Button>
// // //           <div className="flex-grow px-2 py-1 bg-white rounded text-gray-800">
// // //             {getDisplayText(item, field.key)}
// // //             </div>
// // //             {field.popover && (
// // //               <Popover
// // //                 open={popoverSelections[item.id]?.isOpen}
// // //                 onOpenChange={(open) =>
// // //                   setPopoverSelections((prev) => ({
// // //                     ...prev,
// // //                     [item.id]: { ...prev[item.id], isOpen: open },
// // //                   }))
// // //                 }
// // //               >
// // //                 <PopoverTrigger asChild>
// // //                   <Button variant="icon" className="px-2 px-1">
// // //                     <IconArrowBarToRight stroke={1.5} size={14} />
// // //                   </Button>
// // //                 </PopoverTrigger>
// // //                 <PopoverContent className="w-96 bg-white border border-gray-300">
// // //                   <DynamicPopoverContent
// // //                     field={field}
// // //                     item={item}
// // //                     onClose={() =>
// // //                       setPopoverSelections((prev) => ({
// // //                         ...prev,
// // //                         [item.id]: { ...prev[item.id], isOpen: false },
// // //                       }))
// // //                     }
// // //                     onSave={(data) => {
// // //                       handlePopoverSave(field.key, item.id, data);
// // //                     }}
// // //                   />
// // //                 </PopoverContent>
// // //               </Popover>
// // //             )}
// // //           </div>
// // //         )}
// // //       </div>
// // //     );
// // //   };
// // //   const MultipleDropZone: React.FC<{
// // //     onDrop: (item: DroppedItem) => void;
// // //     items: DroppedItem[];
// // //     onRemove: (key: string, id: string) => void;
// // //     placeholder: string;
// // //     field: FormField;
// // //     acceptTypes: string[];
// // //   }> = ({ onDrop, items, onRemove, placeholder, field, acceptTypes }) => {
// // //     const [{ isOver }, drop] = useDrop(() => ({
// // //       accept: acceptTypes,
// // //       drop: (item: DroppedItem) => {
// // //         const newItem = { ...item, id: `${item.id}_${Date.now()}` }; // Create a new unique ID
// // //         onDrop(newItem);
// // //         setPopoverSelections((prev) => ({
// // //           ...prev,
// // //           [newItem.id]: { ...prev[newItem.id], isOpen: true },
// // //         }));
// // //       },
// // //       collect: (monitor) => ({
// // //         isOver: !!monitor.isOver(),
// // //       }),
// // //     }));

// // //     const displayItems = field.key === "filters" ? filters : items;
// // //     return (
// // //       <div
// // //         ref={drop}
// // //         className={`border border-gray-300 rounded-md overflow-hidden text-sm ${
// // //           isOver ? "bg-blue-50" : "bg-white"
// // //         }`}
// // //       >
// // //         {displayItems.length === 0 ? (
// // //           <div className="p-1 text-gray-400">{placeholder}</div>
// // //         ) : (
// // //           <div>
// // //             {displayItems.map((item) => (
// // //               <div
// // //                 key={item.id || item.col}
// // //                 className="flex items-center p-1 border-b border-gray-200 last:border-b-0"
// // //               >
// // //                 <Button
// // //                   variant="icon"
// // //                   className="text-black-500 hover:text-red-500 px-2 px-1"
// // //                   onClick={() => {
// // //                     onRemove(field.key, item.id || item.col);
// // //                     handleRemoveItem(field.key, item.id || item.col);
// // //                   }}
// // //                 > 
// // //                   <IconX stroke={1.5} size={14} />
// // //                 </Button>

// // //                 <div className="flex-grow px-2 py-1 bg-white rounded text-gray-800">
// // //                   {getDisplayText(item, field.key)}
// // //                 </div>
// // //                 {field.popover && (
// // //                   <Popover
// // //                     open={popoverSelections[item.id]?.isOpen}
// // //                     onOpenChange={(open) =>
// // //                       setPopoverSelections((prev) => ({
// // //                         ...prev,
// // //                         [item.id]: { ...prev[item.id], isOpen: open },
// // //                       }))
// // //                     }
// // //                   >
// // //                     <PopoverTrigger asChild>
// // //                       <Button variant="icon" className="px-2 px-1">
// // //                         <IconArrowBarToRight stroke={1.5} size={14} />
// // //                       </Button>
// // //                     </PopoverTrigger>
// // //                     <PopoverContent className="w-96">
// // //                       <DynamicPopoverContent
// // //                         field={field}
// // //                         item={item}
// // //                         onClose={() =>
// // //                           setPopoverSelections((prev) => ({
// // //                             ...prev,
// // //                             [item.id]: { ...prev[item.id], isOpen: false },
// // //                           }))
// // //                         }
// // //                         onSave={(data) => {
// // //                           handlePopoverSave(field.key, item.id, data);
// // //                         }}
// // //                       />
// // //                     </PopoverContent>
// // //                   </Popover>
// // //                 )}
// // //               </div>
// // //             ))}
// // //           </div>
// // //         )}
// // //       </div>
// // //     );
// // //   };

// // //   const renderFormField = (field: FormField) => {
// // //     switch (field.type) {
// // //       case "select":
// // //         return (
// // //           <Select
// // //             value={formData[field.key] || ""}
// // //             onValueChange={(value) => handleFormChange(field.key, value)}
// // //           >
// // //             <SelectTrigger className="w-full bg-white">
// // //               <SelectValue
// // //                 placeholder={field.placeholder || `Select ${field.label}`}
// // //               />
// // //             </SelectTrigger>
// // //             <SelectContent>
// // //               <SelectGroup>
// // //                 <SelectLabel>{field.label}</SelectLabel>
// // //                 {field.options?.map((option) => (
// // //                   <SelectItem key={option} value={option}>
// // //                     {option}
// // //                   </SelectItem>
// // //                 ))}
// // //               </SelectGroup>
// // //             </SelectContent>
// // //           </Select>
// // //         );
// // //         case "drag_and_drop_or_select_single":
// // //           if (field.key === "metric" && chartMetric) {
// // //             // Use chartMetric from Redux if available
// // //             return (
// // //               <SingleDropZone
// // //                 onDrop={(item) => {
// // //                   handleFormChange("metric", item, true);
// // //                   // Update Redux state if needed
// // //                   setChartMetric({
// // //                     expression_type: "SIMPLE",
// // //                     column: {
// // //                       column_name: item.name,
// // //                       type: item.type || "UNKNOWN",
// // //                     },
// // //                     aggregate: item.aggregate || "",
// // //                     label: item.label || item.name,
// // //                   });
// // //                 }}
// // //                 item={{
// // //                   id: chartMetric.column.column_name,
// // //                   name: chartMetric.label,
// // //                   type: chartMetric.column.type,
// // //                 }}
// // //                 onRemove={() => {
// // //                   handleFormChange("metric", null);
// // //                   setChartMetric(null);
// // //                 }}
// // //                 placeholder={field.placeholder || "Drop item here"}
// // //                 field={field}
// // //                 acceptTypes={["METRIC", "COLUMN"]}
// // //               />
// // //             );
// // //           } else {
// // //             // Existing functionality
// // //             return (
// // //               <SingleDropZone
// // //                 onDrop={(item) => handleFormChange(field.key, item, true)}
// // //                 item={formData[field.key] || null}
// // //                 onRemove={() => {
// // //                   handleFormChange(field.key, null);
// // //                   if (field.key === "metric") {
// // //                     setChartMetric(null);
// // //                   }
// // //                 }}
// // //                 placeholder={field.placeholder || "Drop item here"}
// // //                 field={field}
// // //                 acceptTypes={["METRIC", "COLUMN"]}
// // //               />
// // //             );
          
// // //           }
// // //           case "drag_and_drop_or_select_multiple":
// // //             return (
// // //               <MultipleDropZone
// // //                 onDrop={(item) =>
// // //                   handleFormChange(
// // //                     field.key,
// // //                     [...(field.key === "filters" ? filters : (formData[field.key] || [])), item],
// // //                     true
// // //                   )
// // //                 }
// // //                 items={field.key === "filters" ? filters : (formData[field.key] || [])}
// // //                 onRemove={(id) =>
// // //                   field.key === "filters"
// // //                     ? handleRemoveItem("filters", id)
// // //                     : handleFormChange(
// // //                         field.key,
// // //                         (formData[field.key] || []).filter(
// // //                           (item: DroppedItem) => item.id !== id
// // //                         )
// // //                       )
// // //                 }
// // //                 placeholder={field.placeholder || "Drop items here"}
// // //                 field={field}
// // //                 acceptTypes={["METRIC", "COLUMN"]}
// // //               />
// // //             );
            
// // //         case "checkbox":
// // //         return (
// // //           <div className="items-top flex space-x-2">
// // //             <input
// // //               type="checkbox"
// // //               id={field.key}
// // //               checked={formData[field.key] || false}
// // //               onChange={(e) => handleFormChange(field.key, e.target.checked)}
// // //               className="form-checkbox h-4 w-5 text-blue-600"
// // //             />
// // //             <div className="grid gap-1.5 leading-none">
// // //               <label
// // //                 htmlFor={field.key}
// // //                 className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
// // //               ></label>
// // //             </div>
// // //           </div>
// // //         );
// // //       default:
// // //         return (
// // //           <input
// // //             type="text"
// // //             value={formData[field.key] || ""}
// // //             onChange={(e) => handleFormChange(field.key, e.target.value)}
// // //             placeholder={field.placeholder}
// // //             className="w-full p-2 border rounded"
// // //           />
// // //         );
// // //     }
// // //   };

// // //   const renderActiveSection = () => {
// // //     const activeForm = chartForms[activeChartType];
// // //     if (!activeForm) return null;

// // //     return (
// // //       <div className="space-y-4">
// // //         {activeForm.parameters.map((field: FormField) => (
// // //           <div key={field.key}>
// // //             <Label>{field.label}</Label>
// // //             {field.key === "x_axis" ? (
// // //               <SingleDropZone
// // //                 onDrop={(item) => handleFormChange("x_axis", item, true)}
// // //                 item={formData.x_axis || null}
// // //                 onRemove={() => {
// // //                   handleFormChange("x_axis", null);
// // //                   setXAxisData(null);
// // //                 }}
// // //                 placeholder="Drop column for X-axis"
// // //                 field={field}
// // //                 acceptTypes={["COLUMN"]}
// // //               />
// // //             ) : (
// // //               renderFormField(field)
// // //             )}
// // //           </div>
// // //         ))}
// // //       </div>
// // //     );
// // //   };

// // //   const handleCreateChart = async () => {
// // //     setIsLoading(true);
// // //     setError(null);

// // //     try {
// // //       let chartData;
// // //       if (activeTab === "default") {
// // //         switch (activeChartType) {
// // //           case "pie":
// // //             chartData = await createPieChart(
// // //               dataset,
// // //               filters,
// // //               chartMetric,
// // //               {
// // //                 dimensions: (formData.dimensions as Dimension[])?.map(
// // //                   (dim) => ({
// // //                     ...dim,
// // //                     type: columns.find((col) => col.name === dim.name)?.type,
// // //                   })
// // //                 ),
// // //               },
// // //               defaultRowLimit,
// // //               showLegend,
// // //               legendOrientation,
// // //               legendType
// // //             );
// // //             break;
// // //           case "donut":
// // //             chartData = await createDonutChart(
// // //               dataset,
// // //               filters,
// // //               chartMetric,
// // //               {
// // //                 dimensions: (formData.dimensions as Dimension[])?.map(
// // //                   (dim) => ({
// // //                     ...dim,
// // //                     type: columns.find((col) => col.name === dim.name)?.type,
// // //                   })
// // //                 ),
// // //               },
// // //               defaultRowLimit,
// // //               showLegend,
// // //               legendOrientation,
// // //               legendType
// // //             );
// // //             break;
// // //           case "bar":
// // //             console.log(
// // //               "X-axis data before creating bar chart:",
// // //               formData.x_axis
// // //             ); // Add this log
// // //             chartData = await createBarChartRequest(
// // //               dataset,
// // //               filters,
// // //               chartMetric,
// // //               {
// // //                 dimensions: formData.dimensions,
// // //                 x_axis: formData["x-axis"], // Use formData.x_axis instead of xAxisData
// // //               },
// // //               defaultRowLimit,
// // //               showLegend,
// // //               showDataZoom,
// // //               legendOrientation,
// // //               legendType
// // //             );
// // //             break;
// // //           case "custom_bar":
// // //             console.log(
// // //               "X-axis data before creating custom bar chart:",
// // //               formData.x_axis
// // //             ); // Add this log
// // //             chartData = await createCustomBarChartRequest(
// // //               dataset,
// // //               filters,
// // //               chartMetric,
// // //               {
// // //                 dimensions: formData.dimensions,
// // //                 x_axis: formData["x-axis"], // Use formData.x_axis instead of xAxisData
// // //               },
// // //               defaultRowLimit,
// // //               showLegend,
// // //               showDataZoom,
// // //               legendOrientation,
// // //               legendType
// // //             );
// // //             break;
// // //           case "line":
// // //             chartData = await createLineChartRequest(
// // //               dataset,
// // //               filters,
// // //               chartMetric,
// // //               {
// // //                 dimensions: formData.dimensions,
// // //                 x_axis: formData["x-axis"], // Use formData.x_axis instead of xAxisData
// // //               },
// // //               defaultRowLimit,
// // //               showLegend,
// // //               showDataZoom,
// // //               legendOrientation,
// // //               legendType
// // //             );
// // //             break;
// // //           case "area":
// // //             chartData = await createAreaChartRequest(
// // //               dataset,
// // //               filters,
// // //               chartMetric,
// // //               {
// // //                 dimensions: formData.dimensions,
// // //                 x_axis: formData["x-axis"], // Use formData.x_axis instead of xAxisData
// // //               },
// // //               defaultRowLimit,
// // //               showLegend,
// // //               showDataZoom,
// // //               legendOrientation,
// // //               legendType
// // //             );
// // //             break;
// // //           case "table":
// // //             chartData = await createTableRequest(
// // //               dataset,
// // //               filters,
// // //               chartMetric,
// // //               {
// // //                 dimensions: formData.dimensions,
// // //               },
// // //               defaultRowLimit,
// // //               showLegend,
// // //               legendOrientation,
// // //               legendType
// // //             );
// // //             break;
// // //           case "pivot_table":
// // //             chartData = await createPivotTableRequest(
// // //               dataset,
// // //               filters,
// // //               chartMetric,
// // //               {
// // //                 dimensions: formData.dimensions,
// // //               },
// // //               defaultRowLimit,
// // //               showLegend,
// // //               legendOrientation,
// // //               legendType
// // //             );
// // //             break;
// // //           case "big_number":
// // //             chartData = await createBigNumberRequest(
// // //               dataset,
// // //               filters,
// // //               chartMetric,
// // //               {
// // //                 dimensions: formData.dimensions,
// // //                 x_axis: formData["x-axis"], // Use formData.x_axis instead of xAxisData
// // //               },
// // //               defaultRowLimit
// // //             );
// // //             break;
// // //           default:
// // //             throw new Error("Unsupported chart type: " + activeChartType);
// // //         }
// // //       } else if (activeTab === "ask-ai") {
// // //         // The chart creation is handled within the AskAITab component
// // //         return;
// // //       }

// // //       console.log("Chart data before sending:", { ...chartData, showDataZoom });
// // //       onChartCreated({
// // //         ...chartData,
// // //         showLegend,
// // //         legendOrientation,
// // //         legendType,
// // //         showDataZoom,
// // //         showLabelLines,
// // //       });
// // //     } catch (error) {
// // //       console.error("Error creating chart:", error);
// // //       setError("Failed to create chart. Please try again.");
// // //     } finally {
// // //       setIsLoading(false);
// // //     }
// // //   };

// // //   const SettingsIcon = () => (
// // //     <div className="flex items-center space-x-2">
// // //       <TooltipProvider>
// // //         <Tooltip>
// // //           <TooltipTrigger asChild></TooltipTrigger>
// // //           <TooltipContent>
// // //             <p>Customize</p>
// // //           </TooltipContent>
// // //         </Tooltip>
// // //       </TooltipProvider>
// // //       <Button
// // //         variant="ghost"
// // //         size="icon"
// // //         onClick={handleEditClick}
// // //         className="p-2"
// // //       >
// // //         <IconPencil size={24} style={{ color: "#682a7a" }} />
// // //       </Button>
// // //     </div>
// // //   );

// // //   return (
// // //     <div className="bg-white flex flex-col h-full w-80 border-r border-gray-200">
// // //       <div className="p-2 flex justify-between items-center">
// // //         <div className="w-80 ">
// // //           {/* <AskAITab onChartCreated={setChartData} /> */}

// // //           {renderChartDropdown()}
// // //         </div>
// // //         {/* <SettingsIcon /> */}
// // //       </div>
// // //       <div className="flex-grow overflow-y-auto bg-white">
// // //         <div className="p-2 bg-white">{renderActiveSection()}</div>
// // //       </div>
// // //       <div className="p-2 border-t border-gray-200 bg-white">
// // //         {error && <p className="text-red-500 mb-2">{error}</p>}
// // //         <Button
// // //           className="w-full bg-[#0047AB] text-white hover:bg-[#0047AB]"
// // //           onClick={handleCreateChart}
// // //           disabled={isLoading}
// // //         >
// // //           {isLoading ? "CREATING CHART..." : "CREATE CHART"}
// // //         </Button>
// // //       </div>
      
// // //     </div>
// // //   );
// // // };

// // // export default ChartTabs;



// // import React, { useState, useEffect, ReactNode } from "react";
// // import axios from "axios";
// // import { useDrop } from "react-dnd";
// // import {
// //   IconX,
// //   IconArrowBarToRight,
// //   IconPencil,
// //   IconSettings,
// // } from "@tabler/icons-react";
// // import {
// //   Popover,
// //   PopoverContent,
// //   PopoverTrigger,
// // } from "../../../../../@/components/ui/popover";
// // import { Button } from "../../../../../@/components/ui/button";
// // import { Label } from "../../../../../@/components/ui/label";
// // import {
// //   Select,
// //   SelectContent,
// //   SelectGroup,
// //   SelectItem,
// //   SelectLabel,
// //   SelectTrigger,
// //   SelectValue,
// // } from "../../../../../@/components/ui/select";
// // import {
// //   Card,
// //   CardContent,
// //   CardFooter,
// // } from "../../../../../@/components/ui/card";
// // import { createPieChart } from "../ChartRequests/PieChartRequest";
// // import { createBarChartRequest } from "../ChartRequests/BarChartRequest";
// // import { createBigNumberRequest } from "../ChartRequests/BigNumberChartRequest";
// // import { createLineChartRequest } from "../ChartRequests/LineChartRequest";
// // import { createAreaChartRequest } from "../ChartRequests/AreaChartRequest";
// // import { createTableRequest } from "../ChartRequests/TableRequest";
// // import ExpressionEditor from "./ExpressionEditor";
// // import {
// //   Tooltip,
// //   TooltipContent,
// //   TooltipProvider,
// //   TooltipTrigger,
// // } from "../../../../../@/components/ui/tooltip";
// // import MultiSelect from "../../../../../@/components/ui/multi-select";
// // import { createPivotTableRequest } from "../ChartRequests/PivotTableRequest";
// // import {
// //   Tabs,
// //   TabsContent,
// //   TabsList,
// //   TabsTrigger,
// // } from "../../../../../@/components/ui/tabs";
// // import { useLocation } from "react-router-dom";
// // import { createDonutChart } from "../ChartRequests/DonutChartRequest";
// // import { createCustomBarChartRequest } from "../ChartRequests/CustomBarChartRequest";
// // import { useSelector } from "react-redux";
// // import { RootState } from "../../../../../redux/store";
// // // Import all chart images
// // import BarChart from "../../../../../assets/viz_thumbnails/bar.png";
// // import PieChart from "../../../../../assets/viz_thumbnails/pie.png";
// // import LineChart from "../../../../../assets/viz_thumbnails/line.png";
// // import AreaChart from "../../../../../assets/viz_thumbnails/area.png";
// // import SunburstChart from "../../../../../assets/viz_thumbnails/sunburst.png";
// // import BigNumber from "../../../../../assets/viz_thumbnails/big_number.png";
// // import CustomTable from "../../../../../assets/viz_thumbnails/table.png";
// // import PivotTable from "../../../../../assets/viz_thumbnails/pivot_table.png";
// // import GaugeChart from "../../../../../assets/viz_thumbnails/gauge.png";
// // import DonutChart from "../../../../../assets/viz_thumbnails/donut.png";

// // import CustomBarChart from "../../../../../assets/viz_thumbnails/custom_bar.png";
// // import { createGaugeChart } from "../ChartRequests/GaugeChartRequest";

// // interface DroppedItem {
// //   id: string;
// //   name: string;
// //   type: string;
// //   aggregate?: string;
// //   label?: string;
// // }
// // interface Option {
// //   value: string;
// //   label: string;
// // }

// // interface ChartType {
// //   unique_id: string;
// //   name: string;
// //   icon: string; // Changed from ReactNode to string
// //   hasData?: boolean;
// // }

// // interface FormField {
// //   key: string;
// //   label: string;
// //   type: string;
// //   placeholder?: string;
// //   options?: string[];
// //   popover?: {
// //     [key: string]: any[];
// //   };
// // }

// // interface ChartForm {
// //   parameters: FormField[];
// // }

// // interface ChartTabsProps {
// //   dataset: string;
// //   chartType: string;
// //   onChartCreated: (chartOptions: any) => void;
// //   onThemeChange: (theme: string) => void;
// //   selectedTheme: string;
// //   onClearChartPreview: () => void; // Add this line
// // }
// // interface Column {
// //   name: string;
// //   type: string;
// // }

// // interface Dimension {
// //   id: string;
// //   name: string;
// //   type?: string;
// // }
// // interface Metric {
// //   expression_type: string;
// //   column: {
// //     column_name: string;
// //     type: string;
// //   };
// //   aggregate: string;
// //   label: string;
// // }

// // interface Filter {
// //   id: string;
// //   col?: string;
// //   op?: string;
// //   val?: string[];
// //   alias?: string; // Add this line
// // }
// // interface FormData {
// //   dimensions?: DroppedItem[];
// //   metrics?: DroppedItem[];
// //   x_axis?: DroppedItem;
// //   [key: string]: any;
// // }
// // const ChartTabs: React.FC<ChartTabsProps> = ({
// //   dataset,
// //   chartType,
// //   onChartCreated,
// //   onThemeChange,
// //   selectedTheme,
// //   onClearChartPreview, // Add this line
// // }) => {
// //   let [activeChartType, setActiveChartType] = useState<string>("");
// //   const [chartTypes, setChartTypes] = useState<ChartType[]>([]);
// //   const [chartForms, setChartForms] = useState<{ [key: string]: ChartForm }>(
// //     {}
// //   );
// //   const [columns, setColumns] = useState<Column[]>([]);
// //   const [formData, setFormData] = useState<{ [key: string]: any }>({});
// //   const [popoverSelections, setPopoverSelections] = useState<{
// //     [key: string]: any;
// //   }>({});
// //   const [uniqueValues, setUniqueValues] = useState<any>({});
// //   let [defaultRowLimit, setDefaultRowLimit] = useState(10);
// //   let [chartMetric, setChartMetric] = useState<Metric | null>(null);
// //   let [filters, setFilters] = useState<Filter[]>([]);
// //   const [chartDataModel, setChartDataModel] = useState<any>(null);
// //   const [isLoading, setIsLoading] = useState(false);
// //   const [error, setError] = useState<string | null>(null);
// //   const [showLegend, setShowLegend] = useState(true);
// //   const [legendOrientation, setLegendOrientation] = useState("top");
// //   const [legendType, setLegendType] = useState("scroll");
// //   const [showDataZoom, setShowDataZoom] = useState(false);
// //   const [isExpressionEditorOpen, setIsExpressionEditorOpen] = useState(false);
// //   const [showLabelLines, setShowLabelLines] = useState(false);
// //   const [activeTab, setActiveTab] = useState<string>("default");
// //   const [isChartCreated, setIsChartCreated] = useState(false);
// //   const location = useLocation();
// //   const { state } = location;
// //   const [chartData, setChartData] = useState(null);
// //   let [xAxisData, setXAxisData] = useState<any>(null);

// //   const chartDetails: any = useSelector((state: RootState) => state.chart);

// //   const handleEditClick = () => {
// //     setIsExpressionEditorOpen(true);
// //   };

// //   const handleExpressionEditorClose = () => {
// //     setIsExpressionEditorOpen(false);
// //   };

// //   const handleExpressionEditorSave = () => {
// //     // Handle saving the expressions
// //     setIsExpressionEditorOpen(false);
// //   };

// //   useEffect(() => {
// //     fetchChartTypes();
// //     fetchTableData();
// //   }, [dataset]);

// //   useEffect(() => {
// //     if(chartDetails?.id) {
// //       const { chart } = chartDetails;
// //       const { queries, form_data } = chart?.params;
// //       const { metrics } = queries[0];
// //       const { filters: chartFilters } = queries[0];
// //       if (metrics && metrics.length > 0) {
// //         setChartMetric(metrics[0]);
// //       }
  
// //       saveMetric(
// //         metrics[0]?.column?.column_name, metrics[0]?.aggregate, 
// //         { id: metrics[0]?.column?.column_name, name: metrics[0]?.column?.column_name, type: metrics[0]?.column?.type}, 
// //         ""
// //       );
// //       setTimeout(() => {
// //         // setChartMetric(metrics[0]);
// //         chartMetric = metrics[0];
// //         setFilters(chartFilters);
// //         filters = chartFilters;
// //         activeChartType = chart.visualization_name;
// //         defaultRowLimit = queries[0].row_limit.toString();
// //         formData.dimensions = form_data?.groupby || [];
// //         xAxisData = form_data?.x_axis || {};
// //         formData["x-axis"] = form_data?.x_axis || {};
// //       }, 1000);

// //       setTimeout(() => {
// //         handleCreateChart();
// //       }, 2000);
// //     }
// //   }, [chartDetails]);

// //   useEffect(() => {
// //     if (state && state.chart) {
// //       setActiveChartType(state.chart?.visualization_name);
// //     }
// //   }, [state]);
// //   const fetchChartTypes = async () => {
// //     try {
// //       const response = await axios.post("/api/charts/dashboard_charts", {});
// //       const allChartTypes = response.data.data.flatMap(
// //         (section: any) => section.components
// //       );

// //       const filteredChartTypes = allChartTypes.filter((chart: ChartType) => {
// //         if (chart.name.toLowerCase() === "sunburst chart") {
// //           return chart.hasData === true;
// //         }
// //         return true;
// //       });

// //       const chartTypesWithIcons = filteredChartTypes.map(
// //         (chart: ChartType) => ({
// //           ...chart,
// //           icon: getChartIcon(chart.name),
// //         })
// //       );

// //       setChartTypes(chartTypesWithIcons);
// //       if (chartTypesWithIcons.length > 0 && !state?.chart) {
// //         setActiveChartType(chartTypesWithIcons[0].unique_id);
// //       }
// //       fetchChartForms(chartTypesWithIcons);
// //     } catch (error) {
// //       console.error("Error fetching chart types:", error);
// //     }
// //   };

// //   const getChartIcon = (chartName: string): string => {
// //     switch (chartName.toLowerCase()) {
// //       case "bar chart":
// //         return BarChart;
// //       case "custom bar chart":
// //         return CustomBarChart;
// //       case "line chart":
// //         return LineChart;
// //       case "area chart":
// //         return AreaChart;
// //       case "pie chart":
// //         return PieChart;
// //         case "gauge chart":
// //           return GaugeChart;
// //       case "table":
// //         return CustomTable;
// //       case "big number":
// //         return BigNumber;
// //       case "donut chart":
// //         return DonutChart;
// //       case "sunburst chart":
// //         return SunburstChart;
// //       case "pivot table":
// //         return PivotTable;
// //       default:
// //         return CustomTable; // Default to table icon
// //     }
// //   };

// //   const fetchChartForms = async (chartTypes: ChartType[]) => {
// //     const forms: { [key: string]: ChartForm } = {};
// //     for (const chart of chartTypes) {
// //       try {
// //         const response = await axios.post("/api/charts/get_chart_form", {
// //           unique_id: chart.unique_id,
// //         });
// //         forms[chart.unique_id] = response.data.data;
// //       } catch (error) {
// //         console.error(`Error fetching form for ${chart.unique_id}:`, error);
// //       }
// //     }
// //     setChartForms(forms);
// //   };

// //   const fetchTableData = async () => {
// //     let params = {
// //       database: "zolix_c2o",
// //       schema: "public",
// //       table: dataset,
// //     };
// //     try {
// //       const response = await axios.post("/api/charts/get_columns", params);
// //       const columnData: Column[] = response.data.data.map((col: any) => ({
// //         name: col.name,
// //         type: col.type,
// //       }));
// //       setColumns(columnData);
// //       // Fetch unique values for each column
// //       columnData.forEach((column: Column) => fetchUniqueValues(column.name));
// //     } catch (error) {
// //       console.error("Error fetching columns:", error);
// //       alert(
// //         "Failed to fetch columns. Please check the console for more details."
// //       );
// //     }
// //   };

// //   const fetchUniqueValues = async (column: string) => {
// //     try {
// //       const response = await axios.post("/api/charts/get_unique_values", {
// //         database: "zolix_c2o",
// //         schema: "public",
// //         table: dataset,
// //         column: [column],
// //       });

// //       setUniqueValues((prev) => ({
// //         ...prev,
// //         ...response.data.data,
// //       }));
// //     } catch (error) {
// //       console.error(`Error fetching unique values for ${column}:`, error);
// //     }
// //   };
// //   const handleChartTypeChange = (type: string) => {
// //     setActiveChartType(type);
// //     // Reset form data when changing chart type
// //     setFormData({});
// //     setChartMetric(null);
// //     setFilters([]);
// //   };
// //   const handleFormChange = (key: string, value: any, openPopover = false) => {
// //     if (key === "filters") {
// //       if (Array.isArray(value)) {
// //         setFilters(value);
// //       } else if (value) {
// //         setFilters((prevFilters) => [...prevFilters, value]);
// //       }
// //     } else if (key === "x_axis") {
// //       // Only update x_axis if the value is explicitly set for x_axis
// //       setFormData((prevData) => ({
// //         ...prevData,
// //         x_axis: value,
// //       }));
// //       if (value) {
// //         setXAxisData({
// //           name: value.name,
// //           label: value.name,
// //           sort_ascending: true,
// //         });
// //       } else {
// //         setXAxisData(null);
// //       }
// //     } else {
// //       setFormData((prevData) => ({
// //         ...prevData,
// //         [key]: value,
// //       }));
// //     }

// //     if (openPopover && value) {
// //       if (!Array.isArray(value)) {
// //         setPopoverSelections((prev) => ({
// //           ...prev,
// //           [value.id]: { isOpen: true, column: value.name },
// //         }));
// //       } else if (Array.isArray(value) && value.length > 0) {
// //         const lastItem = value[value.length - 1];
// //         setPopoverSelections((prev) => ({
// //           ...prev,
// //           [lastItem.id]: { isOpen: true, column: lastItem.name },
// //         }));
// //       }
// //     }
// //   };
// //   const handleRemoveItem = (key: string, id?: string) => {
// //     if (key === "filters") {
// //       setFilters((prevFilters) => prevFilters.filter((filter) => filter.id !== id));
// //     } else if (key === "x_axis") {
// //       setFormData((prevData) => {
// //         const { x_axis, ...rest } = prevData;
// //         return rest;
// //       });
// //       setXAxisData(null);
// //     } else if (key === "metric" || key === "metrics") {
// //       setFormData((prevData) => {
// //         const { [key]: _, ...rest } = prevData;
// //         return rest;
// //       });
// //       setChartMetric(null);
// //     } else {
// //       setFormData((prevData) => {
// //         if (Array.isArray(prevData[key])) {
// //           return {
// //             ...prevData,
// //             [key]: prevData[key].filter((item: DroppedItem) => item.id !== id),
// //           };
// //         } else {
// //           const { [key]: _, ...rest } = prevData;
// //           return rest;
// //         }
// //       });
// //     }
  
// //     if (id) {
// //       setPopoverSelections((prev) => {
// //         const { [id]: _, ...rest } = prev;
// //         return rest;
// //       });
// //     }
// //   };
// //   const handlePopoverSave = (fieldKey: string, itemId: string, data: any) => {
// //     console.log("Handling popover save:", fieldKey, itemId, data);

// //     let savedData: any = {
// //       id: data.id,
// //       type: data.type,
// //       column: data.column,
// //       alias: data.alias,
// //       aggregate: data.aggregate,
// //       operator: data.operator,
// //       value: data.value,
// //     };
// //     let displayText = data.alias || data.column;

// //     switch (fieldKey) {
// //       case "x_axis":
// //         displayText = data.alias || data.column;
// //         setXAxisData({
// //           name: data.column,
// //           label: data.alias || data.column,
// //           sort_ascending: true,
// //         });
// //         setFormData((prevData) => ({
// //           ...prevData,
// //           x_axis: {
// //             name: data.column,
// //             label: data.alias || data.column,
// //             sort_ascending: true,
// //           },
// //         }));
// //         break;
// //       case "metric":
// //         displayText =
// //           data.alias ||
// //           (data.aggregate && data.column
// //             ? `${data.column} (${data.aggregate})`
// //             : data.column);
// //         // Set chartMetric for the bar chart
// //         const columnData = columns.find((col) => col.name === data.column);
// //         setChartMetric({
// //           expression_type: "SIMPLE",
// //           column: {
// //             column_name: data.column,
// //             type: columnData?.type || "UNKNOWN",
// //           },
// //           aggregate: data.aggregate,
// //           label: data.alias || data.column,
// //         });
// //         break;
// //       case "metrics":
// //         displayText =
// //           data.alias ||
// //           (data.aggregate && data.column
// //             ? `${data.column} (${data.aggregate})`
// //             : data.column);
// //         const columnsData = columns.find((col) => col.name === data.column);
// //         setChartMetric({
// //           expression_type: "SIMPLE",
// //           column: {
// //             column_name: data.column,
// //             type: columnsData?.type || "UNKNOWN",
// //           },
// //           aggregate: data.aggregate,
// //           label: data.alias || data.column,
// //         });
// //         break;
// //       case "dimensions":
// //         displayText = data.alias || data.column;
// //         // Update dimensions in formData
// //         setFormData((prevData) => {
// //           const updatedDimensions = Array.isArray(prevData.dimensions)
// //             ? prevData.dimensions.map((dim: any) =>
// //                 dim.id === itemId
// //                   ? { ...dim, name: data.column, alias: data.alias }
// //                   : dim
// //               )
// //             : [];
// //           return { ...prevData, dimensions: updatedDimensions };
// //         });
// //         break;
// //       case "filters":
// //         displayText = `${data.alias || data.column} ${data.operator} (${
// //           Array.isArray(data.value) ? data.value.join(", ") : data.value
// //         })`;
// //         handleFilterChange(
// //           itemId,
// //           data.column,
// //           data.operator,
// //           Array.isArray(data.value.toString()) ? data.value.toString() : [data.value.toString()],
// //           data.alias
// //         );
// //         break;
// //       default:
// //         displayText = data.alias || data.column;
// //     }
// //     setPopoverSelections((prev) => ({
// //       ...prev,
// //       [itemId]: { ...savedData, isOpen: false },
// //     }));

// //     console.log("Saved x-axis data:", formData.x_axis); // Add this log
// //   };

// //   const saveMetric = (
// //     selectedColumn: string,
// //     selectedAggregate: string,
// //     item: DroppedItem,
// //     alias: string
// //   ) => {
// //     if (!selectedColumn || !selectedAggregate || !item) {
// //       alert("Please select a column and aggregate function.");
// //       return;
// //     }
// //     const columnData = columns.find((col) => col.name === selectedColumn);
// //     const newMetric: Metric = {
// //       expression_type: "SIMPLE",
// //       column: {
// //         column_name: selectedColumn,
// //         type: columnData ? columnData.type : "UNKNOWN",
// //       },
// //       aggregate: selectedAggregate,
// //       label: alias || selectedColumn,
// //     };
// //     setChartMetric(newMetric);
// //   };
// //   const handleFilterChange = (
// //     id: string,
// //     col?: string,
// //     op?: string,
// //     val?: string[],
// //     alias?: string
// //   ) => {
// //     setFilters((prevFilters) => {
// //       const existingFilterIndex = prevFilters.findIndex(
// //         (filter) => filter.id === id
// //       );
// //       const columnData = columns.find((column) => column.name === col);
// //       const newFilter = {
// //         id,
// //         col: col || "",
// //         op: op || "",
// //         val: val || [],
// //         alias: alias || "",
// //         type: columnData ? columnData.type : "UNKNOWN",
// //       };
// //       if (existingFilterIndex !== -1) {
// //         // Update existing filter
// //         const updatedFilters = [...prevFilters];
// //         updatedFilters[existingFilterIndex] = newFilter;
// //         return updatedFilters;
// //       } else {
// //         // Add new filter
// //         return [...prevFilters, newFilter];
// //       }
// //     });
// //   };

// //   const getDisplayText = (item: any, fieldKey: string) => {
// //     if (fieldKey === "x_axis" && item) {
// //       return item.name || item.label || "X-Axis";
// //     }
// //     if (fieldKey === "metrics" || fieldKey === "metric") {
// //       // Check if the item is from Redux
// //       if (item.column && item.aggregate) {
// //         return `${item.column.column_name} (${item.aggregate})`;
// //       }
// //       // Check if the item is from popover selections
// //       const selection = popoverSelections[item.id];
// //       if (selection) {
// //         const aggregate = selection.aggregate || "";
// //         const column = selection.column || "";
// //         const alias = selection.alias || "";
// //         return alias || (aggregate ? `${column} (${aggregate})` : column);
// //       }
// //       // Fallback to item properties if neither Redux nor popover data is available
// //       return item.label || (item.aggregate ? `${item.name} (${item.aggregate})` : item.name);
// //     }
// //     if (fieldKey === "dimensions" && item) {
// //       const selection = popoverSelections[item.id];
// //       return selection?.alias || item.name;
// //     }
// //     if (fieldKey === "filters" && item) {
// //       const selection = popoverSelections[item.id];
// //       if (selection) {
// //         const column = selection.column || item.name || "";
// //         const operator = selection.operator || "";
// //         const value = Array.isArray(selection.value)
// //           ? selection.value.map((v: Option) => v.value || v).join(", ")
// //           : selection.value || "";
// //         return `${column} ${operator} ${value ? `(${value})` : ""}`;
// //       } else {
// //         const column = item.col || "";
// //         const operator = item.op || "";
// //         const value = Array.isArray(item.val)
// //           ? item.val.join(", ")
// //           : item.val || "";
// //         return `${column} ${operator} ${value ? `(${value})` : ""}`;
// //       }
// //     }
// //     return item.name || "";
// //   };
// //   const renderChartDropdown = () => (
// //     <Select value={activeChartType} onValueChange={handleChartTypeChange}>
// //       <SelectTrigger className="w-full">
// //         <SelectValue placeholder="Select a chart type">
// //           {activeChartType && (
// //             <div className="flex items-center">
// //               <img
// //                 src={
// //                   chartTypes.find((ct) => ct.unique_id === activeChartType)
// //                     ?.icon
// //                 }
// //                 alt={
// //                   chartTypes.find((ct) => ct.unique_id === activeChartType)
// //                     ?.name
// //                 }
// //                 className="w-6 h-6 mr-2"
// //               />
// //               <span>
// //                 {
// //                   chartTypes.find((ct) => ct.unique_id === activeChartType)
// //                     ?.name
// //                 }
// //               </span>
// //             </div>
// //           )}
// //         </SelectValue>
// //       </SelectTrigger>
// //       <SelectContent>
// //         {chartTypes.map((chartType) => (
// //           <SelectItem key={chartType.unique_id} value={chartType.unique_id}>
// //             <div className="flex items-center">
// //               <img
// //                 src={chartType.icon}
// //                 alt={chartType.name}
// //                 className="w-6 h-6 mr-2"
// //               />
// //               <span>{chartType.name}</span>
// //             </div>
// //           </SelectItem>
// //         ))}
// //       </SelectContent>
// //     </Select>
// //   );
// //   const DynamicPopoverContent: React.FC<{
// //     field: FormField;
// //     item: DroppedItem;
// //     onClose: () => void;
// //     onSave: (data: any) => void;
// //   }> = ({ field, item, onClose, onSave }) => {
// //     const storedData = popoverSelections[item.id] || {};
// //     const [popoverData, setPopoverData] = useState<{
// //       [key: string]: string | any;
// //     }>({
// //       columns: storedData.column || item.name,
// //       aggregate: storedData.aggregate || "",
// //       operator: storedData.operator || "",
// //       value: storedData.value || [],
// //       row_limit: defaultRowLimit,
// //       alias: storedData.alias || "",
// //     });

// //     const handlePopoverChange = (key: string, value: string | Option[]) => {
// //       setPopoverData((prev) => ({ ...prev, [key]: value }));
// //     };

// //     const handleSave = () => {
// //       try {
// //         const baseData = {
// //           id: item.id,
// //           type: item.type,
// //           column: popoverData["columns"],
// //           alias: popoverData["alias"],
// //         };

// //         let saveData;
// //         switch (field.key) {
// //           case "metrics":
// //             saveData = {
// //               ...baseData,
// //               aggregate: popoverData["aggregate"],
// //             };
// //             break;
// //           case "metric":
// //             saveData = {
// //               ...baseData,
// //               aggregate: popoverData["aggregate"],
// //             };
// //             break;
// //           case "filters":
// //             saveData = {
// //               ...baseData,
// //               operator: popoverData["operator"],
// //               value: Array.isArray(popoverData["value"])
// //                 ? popoverData["value"].map((option: Option) => option.value)
// //                 : popoverData["value"],
// //             };
// //             break;
// //           default:
// //             saveData = baseData;
// //         }

// //         console.log("Saving popover data:", saveData);
// //         onSave(saveData);
// //         onClose(); // Close the popover after successful save
// //       } catch (error) {
// //         console.error("Error saving popover data:", error);
// //         // You might want to show an error message to the user here
// //       }
// //     };

// //     const renderPopoverField = (popoverField: any) => {
// //       switch (popoverField.key) {
// //         case "columns":
// //         case "operator":
// //         case "aggregate":
// //           return (
// //             <Select
// //               value={popoverData[popoverField.key] as string}
// //               onValueChange={(value) =>
// //                 handlePopoverChange(popoverField.key, value)
// //               }
// //             >
// //               <SelectTrigger className="w-full">
// //                 <SelectValue placeholder={popoverField.placeholder} />
// //               </SelectTrigger>
// //               <SelectContent>
// //                 {popoverField.key === "columns"
// //                   ? columns.map((column: Column) => (
// //                       <SelectItem key={column.name} value={column.name}>
// //                         {column.name}
// //                       </SelectItem>
// //                     ))
// //                   : popoverField.options
// //                       ?.filter((option: string) => option !== "")
// //                       .map((option: string) => (
// //                         <SelectItem key={option} value={option}>
// //                           {option}
// //                         </SelectItem>
// //                       ))}
// //               </SelectContent>
// //             </Select>
// //           );
// //         case "value":
// //           if (popoverData["columns"]) {
// //             const options = (
// //               Array.isArray(uniqueValues[popoverData["columns"] as string])
// //                 ? uniqueValues[popoverData["columns"] as string].filter(
// //                     (value: string) => value !== ""
// //                   )
// //                 : []
// //             ).map((value: string) => ({ value, label: value }));

// //             return (
// //               <MultiSelect
// //                 options={options}
// //                 value={popoverData[popoverField.key]}
// //                 onChange={(selected: Option[]) =>
// //                   handlePopoverChange(popoverField.key, selected)
// //                 }
// //               />
// //             );
// //           }
// //           return null;
// //         case "alias":
// //           return (
// //             <input
// //               type="text"
// //               value={popoverData[popoverField.key] as string}
// //               onChange={(e) =>
// //                 handlePopoverChange(popoverField.key, e.target.value)
// //               }
// //               placeholder="Enter alias"
// //               className="w-full p-2 border rounded"
// //             />
// //           );
// //         default:
// //           return (
// //             <input
// //               type="text"
// //               value={popoverData[popoverField.key] as string}
// //               onChange={(e) =>
// //                 handlePopoverChange(popoverField.key, e.target.value)
// //               }
// //               placeholder={popoverField.placeholder}
// //               className="w-full p-2 border rounded"
// //             />
// //           );
// //       }
// //     };

// //     return (
// //       <Tabs defaultValue="SIMPLE" className="w-full">
// //         <TabsList
// //           className={`grid w-full ${
// //             Object.keys(field.popover || {}).length === 1
// //               ? "grid-cols-1"
// //               : "grid-cols-2"
// //           }`}
// //         >
// //           {Object.keys(field.popover || {}).map((tabKey) => (
// //             <TabsTrigger
// //               key={tabKey}
// //               value={tabKey}
// //               className={tabKey === "SIMPLE" ? "shadow-lg" : ""}
// //             >
// //               {tabKey}
// //             </TabsTrigger>
// //           ))}
// //         </TabsList>

// //         {Object.entries(field.popover || {}).map(([tabKey, tabFields]) => (
// //           <TabsContent key={tabKey} value={tabKey}>
// //             <Card className="border-none shadow-none mt-2">
// //               <CardContent>
// //                 <div className="grid gap-4">
// //                   {tabFields.map((popoverField: any) => (
// //                     <div key={popoverField.key} className="grid gap-2">
// //                       <Label>{popoverField.label}</Label>
// //                       {renderPopoverField(popoverField)}
// //                     </div>
// //                   ))}
// //                 </div>
// //               </CardContent>
// //               <CardFooter className="flex justify-between">
// //                 <Button
// //                   className="bg-slate-400 hover:bg-slate-600"
// //                   onClick={onClose}
// //                 >
// //                   Close
// //                 </Button>
// //                 <Button
// //                   className="bg-slate-400 hover:bg-slate-600"
// //                   onClick={handleSave}
// //                 >
// //                   Save
// //                 </Button>
// //               </CardFooter>
// //             </Card>
// //           </TabsContent>
// //         ))}
// //       </Tabs>
// //     );
// //   };
// //   const SingleDropZone: React.FC<{
// //     onDrop: (item: DroppedItem) => void;
// //     item: DroppedItem | null;
// //     onRemove: () => void;
// //     placeholder: string;
// //     field: FormField;
// //     acceptTypes: string[];
// //   }> = ({ onDrop, item, onRemove, placeholder, field, acceptTypes }) => {
// //       const [{ isOver }, drop] = useDrop(() => ({
// //       accept: acceptTypes,
// //       drop: (droppedItem: DroppedItem) => {
// //         onDrop(droppedItem);
// //         setPopoverSelections((prev) => ({
// //           ...prev,
// //           [droppedItem.id]: { ...prev[droppedItem.id], isOpen: true },
// //         }));
// //       },
// //       collect: (monitor) => ({
// //         isOver: !!monitor.isOver(),
// //       }),
// //     }));
// //     const isReduxMetric = field.key === "metric" && item && 'column' in item && 'aggregate' in item;

  
// //     return (
// //       <div
// //         ref={drop}
// //         className={`border border-gray-300 rounded-md overflow-hidden text-sm ${
// //           isOver ? "bg-blue-50" : "bg-white"
// //         }`}
// //       >
// //         {!item ? (
// //           <div className="p-1 text-gray-400">{placeholder}</div>
// //         ) : (
// //           <div className="flex items-center p-1 border-gray-200">
// //             <Button
// //               variant="icon"
// //               className="text-gray-500 hover:text-red-500 px-2 px-1"
// //               onClick={() => {
// //                 onRemove();
// //                 handleRemoveItem(field.key, item.id);
// //               }}
// //             >
// //               <IconX stroke={1.5} size={14} />
// //             </Button>
// //           <div className="flex-grow px-2 py-1 bg-white rounded text-gray-800">
// //             {getDisplayText(item, field.key)}
// //             </div>
// //             {field.popover && (
// //               <Popover
// //                 open={popoverSelections[item.id]?.isOpen}
// //                 onOpenChange={(open) =>
// //                   setPopoverSelections((prev) => ({
// //                     ...prev,
// //                     [item.id]: { ...prev[item.id], isOpen: open },
// //                   }))
// //                 }
// //               >
// //                 <PopoverTrigger asChild>
// //                   <Button variant="icon" className="px-2 px-1">
// //                     <IconArrowBarToRight stroke={1.5} size={14} />
// //                   </Button>
// //                 </PopoverTrigger>
// //                 <PopoverContent className="w-96 bg-white border border-gray-300">
// //                   <DynamicPopoverContent
// //                     field={field}
// //                     item={item}
// //                     onClose={() =>
// //                       setPopoverSelections((prev) => ({
// //                         ...prev,
// //                         [item.id]: { ...prev[item.id], isOpen: false },
// //                       }))
// //                     }
// //                     onSave={(data) => {
// //                       handlePopoverSave(field.key, item.id, data);
// //                     }}
// //                   />
// //                 </PopoverContent>
// //               </Popover>
// //             )}
// //           </div>
// //         )}
// //       </div>
// //     );
// //   };
// //   const MultipleDropZone: React.FC<{
// //     onDrop: (item: DroppedItem) => void;
// //     items: DroppedItem[];
// //     onRemove: (key: string, id: string) => void;
// //     placeholder: string;
// //     field: FormField;
// //     acceptTypes: string[];
// //   }> = ({ onDrop, items, onRemove, placeholder, field, acceptTypes }) => {
// //     const [{ isOver }, drop] = useDrop(() => ({
// //       accept: acceptTypes,
// //       drop: (item: DroppedItem) => {
// //         const newItem = { ...item, id: `${item.id}_${Date.now()}` }; // Create a new unique ID
// //         onDrop(newItem);
// //         setPopoverSelections((prev) => ({
// //           ...prev,
// //           [newItem.id]: { ...prev[newItem.id], isOpen: true },
// //         }));
// //       },
// //       collect: (monitor) => ({
// //         isOver: !!monitor.isOver(),
// //       }),
// //     }));

// //     const displayItems = field.key === "filters" ? filters : items;
// //     return (
// //       <div
// //         ref={drop}
// //         className={`border border-gray-300 rounded-md overflow-hidden text-sm ${
// //           isOver ? "bg-blue-50" : "bg-white"
// //         }`}
// //       >
// //         {displayItems.length === 0 ? (
// //           <div className="p-1 text-gray-400">{placeholder}</div>
// //         ) : (
// //           <div>
// //             {displayItems.map((item) => (
// //               <div
// //                 key={item.id || item.col}
// //                 className="flex items-center p-1 border-b border-gray-200 last:border-b-0"
// //               >
// //                 <Button
// //                   variant="icon"
// //                   className="text-black-500 hover:text-red-500 px-2 px-1"
// //                   onClick={() => {
// //                     onRemove(field.key, item.id || item.col);
// //                     handleRemoveItem(field.key, item.id || item.col);
// //                   }}
// //                 > 
// //                   <IconX stroke={1.5} size={14} />
// //                 </Button>

// //                 <div className="flex-grow px-2 py-1 bg-white rounded text-gray-800">
// //                   {getDisplayText(item, field.key)}
// //                 </div>
// //                 {field.popover && (
// //                   <Popover
// //                     open={popoverSelections[item.id]?.isOpen}
// //                     onOpenChange={(open) =>
// //                       setPopoverSelections((prev) => ({
// //                         ...prev,
// //                         [item.id]: { ...prev[item.id], isOpen: open },
// //                       }))
// //                     }
// //                   >
// //                     <PopoverTrigger asChild>
// //                       <Button variant="icon" className="px-2 px-1">
// //                         <IconArrowBarToRight stroke={1.5} size={14} />
// //                       </Button>
// //                     </PopoverTrigger>
// //                     <PopoverContent className="w-96">
// //                       <DynamicPopoverContent
// //                         field={field}
// //                         item={item}
// //                         onClose={() =>
// //                           setPopoverSelections((prev) => ({
// //                             ...prev,
// //                             [item.id]: { ...prev[item.id], isOpen: false },
// //                           }))
// //                         }
// //                         onSave={(data) => {
// //                           handlePopoverSave(field.key, item.id, data);
// //                         }}
// //                       />
// //                     </PopoverContent>
// //                   </Popover>
// //                 )}
// //               </div>
// //             ))}
// //           </div>
// //         )}
// //       </div>
// //     );
// //   };

// //   const renderFormField = (field: FormField) => {
// //     switch (field.type) {
// //       case "select":
// //         return (
// //           <Select
// //             value={formData[field.key] || ""}
// //             onValueChange={(value) => handleFormChange(field.key, value)}
// //           >
// //             <SelectTrigger className="w-full bg-white">
// //               <SelectValue
// //                 placeholder={field.placeholder || `Select ${field.label}`}
// //               />
// //             </SelectTrigger>
// //             <SelectContent>
// //               <SelectGroup>
// //                 <SelectLabel>{field.label}</SelectLabel>
// //                 {field.options?.map((option) => (
// //                   <SelectItem key={option} value={option}>
// //                     {option}
// //                   </SelectItem>
// //                 ))}
// //               </SelectGroup>
// //             </SelectContent>
// //           </Select>
// //         );
// //         case "drag_and_drop_or_select_single":
// //           if (field.key === "metric" && chartMetric) {
// //             // Use chartMetric from Redux if available
// //             return (
// //               <SingleDropZone
// //                 onDrop={(item) => {
// //                   handleFormChange("metric", item, true);
// //                   // Update Redux state if needed
// //                   setChartMetric({
// //                     expression_type: "SIMPLE",
// //                     column: {
// //                       column_name: item.name,
// //                       type: item.type || "UNKNOWN",
// //                     },
// //                     aggregate: item.aggregate || "",
// //                     label: item.label || item.name,
// //                   });
// //                 }}
// //                 item={{
// //                   id: chartMetric.column.column_name,
// //                   name: chartMetric.label,
// //                   type: chartMetric.column.type,
// //                 }}
// //                 onRemove={() => {
// //                   handleFormChange("metric", null);
// //                   setChartMetric(null);
// //                 }}
// //                 placeholder={field.placeholder || "Drop item here"}
// //                 field={field}
// //                 acceptTypes={["METRIC", "COLUMN"]}
// //               />
// //             );
// //           } else {
// //             // Existing functionality
// //             return (
// //               <SingleDropZone
// //                 onDrop={(item) => handleFormChange(field.key, item, true)}
// //                 item={formData[field.key] || null}
// //                 onRemove={() => {
// //                   handleFormChange(field.key, null);
// //                   if (field.key === "metric") {
// //                     setChartMetric(null);
// //                   }
// //                 }}
// //                 placeholder={field.placeholder || "Drop item here"}
// //                 field={field}
// //                 acceptTypes={["METRIC", "COLUMN"]}
// //               />
// //             );
          
// //           }
// //           case "drag_and_drop_or_select_multiple":
// //             return (
// //               <MultipleDropZone
// //                 onDrop={(item) =>
// //                   handleFormChange(
// //                     field.key,
// //                     [...(field.key === "filters" ? filters : (formData[field.key] || [])), item],
// //                     true
// //                   )
// //                 }
// //                 items={field.key === "filters" ? filters : (formData[field.key] || [])}
// //                 onRemove={(id) =>
// //                   field.key === "filters"
// //                     ? handleRemoveItem("filters", id)
// //                     : handleFormChange(
// //                         field.key,
// //                         (formData[field.key] || []).filter(
// //                           (item: DroppedItem) => item.id !== id
// //                         )
// //                       )
// //                 }
// //                 placeholder={field.placeholder || "Drop items here"}
// //                 field={field}
// //                 acceptTypes={["METRIC", "COLUMN"]}
// //               />
// //             );
            
// //         case "checkbox":
// //         return (
// //           <div className="items-top flex space-x-2">
// //             <input
// //               type="checkbox"
// //               id={field.key}
// //               checked={formData[field.key] || false}
// //               onChange={(e) => handleFormChange(field.key, e.target.checked)}
// //               className="form-checkbox h-4 w-5 text-blue-600"
// //             />
// //             <div className="grid gap-1.5 leading-none">
// //               <label
// //                 htmlFor={field.key}
// //                 className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
// //               ></label>
// //             </div>
// //           </div>
// //         );
// //       default:
// //         return (
// //           <input
// //             type="text"
// //             value={formData[field.key] || ""}
// //             onChange={(e) => handleFormChange(field.key, e.target.value)}
// //             placeholder={field.placeholder}
// //             className="w-full p-2 border rounded"
// //           />
// //         );
// //     }
// //   };

// //   const renderActiveSection = () => {
// //     const activeForm = chartForms[activeChartType];
// //     if (!activeForm) return null;

// //     return (
// //       <div className="space-y-4">
// //         {activeForm.parameters.map((field: FormField) => (
// //           <div key={field.key}>
// //             <Label>{field.label}</Label>
// //             {field.key === "x_axis" ? (
// //               <SingleDropZone
// //                 onDrop={(item) => handleFormChange("x_axis", item, true)}
// //                 item={formData.x_axis || null}
// //                 onRemove={() => {
// //                   handleFormChange("x_axis", null);
// //                   setXAxisData(null);
// //                 }}
// //                 placeholder="Drop column for X-axis"
// //                 field={field}
// //                 acceptTypes={["COLUMN"]}
// //               />
// //             ) : (
// //               renderFormField(field)
// //             )}
// //           </div>
// //         ))}
// //       </div>
// //     );
// //   };

// //   const handleCreateChart = async () => {
// //     setIsLoading(true);
// //     setError(null);

// //     try {
// //       let chartData;
// //       if (activeTab === "default") {
// //         switch (activeChartType) {
// //           case "pie":
// //             chartData = await createPieChart(
// //               dataset,
// //               filters,
// //               chartMetric,
// //               {
// //                 dimensions: (formData.dimensions as Dimension[])?.map(
// //                   (dim) => ({
// //                     ...dim,
// //                     type: columns.find((col) => col.name === dim.name)?.type,
// //                   })
// //                 ),
// //               },
// //               defaultRowLimit,
// //               showLegend,
// //               legendOrientation,
// //               legendType
// //             );
// //             break;
// //           case "donut":
// //             chartData = await createDonutChart(
// //               dataset,
// //               filters,
// //               chartMetric,
// //               {
// //                 dimensions: (formData.dimensions as Dimension[])?.map(
// //                   (dim) => ({
// //                     ...dim,
// //                     type: columns.find((col) => col.name === dim.name)?.type,
// //                   })
// //                 ),
// //               },
// //               defaultRowLimit,
// //               showLegend,
// //               legendOrientation,
// //               legendType
// //             );
// //             break;
// //             case "gauge":
// //             chartData = await createGaugeChart(
// //               dataset,
// //               filters,
// //               chartMetric,
// //               {
// //                 dimensions: (formData.dimensions as Dimension[])?.map(
// //                   (dim) => ({
// //                     ...dim,
// //                     type: columns.find((col) => col.name === dim.name)?.type,
// //                   })
// //                 ),
// //               },
// //               defaultRowLimit,
// //               showLegend,
// //               legendOrientation,
// //               legendType
// //             );
// //             break;
// //           case "bar":
// //             console.log(
// //               "X-axis data before creating bar chart:",
// //               formData.x_axis
// //             ); // Add this log
// //             chartData = await createBarChartRequest(
// //               dataset,
// //               filters,
// //               chartMetric,
// //               {
// //                 dimensions: formData.dimensions,
// //                 x_axis: formData["x-axis"], // Use formData.x_axis instead of xAxisData
// //               },
// //               defaultRowLimit,
// //               showLegend,
// //               showDataZoom,
// //               legendOrientation,
// //               legendType
// //             );
// //             break;
// //           case "custom_bar":
// //             console.log(
// //               "X-axis data before creating custom bar chart:",
// //               formData.x_axis
// //             ); // Add this log
// //             chartData = await createCustomBarChartRequest(
// //               dataset,
// //               filters,
// //               chartMetric,
// //               {
// //                 dimensions: formData.dimensions,
// //                 x_axis: formData["x-axis"], // Use formData.x_axis instead of xAxisData
// //               },
// //               defaultRowLimit,
// //               showLegend,
// //               showDataZoom,
// //               legendOrientation,
// //               legendType
// //             );
// //             break;
// //           case "line":
// //             chartData = await createLineChartRequest(
// //               dataset,
// //               filters,
// //               chartMetric,
// //               {
// //                 dimensions: formData.dimensions,
// //                 x_axis: formData["x-axis"], // Use formData.x_axis instead of xAxisData
// //               },
// //               defaultRowLimit,
// //               showLegend,
// //               showDataZoom,
// //               legendOrientation,
// //               legendType
// //             );
// //             break;
// //           case "area":
// //             chartData = await createAreaChartRequest(
// //               dataset,
// //               filters,
// //               chartMetric,
// //               {
// //                 dimensions: formData.dimensions,
// //                 x_axis: formData["x-axis"], // Use formData.x_axis instead of xAxisData
// //               },
// //               defaultRowLimit,
// //               showLegend,
// //               showDataZoom,
// //               legendOrientation,
// //               legendType
// //             );
// //             break;
// //           case "table":
// //             chartData = await createTableRequest(
// //               dataset,
// //               filters,
// //               chartMetric,
// //               {
// //                 dimensions: formData.dimensions,
// //               },
// //               defaultRowLimit,
// //               showLegend,
// //               legendOrientation,
// //               legendType
// //             );
// //             break;
// //           case "pivot_table":
// //             chartData = await createPivotTableRequest(
// //               dataset,
// //               filters,
// //               chartMetric,
// //               {
// //                 dimensions: formData.dimensions,
// //               },
// //               defaultRowLimit,
// //               showLegend,
// //               legendOrientation,
// //               legendType
// //             );
// //             break;
// //           case "big_number":
// //             chartData = await createBigNumberRequest(
// //               dataset,
// //               filters,
// //               chartMetric,
// //               {
// //                 dimensions: formData.dimensions,
// //                 x_axis: formData["x-axis"], // Use formData.x_axis instead of xAxisData
// //               },
// //               defaultRowLimit
// //             );
// //             break;
// //           default:
// //             throw new Error("Unsupported chart type: " + activeChartType);
// //         }
// //       } else if (activeTab === "ask-ai") {
// //         // The chart creation is handled within the AskAITab component
// //         return;
// //       }

// //       console.log("Chart data before sending:", { ...chartData, showDataZoom });
// //       onChartCreated({
// //         ...chartData,
// //         showLegend,
// //         legendOrientation,
// //         legendType,
// //         showDataZoom,
// //         showLabelLines,
// //       });
// //     } catch (error) {
// //       console.error("Error creating chart:", error);
// //       setError("Failed to create chart. Please try again.");
// //     } finally {
// //       setIsLoading(false);
// //     }
// //   };

  

// //   return (
// //     <div className="bg-white flex flex-col h-full w-80 border-r border-gray-200">
// //       <div className="p-2 flex justify-between items-center">
// //         <div className="w-80 ">
// //           {/* <AskAITab onChartCreated={setChartData} /> */}

// //           {renderChartDropdown()}
// //         </div>
// //         {/* <SettingsIcon /> */}
// //       </div>
// //       <div className="flex-grow overflow-y-auto bg-white">
// //         <div className="p-2 bg-white">{renderActiveSection()}</div>
// //       </div>
// //       <div className="p-2 border-t border-gray-200 bg-white">
// //         {error && <p className="text-red-500 mb-2">{error}</p>}
// //         <Button
// //           className="w-full bg-[#0047AB] text-white hover:bg-[#0047AB]"
// //           onClick={handleCreateChart}
// //           disabled={isLoading}
// //         >
// //           {isLoading ? "CREATING CHART..." : "CREATE CHART"}
// //         </Button>
// //       </div>
     
// //     </div>
// //   );
// // };

// // export default ChartTabs;



// import React, { useState, useEffect, ReactNode } from "react";
// import axios from "axios";
// import { useDrop } from "react-dnd";
// import { IconX,IconArrowBarToRight,IconPencil,IconSettings,
// } from "@tabler/icons-react";
// import { Popover,  PopoverContent, PopoverTrigger,} from "../../../../../@/components/ui/popover";
// import { Button } from "../../../../../@/components/ui/button";
// import { Label } from "../../../../../@/components/ui/label";
// import {Select,SelectContent,SelectGroup,SelectItem,SelectLabel,SelectTrigger, SelectValue,} from "../../../../../@/components/ui/select";
// import { Card,CardContent, CardFooter,} from "../../../../../@/components/ui/card";
// import { createPieChart } from "../ChartRequests/PieChartRequest";
// import { createBarChartRequest } from "../ChartRequests/BarChartRequest";
// import { createBigNumberRequest } from "../ChartRequests/BigNumberChartRequest";
// import { createLineChartRequest } from "../ChartRequests/LineChartRequest";
// import { createAreaChartRequest } from "../ChartRequests/AreaChartRequest";
// import { createTableRequest } from "../ChartRequests/TableRequest";
// import ExpressionEditor from "./ExpressionEditor";
// import {  Tooltip,TooltipContent,TooltipProvider,TooltipTrigger,} from "../../../../../@/components/ui/tooltip";
// import MultiSelect from "../../../../../@/components/ui/multi-select";
// import { createPivotTableRequest } from "../ChartRequests/PivotTableRequest";
// import {Tabs,TabsContent,TabsList, TabsTrigger} from "../../../../../@/components/ui/tabs";
// import { useLocation } from "react-router-dom";
// import { createDonutChart } from "../ChartRequests/DonutChartRequest";
// import { createCustomBarChartRequest } from "../ChartRequests/CustomBarChartRequest";
// import { useSelector } from "react-redux";
// import { RootState } from "../../../../../redux/store";
// // Import all chart images
// import {getChartIcon} from './ChartIcons';
// import { ChartForm, ChartTabsProps, ChartType, Column, Dimension, DroppedItem, Filter, FormField, Metric,Option } from "../../../../../types/chartTabs";
// import { createGaugeChart } from "../ChartRequests/GaugeChartRequest";

// interface ChartMetric {
//   expression_type: string;
//   column: {
//     column_name: string;
//     type: string;
//   };
//   aggregate: string;
//   label: string;
// }
// const ChartTabs: React.FC<ChartTabsProps> = ({
//   dataset,
//   chartType,
//   onChartCreated,
//   onThemeChange,
//   selectedTheme,
//   onClearChartPreview, // Add this line
// }) => {
//   let [activeChartType, setActiveChartType] = useState<string>("");
//   const [chartTypes, setChartTypes] = useState<ChartType[]>([]);
//   const [chartForms, setChartForms] = useState<{ [key: string]: ChartForm }>(
//     {}
//   );
//   const [columns, setColumns] = useState<Column[]>([]);
//   const [formData, setFormData] = useState<{ [key: string]: any }>({});
//   const [popoverSelections, setPopoverSelections] = useState<{
//     [key: string]: any;
//   }>({});
//   const [uniqueValues, setUniqueValues] = useState<any>({});
//   let [defaultRowLimit, setDefaultRowLimit] = useState(10);
//   let [chartMetric, setChartMetric] = useState<Metric | null>(null);
//   const [chartMetrics, setChartMetrics] = useState<ChartMetric[]>([]);
//   let [filters, setFilters] = useState<Filter[]>([]);
//   const [chartDataModel, setChartDataModel] = useState<any>(null);
//   const [isLoading, setIsLoading] = useState(false);
//   const [error, setError] = useState<string | null>(null);
//   const [showLegend, setShowLegend] = useState(true);
//   const [legendOrientation, setLegendOrientation] = useState("top");
//   const [legendType, setLegendType] = useState("scroll");
//   const [showDataZoom, setShowDataZoom] = useState(false);
//   const [isExpressionEditorOpen, setIsExpressionEditorOpen] = useState(false);
//   const [showLabelLines, setShowLabelLines] = useState(false);
//   const [activeTab, setActiveTab] = useState<string>("default");
//   const [isChartCreated, setIsChartCreated] = useState(false);
//   const location = useLocation();
//   const { state } = location;
//   const [chartData, setChartData] = useState(null);
//   let [xAxisData, setXAxisData] = useState<any>(null);
//   const chartDetails: any = useSelector((state: RootState) => state.chart);
//   const handleEditClick = () => {
//     setIsExpressionEditorOpen(true);
//   };
//   const handleExpressionEditorClose = () => {
//     setIsExpressionEditorOpen(false);
//   };
//   const handleExpressionEditorSave = () => {
//     // Handle saving the expressions
//     setIsExpressionEditorOpen(false);
//   };
//   useEffect(() => {
//     fetchChartTypes();
//     fetchTableData();
//   }, [dataset]);

//   useEffect(() => {
//     if(chartDetails?.id) {
//       const { chart } = chartDetails;
//       const { queries, form_data } = chart?.params;
//       const { metrics } = queries[0];
//       const { filters: chartFilters } = queries[0];
//       if (metrics && metrics.length > 0) {
//         setChartMetric(metrics[0]);
//       }
  
//       saveMetric(
//         metrics[0]?.column?.column_name, metrics[0]?.aggregate, 
//         { id: metrics[0]?.column?.column_name, name: metrics[0]?.column?.column_name, type: metrics[0]?.column?.type}, 
//         ""
//       );
//       setTimeout(() => {
//         // setChartMetric(metrics[0]);
//         chartMetric = metrics[0];
//         setFilters(chartFilters);
//         filters = chartFilters;
//         activeChartType = chart.visualization_name;
//         defaultRowLimit = queries[0].row_limit.toString();
//         formData.dimensions = form_data?.groupby || [];
//         xAxisData = form_data?.x_axis || {};
//         formData["x-axis"] = form_data?.x_axis || {};
//       }, 1000);

//       setTimeout(() => {
//         handleCreateChart();
//       }, 2000);
//     }
//   }, [chartDetails]);
//   useEffect(() => {
//     if (state && state.chart) {
//       setActiveChartType(state.chart?.visualization_name);
//     }
//   }, [state]);
//   const fetchChartTypes = async () => {
//     try {
//       const response = await axios.post("/api/charts/dashboard_charts", {});
//       const allChartTypes = response.data.data.flatMap(
//         (section: any) => section.components
//       );

//       const filteredChartTypes = allChartTypes.filter((chart: ChartType) => {
//         if (chart.name.toLowerCase() === "sunburst chart") {
//           return chart.hasData === true;
//         }
//         return true;
//       });

//       const chartTypesWithIcons = filteredChartTypes.map(
//         (chart: ChartType) => ({
//           ...chart,
//           icon: getChartIcon(chart.name),
//         })
//       );

//       setChartTypes(chartTypesWithIcons);
//       if (chartTypesWithIcons.length > 0 && !state?.chart) {
//         setActiveChartType(chartTypesWithIcons[0].unique_id);
//       }
//       fetchChartForms(chartTypesWithIcons);
//     } catch (error) {
//       console.error("Error fetching chart types:", error);
//     }
//   };
//   const fetchChartForms = async (chartTypes: ChartType[]) => {
//     const forms: { [key: string]: ChartForm } = {};
//     for (const chart of chartTypes) {
//       try {
//         const response = await axios.post("/api/charts/get_chart_form", {
//           unique_id: chart.unique_id,
//         });
//         forms[chart.unique_id] = response.data.data;
//       } catch (error) {
//         console.error(`Error fetching form for ${chart.unique_id}:`, error);
//       }
//     }
//     setChartForms(forms);
//   };
//   const fetchTableData = async () => {
//     let params = {
//       database: "zolix_c2o",
//       schema: "public",
//       table: dataset,
//     };
//     try {
//       const response = await axios.post("/api/charts/get_columns", params);
//       const columnData: Column[] = response.data.data.map((col: any) => ({
//         name: col.name,
//         type: col.type,
//       }));
//       setColumns(columnData);
//       // Fetch unique values for each column
//       columnData.forEach((column: Column) => fetchUniqueValues(column.name));
//     } catch (error) {
//       console.error("Error fetching columns:", error);
//       alert(
//         "Failed to fetch columns. Please check the console for more details."
//       );
//     }
//   };
//   const fetchUniqueValues = async (column: string) => {
//     try {
//       const response = await axios.post("/api/charts/get_unique_values", {
//         database: "zolix_c2o",
//         schema: "public",
//         table: dataset,
//         column: [column],
//       });

//       setUniqueValues((prev) => ({
//         ...prev,
//         ...response.data.data,
//       }));
//     } catch (error) {
//       console.error(`Error fetching unique values for ${column}:`, error);
//     }
//   };
//   const handleChartTypeChange = (type: string) => {
//     setActiveChartType(type);
//     // Reset form data when changing chart type
//     setFormData({});
//     setChartMetric(null);
//     setFilters([]);
//   };
//   const handleFormChange = (key: string, value: any, openPopover = false) => {
//     if (key === "filters") {
//       if (Array.isArray(value)) {
//         setFilters(value);
//       } else if (value) {
//         setFilters((prevFilters) => [...prevFilters, value]);
//       }
//     } else if (key === "x_axis") {
//       // Only update x_axis if the value is explicitly set for x_axis
//       setFormData((prevData) => ({
//         ...prevData,
//         x_axis: value,
//       }));
//       if (value) {
//         setXAxisData({
//           name: value.name,
//           label: value.name,
//           sort_ascending: true,
//         });
//       } else {
//         setXAxisData(null);
//       }
//     } else {
//       setFormData((prevData) => ({
//         ...prevData,
//         [key]: value,
//       }));
//     }

//     if (openPopover && value) {
//       if (!Array.isArray(value)) {
//         setPopoverSelections((prev) => ({
//           ...prev,
//           [value.id]: { isOpen: true, column: value.name },
//         }));
//       } else if (Array.isArray(value) && value.length > 0) {
//         const lastItem = value[value.length - 1];
//         setPopoverSelections((prev) => ({
//           ...prev,
//           [lastItem.id]: { isOpen: true, column: lastItem.name },
//         }));
//       }
//     }
//   };
//   const handleRemoveItem = (key: string, id?: string) => {
//     if (key === "filters") {
//         setFilters((prevFilters) => prevFilters.filter((filter) => filter.id !== id));
//     } else if (key === "x_axis") {
//         setFormData((prevData) => {
//             const { x_axis, ...rest } = prevData;
//             return rest;
//         });
//         setXAxisData(null);
//     } else if (key === "metric") {
//         setFormData((prevData) => {
//             const { metric, ...rest } = prevData;
//             return rest;
//         });
//         setChartMetric(null);
//     } else if (key === "metrics") {
//         setFormData((prevData) => ({
//             ...prevData,
//             metrics: prevData.metrics?.filter((item: DroppedItem) => item.id !== id) || []
//         }));
//         setChartMetrics((prevMetrics) => 
//             prevMetrics.filter((metric) => metric.column.column_name !== id)
//         );
//     } else {
//         setFormData((prevData) => {
//             if (Array.isArray(prevData[key])) {
//                 return {
//                     ...prevData,
//                     [key]: prevData[key].filter((item: DroppedItem) => item.id !== id),
//                 };
//             } else {
//                 const { [key]: _, ...rest } = prevData;
//                 return rest;
//             }
//         });
//     }
//     // Remove from popoverSelections
//     if (id) {
//         setPopoverSelections((prev) => {
//             const { [id]: _, ...rest } = prev; // Remove the entry for the removed item
//             return rest;
//         });
//     }
// };
//     const handlePopoverSave = (fieldKey: string, itemId: string, data: any) => {
//     console.log("Handling popover save:", fieldKey, itemId, data);
//     if (!popoverSelections[itemId]) {
//       console.log("Item has been removed; not saving:", itemId);
//       return; // Prevent saving if it's already removed
//   }
//     let savedData: any = {
//       id: data.id,
//       type: data.type,
//       column: data.column,
//       alias: data.alias,
//       aggregate: data.aggregate,
//       operator: data.operator,
//       value: data.value,
//     };
//     let displayText = data.alias || data.column;

//     switch (fieldKey) {
//       case "x_axis":
//         displayText = data.alias || data.column;
//         setXAxisData({
//           name: data.column,
//           label: data.alias || data.column,
//           sort_ascending: true,
//         });
//         setFormData((prevData) => ({
//           ...prevData,
//           x_axis: {
//             name: data.column,
//             label: data.alias || data.column,
//             sort_ascending: true,
//           },
//         }));
//         break;
//         case "metric":
//           displayText = data.alias || (data.aggregate && data.column ? `${data.column} (${data.aggregate})` : data.column);
//           const columnData = columns.find((col) => col.name === data.column);
//           const newMetric: Metric = {
//             expression_type: "SIMPLE",
//             column: {
//               column_name: data.column,
//               type: columnData?.type || "UNKNOWN",
//             },
//             aggregate: data.aggregate,
//             label: data.alias || data.column,
//           };
//           setChartMetric(newMetric);
//           break;
  
//         case "metrics":
//           displayText = data.alias || (data.aggregate && data.column ? `${data.column} (${data.aggregate})` : data.column);
//           const metricsColumnData = columns.find((col) => col.name === data.column);
//           const newChartMetric: ChartMetric = {
//             expression_type: "SIMPLE",
//             column: {
//               column_name: data.column,
//               type: metricsColumnData?.type || "UNKNOWN",
//             },
//             aggregate: data.aggregate,
//             label: data.alias || data.column,
//           };
  
//           setChartMetrics(prevMetrics => {
//             const existingMetricIndex = prevMetrics.findIndex(m => m.column.column_name === itemId);
//             if (existingMetricIndex !== -1) {
//               // Update existing metric
//               const updatedMetrics = [...prevMetrics];
//               updatedMetrics[existingMetricIndex] = newChartMetric;
//               return updatedMetrics;
//             } else {
//               // Add new metric
//               return [...prevMetrics, newChartMetric];
//             }
//           });
//           break;
//       case "dimensions":
//         displayText = data.alias || data.column;
//         // Update dimensions in formData
//         setFormData((prevData) => {
//           const updatedDimensions = Array.isArray(prevData.dimensions)
//             ? prevData.dimensions.map((dim: any) =>
//                 dim.id === itemId
//                   ? { ...dim, name: data.column, alias: data.alias }
//                   : dim
//               )
//             : [];
//           return { ...prevData, dimensions: updatedDimensions };
//         });
//         break;
//       case "filters":
//         displayText = `${data.alias || data.column} ${data.operator} (${
//           Array.isArray(data.value) ? data.value.join(", ") : data.value
//         })`;
//         handleFilterChange(
//           itemId,
//           data.column,
//           data.operator,
//           Array.isArray(data.value.toString()) ? data.value.toString() : [data.value.toString()],
//           data.alias
//         );
//         break;
//       default:
//         displayText = data.alias || data.column;
//     }
//     setPopoverSelections((prev) => ({
//       ...prev,
//       [itemId]: { ...savedData, isOpen: false },
//     }));

//     console.log("Saved x-axis data:", formData.x_axis); // Add this log
//   };
//   const saveMetric = (
//     selectedColumn: string,
//     selectedAggregate: string,
//     item: DroppedItem,
//     alias: string
//   ) => {
//     if (!selectedColumn || !selectedAggregate || !item) {
//       alert("Please select a column and aggregate function.");
//       return;
//     }
//     const columnData = columns.find((col) => col.name === selectedColumn);
//     const newMetric: Metric = {
//       expression_type: "SIMPLE",
//       column: {
//         column_name: selectedColumn,
//         type: columnData ? columnData.type : "UNKNOWN",
//       },
//       aggregate: selectedAggregate,
//       label: alias || selectedColumn,
//     };
//     setChartMetric(newMetric);
//   };
//   const handleFilterChange = (
//     id: string,
//     col?: string,
//     op?: string,
//     val?: string[],
//     alias?: string
//   ) => {
//     setFilters((prevFilters) => {
//       const existingFilterIndex = prevFilters.findIndex(
//         (filter) => filter.id === id
//       );
//       const columnData = columns.find((column) => column.name === col);
//       const newFilter = {
//         id,
//         col: col || "",
//         op: op || "",
//         val: val || [],
//         alias: alias || "",
//         type: columnData ? columnData.type : "UNKNOWN",
//       };
//       if (existingFilterIndex !== -1) {
//         // Update existing filter
//         const updatedFilters = [...prevFilters];
//         updatedFilters[existingFilterIndex] = newFilter;
//         return updatedFilters;
//       } else {
//         // Add new filter
//         return [...prevFilters, newFilter];
//       }
//     });
//   };
//   const getDisplayText = (item: any, fieldKey: string) => {
//     if (fieldKey === "x_axis" && item) {
//       return item.name || item.label || "X-Axis";
//     }
//     if (fieldKey === "metrics" || fieldKey === "metric") {
//       // Check if the item is from Redux
//       if (item.column && item.aggregate) {
//         return `${item.column.column_name} (${item.aggregate})`;
//       }
//       // Check if the item is from popover selections
//       const selection = popoverSelections[item.id];
//       if (selection) {
//         const aggregate = selection.aggregate || "";
//         const column = selection.column || "";
//         const alias = selection.alias || "";
//         return alias || (aggregate ? `${column} (${aggregate})` : column);
//       }
//       // Fallback to item properties if neither Redux nor popover data is available
//       return item.label || (item.aggregate ? `${item.name} (${item.aggregate})` : item.name);
//     }
//     if (fieldKey === "dimensions" && item) {
//       const selection = popoverSelections[item.id];
//       return selection?.alias || item.name;
//     }
//     if (fieldKey === "filters" && item) {
//       const selection = popoverSelections[item.id];
//       if (selection) {
//         const column = selection.column || item.name || "";
//         const operator = selection.operator || "";
//         const value = Array.isArray(selection.value)
//           ? selection.value.map((v: Option) => v.value || v).join(", ")
//           : selection.value || "";
//         return `${column} ${operator} ${value ? `(${value})` : ""}`;
//       } else {
//         const column = item.col || "";
//         const operator = item.op || "";
//         const value = Array.isArray(item.val)
//           ? item.val.join(", ")
//           : item.val || "";
//         return `${column} ${operator} ${value ? `(${value})` : ""}`;
//       }
//     }
//     return item.name || "";
//   };
//   const renderChartDropdown = () => (
//     <Select value={activeChartType} onValueChange={handleChartTypeChange}>
//       <SelectTrigger className="w-full">
//         <SelectValue placeholder="Select a chart type">
//           {activeChartType && (
//             <div className="flex items-center">
//               <img
//                 src={
//                   chartTypes.find((ct) => ct.unique_id === activeChartType)
//                     ?.icon
//                 }
//                 alt={
//                   chartTypes.find((ct) => ct.unique_id === activeChartType)
//                     ?.name
//                 }
//                 className="w-6 h-6 mr-2"
//               />
//               <span>
//                 {
//                   chartTypes.find((ct) => ct.unique_id === activeChartType)
//                     ?.name
//                 }
//               </span>
//             </div>
//           )}
//         </SelectValue>
//       </SelectTrigger>
//       <SelectContent>
//         {chartTypes.map((chartType) => (
//           <SelectItem key={chartType.unique_id} value={chartType.unique_id}>
//             <div className="flex items-center">
//               <img
//                 src={chartType.icon}
//                 alt={chartType.name}
//                 className="w-6 h-6 mr-2"
//               />
//               <span>{chartType.name}</span>
//             </div>
//           </SelectItem>
//         ))}
//       </SelectContent>
//     </Select>
//   );
//   const DynamicPopoverContent: React.FC<{
//     field: FormField;
//     item: DroppedItem;
//     onClose: () => void;
//     onSave: (data: any) => void;
//   }> = ({ field, item, onClose, onSave }) => {
//     const storedData = popoverSelections[item.id] || {};
//     const [popoverData, setPopoverData] = useState<{
//       [key: string]: string | any;
//     }>({
//       columns: storedData.column || item.name,
//       aggregate: storedData.aggregate || "",
//       operator: storedData.operator || "",
//       value: storedData.value || [],
//       row_limit: defaultRowLimit,
//       alias: storedData.alias || "",
//     });
//     const handlePopoverChange = (key: string, value: string | Option[]) => {
//       setPopoverData((prev) => ({ ...prev, [key]: value }));
//     };
//     const handleSave = () => {
//       try {
//         const baseData = {
//           id: item.id,
//           type: item.type,
//           column: popoverData["columns"],
//           alias: popoverData["alias"],
//         };

//         let saveData;
//         switch (field.key) {
//           case "metrics":
//             saveData = {
//               ...baseData,
//               aggregate: popoverData["aggregate"],
//             };
//             break;
//           case "metric":
//             saveData = {
//               ...baseData,
//               aggregate: popoverData["aggregate"],
//             };
//             break;
//           case "filters":
//             saveData = {
//               ...baseData,
//               operator: popoverData["operator"],
//               value: Array.isArray(popoverData["value"])
//                 ? popoverData["value"].map((option: Option) => option.value)
//                 : popoverData["value"],
//             };
//             break;
//           default:
//             saveData = baseData;
//         }
//         console.log("Saving popover data:", saveData);
//         onSave(saveData);
//         onClose(); // Close the popover after successful save
//       } catch (error) {
//         console.error("Error saving popover data:", error);
//         // You might want to show an error message to the user here
//       }
//     };
//     const renderPopoverField = (popoverField: any) => {
//       switch (popoverField.key) {
//         case "columns":
//         case "operator":
//         case "aggregate":
//           return (
//             <Select
//               value={popoverData[popoverField.key] as string}
//               onValueChange={(value) =>
//                 handlePopoverChange(popoverField.key, value)
//               }
//             >
//               <SelectTrigger className="w-full">
//                 <SelectValue placeholder={popoverField.placeholder} />
//               </SelectTrigger>
//               <SelectContent>
//                 {popoverField.key === "columns"
//                   ? columns.map((column: Column) => (
//                       <SelectItem key={column.name} value={column.name}>
//                         {column.name}
//                       </SelectItem>
//                     ))
//                   : popoverField.options
//                       ?.filter((option: string) => option !== "")
//                       .map((option: string) => (
//                         <SelectItem key={option} value={option}>
//                           {option}
//                         </SelectItem>
//                       ))}
//               </SelectContent>
//             </Select>
//           );
//         case "value":
//           if (popoverData["columns"]) {
//             const options = (
//               Array.isArray(uniqueValues[popoverData["columns"] as string])
//                 ? uniqueValues[popoverData["columns"] as string].filter(
//                     (value: string) => value !== ""
//                   )
//                 : []
//             ).map((value: string) => ({ value, label: value }));

//             return (
//               <MultiSelect
//                 options={options}
//                 value={popoverData[popoverField.key]}
//                 onChange={(selected: Option[]) =>
//                   handlePopoverChange(popoverField.key, selected)
//                 }
//               />
//             );
//           }
//           return null;
//         case "alias":
//           return (
//             <input
//               type="text"
//               value={popoverData[popoverField.key] as string}
//               onChange={(e) =>
//                 handlePopoverChange(popoverField.key, e.target.value)
//               }
//               placeholder="Enter alias"
//               className="w-full p-2 border rounded"
//             />
//           );
//         default:
//           return (
//             <input
//               type="text"
//               value={popoverData[popoverField.key] as string}
//               onChange={(e) =>
//                 handlePopoverChange(popoverField.key, e.target.value)
//               }
//               placeholder={popoverField.placeholder}
//               className="w-full p-2 border rounded"
//             />
//           );
//       }
//     };
//     return (
//       <Tabs defaultValue="SIMPLE" className="w-full">
//         <TabsList
//           className={`grid w-full ${
//             Object.keys(field.popover || {}).length === 1
//               ? "grid-cols-1"
//               : "grid-cols-2"
//           }`}
//         >
//           {Object.keys(field.popover || {}).map((tabKey) => (
//             <TabsTrigger
//               key={tabKey}
//               value={tabKey}
//               className={tabKey === "SIMPLE" ? "shadow-lg" : ""}
//             >
//               {tabKey}
//             </TabsTrigger>
//           ))}
//         </TabsList>
//         {Object.entries(field.popover || {}).map(([tabKey, tabFields]) => (
//           <TabsContent key={tabKey} value={tabKey}>
//             <Card className="border-none shadow-none mt-2">
//               <CardContent>
//                 <div className="grid gap-4">
//                   {tabFields.map((popoverField: any) => (
//                     <div key={popoverField.key} className="grid gap-2">
//                       <Label>{popoverField.label}</Label>
//                       {renderPopoverField(popoverField)}
//                     </div>
//                   ))}
//                 </div>
//               </CardContent>
//               <CardFooter className="flex justify-between">
//                 <Button
//                   className="bg-slate-400 hover:bg-slate-600"
//                   onClick={onClose}
//                 >
//                   Close
//                 </Button>
//                 <Button
//                   className="bg-slate-400 hover:bg-slate-600"
//                   onClick={handleSave}
//                 >
//                   Save
//                 </Button>
//               </CardFooter>
//             </Card>
//           </TabsContent>
//         ))}
//       </Tabs>
//     );
//   };
//   const SingleDropZone: React.FC<{
//     onDrop: (item: DroppedItem) => void;
//     item: DroppedItem | null;
//     onRemove: () => void;
//     placeholder: string;
//     field: FormField;
//     acceptTypes: string[];
//   }> = ({ onDrop, item, onRemove, placeholder, field, acceptTypes }) => {
//       const [{ isOver }, drop] = useDrop(() => ({
//       accept: acceptTypes,
//       drop: (droppedItem: DroppedItem) => {
//         onDrop(droppedItem);
//         setPopoverSelections((prev) => ({
//           ...prev,
//           [droppedItem.id]: { ...prev[droppedItem.id], isOpen: true },
//         }));
//       },
//       collect: (monitor) => ({
//         isOver: !!monitor.isOver(),
//       }),
//     }));
//     const isReduxMetric = field.key === "metric" && item && 'column' in item && 'aggregate' in item;
//     return (
//       <div
//         ref={drop}
//         className={`border border-gray-300 rounded-md overflow-hidden text-sm ${
//           isOver ? "bg-blue-50" : "bg-white"
//         }`}
//       >
//         {!item ? (
//           <div className="p-1 text-gray-400">{placeholder}</div>
//         ) : (
//           <div className="flex items-center p-1 border-gray-200">
//             <Button
//               variant="icon"
//               className="text-gray-500 hover:text-red-500 px-2 px-1"
//               onClick={() => {
//                 onRemove();
//                 handleRemoveItem(field.key, item.id);
//               }}
//             >
//               <IconX stroke={1.5} size={14} />
//             </Button>
//           <div className="flex-grow px-2 py-1 bg-white rounded text-gray-800">
//             {getDisplayText(item, field.key)}
//             </div>
//             {field.popover && (
//               <Popover
//                 open={popoverSelections[item.id]?.isOpen}
//                 onOpenChange={(open) =>
//                   setPopoverSelections((prev) => ({
//                     ...prev,
//                     [item.id]: { ...prev[item.id], isOpen: open },
//                   }))
//                 }
//               >
//                 <PopoverTrigger asChild>
//                   <Button variant="icon" className="px-2 px-1">
//                     <IconArrowBarToRight stroke={1.5} size={14} />
//                   </Button>
//                 </PopoverTrigger>
//                 <PopoverContent className="w-96 bg-white border border-gray-300">
//                   <DynamicPopoverContent
//                     field={field}
//                     item={item}
//                     onClose={() =>
//                       setPopoverSelections((prev) => ({
//                         ...prev,
//                         [item.id]: { ...prev[item.id], isOpen: false },
//                       }))
//                     }
//                     onSave={(data) => {
//                       handlePopoverSave(field.key, item.id, data);
//                     }}
//                   />
//                 </PopoverContent>
//               </Popover>
//             )}
//           </div>
//         )}
//       </div>
//     );
//   };
//   const MultipleDropZone: React.FC<{
//     onDrop: (item: DroppedItem) => void;
//     items: DroppedItem[];
//     onRemove: (key: string, id: string) => void;
//     placeholder: string;
//     field: FormField;
//     acceptTypes: string[];
//   }> = ({ onDrop, items, onRemove, placeholder, field, acceptTypes }) => {
//     const [{ isOver }, drop] = useDrop(() => ({
//       accept: acceptTypes,
//       drop: (item: DroppedItem) => {
//         const newItem = { ...item, id: `${item.id}_${Date.now()}` }; // Create a new unique ID
//         onDrop(newItem);
//         setPopoverSelections((prev) => ({
//           ...prev,
//           [newItem.id]: { ...prev[newItem.id], isOpen: true },
//         }));
//       },
//       collect: (monitor) => ({
//         isOver: !!monitor.isOver(),
//       }),
//     }));
//     const displayItems = field.key === "filters" ? filters : items;
//     return (
//       <div
//         ref={drop}
//         className={`border border-gray-300 rounded-md overflow-hidden text-sm ${
//           isOver ? "bg-blue-50" : "bg-white"
//         }`}
//       >
//         {displayItems.length === 0 ? (
//           <div className="p-1 text-gray-400">{placeholder}</div>
//         ) : (
//           <div>
//             {displayItems.map((item) => (
//               <div key={item.id || item.col} className="flex items-center p-1 border-b border-gray-200 last:border-b-0">
//                 <Button
//                   variant="icon"
//                   className="text-black-500 hover:text-red-500 px-2 px-1"
//                   onClick={() => {
//                     onRemove(field.key, item.id || item.col);
//                     handleRemoveItem(field.key, item.id || item.col);
//                   }}> 
//                 <IconX stroke={1.5} size={14} />
//                 </Button>
//                 <div className="flex-grow px-2 py-1 bg-white rounded text-gray-800">
//                   {getDisplayText(item, field.key)} </div>
//                 {field.popover && (
//                   <Popover
//                     open={popoverSelections[item.id]?.isOpen}
//                     onOpenChange={(open) =>
//                       setPopoverSelections((prev) => ({
//                         ...prev,
//                         [item.id]: { ...prev[item.id], isOpen: open },
//                       }))
//                     }
//                   >
//                     <PopoverTrigger asChild>
//                       <Button variant="icon" className="px-2 px-1">
//                         <IconArrowBarToRight stroke={1.5} size={14} />
//                       </Button>
//                     </PopoverTrigger>
//                     <PopoverContent className="w-96">
//                       <DynamicPopoverContent
//                         field={field}
//                         item={item}
//                         onClose={() =>
//                           setPopoverSelections((prev) => ({
//                             ...prev,
//                             [item.id]: { ...prev[item.id], isOpen: false },
//                           }))
//                         }
//                         onSave={(data) => {
//                           handlePopoverSave(field.key, item.id, data);
//                         }}
//                       />
//                     </PopoverContent>
//                   </Popover>
//                 )}
//               </div>
//             ))}
//           </div>
//         )}
//       </div>
//     );
//   };
//   const renderFormField = (field: FormField) => {
//     switch (field.type) {
//       case "select":
//         return (
//           <Select
//             value={formData[field.key] || ""}
//             onValueChange={(value) => handleFormChange(field.key, value)}
//           >
//             <SelectTrigger className="w-full bg-white">
//               <SelectValue
//                 placeholder={field.placeholder || `Select ${field.label}`}
//               />
//             </SelectTrigger>
//             <SelectContent>
//               <SelectGroup>
//                 <SelectLabel>{field.label}</SelectLabel>
//                 {field.options?.map((option) => (
//                   <SelectItem key={option} value={option}>
//                     {option}
//                   </SelectItem>
//                 ))}
//               </SelectGroup>
//             </SelectContent>
//           </Select>
//         );
//         case "drag_and_drop_or_select_single":
//           if (field.key === "metric" && chartMetric) {
//             // Use chartMetric from Redux if available
//             return (
//               <SingleDropZone
//                 onDrop={(item) => {
//                   handleFormChange("metric", item, true);
//                   // Update Redux state if needed
//                   setChartMetric({
//                     expression_type: "SIMPLE",
//                     column: {
//                       column_name: item.name,
//                       type: item.type || "UNKNOWN",
//                     },
//                     aggregate: item.aggregate || "",
//                     label: item.label || item.name,
//                   });
//                 }}
//                 item={{
//                   id: chartMetric.column.column_name,
//                   name: chartMetric.label,
//                   type: chartMetric.column.type,
//                 }}
//                 onRemove={() => {
//                   handleFormChange("metric", null);
//                   setChartMetric(null);
//                 }}
//                 placeholder={field.placeholder || "Drop item here"}
//                 field={field}
//                 acceptTypes={["METRIC", "COLUMN"]}
//               />
//             );
//           } else {
//             // Existing functionality
//             return (
//               <SingleDropZone
//                 onDrop={(item) => handleFormChange(field.key, item, true)}
//                 item={formData[field.key] || null}
//                 onRemove={() => {
//                   handleFormChange(field.key, null);
//                   if (field.key === "metric") {
//                     setChartMetric(null);
//                   }
//                 }}
//                 placeholder={field.placeholder || "Drop item here"}
//                 field={field}
//                 acceptTypes={["METRIC", "COLUMN"]}
//               />
//             );
//           }
//           case "drag_and_drop_or_select_multiple":
//             return (
//               <MultipleDropZone
//                 onDrop={(item) =>
//                   handleFormChange(
//                     field.key,
//                     [...(field.key === "filters" ? filters : (formData[field.key] || [])), item],
//                     true
//                   )
//                 }
//                 items={field.key === "filters" ? filters : (formData[field.key] || [])}
//                 onRemove={(id) =>
//                   field.key === "filters"
//                     ? handleRemoveItem("filters", id)
//                     : handleFormChange(
//                         field.key,
//                         (formData[field.key] || []).filter(
//                           (item: DroppedItem) => item.id !== id
//                         )
//                       )
//                 }
//                 placeholder={field.placeholder || "Drop items here"}
//                 field={field}
//                 acceptTypes={["METRIC", "COLUMN"]}
//               />
//             );
            
//         case "checkbox":
//         return (
//           <div className="items-top flex space-x-2">
//             <input
//               type="checkbox"
//               id={field.key}
//               checked={formData[field.key] || false}
//               onChange={(e) => handleFormChange(field.key, e.target.checked)}
//               className="form-checkbox h-4 w-5 text-blue-600"
//             />
//             <div className="grid gap-1.5 leading-none">
//               <label
//                 htmlFor={field.key}
//                 className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
//               ></label>
//             </div>
//           </div>
//         );
//       default:
//         return (
//           <input
//             type="text"
//             value={formData[field.key] || ""}
//             onChange={(e) => handleFormChange(field.key, e.target.value)}
//             placeholder={field.placeholder}
//             className="w-full p-2 border rounded"
//           />
//         );
//     }
//   };
//   const renderActiveSection = () => {
//     const activeForm = chartForms[activeChartType];
//     if (!activeForm) return null;
//     return (
//       <div className="space-y-4">
//         {activeForm.parameters.map((field: FormField) => (
//           <div key={field.key}>
//             <Label>{field.label}</Label>
//             {field.key === "x_axis" ? (
//               <SingleDropZone
//                 onDrop={(item) => handleFormChange("x_axis", item, true)}
//                 item={formData.x_axis || null}
//                 onRemove={() => {
//                   handleFormChange("x_axis", null);
//                   setXAxisData(null);
//                 }}
//                 placeholder="Drop column for X-axis"
//                 field={field}
//                 acceptTypes={["COLUMN"]}
//               />
//             ) : (
//               renderFormField(field)
//             )}
//           </div>
//         ))}
//       </div>
//     );
//   };
//   const handleCreateChart = async () => {
//     setIsLoading(true);
//     setError(null);

//     try {
//       let chartData;
//         switch (activeChartType) {
//           case "pie":
//             chartData = await createPieChart(
//               dataset,
//               filters,
//               chartMetric,
//               {
//                 dimensions: (formData.dimensions as Dimension[])?.map(
//                   (dim) => ({
//                     ...dim,
//                     type: columns.find((col) => col.name === dim.name)?.type,
//                   })
//                 ),
//               },
//               defaultRowLimit,
//               showLegend,
//               legendOrientation,
//               legendType
//             );
//             break;
//           case "donut":
//             chartData = await createDonutChart(
//               dataset,
//               filters,
//               chartMetric,
//               {
//                 dimensions: (formData.dimensions as Dimension[])?.map(
//                   (dim) => ({
//                     ...dim,
//                     type: columns.find((col) => col.name === dim.name)?.type,
//                   })
//                 ),
//               },
//               defaultRowLimit,
//               showLegend,
//               legendOrientation,
//               legendType
//             );
//             break;
//             case "gauge":
//             chartData = await createGaugeChart(
//               dataset,
//               filters,
//               chartMetric,
//               {
//                 dimensions: (formData.dimensions as Dimension[])?.map(
//                   (dim) => ({
//                     ...dim,
//                     type: columns.find((col) => col.name === dim.name)?.type,
//                   })
//                 ),
//               },
//               defaultRowLimit,
//               showLegend,
//               legendOrientation,
//               legendType
//             );
//             break;
//             case "bar":
//               if (!chartMetrics) {
//                 setError("Please select at least one metric for the bar chart");
//                 setIsLoading(false);
//                 return;
//               }
              
//               chartData = await createBarChartRequest(
//                 dataset,
//                 filters,
//                 chartMetrics,
//                 {
//                   dimensions: formData.dimensions,
//                   x_axis: formData["x-axis"],
//                 },
//                 defaultRowLimit,
//                 showLegend,
//                 showDataZoom,
//                 legendOrientation,
//                 legendType
//               );
//               break;
//           case "custom_bar":
//             console.log(
//               "X-axis data before creating custom bar chart:",
//               formData.x_axis
//             ); // Add this log
//             chartData = await createCustomBarChartRequest(
//               dataset,
//               filters,
//               chartMetrics,
//               {
//                 dimensions: formData.dimensions,
//                 x_axis: formData["x-axis"], // Use formData.x_axis instead of xAxisData
//               },
//               defaultRowLimit,
//               showLegend,
//               showDataZoom,
//               legendOrientation,
//               legendType
//             );
//             break;
//             case "line":
//               if (!chartMetrics) {
//                 setError("Please select at least one metric for the line chart");
//                 setIsLoading(false);
//                 return;
//               }
            
//               if (!formData["x-axis"]?.name) {
//                 setError("Please configure the x-axis for the line chart");
//                 setIsLoading(false);
//                 return;
//               }
            
//               chartData = await createLineChartRequest(
//                 dataset,
//                 filters,
//                 chartMetrics,
//                 {
//                   dimensions: formData.dimensions,
//                   x_axis: formData["x-axis"],
//                 },
//                 defaultRowLimit,
//                 showLegend,
//                 showDataZoom,
//                 legendOrientation,
//                 legendType
//               );
//               break;
//             case "area":
//               chartData = await createAreaChartRequest(
//                 dataset,
//                 filters,
//                 chartMetrics, // Make sure this is properly defined
//                 {
//                   dimensions: formData.dimensions,
//                   x_axis: formData["x-axis"],
//                 },
//                 defaultRowLimit,
//                 showLegend,
//                 showDataZoom,
//                 legendOrientation,
//                 legendType
//               );
//               break;
//           case "table":
//             chartData = await createTableRequest(
//               dataset,
//               filters,
//               chartMetric,
//               {
//                 dimensions: formData.dimensions,
//               },
//               defaultRowLimit,
//               showLegend,
//               legendOrientation,
//               legendType
//             );
//             break;
//           case "pivot_table":
//             chartData = await createPivotTableRequest(
//               dataset,
//               filters,
//               chartMetric,
//               {
//                 dimensions: formData.dimensions,
//               },
//               defaultRowLimit,
//               showLegend,
//               legendOrientation,
//               legendType
//             );
//             break;
//           case "big_number":
//             chartData = await createBigNumberRequest(
//               dataset,
//               filters,
//               chartMetric,
//               {
//                 dimensions: formData.dimensions,
//                 x_axis: formData["x-axis"], // Use formData.x_axis instead of xAxisData
//               },
//               defaultRowLimit
//             );
//             break;
//           default:
//             throw new Error("Unsupported chart type: " + activeChartType);
//         }

//       console.log("Chart data before sending:", { ...chartData, showDataZoom });
//       onChartCreated({
//         ...chartData,
//         showLegend,
//         legendOrientation,
//         legendType,
//         showDataZoom,
//         showLabelLines,
//       });
//     } catch (error) {
//       console.error("Error creating chart:", error);
//       setError("Failed to create chart. Please try again.");
//     } finally {
//       setIsLoading(false);
//     }
//   };
//   return (
//     <div className="bg-white flex flex-col h-full w-80 border-r border-gray-200">
//       <div className="p-2 flex justify-between items-center">
//         <div className="w-80 ">
//           {/* <AskAITab onChartCreated={setChartData} /> */}

//           {renderChartDropdown()}
//         </div>
//         {/* <SettingsIcon /> */}
//       </div>
//       <div className="flex-grow overflow-y-auto bg-white">
//         <div className="p-2 bg-white">{renderActiveSection()}</div>
//       </div>
//       <div className="p-2 border-t border-gray-200 bg-white">
//         {error && <p className="text-red-500 mb-2">{error}</p>}
//         <Button
//           className="w-full bg-[#0047AB] text-white hover:bg-[#0047AB]"
//           onClick={handleCreateChart}
//           disabled={isLoading}
//         >
//           {isLoading ? "CREATING CHART..." : "CREATE CHART"}
//         </Button>
//       </div>
     
//     </div>
//   );
// };
// export default ChartTabs;