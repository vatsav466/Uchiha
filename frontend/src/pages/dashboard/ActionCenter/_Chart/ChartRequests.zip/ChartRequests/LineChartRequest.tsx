// import axios from 'axios';

// interface ChartMetric {
//   expression_type: string;
//   column: {
//     column_name: string;
//     type: string;
//   };
//   aggregate: string;
//   label: string;
// }

// interface Filter {
//   col?: string;
//   op?: string;
//   val?: string[];
// }

// interface FormData {
//   dimensions?: Array<{ column: string }>;
//   metrics?: Array<{ column: string; aggregate: string }>;
//   orderBy?: Array<{ column: string; descending: boolean }>;
// }

// export const createLineChartRequest = async (
//   dataset: string,
//   filters: Filter[],
//   chartMetric: ChartMetric | null,
//   formData: FormData,
//   defaultRowLimit: number
// ) => {
//   const chartRequest = {
//     database: "zolix_c2o",
//     schema: "public",
//     table: dataset,
//     visualization_name: "line",
//     name: "Line Chart",
//     description: "",
//     params: {
//       queries: [
//         {
//           filters: filters.map(filter => ({
//             col: filter.col,
//             op: filter.op,
//             val: filter.val
//           })),
//           columns: [],
//           metrics: [chartMetric],
//           orderby: formData.orderBy?.map(order => ({
//             order_by: order.descending,
//             expression_type: "SIMPLE",
//             column: {
//               column_name: order.column,
//               type: "UNKNOWN"
//             },
//             aggregate: chartMetric?.aggregate || "SUM",
//             label: order.column
//           })) || [],
//           row_limit: defaultRowLimit,
//           series_columns: [],
//           series_limit: 0,
//           order_descending: formData.orderBy?.[0]?.descending || false
//         }
//       ],
//       form_data: {
//         x_axis: {},
//         metrics: [],
//         groupby: formData.dimensions?.map(dim => ({ name: dim.column, label: dim.column })) || [],
//         order_descending: formData.orderBy?.[0]?.descending || false,
//         row_limit: defaultRowLimit,
//         show_legend: false
//       }
//     }
//   };

//   console.log("Line Chart API Request Body:", JSON.stringify(chartRequest, null, 2));

//   const response = await axios.post('/api/charts/chart', chartRequest);
//   console.log("Line Chart API Response Body:", response.data);

//   if (response.data.status === true && response.data.data) {
//     return {
//       chartType: 'line',
//       chartData: response.data.data
//     };
//   } else {
//     throw new Error("Invalid response format for line chart");
//   }
// // };
// import axios from 'axios';

// interface ChartMetric {
//   expression_type: string;
//   column: {
//     column_name: string;
//     type: string;
//   };
//   aggregate: string;
//   label: string;
// }

// interface Filter {
//   col?: string;
//   op?: string;
//   val?: string[];
// }

// interface FormData {
//   dimensions?: Array<{ id: string; name: string }>;
// }

// export const createLineChartRequest = async (
//   dataset: string,
//   filters: Filter[],
//   chartMetric: ChartMetric | null,
//   formData: FormData,
//   defaultRowLimit: number,
//   showLegend: boolean,
//   legendOrientation: string,
//   legendType: string
// ) => {
//   const chartRequest = {
//     "database": "zolix_c2o",
//     "schema": "public",
//     "table": dataset,
//     "visualization_name": "line",
//     "name": "Line Chart",
//     "description": "",
//     "params": {
//       "queries": [
//         {
//           "filters": filters.map(filter => ({
//             col: filter.col,
//             op: filter.op,
//             val: filter.val ? filter.val.flat() : [] // Flatten the val array
//           })),
//           "metrics": chartMetric ? [chartMetric] : [],
//           "orderby": chartMetric ? [
//             {
//               "order_by": false,
//               ...chartMetric
//             }
//           ] : [],
//           "row_limit": defaultRowLimit,
//           "series_columns": [],
//           "series_limit": 0,
//           "order_descending": true
//         }
//       ],
//       "form_data": {
//         "x_axis": {},
//         "groupby": formData.dimensions?.map(dim => ({
//           name: dim.name,
//           label: dim.name
//         })) || [],
//         "order_descending": false,
//         "row_limit": defaultRowLimit,
//         "show_legend": showLegend,
//         "legend_orientation": legendOrientation,
//         "legend_type": legendType
//       }
//     }
//   };

//   console.log("Line Chart API Request Body:", JSON.stringify(chartRequest, null, 2));

//   const response = await axios.post('/api/charts/chart', chartRequest);
//   console.log("Line Chart API Response Body:", response.data);

//   if (response.data.status === true && response.data.data) {
//     return {
//       chartType: 'line',
//       chartData: response.data.data,
//       chartRequest: chartRequest,
//       showLegend,
//       legendOrientation,
//       legendType
//     };
//   } else {
//     throw new Error("Invalid response format for line chart");
//   }
// // };
// import axios from 'axios';

// interface ChartMetric {
//   expression_type: string;
//   column: {
//     column_name: string;
//     type: string;
//   };
//   aggregate: string;
//   label: string;
// }

// interface Filter {
//   col?: string;
//   op?: string;
//   val?: string[];
// }

// interface XAxisConfig {
//   name: string;
//   label: string;
//   sort_ascending: boolean;
// }

// interface FormData {
//   dimensions?: Array<{ id: string; name: string }>;
//   x_axis?: XAxisConfig;
// }

// export const createLineChartRequest = async (
//   dataset: string,
//   filters: Filter[],
//   chartMetric: ChartMetric | null,
//   formData: FormData,
//   defaultRowLimit: number,
//   showLegend: boolean,
//   showDataZoom: boolean,
//   legendOrientation: string,
//   legendType: string = 'scroll' // Set a default value
// ) => {
//   const chartRequest = {
//     "database": "zolix_c2o",
//     "schema": "public",
//     "table": dataset,
//     "visualization_name": "line",
//     "name": "Line Chart",
//     "description": "",
//     "params": {
//       "queries": [
//         {
//           "filters": filters.map(filter => ({
//             col: filter.col,
//             op: filter.op,
//             val: filter.val ? filter.val.flat() : []
//           })),
//           "metrics": chartMetric ? [chartMetric] : [],
//           "orderby": chartMetric ? [
//             {
//               "order_by": false,
//               ...chartMetric
//             }
//           ] : [],
//           "row_limit": defaultRowLimit,
//           "series_columns": [],
//           "series_limit": 0,
//           "order_descending": true
//         }
//       ],
//       "form_data": {
//         "x_axis": formData.x_axis ? {
//           name: formData.x_axis.name,
//           label: formData.x_axis.label || "",
//           sort_ascending: formData.x_axis.sort_ascending || false
//         } : {},
//         "time_grain": "",
//         "groupby": formData.dimensions?.map(dim => ({
//           name: dim.name,
//           label: dim.name
//         })) || [],
//         "query_mode": "",
//         "show_legend": showLegend,
//         "show_data_zoom": showDataZoom,
//         "legend_orientation": legendOrientation,
//         "legend_type": legendType
//       }
//     },
//     "tags": [
//       {
//         "name": "",
//         "value": ""
//       }
//     ],
//     "group_id": 0,
//     "group_name": "",
//     "type": "Manual",
//     "user_query": "",
//     "user_ai_text": "",
//     "created_by": "",
//     "hashed_value": ""
//   };

//   console.log("API Request Body:", JSON.stringify(chartRequest, null, 2));

//   const response = await axios.post('/api/charts/chart', chartRequest);
//   console.log("API Response Body:", response.data);

//   if (response.data.status === true && response.data.data) {
//     return {
//       chartType: 'line',
//       chartData: response.data.data,
//       chartRequest: chartRequest,
//       showLegend,
//       showDataZoom,
//       legendOrientation,
//       legendType
//     };
//   } else {
//     throw new Error("Invalid response format");
//   }
// };


import axios from 'axios';

interface ChartMetric {
  expression_type: string;
  column: {
    column_name: string;
    type: string;
  };
  aggregate: string;
  label: string;
}

interface Filter {
  col?: string;
  op?: string;
  val?: string[];
}

interface XAxisConfig {
  name: string;
  label: string;
  sort_ascending: boolean;
}

interface FormData {
  dimensions?: Array<{ id: string; name: string }>;
  x_axis?: XAxisConfig;
}

export const createLineChartRequest = async (
  dataset: string,
  filters: Filter[],
  chartMetrics: ChartMetric[] | ChartMetric | null,
  formData: FormData,
  defaultRowLimit: number,
  timeGrain: string,
  showLegend: boolean,
  showDataZoom: boolean,
  legendOrientation: string,
  legendType: string = 'scroll'
) => {
  // Convert chartMetrics to array if it's a single metric
  const metricsArray = chartMetrics 
    ? Array.isArray(chartMetrics) 
      ? chartMetrics 
      : [chartMetrics]
    : [];

  // Ensure we have at least one metric
  if (metricsArray.length === 0) {
    throw new Error("At least one metric is required for line chart");
  }

  // Validate x-axis configuration
  if (!formData.x_axis?.name) {
    throw new Error("X-axis configuration is required for line chart");
  }

  const chartRequest = {
    "database": "zolix_c2o",
    "schema": "public",
    "table": dataset,
    "visualization_name": "line",
    "name": "Line Chart",
    "description": "",
    "params": {
      "queries": [
        {
          "filters": filters.map(filter => ({
            col: filter.col,
            op: filter.op,
            val: filter.val ? filter.val.flat() : []
          })),
          "metrics": metricsArray,
          "orderby": metricsArray.map(metric => ({
            order_by: true,
            ...metric
          })),
          "row_limit": defaultRowLimit,
          "series_columns": [],
          "series_limit": 0,
          "order_descending": true
        }
      ],
      "form_data": {
        "x_axis": formData.x_axis ? {
          name: formData.x_axis.name,
          label: formData.x_axis.label || "",
          sort_ascending: formData.x_axis.sort_ascending || false
        } : {},
        "time_grain": timeGrain,
        "groupby": formData.dimensions?.map(dim => ({
          name: dim.name,
          label: dim.name
        })) || [],
        "query_mode": "",
        "show_legend": showLegend,
        "show_data_zoom": showDataZoom,
        "legend_orientation": legendOrientation,
        "legend_type": legendType
      }
    },
    "tags": [
      {
        "name": "",
        "value": ""
      }
    ],
    "group_id": 0,
    "group_name": "",
    "type": "Manual",
    "user_query": "",
    "user_ai_text": "",
    "created_by": "",
    "hashed_value": ""
  };

  try {
    console.log("Line Chart API Request Body:", JSON.stringify(chartRequest, null, 2));
    const response = await axios.post('/api/charts/chart', chartRequest);
    console.log("Line Chart API Response Body:", response.data);

    if (response.data.status === true && response.data.data) {
      return {
        chartType: 'line',
        chartData: response.data.data,
        chartRequest: chartRequest,
        showLegend,
        showDataZoom,
        legendOrientation,
        legendType
      };
    } else {
      throw new Error("Invalid response format from line chart API");
    }
  } catch (error) {
    console.error("Error creating line chart:", error);
    throw error;
  }
};