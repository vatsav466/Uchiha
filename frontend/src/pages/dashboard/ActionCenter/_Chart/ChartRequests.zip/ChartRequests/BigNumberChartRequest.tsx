// import axios from 'axios';

// interface ChartMetric {
//   expression_type: string;
//   column: {
//     column_name: string;
//     type: string;
//   };
//   aggregate: string;
//   label: string;
// }

// interface Filter {
//   col?: string;
//   op?: string;
//   val?: string[];
// }

// interface FormData {
//   metric?: { column: string; aggregate: string };
// }

// export const createBigNumberRequest = async (
//   dataset: string,
//   filters: Filter[],
//   chartMetric: ChartMetric | null,
//   formData: FormData,
//   defaultRowLimit: number
// ) => {
//   const chartRequest = {
//     database: "zolix_c2o",
//     schema: "public",
//     table: dataset,
//     visualization_name: "bignumber",
//     name: "Big Number Metric",
//     description: "",
//     params: {
//       queries: [
//         {
//           filters: filters.map(filter => ({
//             col: filter.col,
//             op: filter.op,
//             val: filter.val ? filter.val.flat() : [] // Flatten the val array
//                       })),
//           columns: [],
//           metrics: [chartMetric || {
//             expression_type: "SIMPLE",
//             column: {
//               column_name: formData.metric?.column || "",
//               type: "UNKNOWN"
//             },
//             aggregate: formData.metric?.aggregate || "COUNT",
//             label: formData.metric?.column || "Metric"
//           }],
//           orderby: [],
//           row_limit: 1,
//           series_columns: [],
//           series_limit: 0,
//           order_descending: true
//         }
//       ],
//       form_data: {
//         x_axis: {},
//         metrics: [],
//         groupby: [],
//         query_mode: "aggregate",
//         order_descending: false,
//         row_limit: 1,
//         show_legend: false
//       }
//     }
//   };

//   console.log("Big Number API Request Body:", JSON.stringify(chartRequest, null, 2));

//   const response = await axios.post('/api/charts/chart', chartRequest);
//   console.log("Big Number API Response Body:", response.data);

//   if (response.data.status === true && response.data.data) {
//     return {
//       chartType: 'big_number',
//       chartData: response.data.data
//     };
//   } else {
//     throw new Error("Invalid response format for big number chart");
//   }
// // };
// import axios from 'axios';

// interface ChartMetric {
//   expression_type: string;
//   column: {
//     column_name: string;
//     type: string;
//   };
//   aggregate: string;
//   label: string;
// }

// interface Filter {
//   col?: string;
//   op?: string;
//   val?: string[];
// }

// interface XAxisConfig {
//   name: string;
//   label: string;
//   sort_ascending: boolean;
// }

// interface FormData {
//   dimensions?: Array<{ id: string; name: string }>;
//   x_axis?: XAxisConfig;
// }


// export const createBigNumberRequest = async (
//   dataset: string,
//   filters: Filter[],
//   chartMetric: ChartMetric | null,
//   formData: FormData,
//   defaultRowLimit: number
// ) => {
//   const chartRequest = {
//     database: "zolix_c2o",
//     schema: "public",
//     table: dataset,
//     visualization_name: "bignumber",
//     name: "",
//     description: "",
//   "params": {
//       "queries": [
//         {
//           "filters": filters.map(filter => ({
//             col: filter.col,
//             op: filter.op,
//             val: filter.val ? filter.val.flat() : []
//           })),
//           "metrics": chartMetric ? [chartMetric] : [],
//           "orderby": chartMetric ? [
//             {
//               "order_by": false,
//               ...chartMetric
//             }
//           ] : [],
//           "row_limit": defaultRowLimit,
//           "series_columns": [],
//           "series_limit": 0,
//           "order_descending": true
//         }
//       ],
//       "form_data": {
//         "x_axis": formData.x_axis ? {
//           name: formData.x_axis.name,
//           label: formData.x_axis.label || "",
//           sort_ascending: formData.x_axis.sort_ascending || false
//         } : {},
//         "time_grain": "",
//         "groupby": formData.dimensions?.map(dim => ({
//           name: dim.name,
//           label: dim.name
//         })) || [],
//         "query_mode": "",
//         "show_legend": "",
//         "show_data_zoom": '',
//         "legend_orientation": '',
//         "legend_type": ''
//       }
//     },
//     "tags": [
//       {
//         "name": "",
//         "value": ""
//       }
//     ],
//     "group_id": 0,
//     "group_name": "",
//     "type": "Manual",
//     "user_query": "",
//     "user_ai_text": "",
//     "created_by": "",
//     "hashed_value": ""
//   };
//   console.log("Big Number API Request Body:", JSON.stringify(chartRequest, null, 2));

//   const response = await axios.post('/api/charts/chart', chartRequest);
//   console.log("Big Number API Response Body:", response.data);

//   if (response.data.status === true && response.data.data) {
//     return {
//       chartType: 'big_number',
//       chartData: response.data.data
//     };
//   } else {
//     throw new Error("Invalid response format for big number chart");
//   }
// };
import axios from 'axios';

interface ChartMetric {
  expression_type: string;
  column: {
    column_name: string;
    type: string;
  };
  aggregate: string;
  label: string;
}

interface Filter {
  col?: string;
  op?: string;
  val?: string[];
}

interface XAxisConfig {
  name: string;
  label: string;
  sort_ascending: boolean;
}

interface FormData {
  dimensions?: Array<{ id: string; name: string }>;
  x_axis?: XAxisConfig;
  show_legend?: boolean; // Changed to boolean
}

export const createBigNumberRequest = async (
  dataset: string,
  filters: Filter[],
  chartMetric: ChartMetric | null,
  formData: FormData,
  defaultRowLimit: number,
  timeGrain: string
) => {
  const chartRequest = {
    database: "zolix_c2o",
    schema: "public",
    table: dataset,
    visualization_name: "bignumber",
    name: "",
    description: "",
    "params": {
      "queries": [
        {
          "filters": filters.map(filter => ({
            col: filter.col,
            op: filter.op,
            val: filter.val ? filter.val.flat() : []
          })),
          "metrics": chartMetric ? [chartMetric] : [],
          "orderby": chartMetric ? [
            {
              "order_by": true,
              ...chartMetric
            }
          ] : [],
          "row_limit": defaultRowLimit,
          "series_columns": [],
          "series_limit": 0,
          "order_descending": true
      }
      ],
      "form_data": {
        "x_axis": formData.x_axis ? {
          name: formData.x_axis.name,
          label: formData.x_axis.label || "",
          sort_ascending: formData.x_axis.sort_ascending || false
        } : {},
        "time_grain":timeGrain ,
        "groupby": formData.dimensions?.map(dim => ({
          name: dim.name,
          label: dim.name
        })) || [],
        "query_mode": "",
        "show_legend": formData.show_legend, // Changed to boolean
        "show_data_zoom": '',
        "legend_orientation": '',
        "legend_type": ''
      }
    },
    "tags": [
      {
        "name": "",
        "value": ""
      }
    ],
    "group_id": 0,
    "group_name": "",
    "type": "Manual",
    "user_query": "",
    "user_ai_text": "",
    "created_by": "",
    "hashed_value": ""
  };

  console.log("Big Number API Request Body:", JSON.stringify(chartRequest, null, 2));

  const response = await axios.post('/api/charts/chart', chartRequest);
  console.log("Big Number API Response Body:", response.data);

  if (response.data.status === true && response.data.data) {
    return {
      chartType: 'big_number',
      chartData: response.data.data,
      chartRequest: chartRequest,

    };
  } else {
    throw new Error("Invalid response format for big number chart");
  }
};